zebra.controller('ResizeCtrl', ['$scope', '$rootScope', '$http', '$location', '$timeout', '$route', 'loginService', 'menuService', 'servicesUrl', '$window', function ($scope, $rootScope, $http, $location, $timeout, $route, loginService, menuService, servicesUrl, $window) {
    $scope.lastPath = '';
	var windowHeight = $(window).innerHeight(); // returns height of browser viewport
	$('.modelDiv').css("min-height", windowHeight + "px");
	$('#wrapper').css("min-height", windowHeight + "px");
	var reloadPartial = function () {
		$scope.userName = loginService.userName();
		$scope.userLoginStatus = loginService.getLoginStatus();
		
		if (angular.isDefined($route.current)) {
			//var renderEvent = $route.current.event;
			//$scope.activeTemp = $scope.template[renderEvent];
			
		}
		
	};

    $scope.getWidth = function() {
        return $(window).width();
    };

    $scope.getHeight = function() {
        return $(window).innerHeight();//$(window).height();
    };
    
    $scope.setContentHeight = function() {
        $timeout(function() {
        	
			var windowHeight = $(window).innerHeight(); // returns height of browser viewport
			
			$('.modelDiv').css("min-height", windowHeight + "px");
			$('#wrapper').css("min-height", windowHeight + "px");

			}, 0);
    };

    $scope.$watch($scope.getHeight, function(newValue, oldValue) {
    	$scope.setContentHeight();
    	//$scope.$apply();
    });
    window.onload = function(){
        $scope.$apply();
    }
    window.onresize = function(){
        $scope.$apply();
    }
    $scope.dynamicInterval;
      $scope.loadConfig = function () {
	        $http({
	            url: servicesUrl.getConfigUrl,
	            method: 'GET',
	            headers: {'Content-Type': 'application/json'}
	        }).success(function (response) {
	                loginService.setUserList(response.userList);
	                loginService.setTimeoutInterval(response.appTimeout);
	                $scope.dynamicInterval = response.appTimeout; 	                
	            })
	        .error(function (response, status) {
	        	$scope.msg = response.status.responseMessage;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
	        });
	    };
	    $scope.loadConfig();


	    $rootScope.$on('event:auth-loginConfirmed', function () {
	      if ($scope.lastPath != '') {
	        $location.path($scope.lastPath);
	      } else {
	         $location.path('/feed');
	      }
	      
	    });

	    $scope.$on('$routeChangeStart', function () {
	      if ($location.path() != '/' && $location.path() != '/login' && $location.path() != '/logout') {
	        $scope.lastPath = $location.path();
	      }
	    
	    });

	    $scope.$on('$routeChangeSuccess', function (event, next, current) {
	        if ((menuService.getUrlParts(1) === '')){
	          reloadPartial();
	          return;
        	}
	        if (!loginService.getLoginStatus()) {
				$location.search({});
				$location.path('/');
				reloadPartial();
				return;
	        } 
	        else {
				//Check added so that the logged in user will be redirected to the homepage if visiting the login page again
				if ($location.path() === '/login') {
					$location.path('/');
				}
				reloadPartial();
	        }
	        if (current && current.$route) {
	            if ($scope.tC.get(current.$route.templateUrl)) {
	                $scope.tC.remove(current.$route.templateUrl);
	            };
	        };
      	});

		$rootScope.$on('event:auth-logoutConfirmed', function () {
			$location.search({});
			$location.path('/');
			$location.lastPath = '';
			reloadPartial();
		});

		$window.onbeforeunload = function (e) {
	        if (loginService.getLoginStatus()) {
	       		loginService.userLogout();
	          //	return 'You will have to log in again.';
	        }
	      
    	};


}]);

zebra.controller('ModalController', ['$scope','commonFunctions','close','title', 'message', 'alertType', function($scope, commonFunctions, close, title, message, alertType) {
  $scope.message = message;
  $scope.modaltitle = title;
  $scope.alertType = alertType;
 
  $scope.close = function(result) {
  		close(result, 500); // close, but give 500ms for bootstrap to animate
  };

  }]);
