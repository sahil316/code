'use strict';
zebra.controller('cornerStoneCtrl', ['$scope', '$http', '$rootScope', '$location', '$timeout', '$cookieStore', '$log', 'menuService', 'loginService', 'servicesUrl', 'commonFunctions', function ($scope, $http, $rootScope, $location, $timeout, $cookieStore, $log, menuService,loginService,servicesUrl,commonFunctions) {
if (!loginService.getLoginStatus()) {
        $location.path('/');
        return;
    }
$scope.cStoneSelectedTrendFeed = {};
$scope.cStoneSelectedTrendFeed.id = "";
$scope.cStoneSelectedTrendFeed.feedName = "";

$scope.windowHeight = $(window).innerHeight() + 'px';

$scope.cStoneSelectedTrendColumn = {};
$scope.cStoneSelectedTrendColumn.id = "";
$scope.cStoneSelectedTrendColumn.columnName = "";

$scope.cStoneSelectedTrendColumnStat = {};
$scope.cStoneSelectedTrendColumnStat.id = "";
$scope.cStoneSelectedTrendColumnStat.columnName = "";

$scope.cStoneColumnList = {};
$scope.cStoneStatsList = [];

$scope.cStoneSelectedStats = {};
//$scope.cStoneSelectedStats.id = "";
$scope.cStoneSelectedStats.statName = "";

$scope.cStoneSelectedStatData= [];

$scope.trendPastRuns = commonFunctions.getPastRuns();

$scope.selectedPastRun = $scope.trendPastRuns[0].id;

$scope.selectedColumnPastRun = $scope.trendPastRuns[0].id;

$scope.cStoneSelectedColumnStatsPastRun = $scope.trendPastRuns[0].id;

$scope.noColumnGraph = true;
$scope.noCStoneColumnStatGraph = true;
$scope.hideGraph = false;
$scope.generateRuns = function(runs) {
    var category = [];
    for (var i = 1; i <= runs; i++) {
        category.push({"label": i.toString()});
    }
    return category;
};
var myjson = {
            "chart": {
                "caption": "Feed Name",
                "captionFontSize": "14",
                "subcaptionFontSize": "",
                "subcaptionFontBold": "0",
                "paletteColors": "#0b2e59,#7a237a,#979aa3,#058ea0,#17884a,#D52000,#FBD300,#5500C2,#F40000",
                "bgcolor": "#ffffff",
                /*"formatNumberScale":"0",*/
                "showBorder": "0",
                "showShadow": "0",
                "showCanvasBorder": "0",
                "usePlotGradientColor": "0",
                "legendBorderAlpha": "0",
                "legendIconScale":'2',
                "legendBgColor": "green",
                "legendShadow": "0",
                "showAxisLines": "0",
                "showAlternateHGridColor": "0",
                "divlineThickness": "1",
                "divLineIsDashed": "1",
                "divLineDashLen": "1",
                "divLineGapLen": "1",
                "xAxisName": "",
                "showValues": "0",
                "plottooltext": "<div class='tooltipHeaderDiv'>{br}$seriesName</div>{br}<div class='tooltipValueDiv'><b>$value</b></div>"
            },
            "categories": [
            ]
        };

var statsJSON = {
                    "chart": {
                    "caption": "Feed Name",
                    "captionFontSize": "14",
                    "subcaptionFontSize": "",
                    "subcaptionFontBold": "0",
                    "paletteColors": "#0b2e59,#7a237a,#979aa3,#058ea0,#17884a,#D52000,#FBD300,#5500C2,#F40000",
                    "bgcolor": "#ffffff",
                    "showBorder": "0",
                    "showShadow": "0",
                    "showCanvasBorder": "0",
                    "usePlotGradientColor": "0",
                    "legendBorderAlpha": "0",
                    "legendIconScale":'2',
                    "legendBgColor": "green",
                    "legendShadow": "0",
                    "showAxisLines": "0",
                    "showAlternateHGridColor": "0",
                    "divlineThickness": "1",
                    "divLineIsDashed": "1",
                    "divLineDashLen": "1",
                    "divLineGapLen": "1",
                    "xAxisName": "",
                    "showValues": "0",
                    "plottooltext": "<div class='tooltipHeaderDiv'>{br}$seriesName</div>{br}<div class='tooltipValueDiv'><b>$value</b></div>"
                    },
                    "categories": [
                        
                    ],
                    "dataset":[
                    ]
                };
$scope.loadCStoneFeedTrend = function (feedID,pastRun) {
    $http({
          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.loadCSFeedGraphUrl+'/'+feedID+'/'+pastRun,
          method: 'GET',
         // data: $scope.feed_requestObj,
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                if (angular.isDefined(response.dataset) && response.dataset != '') {
                    myjson.dataset = response.dataset;
                }
                else {
                    myjson.dataset = [];
                }
                if (angular.isDefined(response.columnList) && response.columnList != '') {
                	 $scope.cStoneColumnList = response.columnList;
                	/* $scope.cStoneSelectedTrendColumnStat = $scope.cStoneColumnList[0];
                     $scope.cStoneSelectedTrendColumnStat.id = $scope.cStoneSelectedTrendColumnStat.columnID;
                     $scope.cStoneSelectedTrendColumnStat.columnName = $scope.cStoneSelectedTrendColumnStat.columnName;*/
                }
               
                $scope.hideGraph = false;
                $scope.finalCategory = {};
                myjson.categories = [];               
                $scope.category = $scope.generateRuns($scope.selectedPastRun);
                $scope.finalCategory = {"category": $scope.category};
                myjson.categories.push($scope.finalCategory);
                FusionCharts.ready(function () {
                    var visitChart = new FusionCharts({
                        type: 'msline',
                        renderAt: 'chart-container',
                        width: '800',
                        height: '350',
                        dataFormat: 'json',
                        dataSource: myjson,
                    }).render();
                });
            }
            else {
               
                $scope.msg = response.status.responseMessage;
                $scope.hideGraph = true;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            }
            
        })
        .error( function(response) {
            $scope.hideGraph = true;
            $scope.msg = response.status.responseMessage;
            
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
           
        });
};


$scope.loadCStoneColumnStatsTrend = function (feedID,columnID,pastRuns,type) {
    $http({
          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.loadCStoneColumnStatsGraphUrl+'/'+feedID+'/'+columnID+'/'+pastRuns,
          //url: servicesUrl.loadCStoneColumnStatsGraphUrl,
          method: 'GET',
          //data: $scope.stats_requestObj,
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                $scope.finalCategory = {};
                statsJSON.categories = [];
                if (angular.isDefined(response.dataset) && response.dataset != '') {
                     commonFunctions.setCStoneColumnStatDataSet(response.dataset);
                     $scope.cStoneStatsList= response.dataset;
                }
                else {
                    commonFunctions.setCStoneColumnStatDataSet('');
                }
               /* angular.forEach(response.dataset, function(data){                    
                    	$scope.cStoneStatsList.push(data.seriesname);
                });*/
                $scope.category = $scope.generateRuns($scope.cStoneSelectedColumnStatsPastRun);
                $scope.finalCategory = {"category": $scope.category};
                statsJSON.categories.push($scope.finalCategory);
                
            }
            else {
                $scope.msg = response.status.responseMessage;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
                commonFunctions.setCStoneColumnStatDataSet('');
            }
            
        })
        .error( function(response) {
            $scope.msg = response.status.responseMessage;
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
        })
        .then (function() {
        	 if (type === 'past') {
                 $scope.loadCStoneColumnStatsGraph(); 
             }
                //$scope.loadCStoneColumnStatsGraph(); 
            
        });     
};

$scope.loadCStoneColumnStatsGraph = function () {
   // var dataSetJson = commonFunctions.getCStoneColumnStatDataSet();
	var cStoneSelectedStatData =[];
	var cStoneSelStatDataList = commonFunctions.getCStoneColumnStatDataSet();
	var count = 0;
    angular.forEach(cStoneSelStatDataList, function (key, val) {
    if (key.seriesname === $scope.cStoneSelectedStats.statName) {
    	cStoneSelectedStatData.push(cStoneSelStatDataList[count]);
    }   
    count++ ;
     });
    
    statsJSON.dataset = cStoneSelectedStatData;
    FusionCharts.ready(function () {
        var visitChart = new FusionCharts({
            type: 'msline',
            renderAt: 'chart-container3',
            width: '800',
            height: '350',
            dataFormat: 'json',
            dataSource: statsJSON,
        }).render();
    })
};

/*Get the feed list on page load */
$scope.getCSTrendFeedList = function() {
   // if (commonFunctions.getFeedList().length === 0) {
        $http({
          //To Do  - Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.getCSFeedListUrl,
          method: 'GET',
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                if (response.result.feedList !== null) {
                    $scope.cStoneFeedList = response.result.feedList;
                    $scope.cStoneSelectedFeed = $scope.cStoneFeedList[0];
                    $scope.cStoneSelectedTrendFeed.id = $scope.cStoneSelectedFeed.storage_ID;
                    $scope.cStoneSelectedTrendFeed.feedName = $scope.cStoneSelectedFeed.table_name;
                    myjson.chart.caption =  $scope.cStoneSelectedTrendFeed.tableName;

                    /* Saved the feed column and rule list for future use */
                    commonFunctions.setCStoneFeedList($scope.cStoneFeedList);
                
                    $scope.cStoneSelectedTrendColumn = {};
                    $scope.cStoneSelectedTrendColumn.id = "";
                    $scope.cStoneSelectedTrendColumn.columnName = "";
                  
                    
                    $scope.cStoneSelectedTrendColumnStat = {};
                    $scope.cStoneSelectedTrendColumnStat.id = "";
                    $scope.cStoneSelectedTrendColumnStat.columnName = "";
                    
                }
                else {
                    $scope.cStoneFeedList = "";
                }

            }
            else {
                $scope.msg = response.status.responseMessage;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            }
            $scope.queryInProgress = false;
          })
          .error(function (response) {
            $scope.msg = response.status.responseMessage;
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            $scope.queryInProgress = false;
          })
          .then(function () {
           /* $scope.feed_requestObj = {
                "storage_ID": $scope.cStoneSelectedTrendFeed.id,
                "pastRuns": $scope.selectedPastRun,
                "requestChart": "trend"
            };*/

            $scope.loadColumnFeed($scope.cStoneSelectedTrendFeed.id);
            $scope.loadCStoneFeedTrend($scope.cStoneSelectedTrendFeed.id,$scope.selectedPastRun);
           
          });
   // }
    /*else {
        $scope.feedList = commonFunctions.getFeedList();
        $scope.selectedFeed = $scope.feedList[0];
        $scope.selectedTrendFeed.id = $scope.selectedFeed.feedID;
        $scope.selectedTrendFeed.feedName = $scope.selectedFeed.feedName;
        myjson.chart.caption =  $scope.selectedTrendFeed.feedName;
        $scope.feed_requestObj = {
                "feedID": $scope.selectedTrendFeed.id,
                "pastRuns": $scope.selectedPastRun,
                "requestChart": "trend"
            };       
        $scope.loadColumnFeed($scope.selectedTrendFeed.id);
        $scope.loadFeedTrend();
    }*/
};


$scope.loadColumnFeed = function (feedID) {
    $scope.columnList = commonFunctions.getColumnList(feedID);
    //$scope.columnList = commonFunctions.getColumnList(feedID);
};
$scope.loadColumnStats = function (feedID, columnID) {
    $scope.statsList = commonFunctions.getStatsList(feedID, columnID);
};
$scope.selectionChangedTrend = function () {
    angular.forEach($scope.cStoneFeedList, function (key, val) {
        if (key.storage_ID === $scope.cStoneSelectedTrendFeed.id) {
            $scope.cStoneSelectedTrendFeed.feedName = key.table_name;
        }           
    });
    myjson.chart.caption =  $scope.cStoneSelectedTrendFeed.feedName;
   // $scope.loadColumnFeed($scope.selectedTrendFeed.id);
   // $scope.loadColumnFeed($scope.selectedTrendFeed.id);
   
/*    $scope.feed_requestObj = {
        "feedID": $scope.cStoneSelectedTrendFeed.id,
        "pastRuns": $scope.selectedPastRun,
        "requestChart": "trend"
    };*/
    $scope.noColumnGraph = true;
    $scope.loadCStoneFeedTrend($scope.cStoneSelectedTrendFeed.id,$scope.selectedPastRun);
};


/*for stats graph */

$scope.cStoneColumnStatsSelChangedTrend = function (type) {
   if ($scope.cStoneSelectedTrendColumnStat.id == null || $scope.cStoneSelectedTrendColumnStat.id == '') {
        $scope.noCStoneColumnStatGraph = true;
        $scope.cStoneSelectedStats = {};
       // $scope.cStoneSelectedStats.id = "";
        $scope.cStoneSelectedStats.name = "";
        $scope.cStoneSelectedColumnStatsPastRun = "10";
    }
    else {
        angular.forEach($scope.columnList, function (key, val) {
        if (key.columnID === $scope.cStoneSelectedTrendColumnStat.id) {
            $scope.cStoneSelectedTrendColumnStat.columnName = key.columnName;
        }           
         });
   
        /*$scope.stats_requestObj = {
            "feedID": $scope.selectedTrendFeed.id,
            "columnID": $scope.selectedTrendColumnStat.id,
            "pastRuns": $scope.selectedColumnStatsPastRun,
            "requestChart": "trend"
        };*/
        if (type == 'column') {
        	  $scope.cStoneSelectedStats = {};
              $scope.cStoneSelectedStats.id = "";
              $scope.cStoneSelectedStats.name = "";
              $scope.selectedColumnStatsPastRun = "10";
        }
       // $scope.loadCStoneColumnStatsTrend($scope.cStoneSelectedTrendFeed.id, $scope.cStoneSelectedTrendColumnStat.id, $scope.selectedColumnStatsPastRun);
        if ($scope.cStoneSelectedTrendColumnStat.id) {
            if ($scope.cStoneSelectedStats.statName) {
               $scope.noCStoneColumnStatGraph = false;
           }
           else {
               $scope.noCStoneColumnStatGraph = true;
           }
          
           $("body").animate({scrollTop: $('.trending_column_stats').offset().top - 300}, 1200);   
           $scope.loadCStoneColumnStatsTrend($scope.cStoneSelectedTrendFeed.id, $scope.cStoneSelectedTrendColumnStat.id, $scope.cStoneSelectedColumnStatsPastRun,type);
           //$scope.loadColumnStatsGraph(); 
       }
       else {
           $scope.noCStoneColumnStatGraph = true;
       }
      }
};
$scope.cStoneStatSelectionChangedTrend = function (type) {

  /*  $scope.stats_requestObj = {
        "feedID": $scope.selectedTrendFeed.id,
        "columnID": $scope.selectedTrendColumnStat.id,
        "pastRuns": $scope.selectedColumnStatsPastRun,
        "requestChart": "trend"
    };*/
    if ($scope.cStoneSelectedTrendColumnStat.id && $scope.cStoneSelectedStats.statName) {
        $scope.noCStoneColumnStatGraph = false;
        $("body").animate({scrollTop: $('.trending_column_stats').offset().top - 100}, 1200);  
        $scope.loadCStoneColumnStatsGraph();  
    }
    else {
        $scope.noCStoneColumnStatGraph = true;
    }
    
};

$scope.showEditRequestPage = function (id, type) {
    if (type === 'feed') {
        commonFunctions.setFeedID(id);
        commonFunctions.setFeedName($scope.selectedTrendFeed.feedName);
        // Redirect to Request page for editing
        $location.url('/feed?mode=edit');
    }
    else if (type === 'column') {
        commonFunctions.setReqColumnId(id);
        commonFunctions.setReqFeedID($scope.selectedTrendFeed.id);
        commonFunctions.setReqFeedName($scope.selectedTrendFeed.feedName);
       // console.log(angular.toJson($scope.selectedTrendFeed));
        // Redirect to Request page for editing
        $location.url('/column');
    }
};

/*Call feed list on load */
$scope.getCSTrendFeedList();

}]);
