'use strict';

zebra.controller('LoginFormCtrl', ['$scope', 'loginService','servicesUrl','menuService', '$rootScope','$route','$http','$timeout','$location',
        function ($scope, loginService, servicesUrl, menuService, $rootScope, $route, $http, $timeout, $location) {
		$scope.error = '';
  		$scope.windowHeight = $(window).innerHeight() + 'px';
		
		$scope.submitLogin = function () {
			if (angular.isDefined($scope.login.username) && $scope.login.username.length && angular.isDefined($scope.login.password) && $scope.login.password.length) {
				$scope.data = angular.toJson($scope.login, true);
				$scope.loginStatus = loginService.userLogin($scope.data);
				$scope.error = 'Authenticating...';
			}
            else if (((angular.isDefined($scope.login.username) && !$scope.login.username.length) || angular.isUndefined($scope.login.username))  && angular.isDefined($scope.login.password) && $scope.login.password.length) {
                $scope.error = 'Please provide a valid username';
            }
            else if (((angular.isDefined($scope.login.password) && !$scope.login.password.length) || angular.isUndefined($scope.login.password))  && angular.isDefined($scope.login.username) && $scope.login.username.length) {
                $scope.error = 'Please provide a valid password';
            }
            else {
				$scope.error = 'Please provide username and password';
			}
		};


		$scope.userLogout = function () {
		    loginService.userLogout();
		};
	    $scope.userLoginUrl = function () {
			$location.search({});
			$location.path('/');
			reloadPartial();
			return;
	    };



		$rootScope.$on('event:auth-loginFailed', function () {
			$scope.error = 'Invalid username or password.';
		});

		$rootScope.$on('event:auth-loginServiceError', function () {
			$scope.error = 'Login failed.Try again';
		});

		$rootScope.$on('event:auth-invalidUser', function () {
			$scope.error = '';
			$scope.login.username = '';
			$scope.login.password = '';
		});
	
}]);
