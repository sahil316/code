'use strict';
zebra.controller('feedCtrl', ['$scope', '$rootScope', '$http', '$filter', '$location', '$timeout', '$cookieStore', '$log', 'servicesUrl', 'loginService', 'menuService', 'commonFunctions', 'ModalService', function ($scope, $rootScope, $http, $filter, $location, $timeout, $cookieStore, $log, servicesUrl, loginService, menuService, commonFunctions, ModalService) {
	if (!loginService.getLoginStatus()) {
	  $location.path('/');
	    return;
  	}
  	$('.clockpicker').clockpicker({
	    placement: 'top',
	    align: 'left',
	    donetext: 'Done',
	    'default': Date.now()
	});
	var date = new Date();
  	// datepicker call
   	$('#startDate').datepicker();  
	$('#endDate').datepicker("setDate", new Date('12/31/2031'));
  	$scope.windowHeight = $(window).innerHeight() + 'px';
  	$scope.hasError = false;
  	$scope.fileformatError = false;
  	$scope.fileFormatFixed = true;
  	$scope.thresholdActive = true;
  	$scope.thresholdPattern = new RegExp();
  	$scope.thresholdType = '';
  	$scope.feedUpdate = false;
	$scope.fileTrailer = 0;
	$scope.fileHeader = 0;
	$scope.disablePastRuns = false;
  	var date = new Date();
  	$scope.endDate = $filter('date')(new Date('12/31/2031'), 'MM/dd/yyyy');  	
    $scope.startDate = $filter('date')(new Date(), 'MM/dd/yyyy');
    $scope.path = $location.absUrl().split('?')[1];
  	$scope.fileFormatDelimiterList = commonFunctions.getFileDelimiter();
  	$scope.recordFormatDelimiterList = commonFunctions.getRecordDelimiter();

  	/*start ticket Robo*/
  	$scope.ticketRobo='';
  	/*end ticket Robo*/
  	
  	$scope.noEdit = false;
  	$scope.weekDays = commonFunctions.getWeekDays();
  	$scope.monthQuarterList = ["1", "2", "3"];
  	$scope.dateOfMonth = commonFunctions.getDateOfMonth();
  	$scope.regexTime = new RegExp('^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$');
  	if (angular.isDefined(commonFunctions.getFeedID()) && commonFunctions.getFeedID() !== 0 && angular.isDefined($scope.path) && $scope.path === 'mode=edit') {
  		$scope.feedUpdate = true;
  		 $scope.reqFeedId = commonFunctions.getFeedID();
                $http.get(servicesUrl.getFeedEditUrl + '?feedID=' + $scope.reqFeedId + '&timeStamp=' + Date.now())
                  .success(function (data) {
                  	if (data.status.responseCode == 200) {
                  		$scope.feedName = data.result.feed_name;
						$scope.feedFrequency = data.result.feed_frequency;
						$scope.fileFormat = data.result.file_format;
						$scope.fileTrailer = (data.result.fileTrailer == "true") ? 1 : 0;
						$scope.fileHeader = (data.result.fileHeader == "true") ? 1 : 0;
						if (data.result.file_format == 'DELIMITER') {
							$scope.fileFormatFixed = false;
							angular.forEach($scope.fileFormatDelimiterList, function(val) {
								if (val.value === data.result.file_format_delimited) {
									$scope.fileFormatDelimited = val;
								}
							});
						}
						angular.forEach($scope.recordFormatDelimiterList, function(val) {
							if (val.value === data.result.record_delimiter) {
								$scope.recordDelimiter = val;
							}
						});
						$scope.sla = data.result.sla;						
						if ($scope.sla == '1') {
							
							$scope.timeSelected = data.result.sla_time;
							if ($scope.feedFrequency.toLowerCase() === 'daily') {
								$scope.skipDay = data.result.skipDay;
							}
							else if ($scope.feedFrequency.toLowerCase() === 'weekly') {
								$scope.weekDay = data.result.weekDay;
							}
							else if ($scope.feedFrequency.toLowerCase() === 'monthly') {
								$scope.monthDate = data.result.monthDate;
							}
							else if ($scope.feedFrequency.toLowerCase() === 'intraday') {
								$scope.timeElapsed = data.result.sla_time_elapsed;
							}						
							else {
								$scope.monthQuarterDate = data.result.monthDate;
								$scope.monthQuarter = data.result.monthQuarter;
							}
						}
						else {
							$scope.sla = 0;
						}
						$scope.ticketRobo = data.result.ticketRobo;						
						if ($scope.ticketRobo == '1') {
							
							$scope.rGrp = data.result.rGrp;
							$scope.aGrp = data.result.aGrp;							
						}
						else {
							$scope.ticketRobo = 0;
						}			
						if (data.result.threshold_type !== '') {
							$scope.thresholdType = data.result.threshold_type;
							$scope.thresholdActive = false;
							$scope.alertMinThres = data.result.alert_threshold_min;
							$scope.alertMaxThres = data.result.alert_threshold_max;
							$scope.abortMinThres = data.result.abort_threshold_min;
							$scope.abortMaxThres = data.result.abort_threshold_max;
						}
						
						$scope.pastRuns = data.result.past_runs;
						//$scope.startDate = data.result.start_date;
						//$scope.endDate = data.result.end_date;
						$('#startDate').datepicker("setDate", new Date(data.result.start_date));
						$('#endDate').datepicker("setDate", new Date(data.result.end_date));
						$scope.userEmail = data.result.email_id.split(",");
						
						if (new Date($scope.endDate).getTime() < Date.now()) {
							$scope.noEdit = true;
						}
						else {
							$scope.noEdit = false;
						}
                  	}
                  })
                  .error (function (response) {

                  });
  	}

  	$scope.slaReset = function() {
		$scope.sla = '';
		$scope.slaFrequency = '';
		$scope.timeSelected = '';
		$scope.timeElapsed = '';
		$scope.skipDay = '';
		$scope.weekDay = '';
		$scope.monthDate = '';
		$scope.monthQuarter = '';
	};
  	$scope.thresholdTypeSelection = function(type) {
  		$scope.thresholdActive = false;
  		$scope.abortMaxThres = '';
  		$scope.alertMaxThres = '';
  		$scope.abortMinThres = '';
  		$scope.alertMinThres = '';
  		if (type == 'Absolute') {
  			$scope.thresholdPattern = new RegExp('^\\d*$');
  			$scope.disablePastRuns = true;
  			$scope.pastRuns = "0";
  			$scope.pastRunsError = false;
  		}
  		else if (type == 'Percentage') {
  			$scope.thresholdPattern = new RegExp('^-?(?:\\d{1,2}(?:[.]\\d{1,2})?|100(?:[.]0{1,2})?)$');//'/^-?(?:\d{1,3}(?:[.]\d{1,2})?|1000(?:[.]0{1,2})?)$/';
  			$scope.disablePastRuns = false;
  		}
  		else {
  			$scope.thresholdPattern = new RegExp('^-?(?:\\d{1,2}(?:[.]\\d{1,2})?|100(?:[.]0{1,2})?)$');
  			$scope.disablePastRuns = false;
  		}
  	};
	$scope.checkFileFormat = function () {
		var validEmails = 1;
		$scope.invalidEmail = false;
		if ($scope.fileFormat === 'DELIMITER' && ($scope.fileFormatDelimited === '' || angular.isUndefined($scope.fileFormatDelimited))) {
			$scope.fileformatError = true;
		}
		else {
			$scope.fileformatError = false;
		}
		if ($scope.thresholdType !== 'Absolute' && ($scope.pastRuns == '' || angular.isUndefined($scope.pastRuns))) {
			$scope.pastRunsError = true;
		}
		else {
			$scope.pastRunsError = false;
		}

		if (angular.isUndefined($scope.userEmail) || $scope.userEmail === null) {
			$scope.invalidEmail = true;
		}
		else {
			angular.forEach($scope.userEmail, function (value) {
			  if (!value.match(/^\w+([\+\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
			    validEmails = 0;
			  }
			});
			if (validEmails === 0) {
			  $scope.invalidEmail = true;
			}
		}

	};
	
	$scope.feedMetadataSubmit = function () {
		$scope.checkFileFormat();
		if($scope.feedForm.$valid) {
			if (($scope.alertMinThres === '' || angular.isUndefined($scope.alertMinThres)) && ($scope.alertMaxThres === '' || angular.isUndefined($scope.alertMaxThres)) && ($scope.abortMinThres === '' || angular.isUndefined($scope.abortMinThres)) && ($scope.abortMaxThres || angular.isUndefined($scope.abortMaxThres))) {
				var mesg = "Are you sure to proceed without any min & max threshold values defined?";
				$scope.showWarning(mesg, 'Warning!', true);	
			}		
			else {
				$scope.feedSubmit();
			}		
		}
		else {
			$scope.hasError = true;
		}
	};

  	$scope.feedSubmit = function () {
  			$scope.checkFileFormat();
			if($scope.feedForm.$valid && !$scope.invalidEmail && !$scope.abortMinError && !$scope.abortMaxError && !$scope.alertMinError && !$scope.alertMaxError) {
				$scope.hasError = false;
				if ($scope.fileFormatDelimited == '' || angular.isUndefined($scope.fileFormatDelimited)) {
					$scope.fileFormatDelimitedval = '';
				}
				else {
					$scope.fileFormatDelimitedVal = $scope.fileFormatDelimited.value;
				}
				var feed_data = {};
				feed_data.feed_name = $scope.feedName;
					feed_data.feed_frequency = $scope.feedFrequency;
					feed_data.sla = $scope.sla;
					if ($scope.sla == '1') {
						
						feed_data.sla_time = $scope.timeSelected;
						if ($scope.feedFrequency.toLowerCase() === 'daily') {
							feed_data.skipDay = $scope.skipDay;
						}
						else if ($scope.feedFrequency.toLowerCase() === 'weekly') {
							feed_data.weekDay = $scope.weekDay;
						}
						else if ($scope.feedFrequency.toLowerCase() === 'monthly') {
							feed_data.monthDate = $scope.monthDate;//.toString();
						}
						else if ($scope.feedFrequency.toLowerCase() === 'intraday') {
							feed_data.sla_time_elapsed = $scope.timeElapsed;
						}						
						else {
							feed_data.monthDate = $scope.monthQuarterDate;//.toString();
							feed_data.monthQuarter = $scope.monthQuarter;
						}
					}
					feed_data.ticketRobo = $scope.ticketRobo;
					if ($scope.ticketRobo == '1') {
						feed_data.rGrp = $scope.rGrp;
						feed_data.aGrp = $scope.aGrp;
					}					
				feed_data.file_format = $scope.fileFormat;				
				feed_data.file_format_delimited = $scope.fileFormatDelimitedVal;
				feed_data.record_delimiter = $scope.recordDelimiter.value;
				feed_data.fileTrailer = $scope.fileTrailer;
				feed_data.fileHeader = $scope.fileHeader;
				feed_data.threshold_type = $scope.thresholdType;
				feed_data.alert_threshold_min = $scope.alertMinThres;
				feed_data.alert_threshold_max = $scope.alertMaxThres;
				feed_data.abort_threshold_min = $scope.abortMinThres;
				feed_data.abort_threshold_max = $scope.abortMaxThres;
				feed_data.past_runs = $scope.pastRuns;
				feed_data.start_date = $scope.startDate;
				feed_data.end_date = $scope.endDate;
				feed_data.email_id = $scope.userEmail.toString();
				feed_data.user_id =  loginService.userName();
				if ($scope.reqFeedId != '' && angular.isDefined($scope.path) && $scope.path === 'mode=edit') {
		 				feed_data.feed_Id = $scope.reqFeedId;
		 				$scope.url = servicesUrl.updateFeedMetadataUrl;
		 				$scope.msg = $scope.feedName + " with ID - " + $scope.reqFeedId + " is updated successfully";
		 				$scope.modalTitle = "Updated";
		 			}
		 			else {
		 				$scope.url = servicesUrl.submitFeedMetadataUrl;
		 				$scope.msg = '';
		 			}
				$http({
			          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
			          url: $scope.url,
			          method: 'POST',
			          data: angular.toJson(feed_data),
			          headers: {'Content-Type': 'application/json'}
			    }).success(function (response) {
			    	 if (response.status.responseCode == 200) {
		              	if (response.status.feedID != null) {
		              		commonFunctions.setFeedID(response.status.feedID);
			    			commonFunctions.setFeedName(response.status.feedName);
				    		commonFunctions.setFileFormat(response.status.fileFormat);
			    			commonFunctions.setUserID(response.status.userID);
			    			commonFunctions.setStartDate(response.status.startDate);
			    			commonFunctions.setEndDate(response.status.endDate);
			    			if ($scope.msg != '') {
			    				var successMessage = $scope.msg;
			    			}
			    			else {
			    				var successMessage = response.status.feedName + " with ID - " + response.status.feedID + " is submitted Successfully";
			    				$scope.modalTitle = "Submitted";
			    			}
			    			
							$scope.showModal(successMessage, $scope.modalTitle, false);
						

		         		}
		              	else {
		               		$scope.msg = response.status.responseMessage;
							commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
		              	}
		              	$scope.queryInProgress = true;
		            }
		            else {
		             
		            	$scope.msg = response.status.responseMessage;
						commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
		            }
		            $scope.queryInProgress = false;
			    })
			    .error (function (response) {
					$scope.msg = response.status.responseMessage;
					commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
					$scope.queryInProgress = false;
			    });
			}
			else {
				$scope.hasError = true;
			}
		};

  	$('.datepicker').datepicker();
    $scope.showModal = function(message, title, type) {
        ModalService.showModal({
		    templateUrl: 'modal.html',
		    controller: "ModalController",
				inputs: {
		        title: title,
		        message: message,
		        alertType: type       
		    }
		}).then(function(modal) {
		    modal.element.modal();
		     modal.close.then(function(result) {

		     	if (title === 'Updated') {
					$scope.resetFields();
					commonFunctions.setFeedID('');
					commonFunctions.setFileFormat('');
					commonFunctions.setReqFeedID('');
					commonFunctions.setFeedName('');
					commonFunctions.setReqFeedName('');
					//$location.path('/feed');
					$location.url('/feed');
				}
				else {
					commonFunctions.setReqFeedID('');
					commonFunctions.setReqFeedName('');
					$location.url('/column');
				}
		     	
		    	
		    });
		});
    };
     $scope.showWarning = function(message, title, type) {
        ModalService.showModal({
		    templateUrl: 'modal.html',
		    controller: "ModalController",
				inputs: {
		        title: title,
		        message: message,
		        alertType: type        
		    }
		}).then(function(modal) {
		    modal.element.modal();
		     modal.close.then(function(result) {
		     	if (result === 'Yes')
		    		$scope.feedSubmit();
		    });
		});
    };
    $scope.resetFields = function() {
    	$scope.feedName = '';
    	$scope.feedID = '';
    	commonFunctions.setFeedID('');
		commonFunctions.setFileFormat('');
		$scope.feedFrequency = '';
		$scope.fileFormat = '';
		$scope.fileFormatDelimited = '';
		$scope.recordDelimiter.value = '';
		$scope.recordDelimiter.id = '';
		$scope.thresholdType = '';
		$scope.alertMinThres = '';
		$scope.alertMaxThres = '';
		$scope.abortMinThres = '';
		$scope.abortMaxThres = '';
		$scope.pastRuns = '';
		$scope.startDate = '';
		$scope.endDate = '';
		$scope.userEmail = '';
		$scope.feedUpdate = false;
		$scope.pastRunsError = false;
		$scope.fileTrailer = 0;
		$scope.fileHeader = 0;
		$scope.slaReset();
    };
    $scope.cancel = function () {
    	$scope.resetFields();
    	$location.url('/feed');
    };
}]);
