'use strict';

/**
 * Login controller
 * @param  {object} $scope             	[oject for model]
 * @param  {object} $location          	[description]
 * @param  {[type]} $timeout           	[description]
 * @param  {[type]} $cookieStore       	[description]
 * @param  {[type]} $log               	[description]
 */
zebra.controller('HomeCtrl', ['$scope', '$rootScope', '$location', '$timeout', '$http', '$cookieStore', '$log', 'menuService', 'loginService','commonFunctions','ModalService', 'servicesUrl', function ($scope, $rootScope, $location, $timeout, $http, $cookieStore, $log, menuService, loginService, commonFunctions, ModalService, servicesUrl) {
	$scope.checkSession = false;
	if (!loginService.getLoginStatus()) {
    $location.path('/');
    $scope.checkSession = false;
    return;
  }else{
    $scope.checkSession = true;
  }
  $scope.windowHeight = $(window).innerHeight() + 'px';
  $scope.oneAtATime = true;
  $scope.status = {
    isFirstOpen: true,
    isFirstDisabled: false
  };

  $scope.showModal = function(title, type) {
      //if (commonFunctions.getFeedList().length === 0) {
        $http({
            //To Do : Add Timestamp URL parameter to fix IE service call cache issue
            url: servicesUrl.getFeedListUrl,
            method: 'GET',
            headers: {'Content-Type': 'application/json'}
          }).success(function (response) {

              if (response.status.responseCode == 200) {
                  if (response.result.feedList !== null) {
                    $scope.feedList = response.result.feedList;
                    commonFunctions.setFeedList($scope.feedList);
                  }
                  else {
                    $scope.feedList = "";
                  }

              }
              else {
                $scope.msg = response.status.responseMessage;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 

              }
              $scope.queryInProgress = false;
            })
            .error(function (response) {
              $scope.msg = response.status.responseMessage;
              commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
              $scope.queryInProgress = false;
            })
            .then(function () {
              if (commonFunctions.getFeedList().length != 0) {
                ModalService.showModal({
                  templateUrl: 'partials/modeler/modalEdit.html',
                  controller: "ModalEditController",
                  inputs: {
                    title: title,
                    entityType: type        
                  }
                }).then(function(modal) {
                  modal.element.modal();
                  modal.close.then(function(result) {
                  if (result !== 'Yes' && result !== 'No') {
                    if (type === 'feed') {
                      commonFunctions.setFeedID(result.split("_")[1]); 
                      if ($location.absUrl().split('?')[1] == 'mode=edit') {
                        $location.url('/feed');
                        $timeout(function(){
                          $location.url('/feed?mode=edit');
                        }, 100)
                      }
                      else {
                        $location.url('/feed?mode=edit');
                      }
                      
                    }
                    else {
                      commonFunctions.setReqFeedID(result.split("_")[1]);   
                      commonFunctions.setReqColumnId(result.split("_")[2]);
                      if ($location.path() === '/column') {
                        $location.url('/column');
                        $location.hash('edit'+Date.now());
                      }
                      else {
                         $location.url('/column');
                      }
                      
                    }
                  }
                  });
                });
              }
            });
      //}
      /*else {
         ModalService.showModal({
                templateUrl: 'partials/modeler/modalEdit.html',
                controller: "ModalEditController",
                inputs: {
                  title: title,
                  entityType: type        
                }
              }).then(function(modal) {
                modal.element.modal();
                modal.close.then(function(result) {
                if (result !== 'Yes' && result !== 'No') {
                  
                  if (type === 'feed') {   
                    //commonFunctions.setReqFeedID(result.split("_")[1]); 
                    commonFunctions.setFeedID(result.split("_")[1]); 
                    if ($location.absUrl().split('?')[1] == 'mode=edit') {
                      $location.url('/feed');
                      $timeout(function(){
                        $location.url('/feed?mode=edit');
                      }, 100)
                    }
                    else {
                      $location.url('/feed?mode=edit');
                    }
                    
                  }
                  else {
                    commonFunctions.setReqFeedID(result.split("_")[1]);   
                    commonFunctions.setReqColumnId(result.split("_")[2]);
                    $location.url('/column');
                  }
                }
                });
              });
      }*/
    };

    $scope.userLogout = function () {
        loginService.userLogout();
    };
  
	$scope.reverse = function(array) {
		var copy = [].concat(array);
		return copy.reverse();
	}
	
	var reloadMenu = function () {
      $scope.activeItem = menuService.getUrlParts(1);

  

      menuService.setMainMenu($scope.menuItems);
      menuService.setActiveItem($scope.activeItem);

      if ($scope.activeItem === '') {
        menuService.setActiveItem('feed');
      }
    };

    $scope.activeItem = 'feed';

    $scope.menuItems = [
     
      {
        "class": 'feed',
        "href": 'feed',
        "key": 'feed',
        "title": 'Feed Metadata',
        "weight": 2
      },
      {
        "class": 'column',
        "href": 'column',
        "key": 'column',
        "title": 'Column Metadata',
        "weight": 3
      },
      {
        "class": 'report',
        "href": 'report',
        "key": 'report',
        "title": 'Report',
        "weight": 4
      },
      {
        "class": 'trending',
        "href": 'trending',
        "key": 'trending',
        "title": 'Trending',
        "weight": 5
      },
      {
        "class": 'cornerstone',
        "href": 'cornerstone',
        "key": 'cornerstone',
        "title": 'Cornerstone Feeds',
        "weight": 6
      }
    ];
    $rootScope.$on('$routeChangeSuccess', function () {
      reloadMenu();
    });
    $scope.$on('event:auth-loginConfirmed', function () {
      reloadMenu();
    });
    reloadMenu();

	
}]);


zebra.controller('ModalEditController', ['$scope','commonFunctions','close','title', 'entityType', function($scope, commonFunctions, close, title, entityType) {
 
  $scope.modaltitle = title;
  $scope.entityType = entityType;
  $scope.feedList = $scope.columnList = [];
  if (commonFunctions.getFeedList().length != 0)
    $scope.feedList = commonFunctions.getFeedList();
 

  $scope.close = function(result) {
    if (angular.isDefined($scope.enteredFeed) && $scope.enteredFeed != '' && result === 'Yes') {
      if (angular.isDefined($scope.enteredColumn) && $scope.enteredColumn != '') {
          close(result + '_' + commonFunctions.getFeedID() + '_' + commonFunctions.getReqColumnId(), 500); // close, but give 500ms for bootstrap to animate
      }
      else {
        close(result + '_' + commonFunctions.getFeedID(), 500); // close, but give 500ms for bootstrap to animate
      }
      
    }

    else {
      close(result, 500); // close, but give 500ms for bootstrap to animate
    }
    
  };
  $scope.list = function (item) {
    commonFunctions.setFeedID(item.feedID);
    commonFunctions.setReqFeedID(item.feedID);
     $scope.columnList = commonFunctions.getColumnList(item.feedID);
  };
  $scope.listColumn = function(item) {
    commonFunctions.setReqColumnId(item.columnID);
  };
  }]);

