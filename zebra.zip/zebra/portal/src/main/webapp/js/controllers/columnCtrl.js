'use strict';
zebra.controller('columnCtrl', ['$scope', '$rootScope', '$http', '$location', '$anchorScroll', '$timeout', '$cookieStore', '$log', 'servicesUrl', 'loginService', 'menuService', 'commonFunctions', 'ModalService', 'Upload','FileUploader', function ($scope, $rootScope, $http, $location, $anchorScroll, $timeout, $cookieStore, $log, servicesUrl, loginService, menuService,commonFunctions, ModalService, Upload, FileUploader) {

	if (!loginService.getLoginStatus()) { 
	   $location.path('/');
	    return;
  	}
   	$scope.windowHeight = $(window).innerHeight() + 'px';
  	$scope.column_ID = '';
	$scope.columnUpload = false;
  	$scope.hasError = false;
  	$scope.submitButtomEnabled = false;
	if (commonFunctions.getReqFeedID() != '' && angular.isDefined(commonFunctions.getReqFeedID())) {
		$scope.feedName = commonFunctions.getReqFeedName();
		$scope.feedID = commonFunctions.getReqFeedID();
		$scope.fileFormat = commonFunctions.getFileFormat();
		$scope.fileFeedId = commonFunctions.getReqFeedID();
		$scope.submitButtomEnabled = true;
	}
	else {
		$scope.feedName = commonFunctions.getFeedName();
		$scope.feedID = commonFunctions.getFeedID();
		$scope.fileFormat = commonFunctions.getFileFormat();
		$scope.fileFeedId = commonFunctions.getFeedID();
		if (commonFunctions.getFeedID() != '' && angular.isDefined(commonFunctions.getFeedID())) {
			$scope.submitButtomEnabled = true;
		}
	}
	
	$scope.userID = loginService.userName();//commonFunctions.getUserID();
	$scope.finalJSONGenerated = {};
	$scope.finalJSONGenerated.feedID = parseInt($scope.feedID, 10);
	$scope.finalJSONGenerated.feedName = $scope.feedName;
	$scope.finalJSONGenerated.userID = loginService.userName();
	$scope.endDate = commonFunctions.getEndDate() ? commonFunctions.getEndDate() : '';
	$scope.startDate = commonFunctions.getStartDate() ? commonFunctions.getStartDate() : '';
	$scope.finalJSONGenerated.endDate = $scope.endDate;
	$scope.finalJSONGenerated.startDate = $scope.startDate;
	
	$scope.dataFormatList = commonFunctions.getDateFormatList();
	$scope.dateTimeSelected = true;
	$scope.invalidEntries = [];
	$scope.rangePara = {};
	$scope.dataType = {};
	$scope.dataFormat = {};
	$scope.runs = {};
	$scope.minAlert = {};
	$scope.minAbort = {};
	$scope.maxAlert = {};
	$scope.maxAbort = {};
	$scope.alertMaxError = {};
	$scope.alertMinError = {};
	$scope.abortMaxError = {};
	$scope.abortMinError = {};
	$scope.pastrunVal = {};
	$scope.errorMsg = [];
	$scope.noEdit = false;
	$scope.path = $location.absUrl().split('?')[1];
	 /*if (angular.isDefined(commonFunctions.getReqColumnId()) && commonFunctions.getReqColumnId() !== 0 ) {
	 	$scope.column_ID = commonFunctions.getReqColumnId();
	 }*/
	$scope.initializeColumnTree = function () {
		$scope.columnList = [ 
   		{
    	columnName : '', 
    	columnID: '',
		dataType : '', 
		dataFormat: '',
		startDate: $scope.startDate,
		endDate: $scope.endDate,
		userID: $scope.userID,
		showRule: false,
      	rules:[
      		{
      			columnName: '',
      			columnID: '',
      			ruleID: '',
      			ruleParameter: '',
      			pastRuns: '',
      			userID: $scope.userID,
      			startDate: $scope.startDate,
				endDate: $scope.endDate,
      			thresholdType: '',
      			minAlertThreshold: '',
      			minAbortThreshold: '',
      			maxAlertThreshold: '',
      			maxAbortThreshold: ''
      		}
      	],
      } ];
	};
	
	 

	$scope.editCol = function (id) {
		 $http.get(servicesUrl.getColumnEditUrl + '?feedID=' + id + '&timeStamp=' + Date.now())
          .success(function (data) {
          	if (data.status.responseCode == 200) {
          		/* columnExportInfo localStorage will be used to export the columns during export functionality */
          		//closing for now. Too heavy to keep so much data in browser memory.
          		//window.localStorage.setItem('columnsInfo', JSON.stringify(data.result.columns));
				
				if (angular.isDefined(data.result.feedName)) {
					$scope.finalJSONGenerated.feedName = data.result.feedName; 
				}
				/*if (angular.isDefined(data.result.userID)) {
					$scope.finalJSONGenerated.userID = data.result.userID; 
				}*/							
				if (angular.isDefined(data.result.endDate)) {
					$scope.finalJSONGenerated.endDate = data.result.endDate;
				}
				if (angular.isDefined(data.result.startDate)) {
					$scope.finalJSONGenerated.startDate = data.result.startDate;
				}
				
          		var keepChecking = true;
          		$scope.fileFormat = data.result.fileFormat;
				if ($scope.fileFormat && $scope.fileFormat.toLowerCase() === 'fixed') {
					$scope.dataTypeList = commonFunctions.getFixedDataTypeList();
				}
				else {
					$scope.dataTypeList = commonFunctions.getDataTypeList();
				}
				angular.forEach(data.result.columns, function(col) {
					$scope.endDate = col.endDate;
					$scope.startDate = col.startDate;
					if (keepChecking) {
						if (new Date(col.endDate).getTime() < Date.now()) {
							$scope.noEdit = true;
							keepChecking = false;
						}
						else {
							$scope.noEdit = false;
						}
					}
					angular.forEach(col.rules, function(rule) {
						if (rule.ruleID === "10" || rule.ruleID === "11") {
							rule.ruleParameter = rule.ruleParameter.split(",");
						}
					});
				});
				if (angular.isUndefined(data.result.columns)) {
				$scope.columnList = [];
				}
				else {
				$scope.columnList = data.result.columns;
				}
			
				
          	}
          	else {
				$scope.columnList = [];
          		$scope.msg = data.status.responseMessage;
				commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
          	}
          })
          .error (function (response) {
          	$scope.msg = response.status.responseMessage;
			commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
          })
          .then (function (res) {
			/*if ($scope.columnUpload) {
				var successMessage = "Column Metadata registered successfully for Feed ID - " + id;
	              		
	              		$scope.showModal(successMessage, 'Submitted', false);	
			}
			else {*/
				if (angular.isDefined($scope.reqColumnId) && $scope.reqColumnId != '') {
				$timeout(function(){
					//$("body").animate({scrollTop: $('#column_2').offset() - 300}, 1200);  	
					$location.hash('column_'+ $scope.reqColumnId);
					$anchorScroll();
				}, 10); 
				}
			
			//}
		      	
          });
	};

	
  if (angular.isDefined(commonFunctions.getReqFeedID()) && commonFunctions.getReqFeedID() != '' ) {
		
    	if (commonFunctions.getReqColumnId()) {
    		$scope.reqColumnId = commonFunctions.getReqColumnId();
    	}
    	else {
    		$scope.reqColumnId = '';
    	}
  		
  		$scope.reqFeedId = commonFunctions.getReqFeedID();
  		$scope.editCol($scope.reqFeedId);
        
  	}
  	else  {
	  		$scope.initializeColumnTree();
			if ($scope.fileFormat && $scope.fileFormat.toLowerCase() === 'fixed') {
				$scope.dataTypeList = commonFunctions.getFixedDataTypeList();
			}
			else {
				$scope.dataTypeList = commonFunctions.getDataTypeList();
			}
  	}
	

    $scope.newItem = function($event) {
        $scope.columnList.push(
        	{ 
        		columnName : '', 
        		columnID: '',
        		dataType : '', 
        		dataFormat: '',
        		startDate: $scope.startDate,
				endDate: $scope.endDate,
        		userID: $scope.userID,
        		showRule: false,
		      	rules:[
		      		{
		      			columnName: '',
		      			columnID: '',
		      			ruleID: '',
		      			ruleParameter: '',
		      			pastRuns: '',
		      			userID: $scope.userID,
		      			startDate: $scope.startDate,
						endDate: $scope.endDate,
		      			thresholdType: '',
		      			minAlertThreshold: '',
		      			minAbortThreshold: '',
		      			maxAlertThreshold: '',
		      			maxAbortThreshold: ''
		      		}
		      		]
        	});
        $event.preventDefault();
    }

    $scope.newRule = function($event, index){
    	angular.forEach ($scope.columnList, function (key, val) {
    		
    		if (index === val) {
    			
    			 $scope.columnList[val].rules.push({ 
    			 	columnName: $scope.columnList[val].columnName,
    			 	columnID: $scope.columnList[val].columnID,
	      			ruleID: '',
	      			ruleParameter: '',
	      			pastRuns: '',
	      			userID: $scope.userID,
	      			startDate: $scope.startDate,
					endDate: $scope.endDate,
	      			thresholdType: '',
	      			minAlertThreshold: '',
	      			minAbortThreshold: '',
	      			maxAlertThreshold: '',
	      			maxAbortThreshold: ''
    			 });
    		}
    	});       
        $event.preventDefault();
    }
    $scope.ruleTypeSelectionChange = function (obj) {
    	obj.rule.ruleParameter = '';
    	obj.rule.pastRuns = '';
    	obj.rule.thresholdType = '';
    	obj.rule.maxAbortThreshold = '';
    	obj.rule.maxAlertThreshold = '';
    	obj.rule.minAbortThreshold = '';
    	obj.rule.minAlertThreshold = '';

    }

    $scope.thresholdTypeChange = function(obj, ind) {
    	if (obj.rule.thresholdType === 'Absolute') {
    		obj.rule.pastRuns = "0";
    	}
    	//else if (obj.rule.thresholdType === '') {
    		obj.rule.minAlertThreshold = '';
    		obj.rule.maxAlertThreshold = '';
    		obj.rule.minAbortThreshold = '';
    		obj.rule.maxAbortThreshold = '';
    	//}
    }


    $scope.deleteInvalidEntries = function () {
    	$scope.optimizedJSON = angular.copy($scope.finalJSONGenerated);
    	angular.forEach($scope.finalJSONGenerated.columns, function(val, key) {
			if ($scope.finalJSONGenerated.columns[key].columnName == '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].columnName)) {
		      	$scope.finalJSONGenerated.columns.splice(key,1);		      
			} 
			});  
			angular.forEach($scope.finalJSONGenerated.columns, function(val, key) { 			
				angular.forEach($scope.finalJSONGenerated.columns[key].rules, function(val1, key1) {
				/*	$scope.finalJSONGenerated.columns[key].rules[key1].ruleParameter = $scope.finalJSONGenerated.columns[key].rules[key1].ruleParameter.toString();*/
					if ($scope.finalJSONGenerated.columns[key].rules[key1].columnName == '') {
						$scope.finalJSONGenerated.columns[key].rules[key1].columnName = $scope.finalJSONGenerated.columns[key].columnName;
						
					}
					if ($scope.finalJSONGenerated.columns[key].rules[key1].ruleID === '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].ruleID)) {
		      			$scope.finalJSONGenerated.columns[key].rules.splice(key1,1);
		      		}
					
				});
		});
		
		$scope.invalidEntries = [];
	};
   
    $scope.submitColumnMetadata = function () {
    	$scope.finalJSONGenerated.columns = $scope.columnList;
    	angular.forEach($scope.finalJSONGenerated.columns, function(val, key) { 
			if ($scope.finalJSONGenerated.columns[key].columnName == '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].columnName)) {
		      	$scope.invalidEntries.push($scope.finalJSONGenerated.columns[key]);

			} 
			angular.forEach($scope.finalJSONGenerated.columns[key].rules, function(val1, key1) {
				if (angular.isDefined($scope.finalJSONGenerated.columns[key].rules[key1].ruleParameter) && $scope.finalJSONGenerated.columns[key].rules[key1].ruleParameter !== '') {
					$scope.finalJSONGenerated.columns[key].rules[key1].ruleParameter = $scope.finalJSONGenerated.columns[key].rules[key1].ruleParameter.toString();
				}		
				if (angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].pastRuns) || $scope.finalJSONGenerated.columns[key].rules[key1].pastRuns === '') {
					$scope.finalJSONGenerated.columns[key].rules[key1].pastRuns = "0";
				}
				if ($scope.finalJSONGenerated.columns[key].rules[key1].columnName == '') {
					$scope.finalJSONGenerated.columns[key].rules[key1].columnName = $scope.finalJSONGenerated.columns[key].columnName;
				} 
				if ($scope.finalJSONGenerated.columns[key].rules[key1].minAlertThreshold === '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].minAlertThreshold)) {
		      		$scope.finalJSONGenerated.columns[key].rules[key1].minAlertThreshold = '';
		      	}
		      	if ($scope.finalJSONGenerated.columns[key].rules[key1].minAbortThreshold === '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].minAbortThreshold)) {
		      		$scope.finalJSONGenerated.columns[key].rules[key1].minAbortThreshold = '';
		      	}
		      	if ($scope.finalJSONGenerated.columns[key].rules[key1].maxAlertThreshold === '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].maxAlertThreshold)) {
		      		$scope.finalJSONGenerated.columns[key].rules[key1].maxAlertThreshold = '';
		      	}
		      	if ($scope.finalJSONGenerated.columns[key].rules[key1].maxAbortThreshold === '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].maxAbortThreshold)) {
		      		$scope.finalJSONGenerated.columns[key].rules[key1].maxAbortThreshold = '';
		      	}
				if ($scope.finalJSONGenerated.columns[key].rules[key1].ruleID === '' || angular.isUndefined($scope.finalJSONGenerated.columns[key].rules[key1].ruleID)) {
		      		$scope.finalJSONGenerated.columns[key].rules.splice(key1,1);
		      	}
			});   		
    	});
		if ($scope.invalidEntries.length) {
			var mesg = "Few Column Names are empty. Are you sure to proceed?";
			$scope.showWarning(mesg, 'Warning!', true);
			
		}
		else {
			$scope.submitColumn();
		}
    };
    $scope.dataTypeSelect = function (item, index) {
    	if (item.name.indexOf("string") > -1 || item.name.indexOf("double") > -1 || item.name.indexOf("varchar") > -1 || item.name.indexOf("numeric") > -1 || item.name.indexOf("decimal") > -1) { 
    		$scope.dataType[index] = true;
    	}
    	else {
    		$scope.dataType[index] = false;
    	}   	

    };
    $scope.dataFormatSelect = function (item, index) {
    	$scope.dataFormat[index] = false;

    };
    $scope.checkValid = function(val, obj, rangeIndex) {
    	var valMatched = true;
    	if (val === 'dataType') {
    		if (angular.isDefined(obj.column.dataType) && obj.column.dataType !== '') {
				if (obj.column.dataType.indexOf("string") > -1 || obj.column.dataType.indexOf("varchar") > -1) {
					if (obj.column.dataType.length === 11) {
						if ((obj.column.dataType.charAt(9).match(/^\d*$/) !== null && obj.column.dataType.charAt(9) < 10 && obj.column.dataType.charAt(9) >= 0 && obj.column.dataType.charAt(8).match(/^\d*$/) !== null && obj.column.dataType.charAt(8) < 10 && obj.column.dataType.charAt(8) >= 0 && obj.column.dataType.charAt(7).match(/^\d*$/) !== null && obj.column.dataType.charAt(7) < 10 && obj.column.dataType.charAt(7) >= 0) && obj.column.dataType.charAt(10) == ")" && obj.column.dataType.charAt(6) == "(") {
							$scope.dataType[rangeIndex] = false;
						}
						else {
							$scope.dataType[rangeIndex] = true;
						}
					} 
					else if (obj.column.dataType.length === 10) {
						if ((obj.column.dataType.charAt(8).match(/^\d*$/) !== null && obj.column.dataType.charAt(8) < 10 && obj.column.dataType.charAt(8) >= 0 && obj.column.dataType.charAt(7).match(/^\d*$/) !== null && obj.column.dataType.charAt(7) < 10 && obj.column.dataType.charAt(7) >= 0) && obj.column.dataType.charAt(9) == ")" && obj.column.dataType.charAt(6) == "(") {
							$scope.dataType[rangeIndex] = false;
						}
						else {
							$scope.dataType[rangeIndex] = true;
						}
					}
					else if (obj.column.dataType.length === 9) {
						if ((obj.column.dataType.charAt(7).match(/^\d*$/) !== null && obj.column.dataType.charAt(7) < 10 && obj.column.dataType.charAt(7) >= 0) && obj.column.dataType.charAt(8) == ")" && obj.column.dataType.charAt(6) == "(") {
							$scope.dataType[rangeIndex] = false;
						}
						else {
							$scope.dataType[rangeIndex] = true;
						}
					}
					else {
						$scope.dataType[rangeIndex] = true;
					}
					
				} 
				else if (obj.column.dataType.indexOf("numeric") > -1 || obj.column.dataType.indexOf("decimal") > -1 || obj.column.dataType.indexOf("double") > -1) {
					
					if (obj.column.dataType.length === 13) {
						if (obj.column.dataType.charAt(9).match(/^\d*$/) !== null && obj.column.dataType.charAt(9) < 10 && obj.column.dataType.charAt(9) >= 0 && obj.column.dataType.charAt(8).match(/^\d*$/) !== null && obj.column.dataType.charAt(8) < 10 && obj.column.dataType.charAt(8) >= 0 && obj.column.dataType.charAt(11).match(/^\d*$/) !== null && obj.column.dataType.charAt(11) < 10 && obj.column.dataType.charAt(11) >= 0 && obj.column.dataType.charAt(12) == ")" && obj.column.dataType.charAt(7) == "(" && obj.column.dataType.charAt(10) == ",") {
							
							$scope.dataType[rangeIndex] = false;
						}
						else {
							
							$scope.dataType[rangeIndex] = true;
						}
					} 
					else if (obj.column.dataType.length === 12) {
						if (obj.column.dataType.charAt(8).match(/^\d*$/) !== null && obj.column.dataType.charAt(8) < 10 && obj.column.dataType.charAt(8) >= 0 && obj.column.dataType.charAt(10).match(/^\d*$/) !== null && obj.column.dataType.charAt(10) < 10 && obj.column.dataType.charAt(10) >= 0 && obj.column.dataType.charAt(11) == ")" && obj.column.dataType.charAt(7) == "(" && obj.column.dataType.charAt(9) == ",") {
							
							$scope.dataType[rangeIndex] = false;
						}
						else {
							
							$scope.dataType[rangeIndex] = true;
						}
					}
					else {
						$scope.dataType[rangeIndex] = true;
					}

				}
				else if (obj.column.dataType.indexOf("int") > -1 || obj.column.dataType.indexOf("bigint") > -1 || obj.column.dataType.indexOf("smallint") > -1 || obj.column.dataType.indexOf("tinyint") > -1) {
						angular.forEach ($scope.dataTypeList, function(value){
							if(valMatched) {
								if (value.name === obj.column.dataType) {
									
									$scope.dataType[rangeIndex] = false;
									valMatched = false;
								}
								else {
									$scope.dataType[rangeIndex] = true;
								}
							}
    					});
				}
				else {
					$scope.dataType[rangeIndex] = true;
				}
				
    		}
    		else {
    			$scope.dataType[rangeIndex] = false;
    		}
    	}
    	else if (val === 'dataFormat') {
    		if (angular.isDefined(obj.column.dataFormat) && obj.column.dataFormat !== '') {
    			angular.forEach ($scope.dataFormatList, function(value){
    				if (val.name === obj.column.dataFormat) {
    					$scope.dataFormat[rangeIndex] = false;
    				}
    				else {
    					$scope.dataFormat[rangeIndex] = true;
    				}
    			});
    			
    			
    		}
    		else {
    			$scope.dataType[rangeIndex] = false;
    		}
    	}
    	else if (val === 'range') {
    		if (obj.rule.ruleParameter.split(':').length != 2 && obj.rule.ruleParameter !='' && obj.rule.ruleParameter !=null) {
    			$scope.rangePara[rangeIndex] = true;
    		} 
    		else if (obj.rule.ruleParameter.split(':').length === 2 && (/*obj.rule.ruleParameter.split(':')[1].replace(/\s/g,'') > 100 || obj.rule.ruleParameter.split(':')[0].replace(/\s/g,'') > 100 || */obj.rule.ruleParameter.split(':')[1].replace(/\s/g,'') < 0 || obj.rule.ruleParameter.split(':')[0].replace(/\s/g,'') < 0)) {
    			$scope.rangePara[rangeIndex] = true;
    		}
    		else {
    			$scope.rangePara[rangeIndex] = false;
    		}
    		
    	}
    	else if (val === 'runs') {
    		
    		if (obj.rule.pastRuns === '') {
    			$scope.runs[rangeIndex] = false;
    		}
    		else if (obj.rule.pastRuns.match(/^\d*$/) === null || obj.rule.pastRuns > 365 || obj.rule.pastRuns < 0) {
    			
    			$scope.runs[rangeIndex] = true;
    		}    		
    		else {
    			$scope.runs[rangeIndex] = false;
    		}
    		
    	}
    	else if (angular.isDefined(obj.rule.thresholdType) && obj.rule.thresholdType == 'Absolute') {
    		
	    	if (val === 'maxAlert') {
	    		if ((obj.rule.maxAlertThreshold != '' && obj.rule.maxAlertThreshold < 0 ) || obj.rule.maxAlertThreshold.match(/^\d*$/) === null) {
	    			$scope.maxAlert[rangeIndex] = true;
	    		}
	    		else {
	    			$scope.maxAlert[rangeIndex] = false;
	    		}
	    		
	    	}
	    	if (val === 'maxAbort') {
	    		if ((obj.rule.maxAbortThreshold != '' && obj.rule.maxAbortThreshold < 0 ) || obj.rule.maxAbortThreshold.match(/^\d*$/) === null) {
	    			$scope.maxAbort[rangeIndex] = true;
	    		}
	    		else {
	    			$scope.maxAbort[rangeIndex] = false;
	    		}
	    		
	    	}
    	}
    	else {
    		if (val === 'minAlert') {
	    		if ((obj.rule.minAlertThreshold != '' && (parseInt(obj.rule.minAlertThreshold) > 100 || parseInt(obj.rule.minAlertThreshold)  < -100)) || (obj.rule.minAlertThreshold.match(/^\d*$/) === null && obj.rule.minAlertThreshold != '' && isNaN(obj.rule.minAlertThreshold))) {
	    			
	    			$scope.minAlert[rangeIndex] = true;
	    		}
	    		
	    		else {

	    			$scope.minAlert[rangeIndex] = false;
	    		}
	    		
	    	}
	    	if (val === 'minAbort') {
	    		if ((obj.rule.minAbortThreshold != '' && (parseInt(obj.rule.minAbortThreshold) > 100 || parseInt(obj.rule.minAbortThreshold) < -100)) || (obj.rule.minAbortThreshold.match(/^\d*$/) === null && obj.rule.minAbortThreshold != '' && isNaN(obj.rule.minAbortThreshold))) {
	    			$scope.minAbort[rangeIndex] = true;
	    		}
	    		/*else if (obj.rule.minAbortThreshold.match(/^\d*$/) === null) {
	    			$scope.minAbort[rangeIndex] = true;
	    		}*/
	    		else {
	    			$scope.minAbort[rangeIndex] = false;
	    		}
	    		
	    	}
	    	if (val === 'maxAlert') {
	    		if ((obj.rule.maxAlertThreshold != '' && (obj.rule.maxAlertThreshold > 100 || obj.rule.maxAlertThreshold < -100)) || (obj.rule.maxAlertThreshold.match(/^\d*$/) === null && obj.rule.maxAlertThreshold != '' && isNaN(obj.rule.maxAlertThreshold))) {
	    			$scope.maxAlert[rangeIndex] = true;
	    		}
	    		else {
	    			$scope.maxAlert[rangeIndex] = false;
	    		}
	    		
	    	}
	    	if (val === 'maxAbort') {
	    		if ((obj.rule.maxAbortThreshold != '' && (obj.rule.maxAbortThreshold > 100 || obj.rule.maxAbortThreshold < -100)) || (obj.rule.maxAbortThreshold.match(/^\d*$/) === null && obj.rule.maxAbortThreshold != '' && isNaN(obj.rule.maxAbortThreshold))) {
	    			$scope.maxAbort[rangeIndex] = true;
	    		}
	    		else {
	    			$scope.maxAbort[rangeIndex] = false;
	    		}
	    		
	    	}
    	}

    	/*if ((val === 'maxAlert' && obj.rule.thresholdType !== 'Absolute') || val === 'minAlert') {
    		if (obj.rule.minAlertThreshold != '' && (obj.rule.maxAlertThreshold === '' || angular.isUndefined(obj.rule.maxAlertThreshold))) {
				$scope.alertMaxError[rangeIndex] = true;
			}
			else if (obj.rule.maxAlertThreshold != '' && (obj.rule.minAlertThreshold === '' || angular.isUndefined(obj.rule.minAlertThreshold))) {
				$scope.alertMinError[rangeIndex] = true;
			}
			else {
				$scope.alertMaxError[rangeIndex] = false;
				$scope.alertMinError[rangeIndex] = false;
			} 	
    	}
    	else if ((val === 'maxAbort' && obj.rule.thresholdType !== 'Absolute') || val === 'minAbort') {
    		if (obj.rule.minAbortThreshold != '' && (obj.rule.maxAbortThreshold === '' || angular.isUndefined(obj.rule.maxAbortThreshold))) {
				$scope.abortMaxError[rangeIndex] = true;
			}
			else if (obj.rule.maxAbortThreshold != '' && (obj.rule.minAbortThreshold === '' || angular.isUndefined(obj.rule.minAbortThreshold))) {
				$scope.abortMinError[rangeIndex] = true;
			}
			else {
				$scope.abortMaxError[rangeIndex] = false;
				$scope.abortMinError[rangeIndex] = false;
			}
    	}*/

    	
    	
    };
    $scope.checkAllFieldsValid = function() {
    	angular.forEach($scope.rangePara, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Rule Parameter correctly in format Range1:Range2");
		        }
		});
		angular.forEach($scope.runs, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Past Runs correctly against Rule");
		        }
		});
		angular.forEach($scope.minAlert, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Min Alert Threshold Values properly");
		        }
		});
		angular.forEach($scope.minAbort, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Min Abort Threshold Values properly");
		        }
		});
		angular.forEach($scope.maxAlert, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Max Alert Threshold Values properly");
		        }
		});
		angular.forEach($scope.maxAbort, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Max Abort Threshold Values properly");
		        }
		});
		angular.forEach($scope.alertMaxError, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Max Alert Value");
		        }
		});
		angular.forEach($scope.alertMinError, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Min Alert Value");
		        }
		});
		angular.forEach($scope.abortMaxError, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Max Abortt Value");
		        }
		});
		angular.forEach($scope.abortMinError, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Min Abort Value");
		        }
		});
		angular.forEach($scope.dataType, function(prop) {
		        if(prop === true) {
		            $scope.errorMsg.push("Please fill the Data Types appropriatly");
		        }
		});
		
    };
    $scope.submitColumn = function () {
    	$scope.errorMsg = [];
    	$scope.checkAllFieldsValid();
    	//console.log("final json",angular.toJson($scope.finalJSONGenerated));
    	if($scope.columnForm.$valid && $scope.invalidEntries.length === 0 && $scope.errorMsg.length === 0) {
			if (commonFunctions.getReqFeedID() != '') {
				
				$scope.url = servicesUrl.updateColumnMetadataUrl;
			}
			else {
				$scope.url = servicesUrl.submitColumnMetadataUrl;
			}

			$http({
		          // To Do Add Timestamp URL parameter to fix IE service call cache issue
		          url: $scope.url,//servicesUrl.submitColumnMetadataUrl,
		          method: 'POST',
		          data: angular.toJson($scope.finalJSONGenerated),
		          headers: {'Content-Type': 'application/json'}
		    }).success(function (response) {
		    	 if (response.status.responseCode == 200) {
	              	if (response.status.feedID != null) {
	              		 var successMessage = "Column Metadata registered successfully for Feed ID - " + response.status.feedID;
	              		
	              		$scope.showModal(successMessage, 'Submitted', false);	              		
	         		}
	              	else {
	               		
	              	}

	            }
	            else {
	             
	            	$scope.msg = response.status.responseMessage;
					commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
	            }
	            $scope.queryInProgress = false;
		    })
		    .error (function (response) {
				$scope.msg = response.status.responseMessage;
				commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
		    });
		}
		else {
			$scope.hasError = true;
		}
    }
	 $scope.showModal = function(message, title, type) {
        ModalService.showModal({
		    templateUrl: 'modal.html',
		    controller: "ModalController",
				inputs: {
		        title: title,
		        message: message,
		        alertType: type,
		        inputReq: false        
		    }
		}).then(function(modal) {
		    modal.element.modal();
		     modal.close.then(function(result) {
					$scope.finalJSONGenerated = {};
					$scope.initializeColumnTree();
					commonFunctions.setReqColumnId('');
					commonFunctions.setReqFeedID('');
		    });
		});
    };
	$scope.showWarning = function(message, title, type) {
		ModalService.showModal({
		    templateUrl: 'modal.html',
		    controller: "ModalController",
				inputs: {
		        title: title,
		        message: message, 
		        alertType: type,
		        inputReq: false       
		    }
		}).then(function(modal) {
		    modal.element.modal();
		    modal.close.then(function(result) {
		    	if (result === 'Yes') {
		    		$scope.deleteInvalidEntries();
		    		$scope.submitColumn();

		    	}
		    
		    });
		});
	};	
	$scope.cancel = function () {
		$scope.finalJSONGenerated = {};
		$scope.initializeColumnTree();
		commonFunctions.setReqColumnId('');
		commonFunctions.setReqFeedID('');
		$location.url('/feed');
	};
	
	/* file export code */
	$scope.fileExport = function() {
		
			var data = window.localStorage['columnsInfo'];
		
			var filename = 'feed_columns.json';
			
			/* var form = document.forms.namedItem("column-form");
			var data = new FormData(form); */
			
			 if (!data) {
    			console.error('No data');
    			return;
  			}
  			if (typeof data === 'object') {
    			data = JSON.stringify(data);
  			}
			
		    var blob = new Blob([data], {type: 'text/json'}),
    		e = document.createEvent('MouseEvents'),
    		a = document.createElement('a');
    		
    		a.download = filename;
  			a.href = window.URL.createObjectURL(blob);
  			a.dataset.downloadurl = ['text/json', a.download, a.href].join(':');
  			e.initEvent('click', true, false, window,0, 0, 0, 0, 0, false, false, false, false, 0, null);
  			a.dispatchEvent(e);
	}


	/* file upload code */
	
	$scope.fileUpload = function() {
		if ($scope.feedID) {
		var form = document.forms.namedItem("columnMDFileForm");
		var oData = new FormData(form);
		
		  var oReq = new XMLHttpRequest();
		  oReq.open("POST", servicesUrl.columnUpload, true);
		  oReq.onload = function(oEvent) {
		  var responseJson = angular.toJson(oReq.response);
		   responseJson = JSON.parse(oReq.response);
			if (responseJson.status.responseCode == 200) {
				$scope.columnUpload = true;
				
				if (angular.isDefined(responseJson.result.feedName)) {
					$scope.finalJSONGenerated.feedName = responseJson.result.feedName; 
				}				
				if (angular.isDefined(responseJson.result.endDate)) {
					$scope.finalJSONGenerated.endDate = responseJson.result.endDate;
				}
				if (angular.isDefined(responseJson.result.startDate)) {
					$scope.finalJSONGenerated.startDate = responseJson.result.startDate;
				}
				
          		var keepChecking = true;
          		$scope.fileFormat = responseJson.result.fileFormat;
				if ($scope.fileFormat && $scope.fileFormat.toLowerCase() === 'fixed') {
					$scope.dataTypeList = commonFunctions.getFixedDataTypeList();
				}
				else {
					$scope.dataTypeList = commonFunctions.getDataTypeList();
				}
				angular.forEach(responseJson.result.columns, function(col) {
					$scope.endDate = col.endDate;
					$scope.startDate = col.startDate;
					if (keepChecking) {
						if (new Date(col.endDate).getTime() < Date.now()) {
							$scope.noEdit = true;
							keepChecking = false;
						}
						else {
							$scope.noEdit = false;
						}
					}
					angular.forEach(col.rules, function(rule) {
						if (rule.ruleID === "10" || rule.ruleID === "11") {
							rule.ruleParameter = rule.ruleParameter.split(",");
						}
					});
				});
				if (angular.isUndefined(responseJson.result.columns)) {
					$scope.columnList = [];
				}
				else {
					$scope.columnList = responseJson.result.columns;
				}
				$scope.$apply();
				
				 
					//$scope.editCol(responseJson.status.feedID);
				
			 
			  
			} else {
			  $scope.msg = responseJson.status.responseMessage;
			commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
			}
		  };
		  oReq.send(oData);
		 // ev.preventDefault();
		 // ev.stopPropagation();
		//}, false);
		}
		else {
			$scope.msg = "Feed ID is missing";
			commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
			}


	};
}]);
