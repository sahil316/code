'use strict';
zebra.controller('reportCtrl', ['$scope', '$http', '$rootScope', '$location', '$timeout', 'loginService', 'menuService', 'servicesUrl', 'commonFunctions', '$anchorScroll', function ($scope, $http, $rootScope, $location, $timeout, loginService, menuService, servicesUrl, commonFunctions, $anchorScroll) {
	if (!loginService.getLoginStatus()) {
		 $location.path('/');
		return;
	}
	
	$scope.currentFeed = {};
	$scope.currentFeed.id = "";
	$scope.currentFeed.feedName = "";
	
	$scope.reportPastRuns = commonFunctions.getPastRuns();
	//$scope.selectedRun = $scope.reportPastRuns[0].id;
	//$scope.nodeClicked = false;

	$scope.createRandomId = function() {
		var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		var str = '';
		var strLength = 15;
		for (var i = strLength; i > 0; --i) str += chars[Math.round(Math.random() * (chars.length - 1))];
		return str;
	};

	

	$scope.collapseAllOnClick = function (x) {
		
	    if (x.children) {
	        x._children = x.children;
	        x._children.forEach($scope.collapseAllOnClick);
	        x.children = null;

	    }
	};
// Toggle children on click.
	$scope.nodeClick = function (d) {
	    var rootName = $(this).closest('g.tree-root').attr('id');
	    $("g.tree-root").each(function(index ) {
	        var x = $scope.root[$(this).attr("id")];
	        if( x.parent != rootName) {     
	            $scope.collapseAllOnClick(x);
	            $scope.update(x, $(this).attr("id"), x.text, x.status);
	            
	        }
	        else { 
	            if (d.children) {
	                d._children = d.children;
	                d.children = null;
	            } 
	            else {
	                d.children = d._children;
	                d._children = null;
	            }
			 	if (d.depth === 0) {
			 		$("body").animate({scrollTop: $(this).offset().top - 630}, 1200);
			 	}
			 	   
	            $scope.update(d, rootName, d.text, d.status);
	        }
	     
	    });
	}
	

	/*Get the feed list on page load */
	$scope.getFeedList = function() {
		//if (commonFunctions.getFeedList().length === 0) {
	    	$http({
	          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
	          url: servicesUrl.getAllFeedsIdsListUrl,
	          method: 'GET',
	          headers: {'Content-Type': 'application/json'}
	        }).success(function (response) {
	            if (response.status.responseCode == 200) {
	              	if (response.result.feedList !== null) {
	              		$scope.feedList = response.result.feedList;
	              		//$scope.selectedFeed = $scope.feedList[0];
	              		//$scope.currentFeed.id = $scope.selectedFeed.feedID;
	              		//$scope.currentFeed.feedName = $scope.selectedFeed.feedName;
	              		commonFunctions.setFeedList($scope.feedList);
	         		}
	              	else {
	               		$scope.feedList = "";
	              	}

	            }
	            else {
	             

	            }
	            $scope.queryInProgress = false;
	          })
	          .error(function (response) {


	            $scope.queryInProgress = false;
	          })
	          .then(function () {
	          	$scope.requestObj = {
				    "feedID": $scope.currentFeed.id,
				    "pastRuns": $scope.selectedRun,
				    "requestChart": "report"
				};
	          	//$scope.loadGraph();
	          });
	   
    };
   

    $scope.selectionChanged = function () { 
    	if($scope.currentFeed.id !== undefined && $scope.selectedRun !== undefined){
    		angular.forEach($scope.feedList, function (key, val) {
    		if (key.feedID === $scope.currentFeed.id) {
    			$scope.currentFeed.feedName = key.feedName;
    		}    		
    	});
    	
    	$scope.requestObj = {
		    "feedID": $scope.currentFeed.id,
		    "pastRuns": $scope.selectedRun,
		    "requestChart": "report"
		};
		d3.select("#container").selectAll("svg").remove();
		$scope.linkr = linker.set({
			renderer: "container",
			connection: {
				paint: {
					strokeColor: '#dddddd',
					strokeWidth: 10,
				}
			}
		});
	
		$scope.loadGraph();
    	}else{
    		$scope.selectedRun = undefined;  
    		angular.element('#container').html('');
    		$scope.queryInProgress = false;
    		$scope.currentFeed.feedName = "";
    	}
    };
 	$scope.loadGraph = function() {  
 		$http({
          //Timestamp URL parameter added to fix IE service call cache issue
          url: servicesUrl.getReportUrl,
          data: angular.toJson($scope.requestObj),
          method: 'POST',
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
              if (response.result != null) {

			 		// To init linker
				$scope.linkr = linker.set({
				renderer: "container",
				connection: {
					paint: {
						strokeColor: '#dddddd',
						strokeWidth: 10,
					}
				}
				});
				var childFlag = false;
				response.result.forEach(function(parent) {	
					var child_count = 0;
					if(!angular.isUndefined(parent.children[1].children)) {
						parent.children[1].children.forEach(function(child) {
							child_count++;
						});
					}
					if (child_count > 30) {
						childFlag = true;
					}
				
				});
				if (childFlag) {
					var margin = {top: -30, right: 0, bottom: 140, left: 220},
					width = 1000 - margin.right - margin.left,
					height = 700 - margin.top - margin.bottom,
					treeHeight = 1000;
					$scope.rad = 6;
					$scope.stroke = 5;
				}
				else {
					var margin = {top: -30, right: 0, bottom: 140, left: 220},
					width = 1000 - margin.right - margin.left,
					height = 500 - margin.top - margin.bottom,
					treeHeight = 800;
					$scope.rad = 9;
					$scope.stroke = 14;
				}
				$scope.root = {};
				$scope.duration = 750;
				var k=0;
				$scope.i =0;
				$scope.svg = d3.select("#container").select("svg");	  
				$scope.tree = d3.layout.tree()
				    .size([height, width]);

				$scope.diagonal = d3.svg.diagonal()
				    .projection(function(d) { return [d.y, d.x]; });
				d3.select(self.frameElement).style("height", "800px");

               	$scope.wholeTree = response.result;	
				response.result.forEach(function(parent) {		
					parent.parent = "_"+parent.parent;
					$scope.svg.append("g")
					.attr("transform", "translate(" + margin.left + "," + (treeHeight*(k/$scope.selectedRun)) + ")")		
					.attr("class", "tree-root")
					.attr("id",parent.parent)		
					.append("g")
					.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
					
					$scope.root[parent.parent] = parent;
					$scope.root[parent.parent].x0 = height / 2;
					$scope.root[parent.parent].y0 = 0;		
					function collapse (d) {
					if (d.children) {
					  d._children = d.children;
					  d._children.forEach(collapse);
					  d.children = null;
					 
						}
					}  
					
					if ($scope.root[parent.parent].children) {
						$scope.root[parent.parent]._children = $scope.root[parent.parent].children;
						$scope.root[parent.parent]._children.forEach(collapse);
						$scope.root[parent.parent].children = null;
					}
					

					$scope.update($scope.root[parent.parent], parent.parent, parent.text, parent.status);
					k++;
				});	

              }
              else {
               
              }

            }
            else {
				$scope.msg = response.status.responseMessage;
				commonFunctions.showErrorMessage($scope.msg, 'Message', false); 

            }
            $scope.queryInProgress = false;
          })
          .error(function (response) {

          	$scope.msg = response.status.responseMessage;
			commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            $scope.queryInProgress = false;
          });
    };

    $scope.update = function (source, rootName, rootText, rootColor) {
		
		var color = ["steelblue","green","#fa6900","#b80000"];
		
		var treeObj = $scope.root[rootName];	
		// Compute the new tree layout.
	  
		var nodes = $scope.tree.nodes(treeObj).reverse(),
	      links = $scope.tree.links(nodes);
		
		
		// Normalize for fixed-depth.
		nodes.forEach(function(d) {
			d.y = d.depth * 190;

		});
		 var tip = d3.tip()
	        .attr('class', 'd3-tip')
	        .offset([-5, 0]);
	      
	    var finalText;
	    $scope.svg.call(tip);  
		// Update the nodes…
		var node = d3.select('#'+rootName).selectAll("g.node") //d3.select('.tree-root'+rootName).selectAll("g.node")
	      .data(nodes, function(d) {

	        return d.id || (d.id = ++$scope.i); 
	      });
	   
	       
		// Enter any new nodes at the parent's previous position.
	   
		var nodeEnter = node.enter().append("g")
	          .attr("class", "node")
	          .attr("transform", function(d) {
	    			return "translate(" + source.y0 + "," + (source.x0) + ")";
	    	  })
	    	  .attr("id", function(d) {
	    			var id = $scope.createRandomId();
	    			d.id = id;
	    			return id;
	    	  });         
	        
	      
	      	nodeEnter.append("circle")
	        .attr("r", $scope.rad)
	        .style("fill", function(d) { return d._children ? color[rootColor] : color[rootColor] })
	        .on("mouseover", function(d) {
	                var g = d3.select(this);	               	
	                var customText = d.text;
	                var tooltipArr = customText.split(",");
	            	finalText = tooltipArr.join('<br/>');
	                tip.html(function(d) {
	                    return "<span style='color:#fff'>"+finalText+"</span>";
	                });
	                if (d.text) {
	                	                	
	                    tip.show();
	                }
	            })
	        .on("mouseout", tip.hide)
	       
	        .on("click", $scope.nodeClick);
	        
	      
			  
		  	nodeEnter.append("text")
			  .attr("x", function(d) { return d.children || d._children ? -11 : 11; })
			  .attr("dy", ".30em")
			  .attr("text-anchor", function(d) { return d.children || d._children ? "end" : "start"; })
			  .text(function(d) { return d.name.replace("_",""); })
			  .style("fill-opacity", 1e-6);
					  
	     
		
		// Transition nodes to their new position.
			var nodeUpdate = node.transition()
		      .duration($scope.duration)
		      .attr("transform", function(d) { return "translate(" + d.y + "," + (d.x) + ")"; });
			nodeUpdate.select("circle")
		        .attr("r", $scope.rad)
		        .style("fill", function(d) { return d._children ? color[d.status] : color[d.status] });
		   

			nodeUpdate.select("text")
		      .style("fill-opacity", 1);
	  

		// Transition exiting nodes to the parent's new position.
		var nodeExit = node.exit().transition()
	      .duration($scope.duration)
	      .attr("transform", function(d) { return "translate(" + source.y + "," + (source.x) + ")"; })
	      .remove();

		nodeExit.select("circle")
	      .attr("r", $scope.rad)
		  .style("fill", color[rootColor])
		  .style("stroke", color[rootColor]);
	
		nodeExit.select("text")
	      .style("fill-opacity", 1e-6);

		// Update the links…
			var link = d3.select('#'+rootName).selectAll("path.link")
		      .data(links, function(d) { return d.target.id; });

			// Enter any new links at the parent's previous position.
			link.enter().insert("path", "g")
		      .attr("class", "link")
		      .attr("d", function(d) {
		        var o = {x: source.x0, y: source.y0};
		        return $scope.diagonal({source: o, target: o});
		      })
		      .style("stroke", color[rootColor])
			  .style("stroke-width", $scope.stroke + 'px');

			// Transition links to their new position.
			link.transition()
		      .duration($scope.duration)
		      .attr("d", $scope.diagonal);

			// Transition exiting nodes to the parent's new position.
			link.exit().transition()
		      .duration($scope.duration)
		      .attr("d", function(d) {
		        var o = {x: source.x, y: source.y};
		        return $scope.diagonal({source: o, target: o});
		      })
		      .remove();
	     //}
	     
		// Stash the old positions for transition.
		nodes.forEach(function(d) {
			d.x0 = d.x;
			d.y0 = d.y;
			//linker ... draw component
			$scope.linkr.drawComponent({}, d.id);
			/*setTimeout(function() {
				$scope.linkr.drawComponent({}, d.id);
			}, 1000)*/
		});
	};

     $scope.getFeedList();
}]);
