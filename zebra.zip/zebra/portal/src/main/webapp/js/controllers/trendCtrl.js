'use strict';
zebra.controller('trendCtrl', ['$scope', '$http', '$rootScope', '$location', '$timeout', '$cookieStore', '$log', 'menuService', 'loginService', 'servicesUrl', 'commonFunctions', function ($scope, $http, $rootScope, $location, $timeout, $cookieStore, $log, menuService,loginService,servicesUrl,commonFunctions) {
if (!loginService.getLoginStatus()) {
        $location.path('/');
        return;
    }
$scope.selectedTrendFeed = {};
$scope.selectedTrendFeed.id = "";
$scope.selectedTrendFeed.feedName = "";

$scope.windowHeight = $(window).innerHeight() + 'px';

$scope.selectedTrendColumn = {};
$scope.selectedTrendColumn.id = "";
$scope.selectedTrendColumn.columnName = "";

$scope.selectedRule = {};
$scope.selectedRule.id = "";
$scope.selectedRule.ruleName = "";

$scope.selectedTrendColumnStat = {};
$scope.selectedTrendColumnStat.id = "";
$scope.selectedTrendColumnStat.columnName = "";

$scope.selectedStats = commonFunctions.getStatsList();

$scope.trendPastRuns = commonFunctions.getPastRuns();
$scope.selectedColumnPastRun = $scope.trendPastRuns[0].id;
$scope.selectedColumnStatsPastRun = $scope.trendPastRuns[0].id;

$scope.noColumnGraph = true;
$scope.noColumnStatGraph = true;
$scope.hideGraph = false;
$scope.generateRuns = function(runs) {
    var category = [];
    for (var i = 1; i <= runs; i++) {
        category.push({"label": i.toString()});
    }
    return category;
};
var myjson = {
            "chart": {
                "caption": "Feed Name",
                "captionFontSize": "14",
                "subcaptionFontSize": "",
                "subcaptionFontBold": "0",
                "paletteColors": "#0b2e59,#7a237a,#979aa3,#058ea0,#17884a,#D52000,#FBD300,#5500C2,#F40000",
                "bgcolor": "#ffffff",
                /*"formatNumberScale":"0",*/
                "showBorder": "0",
                "showShadow": "0",
                "showCanvasBorder": "0",
                "usePlotGradientColor": "0",
                "legendBorderAlpha": "0",
                "legendIconScale":'2',
                "legendBgColor": "green",
                "legendShadow": "0",
                "showAxisLines": "0",
                "showAlternateHGridColor": "0",
                "divlineThickness": "1",
                "divLineIsDashed": "1",
                "divLineDashLen": "1",
                "divLineGapLen": "1",
                "xAxisName": "",
                "showValues": "0",
                "plottooltext": "<div class='tooltipHeaderDiv'>{br}$seriesName</div>{br}<div class='tooltipValueDiv'><b>$value</b></div>"
            },
            "categories": [
            ]
        };

var statsJSON = {
                    "chart": {
                    "caption": "Feed Name",
                    "captionFontSize": "14",
                    "subcaptionFontSize": "",
                    "subcaptionFontBold": "0",
                    "paletteColors": "#0b2e59,#7a237a,#979aa3,#058ea0,#17884a,#D52000,#FBD300,#5500C2,#F40000",
                    "bgcolor": "#ffffff",
                    "showBorder": "0",
                    "showShadow": "0",
                    "showCanvasBorder": "0",
                    "usePlotGradientColor": "0",
                    "legendBorderAlpha": "0",
                    "legendIconScale":'2',
                    "legendBgColor": "green",
                    "legendShadow": "0",
                    "showAxisLines": "0",
                    "showAlternateHGridColor": "0",
                    "divlineThickness": "1",
                    "divLineIsDashed": "1",
                    "divLineDashLen": "1",
                    "divLineGapLen": "1",
                    "xAxisName": "",
                    "showValues": "0",
                    "plottooltext": "<div class='tooltipHeaderDiv'>{br}$seriesName</div>{br}<div class='tooltipValueDiv'><b>$value</b></div>"
                    },
                    "categories": [
                        
                    ],
                    "dataset":[
                    ]
                };
$scope.loadFeedTrend = function () {
    $http({
          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.loadFeedGraphUrl,
          method: 'POST',
          data: $scope.feed_requestObj,
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                if (angular.isDefined(response.dataset) && response.dataset != '') {
                    myjson.dataset = response.dataset;
                }
                else {
                    myjson.dataset = [];
                }
                $scope.hideGraph = false;
                $scope.finalCategory = {};
                myjson.categories = [];               
                $scope.category = $scope.generateRuns($scope.selectedPastRun);
                $scope.finalCategory = {"category": $scope.category};
                myjson.categories.push($scope.finalCategory);
                FusionCharts.ready(function () {
                    var visitChart = new FusionCharts({
                        type: 'msline',
                        renderAt: 'chart-container',
                        width: '800',
                        height: '350',
                        dataFormat: 'json',
                        dataSource: myjson,
                    }).render();
                });
            }
            else {
               
                $scope.msg = response.status.responseMessage;
                $scope.hideGraph = true;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            }
        })
        .error( function(response) {
            $scope.hideGraph = true;
            $scope.msg = response.status.responseMessage;
            
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
           
        });
};

$scope.loadColumnTrend = function () {
    $http({
          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.loadColumnRulesGraphUrl,
          method: 'POST',
          data: $scope.rules_requestObj,
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                if (angular.isDefined(response.dataset) && response.dataset != '') {
                    myjson.dataset = response.dataset;
                }
                else {
                    myjson.dataset = [];
                }
                $scope.finalCategory = {};
                myjson.categories = [];
                $scope.category = $scope.generateRuns($scope.selectedColumnPastRun);
                $scope.finalCategory = {"category": $scope.category};
                myjson.categories.push($scope.finalCategory);
                FusionCharts.ready(function () {
                    var visitChart = new FusionCharts({
                       type: 'msline',
                        renderAt: 'chart-container2',
                        width: '800',
                        height: '350',
                        dataFormat: 'json',
                        dataSource: myjson,
                    }).render();
                })
            }
            else {
                $scope.msg = response.status.responseMessage;
                myjson.dataset = [];
                $scope.finalCategory = {};
                myjson.categories = [];
                $scope.category = $scope.generateRuns($scope.selectedColumnPastRun);
                $scope.finalCategory = {"category": $scope.category};
                myjson.categories.push($scope.finalCategory);
                FusionCharts.ready(function () {
                    var visitChart = new FusionCharts({
                       type: 'msline',
                        renderAt: 'chart-container2',
                        width: '800',
                        height: '350',
                        dataFormat: 'json',
                        dataSource: myjson,
                    }).render();
                });
                commonFunctions.showErrorMessage($scope.msg, 'Message', false);
            }
        })
        .error( function(response) {
            $scope.msg = response.status.responseMessage;
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
        });
};

$scope.loadColumnStatsTrend = function (type) {
    $http({
          //To Do : Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.loadColumnStatsGraphUrl,
          method: 'POST',
          data: $scope.stats_requestObj,
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                $scope.finalCategory = {};
                statsJSON.categories = [];
                if (angular.isDefined(response.dataset) && response.dataset != '') {
                     commonFunctions.setColumnStatDataSet(response.dataset);
                }
                else {
                     commonFunctions.setColumnStatDataSet('');
                }
                $scope.category = $scope.generateRuns($scope.selectedColumnStatsPastRun);
                $scope.finalCategory = {"category": $scope.category};
                statsJSON.categories.push($scope.finalCategory);
            }
            else {
                $scope.msg = response.status.responseMessage;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
                commonFunctions.setColumnStatDataSet('');
            }
        })
        .error( function(response) {
            $scope.msg = response.status.responseMessage;
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
        })
        .then (function() {
            if (type === 'past') {
                $scope.loadColumnStatsGraph(); 
            }
        });     
};

$scope.loadColumnStatsGraph = function () {
    var dataSetJson = commonFunctions.getColumnStatDataSet();
    statsJSON.dataset = [];
    angular.forEach(dataSetJson, function(data){
        if (data.seriesname == $scope.selectedStats.name) {
            statsJSON.dataset.push(data);
        }
    });
    FusionCharts.ready(function () {
        var visitChart = new FusionCharts({
            type: 'msline',
            renderAt: 'chart-container3',
            width: '800',
            height: '350',
            dataFormat: 'json',
            dataSource: statsJSON,
        }).render();
    })
};

/*Get the feed list on page load */
$scope.getTrendFeedList = function() {
   // if (commonFunctions.getFeedList().length === 0) {
        $http({
          //To Do  - Add Timestamp URL parameter to fix IE service call cache issue
          url: servicesUrl.getAllFeedsIdsListUrl,
          method: 'GET',
          headers: {'Content-Type': 'application/json'}
        }).success(function (response) {
            if (response.status.responseCode == 200) {
                if (response.result.feedList !== null) {
                    $scope.feedList = response.result.feedList;
                    /* Saved the feed column and rule list for future use */
                    commonFunctions.setFeedList($scope.feedList);
                    $scope.selectedTrendColumn = {};
                    $scope.selectedTrendColumn.id = "";
                    $scope.selectedTrendColumn.columnName = "";
                    $scope.selectedRule = {};
                    $scope.selectedRule.id = "";
                    $scope.selectedRule.ruleName = "";
                    $scope.selectedTrendColumnStat = {};
                    $scope.selectedTrendColumnStat.id = "";
                    $scope.selectedTrendColumnStat.columnName = "";
                    $scope.selectedStats = {};
                    $scope.selectedStats.id = "";
                    $scope.selectedStats.name = "";
                }
                else {
                    $scope.feedList = "";
                }
            }
            else {
                $scope.msg = response.status.responseMessage;
                commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            }
            $scope.queryInProgress = false;
          })
          .error(function (response) {
            $scope.msg = response.status.responseMessage;
            commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
            $scope.queryInProgress = false;
          })
};


$scope.loadColumnFeed = function (feedID) {
    $http({url: servicesUrl.getColumnsRulesUrl+ '?feedID=' + feedID + '&timeStamp=' + Date.now(), method: 'GET',headers: {'Content-Type': 'application/json'}})
    .success(function (data) {
        if (data.status.responseCode == 200) {
            $scope.columnList = data.columnList;
            
            $scope.selectedTrendColumn.id = "";
            $scope.selectedTrendColumn.columnName = "";
        }
        else {
            $scope.columnList = {};
        }
      })
      .error(function (data) {
        $scope.msg = data.status.responseMessage;
        commonFunctions.showErrorMessage($scope.msg, 'Message', false); 
        $scope.queryInProgress = false;
      })  
};
$scope.loadColumnRule = function (feedID, columnID) {
    angular.forEach($scope.columnList, function(key1,val1) {
	            		if (key1.columnID == columnID) {
	            			$scope.rulesList = key1.ruleList;
	        			}
	        		});
};
$scope.loadColumnStats = function (feedID, columnID) {
    $scope.statsList = commonFunctions.getStatsList(feedID, columnID);
};

$scope.feedSelectionChangedTrend = function () {
    if($scope.selectedTrendFeed.id !== undefined && $scope.selectedTrendFeed.id !== null){
        angular.forEach($scope.feedList, function (key, val) {
        if (key.feedID === $scope.selectedTrendFeed.id) {
            $scope.selectedTrendFeed.feedName = key.feedName;
        }           
    	});
    myjson.chart.caption =  $scope.selectedTrendFeed.feedName;
    $scope.loadColumnFeed($scope.selectedTrendFeed.id);
    $scope.selectedRule = {};
    $scope.selectedRule.id = "";
    $scope.selectedRule.ruleName = "";

    $scope.selectedStats = {};
    $scope.selectedStats.id = "";
    $scope.selectedStats.name = "";
    }
    $scope.selectedPastRun = undefined;
    $scope.hideGraph = true;
    $scope.noColumnGraph = true
 	$scope.noColumnStatGraph = true;
    
    $scope.rulesList = {}; 
    
};


$scope.pastRunsSelectionChangedTrend = function () {
    if($scope.selectedTrendFeed.id !== undefined && $scope.selectedTrendFeed.id !== null && $scope.selectedPastRun !== undefined && $scope.selectedPastRun !== null){
        angular.forEach($scope.feedList, function (key, val) {
        if (key.feedID === $scope.selectedTrendFeed.id) {
            $scope.selectedTrendFeed.feedName = key.feedName;
        }           
    });
    myjson.chart.caption =  $scope.selectedTrendFeed.feedName;
    $scope.loadColumnFeed($scope.selectedTrendFeed.id);
   // $scope.loadColumnFeed($scope.selectedTrendFeed.id);
    $scope.selectedRule = {};
    $scope.selectedRule.id = "";
    $scope.selectedRule.ruleName = "";

    $scope.selectedStats = {};
    $scope.selectedStats.id = "";
    $scope.selectedStats.name = "";
   
    $scope.feed_requestObj = {
        "feedID": $scope.selectedTrendFeed.id,
        "pastRuns": $scope.selectedPastRun,
        "requestChart": "trend"
    };
    //$scope.noColumnGraph = true;
    $scope.loadFeedTrend();
    }else{
        $scope.selectedPastRun = undefined;
        $scope.hideGraph = true;
    }
    
};

/*for column rule graph */
$scope.columnSelectionChangedTrend = function (type) {
    if ($scope.selectedTrendColumn.id == null) {
         $scope.noColumnGraph = true;
    }
    else {
        angular.forEach($scope.columnList, function (key, val) {
        if (key.columnID === $scope.selectedTrendColumn.id) {
            $scope.selectedTrendColumn.columnName = key.columnName;
        }           
         });
   
        $scope.rules_requestObj = {
            "feedID": $scope.selectedTrendFeed.id,
            "columnID": $scope.selectedTrendColumn.id,
            "ruleID": $scope.selectedRule.id,//"",
            "pastRuns": $scope.selectedColumnPastRun,
            "requestChart": "trend"
        };
        if (type == 'column') {
            $scope.selectedRule = {};
            $scope.selectedRule.id = "";
            $scope.selectedRule.ruleName = "";
        }
        $scope.loadColumnRule($scope.selectedTrendFeed.id, $scope.selectedTrendColumn.id);
        if ($scope.selectedTrendColumn.id && $scope.selectedRule.id) {
            $scope.noColumnGraph = false;
            $scope.loadColumnTrend(); 
            $("body").animate({scrollTop: $('.trending_column').offset().top - 300}, 1200);   
        }
        else {
            $scope.noColumnGraph = true;
        }

    }
    
};
$scope.ruleSelectionChangedTrend = function () {
    angular.forEach($scope.rulesList, function (key, val) {
    if (key.ruleID === $scope.selectedRule.id) {
        $scope.selectedRule.ruleName = key.ruleName;
    }           
     });

    $scope.rules_requestObj = {
        "feedID": $scope.selectedTrendFeed.id,
        "columnID": $scope.selectedTrendColumn.id,
        "ruleID": $scope.selectedRule.id,
        "pastRuns": $scope.selectedColumnPastRun,
        "requestChart": "trend"
    };
   
    if ($scope.selectedTrendColumn.id && $scope.selectedRule.id) {
        $scope.noColumnGraph = false;
        $scope.loadColumnTrend();   
        /*var x = event.x;
        var y = event.y;
        var offsetX = event.offsetX;
        var offsetY = event.offsetY;*/
        $("body").animate({scrollTop: $('.trending_column').offset().top - 300}, 1200);    
    }
    else {
        $scope.noColumnGraph = true;
    }
    
};

/*for stats graph */

$scope.columnStatsSelectionChangedTrend = function (type) {
   if ($scope.selectedTrendColumnStat.id == null || $scope.selectedTrendColumnStat.id == '') {
        $scope.noColumnStatGraph = true;
        $scope.selectedStats = {};
        $scope.selectedStats.id = "";
        $scope.selectedStats.name = "";
        $scope.selectedColumnStatsPastRun = "10";
    }
    else {
        angular.forEach($scope.columnList, function (key, val) {
        if (key.columnID === $scope.selectedTrendColumnStat.id) {
            $scope.selectedTrendColumnStat.columnName = key.columnName;
        }           
         });
   
        $scope.stats_requestObj = {
            "feedID": $scope.selectedTrendFeed.id,
            "columnID": $scope.selectedTrendColumnStat.id,
            "pastRuns": $scope.selectedColumnStatsPastRun,
            "requestChart": "trend"
        };
        if (type == 'column') {
            $scope.selectedStats = {};
            $scope.selectedStats.id = "";
            $scope.selectedStats.name = "";
            $scope.selectedColumnStatsPastRun = "10";
        }
        $scope.loadColumnStats($scope.selectedTrendFeed.id, $scope.selectedTrendColumnStat.id);
        if ($scope.selectedTrendColumnStat.id) {
             if ($scope.selectedStats.id) {
                $scope.noColumnStatGraph = false;
            }
            else {
                $scope.noColumnStatGraph = true;
            }
           
            $("body").animate({scrollTop: $('.trending_column_stats').offset().top - 300}, 1200);   
            $scope.loadColumnStatsTrend(type); 
            //$scope.loadColumnStatsGraph(); 
        }
        else {
            $scope.noColumnStatGraph = true;
        }

    }
};
$scope.statSelectionChangedTrend = function () {
    angular.forEach($scope.statsList, function (key, val) {
    if (key.id === $scope.selectedStats.id) {
        $scope.selectedStats.name = key.name;
    }           
     });

    $scope.stats_requestObj = {
        "feedID": $scope.selectedTrendFeed.id,
        "columnID": $scope.selectedTrendColumnStat.id,
        "pastRuns": $scope.selectedColumnStatsPastRun,
        "requestChart": "trend"
    };
    if ($scope.selectedTrendColumnStat.id && $scope.selectedStats.id) {
        $scope.noColumnStatGraph = false;
        $("body").animate({scrollTop: $('.trending_column_stats').offset().top - 300}, 1200);  
        $scope.loadColumnStatsGraph();  
    }
    else {
        $scope.noColumnStatGraph = true;
    }
    
};

$scope.showEditRequestPage = function (id, type) {
    if (type === 'feed') {
        commonFunctions.setFeedID(id);
        commonFunctions.setFeedName($scope.selectedTrendFeed.feedName);
        // Redirect to Request page for editing
        $location.url('/feed?mode=edit');
    }
    else if (type === 'column') {
        commonFunctions.setReqColumnId(id);
        commonFunctions.setReqFeedID($scope.selectedTrendFeed.id);
        commonFunctions.setReqFeedName($scope.selectedTrendFeed.feedName);
       // console.log(angular.toJson($scope.selectedTrendFeed));
        // Redirect to Request page for editing
        $location.url('/column');
    }
};

/*Call feed list on load */
$scope.getTrendFeedList();

}]);
