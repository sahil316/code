/**
 * [description]
 * @return {[type]} [description]
 */
zebra.directive('loadingWidget', function(commonFunctions) {

	return {
		restrict: 'E',
		replace:true,
		template: '<div id="loaderDiv" loader><img src="img/ajax-loader.gif" class="ajax-loader"/></div>',
		link: function (scope, element, attr) {
			scope.$on("loader_show", function () {
				$('#backdrop').css('display', 'block');
            	return element.show();
	        });
	        return scope.$on("loader_hide", function () {
	        	commonFunctions.updateContentHeight();
	        	$('#backdrop').css('display', 'none');
	            return element.hide();
	        });
		}
	};

});
zebra.directive('allowPattern', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.bind("keypress", function (e) {
                var regex;                
                if (attrs.allowPattern && attrs.allowPattern != '') {
                    regex = new RegExp(attrs.allowPattern);
                } else {
                    regex = new RegExp("^[a-zA-Z0-9_]+$");
                }
                var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
                if (regex.test(str)) {
                    return true;
                }

                e.preventDefault();
                return false;

            });
            element.bind("keyup", function (e) {
            	this.value = this.value.toUpperCase();
            });
        }
    }
});
zebra.directive('sessionTimeout', function (loginService) {
    return {
        restrict: 'A', 
         scope: {
          interval_val: '=sessionTimeout'
        },       
        link: function (scope, element, attrs) {         		
        	var tempLocationArr = window.location.href.split('#');
        	var newUrl = tempLocationArr[0];        	     	
            $(document).userTimeout({
			    logouturl: newUrl,
				session: scope. interval_val
			});			
            $('body').on("click", '#logoff', function (e) {
            	loginService.userLogout();            	         	
            });

        }
    }
});

