// angular services for common functions
zebra.factory('commonFunctions', ['$timeout', '$rootScope', '$cookieStore', 'ModalService', function($timeout, $rootScope, $cookieStore, ModalService) {
	var savedFeedList = [];
	var savedColumnList = [];
	var savedRuleList = [];
	var feeds = columnStatList = [];
	var cStonefeeds = [];
	var	cStoneColumnStatList = [];
	var columns, rules, stats, startdate, enddate, feedID, feedName, reqFeedName, userID, reqFeedId, reqColumnId, fileFormat,cStoneColumns;
	return {
		setFeedList: function(feedlist) {
			feeds = feedlist;
		},
	
		getFeedList: function() {
			return feeds;
		},
		setFeedID: function(id) {
			feedID = id;
		},
		setReqFeedID: function(id) {
			reqFeedId = id;
		},
		setReqColumnId: function(id) {
			reqColumnId = id;
		},
		setColumnStatDataSet: function(list) {
			columnStatList = list;
		},
		getFeedID: function() {
			return feedID;
		},
		getReqFeedID: function() {
			return reqFeedId;
		},
		getReqColumnId: function() {
			return reqColumnId;
		},
		setFeedName: function(name) {
			feedName = name;
		},
		setFileFormat: function(format) {
			fileFormat = format;
	    },
		getFeedName: function() {
			return feedName;
		},
		setReqFeedName: function(name) {
			reqFeedName = name;
		},
		getReqFeedName: function() {
			return reqFeedName;
		},
		setUserID: function(userid) {
			userID = userid;
		},
		getUserID: function() {
			return userID;
		},
		getColumnList: function(feedID) {
			angular.forEach(feeds, function(key,val) {
			if (key.feedID == feedID) {
            	columns = key.columnList;
        	}  
			});
			return columns;
		},
		getStatsList: function(feedID, columnID) {
			angular.forEach(feeds, function(key,val) {
				if (key.feedID == feedID) {
	            	angular.forEach(key.columnList, function(key1,val1) {
	            		if (key1.columnID == columnID) {
	            			stats = key1.statsList;
	        			}
	        		});  
	        	}
			});			
			return stats;
		},
		getRuleList: function(feedID, columnID) {
			angular.forEach(feeds, function(key,val) {
				if (key.feedID == feedID) {
	            	angular.forEach(key.columnList, function(key1,val1) {
	            		if (key1.columnID == columnID) {
	            			rules = key1.ruleList;
	        			}
	        		});  
	        	}
			});			
			return rules;
		},
		getWidth: function() {
        	return $(window).width();
	    },

	    getHeight: function() {
	        return $(window).height();
	    },
	    setEndDate: function(date) {
	    	enddate = date;
	    },
	    setStartDate: function(date) {
	    	startdate = date;
	    },
	    getEndDate: function() {
	    	return enddate;
	    },
	    getStartDate: function() {
	    	return startdate;
	    },
	    getFileFormat: function() {
	    	return fileFormat;
	    },
		updateContentHeight: function() {
			
			$timeout(function() {
	        	var header = $(".headerblock");
				//var tabbar = $(".tabbar");
				//var toolbar = $(".toolbar");
				//var captionbar = $(".captionbar");
				//var footer = $(".footer");

				if( $(".headerblock").css('display') != 'none' ) {
				var headerHeight = $(header).outerHeight();
				} else {
					var headerHeight = 0;
				}	

				/*if( $(".tabbar").css('display') != 'none' ) {
				var tabbarHeight = $(tabbar).outerHeight();
			}else{var tabbarHeight = 0;}

			if( $(".toolbar").css('display') != 'none' ) {
				var toolBarHeight = $(toolbar).outerHeight();
			}else{var toolBarHeight = 0;}

			if( $(".captionbar").css('display') != 'none' ) {
				var captionbarHeight = $(captionbar).outerHeight();
			}else{var captionbarHeight = 0;}


			if( $(".footer").css('display') != 'none' ) {
				var footerHeight = $(footer).outerHeight();
			}else{var footerHeight = 0;}*/

				
				var windowHeight = $(window).height(); // returns height of browser viewport
				
				var contentHeight = windowHeight - headerHeight;
				
				//$('.toolbar').css("top", headerHeight + "px");
				
				//$('.tabbar').css("top", (headerHeight + tabbarHeight) + "px");	

				//$('.captionbar').css("top", (headerHeight + tabbarHeight + toolBarHeight) + "px");	
				
				//$('.modelDiv').css("top", parseInt(headerHeight + tabbarHeight + toolBarHeight + captionbarHeight) + "px");
				//$('.modelDiv').css("top", parseInt(headerHeight) + "px");

				//$('.modelDiv').height(contentHeight-31);
				
				//$('.footer').css("margin-top", windowHeight - parseInt((headerHeight + toolBarHeight + tabbarHeight + footerHeight + captionbarHeight)) + "px");

			}, 0);
		}, 
		getPastRuns: function() {
			var pastruns = [
				{"id":"10", "value":"10"},
				{"id":"20", "value":"20"},
				{"id":"30", "value":"30"},
				{"id":"40", "value":"40"},
				{"id":"50", "value":"50"},
				{"id":"60", "value":"60"},
				{"id":"70", "value":"70"},
				{"id":"80", "value":"80"},
				{"id":"90", "value":"90"}
			];
			return pastruns;

		},
		getFileDelimiter: function() {
			var fileDelimiter = [
				{"id":"comma", "value":"COMMA"},
				{"id":"ctrlA", "value":"CONTROL-A"},
				{"id":"pipe", "value":"PIPE"},
				{"id":"space", "value":"SPACE"},
				{"id":"tab", "value":"TAB"},
				{"id":"caret", "value":"CARET"},
				{"id":"exclamation", "value":"EXCLAMATION MARK"},
				{"id":"colon", "value":"COLON"},
				{"id":"question", "value":"QUESTION MARK"}
			];
			return fileDelimiter;
		},
		getRecordDelimiter: function() {
			var recordDelimiter = [
				{"id":"1", "value":"New Line"}
			];
			return recordDelimiter;
		},
		getDataTypeList: function() {
			var dataType = [
				{"id":"integer", "name":"integer"},
				{"id":"smallint", "name":"smallint"},
				{"id":"tinyint", "name":"tinyint"},
				{"id":"int", "name":"int"},
				{"id":"bigint", "name":"bigint"},
				{"id":"datetime", "name":"datetime"},
				{"id":"date", "name":"date"},
				{"id":"string", "name":"string(x)"},
				{"id":"decimal", "name":"decimal(x,y)"}
			];
			return dataType;
		},
		getFixedDataTypeList: function() {
			var dataType = [
				{"id":"datetime", "name":"datetime"},
				{"id":"date", "name":"date"},
				{"id":"string", "name":"string(x)"},
				{"id":"decimal", "name":"decimal(x,y)"}
			];
			return dataType;
		},
		getStatsList: function() {
			var stats = [
				{"id":"#Data Type Hit", "name":"Data Type Hit"},
				{"id":"#Distinct Values", "name":"Distinct Values"},
				{"id":"#Null Values", "name":"Null Values"},
				{"id":"Average", "name":"Average"},
				{"id":"Record Count", "name":"Record Count"},
				{"id":"Min Value", "name":"Min Value"},
				{"id":"Max Value", "name":"Max Value"}
			];
			return stats;
		},
		getDateFormatList: function() {
			var stats = [
				{"id":"1", "name":"dd/mm/yyyy"},
				{"id":"2", "name":"DD-MM-YYYY"},
				{"id":"3", "name":"MM/DD/YYYY"},
				{"id":"4", "name":"D/M/Y"},
				{"id":"5", "name":"mm-dd-yyyy"}
			];
			return stats;
		},
		getColumnStatDataSet: function() {
			return columnStatList;
		},
		showErrorMessage: function(message, title, type) {
	        ModalService.showModal({
			    templateUrl: 'modal.html',
			    controller: "ModalController",
					inputs: {
			        title: title,
			        message: message,
			        alertType: type        
			    }
			}).then(function(modal) {
			    modal.element.modal();
			     modal.close.then(function(result) {
			     	
			    });
			});
    	},
    	getWeekDays: function() {
			var weekDay = [
				{"id":"0", "name":"Sunday"},
				{"id":"1", "name":"Monday"},
				{"id":"2", "name":"Tuesday"},
				{"id":"3", "name":"Wednesday"},
				{"id":"4", "name":"Thursday"},
				{"id":"5", "name":"Friday"},
				{"id":"6", "name":"Saturday"},
				{"id":"7", "name":"Weekends"}
			];
			return weekDay;
		},
		getDateOfMonth: function() {
			var dateMonth = [];
			for (var i = 1; i <= 28; i++) {
				dateMonth.push(i.toString());
			}
			dateMonth.push("Last Day of Month");
			//dateMonth.push("First Day of Month");
			return dateMonth;
		},
		setCStoneFeedList: function(feedlist) {
			cStonefeeds = feedlist;
		},
	
		getCStoneFeedList: function() {
			return cStonefeeds;
		},
		setCStoneColumnStatDataSet: function(columnStateList) {
			cStoneColumnStatList = columnStateList;
		},
	
		getCStoneColumnStatDataSet: function() {
			return cStoneColumnStatList;
		}

	}
	
}]);