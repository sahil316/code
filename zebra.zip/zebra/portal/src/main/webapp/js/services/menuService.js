'use strict';

zebra.factory('menuService', ['$location', function ($location) {
    // Service logic
    // ...
    var path = '';
    var pathArray = [];
    var mainMenu = [];
    var activeItem = '';

    // Public API here
    return {
      getUrl: function () {
        return $location.path();
      },
      getUrlParts: function (index) {
        path = this.getUrl();
        pathArray = path.split('/');
        if (isNaN(index)) {
          return pathArray;
        } else {
          return pathArray[index];
        }
      },
      getMainMenu: function () {
        return mainMenu;
      },
      setMainMenu: function (data) {
        mainMenu = data;
      },
      getActiveItem: function () {
        return activeItem;
      },
      setActiveItem: function (data) {
        activeItem = data;
      }
    };
  }]);
