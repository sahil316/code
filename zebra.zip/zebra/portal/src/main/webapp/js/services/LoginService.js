'use strict';

zebra.factory('loginService', ['$http', '$rootScope', '$location', '$filter', 'servicesUrl',
        function ($http, $rootScope, $location, $filter, servicesUrl) {
    // Service logic
    var currentUser = null;
    var userInfo = {};
    userInfo.isSessionExist = false;
    var isLoggedIn = false;
    var userTempName = '';
    var userId;
    var userList = [];  // Array for holding the list of users from config file
    var idleTime = 0;   // To track time in minutes for which system remain idle
    var idleTimeoutInterval = 0;

    // Public API here
    return {
        getLoginStatus: function () {
            return isLoggedIn;
        },
        getUserId: function () {
            return userId;
        },
      
        userName: function () {
            return userTempName;
        },
        // Getter/Setter for list of users to be read from config file
        setUserList: function (users) {
            userList = users;
        },
        // Get timeout interval
        setTimeoutInterval: function (interval) {
            idleTimeoutInterval = interval;
        },
         userLogin: function (data) {
            var loginData = angular.fromJson(data); 
            var userData = 'j_username='+loginData.username+'&j_password='+loginData.password;
           
            $http.post(servicesUrl.getLoginUrl, userData, {
              headers: { 'Content-Type': 'application/x-www-form-urlencoded;'}
            }).success(function (data) {
                if (data === loginData.username) {
                    isLoggedIn = true;                    
                    userInfo.userId = loginData.username;
                    userInfo.userTempName = loginData.password;
                    currentUser = userInfo;
                    userInfo.isSessionExist = true;
                    window.localStorage.setItem('userInfo', JSON.stringify(currentUser));
                    $rootScope.$broadcast('event:auth-loginConfirmed');
                }
                else {
                    isLoggedIn = false;
                    userInfo.userId = '';
                    userInfo.userTempName = '';
                    $rootScope.$broadcast('event:auth-loginFailed');
                 
                }
              
              }).error(function () {
                $rootScope.$broadcast('event:auth-loginServiceError');
              });
        },
        userLogout: function () {
            
            $http.get(servicesUrl.getLogoutUrl, {
              headers: { 'Content-Type': 'application/x-www-form-urlencoded;'}
            }).success(function (data) {
                    if(!angular.isUndefined(window.localStorage.getItem('userInfo')) && window.localStorage.getItem('userInfo') != null){
                       userInfo = JSON.parse(window.localStorage.getItem('userInfo'));
                        }
                        isLoggedIn = false;
                        userInfo.isSessionExist = false;
                        window.localStorage.removeItem('userInfo');
                        $rootScope.$broadcast('event:auth-logoutConfirmed');   
                        
                      }).error(function () {
                        $rootScope.$broadcast('event:auth-loginServiceError');
                      });

                   
                    
                       
        },
        startTimer: function() {
            //Increment the idle time counter every minute.
            var idleInterval = setInterval (function () {
                idleTime = idleTime + 1;
                if (idleTime >= idleTimeoutInterval) { // 30 minutes
                    alert('Your session has expired. Please login again.');
                    isLoggedIn = false;
                    userTempName = '';
                    idleTime = 0;
                    $rootScope.$broadcast('event:auth-logoutConfirmed');
                    clearInterval(idleInterval);    // Clear the interval
                    window.location.reload();
                    this.userLogout();
                }
            }, 60000); // 1 minute
        },
        setTimer: function(val) {
            idleTime = val;
        }
    };
  }]);