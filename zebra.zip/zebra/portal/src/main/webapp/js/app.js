'use strict';

var zebra = angular.module('zebra', ['ui', 'ngRoute', 'ngResource', 'ui.bootstrap', 'ngCookies', 'ngAnimate', 'angularModalService', 'ngFileUpload', 'angularFileUpload']);
zebra.config(['$routeProvider', '$httpProvider', function($routeProvider, $httpProvider) {

    $routeProvider.
        when('/', {
            templateUrl: 'partials/login.html',
            access: {
                requireLogin: true
            }
        })
        .when('/feed', {
            templateUrl: 'partials/modeler/feed.html',
            header: 'partials/header/headerAfterLogin.html',
            footer: 'partials/footer/footerAfterLogin.html',
            access: {
                requireLogin: true
            }
        })
        .when('/column', {
            templateUrl: 'partials/modeler/column.html',
            header: 'partials/header/headerAfterLogin.html',
            footer: 'partials/footer/footerAfterLogin.html',
            access: {
                requireLogin: true
            }
        })
        .when('/report', {
            templateUrl: 'partials/modeler/report.html',
            header: 'partials/header/headerAfterLogin.html',
            footer: 'partials/footer/footerAfterLogin.html',
            access: {
                requireLogin: true
            }
        })
        .when('/trending', {
            templateUrl: 'partials/modeler/trend.html',
            header: 'partials/header/headerAfterLogin.html',
            footer: 'partials/footer/footerAfterLogin.html',
            access: {
                requireLogin: true
            }
        })
        .when('/help', {
            templateUrl: 'partials/modeler/help.html',
            header: 'partials/header/headerAfterLogin.html',
            footer: 'partials/footer/footerAfterLogin.html',
            access: {
                requireLogin: true
            }
        })
		.when('/cornerstone', {
            templateUrl: 'partials/modeler/cornerstone.html',
            header: 'partials/header/headerAfterLogin.html',
            footer: 'partials/footer/footerAfterLogin.html',
            access: {
                requireLogin: true
            }
        })
        .otherwise({redirectTo: '/feed'});

        $httpProvider.interceptors.push('InterceptorService');
}])
    //Services URL API
    .factory('servicesUrl', ['$rootScope', '$location', function ($rootScope, $location) {
        var baseUrl = $location.protocol() + '://' + $location.host() + ':' + $location.port();

        // Path of application
        var appUrl = $location.absUrl();
        appUrl = baseUrl + '/${portal.context}';

        var sampleDataPath = appUrl + '/sampledata/';
       // var servicePath = '/cornerstone-app/services/rest/';

        // Global Variables for Service Urls
        return {
            // Applicatin Url
            getAppUrl: appUrl,
            getSampleDataPath: sampleDataPath,
            getConfigUrl: sampleDataPath + 'config.json',
            authenticateUrl: '',

            getLoginUrl: appUrl + '/j_spring_security_check',
            getLogoutUrl: appUrl + '/j_spring_security_logout', 

            // Report Page
            getReportUrl: appUrl + '/stats_report/',//sampleDataPath + 'tree.json',
           
            getFeedListUrl: appUrl + '/feed_column_list/',//sampleDataPath + 'feedList.json',
			
			getAllFeedsIdsListUrl: appUrl + '/feed_list/',
			
            submitFeedMetadataUrl: appUrl + '/register_feed/', //sampleDataPath + 'status.json',
            updateFeedMetadataUrl: appUrl + '/update_feed_md/',
            submitColumnMetadataUrl: appUrl + '/register_column/',//sampleDataPath + 'status.json',
            updateColumnMetadataUrl: appUrl + '/update_column_md/',

            getFeedEditUrl: appUrl + '/fetch_feed_md/', //feed_response.json',
            getColumnEditUrl: appUrl + '/fetch_column_md/', //column_response.json',
            getColumnsRulesUrl: appUrl + '/fetch_columns_rules/',
            /*Trending page*/
            loadColumnStatsGraphUrl: appUrl + '/stats_trend/',//sampleDataPath + 'fusion_chart_column_stats.json',
            loadColumnRulesGraphUrl: appUrl + '/stats_trend/',
            loadFeedGraphUrl: appUrl + '/stats_trend/', //sampleDataPath + 'fusion_chart_feed.json'
         
            columnUpload: appUrl + '/upload_column_md',
            /*CornerStone page URLs*/
            getCSFeedListUrl: appUrl + '/cstone_storage_list/',//sampleDataPath + 'CStone_Feed_List.json',
            loadCSFeedGraphUrl:appUrl + '/cstone_stats_trend/',// sampleDataPath + 'CStone_Feed_Stats.json',
            loadCStoneColumnStatsGraphUrl: appUrl + '/cstone_stats_trend/'// sampleDataPath + 'CStone_Feed_Stats.json', sampleDataPath + 'CStone_Column_Stats.json'
        }
    }])

zebra.run(['$location', '$rootScope', '$cookieStore', function ($location, $rootScope, $cookieStore) {
    
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        // to load partial views
        $rootScope.layoutPartial = function (partialName) {
            return current[partialName];
        };
    });

}]);