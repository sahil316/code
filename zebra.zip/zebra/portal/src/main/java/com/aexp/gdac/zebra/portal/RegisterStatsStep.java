package com.aexp.gdac.zebra.portal;

import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;

public class RegisterStatsStep {
	private final static Logger logger = Logger.getLogger(RegisterFeedMetadataStep.class);
	private StatsDAO statsDAO ;
	
	public RegisterStatsStep(){
		this.statsDAO = (StatsDAO)ZebraResourceManager.getBean("statsDAO");
	}
	
	public StatusJO registerStats(StatsRegisterRequestJO statsRegReqJo) throws ZebraPortalException{
		logger.info("Register Stats Request:-"+statsRegReqJo);
		try{
			Stats stat = new Stats();
			stat.setFeedID(Long.parseLong(statsRegReqJo.getFeedID()));
			stat.setFeedName(statsRegReqJo.getFeedName());
			stat.setInputFilePath(statsRegReqJo.getInputFilePath());
			stat.setRunDate(generateTimeStamp(statsRegReqJo.getRunDate()));
			stat.setUserID(statsRegReqJo.getUserID());
			stat.setCreated(new Timestamp(new Date().getTime()));
			
			if("true".equalsIgnoreCase(statsRegReqJo.getUpdateProcessedDate())){
				stat.setProcessDate(new Timestamp(new Date().getTime()));
			}
			
			statsDAO.create(stat);
			
			
			return new StatusJO(""+statsRegReqJo.getFeedID(),statsRegReqJo.getFeedName(),
					statsRegReqJo.getUserID(),StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Feed Stats") ;
			
		}catch(ZebraServiceException zse){
			throw new ZebraPortalException("Exception Occured while inseting Stats ",ZebraPortalException.Reason.STATS_REGISTER_EXCEPTION);
		}catch(NumberFormatException nfe){
			throw new ZebraPortalException("FeedID is not a number ",ZebraPortalException.Reason.STATS_REGISTER_EXCEPTION);
		}
	}
	
	
	private static java.sql.Timestamp generateTimeStamp(String runDate)throws ZebraPortalException{
		try{
			return java.sql.Timestamp.valueOf(runDate+" "+"00:00:00");
		}catch(NumberFormatException nfe){
			throw new ZebraPortalException("RunDate format must be yyyy-mm-dd",ZebraPortalException.Reason.STATS_REGISTER_EXCEPTION);
		}catch(java.lang.IllegalArgumentException iae){
			throw new ZebraPortalException("RunDate format must be yyyy-mm-dd",ZebraPortalException.Reason.STATS_REGISTER_EXCEPTION);
		}
	}
	
	private static void assertMandatoryFields(StatsRegisterRequestJO statsRegReqJo)throws ZebraPortalException{
		if(statsRegReqJo.getFeedID()==null || statsRegReqJo.getFeedID().trim().isEmpty()
				|| statsRegReqJo.getInputFilePath() == null || statsRegReqJo.getInputFilePath().trim().isEmpty()
				|| statsRegReqJo.getRunDate() == null || statsRegReqJo.getRunDate().trim().isEmpty()
				|| statsRegReqJo.getUserID() == null || statsRegReqJo.getUserID().trim().isEmpty()){
			throw new ZebraPortalException("Mandatory fields missing (FeedID,InputFilePath,RunDate,UserID)",ZebraPortalException.Reason.STATS_REGISTER_EXCEPTION);
		}
	}
}
