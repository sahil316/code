package com.aexp.gdac.zebra.portal.json;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.Action;
import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneIngestionFeeDQMStatistics;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneStorage;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneStorageAttribute;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageDetailJO.CStoneStorageInfoJO;
import com.aexp.gdac.zebra.common.json.model.ColumnMetadataJO;
import com.aexp.gdac.zebra.common.json.model.ColumnRuleMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FeedStatsBranchJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.ColumnInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.ColumnRuleInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.FeedInfoJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendJO.DataJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendJO.TrendJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageStatsJO.StorageStatDataJO;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageAttrJO;
import com.aexp.gdac.zebra.portal.ZebraPortalException;

public class JsonMapper {
	
	private final static Logger logger = Logger.getLogger(JsonMapper.class);
	
	private static final String DEFAULT_TIME_STAMP = "9999-12-31 00:00:00";
	public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
	private static final String MIN_ABORT_THRESHOLD_TEXT ="Min Abort Threshold";
	private static final String MAX_ABORT_THRESHOLD_TEXT ="Max Abort Threshold";
	private static final String MIN_ALERT_THRESHOLD_TEXT ="Min Alert Threshold";
	private static final String MAX_ALERT_THRESHOLD_TEXT ="Max Alert Threshold";
	private static final String VOLUME_TEXT ="Volume";
		
	private static final String DATA_TYPE_HIT_TEXT ="Data Type Hit";
	private static final String DISTINCT_VALUES_TEXT ="Distinct Values";
	private static final String NULL_VALUE_TEXT ="Null Values";
	private static final String AVERAGE_VALUES_TEXT ="Average";
	private static final String RECORD_COUNT_TEXT = "Record Count";
	private static final String MIN_VALUE_TEXT = "Min Value";
	private static final String MAX_VALUE_TEXT = "Max Value";

	
	
	
	public static FeedMetadata mapToFeedMetadata(FeedMetadataJO feedMdJo,String userId) throws ZebraPortalException{
		
		FeedMetadata feedMD = new FeedMetadata();
		
		logger.info("FeedMetadataJo :-"+feedMdJo);
		
		if(feedMdJo.getFeed_Id() != null ){
			feedMD.setFeedID(Long.parseLong(feedMdJo.getFeed_Id()));
		}
		
		feedMD.setFeedName(feedMdJo.getFeed_name());
		feedMD.setFileFormat(feedMdJo.getFile_format());
		feedMD.setFrequency(feedMdJo.getFeed_frequency());
		feedMD.setColumnDelimiter(feedMdJo.getFile_format_delimited());
		feedMD.setRecordDelimiter(feedMdJo.getRecord_delimiter());
		feedMD.setHeader(feedMdJo.getFileHeader());
		feedMD.setTailer(feedMdJo.getFileTrailer());
		
		if((feedMdJo.getPast_runs() != null && !feedMdJo.getPast_runs().trim().isEmpty())){
			feedMD.setPastRuns(Integer.parseInt(feedMdJo.getPast_runs()));
		}
		
		feedMD.setThresholdType((feedMdJo.getThreshold_type() == null || feedMdJo.getThreshold_type().trim().isEmpty())?null:feedMdJo.getThreshold_type());
		feedMD.setMaxAbortThreshold((feedMdJo.getAbort_threshold_max() == null || feedMdJo.getAbort_threshold_max().trim().isEmpty())?null:Double.parseDouble(feedMdJo.getAbort_threshold_max()));
		feedMD.setMinAbortThreshold((feedMdJo.getAbort_threshold_min() == null || feedMdJo.getAbort_threshold_min().trim().isEmpty())?null:Double.parseDouble(feedMdJo.getAbort_threshold_min()));
		feedMD.setMinAlertThreshold((feedMdJo.getAlert_threshold_min() == null || feedMdJo.getAlert_threshold_min().trim().isEmpty())?null:Double.parseDouble(feedMdJo.getAlert_threshold_min())); 
		feedMD.setMaxAlertThreshold((feedMdJo.getAlert_threshold_max() == null || feedMdJo.getAlert_threshold_max().trim().isEmpty())?null:Double.parseDouble(feedMdJo.getAlert_threshold_max()));
		
		if(userId == null || userId.isEmpty()){
			feedMD.setUserID(feedMdJo.getUser_id());
		}else {
			feedMD.setUserID(userId);
		}
		
		
		
		/* map for ticket robo*/
		if(Boolean.parseBoolean(feedMdJo.getTicketRobo()) &&
				feedMdJo.getrGrp() != null && !feedMdJo.getrGrp().trim().isEmpty() &&
				feedMdJo.getaGrp() != null && !feedMdJo.getaGrp().trim().isEmpty()){
			feedMD.setTicketRobo(feedMdJo.getTicketRobo());
			feedMD.setRGRP(feedMdJo.getrGrp());
			feedMD.setAGRP(feedMdJo.getaGrp());
			
		}else {
			feedMD.setTicketRobo("false");
		}
		
		// converting colan separated email ids to comma separated email ids
		
		if(feedMdJo.getEmail_id() != null){
			feedMD.setEmailID(feedMdJo.getEmail_id().replace(';', ','));
		}
		
		if(feedMdJo.getStart_date() == null || feedMdJo.getStart_date().trim().isEmpty()){
			
			feedMD.setStartDate(new java.sql.Timestamp(new java.util.Date().getTime()));	
		}else{
			try {
				feedMD.setStartDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(feedMdJo.getStart_date())).getTime()));
			} catch (ParseException e) {
				throw new ZebraPortalException("Exception occured while parsing start date",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
			}
		}
		
		if(feedMdJo.getEnd_date() == null || feedMdJo.getEnd_date().trim().isEmpty()){
			
			feedMD.setEndDate(Timestamp.valueOf(DEFAULT_TIME_STAMP));
			
		} else{
			try {
				feedMD.setEndDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(feedMdJo.getEnd_date())).getTime()));
			} catch (ParseException e) {
				throw new ZebraPortalException("Exception occured while parsing end date",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
			}
		}
		
		return feedMD;
	}
	
	public static FeedStatsBranchJO mapToFeedLevelStatsJo(FeedStats feedStats, String statsName) throws ZebraPortalException{
		
		FeedStatsBranchJO statsBranchJO = new FeedStatsBranchJO();
		try {

			statsBranchJO.setName(statsName);
			statsBranchJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			statsBranchJO.setText(""+ feedStats.getStateID());
			statsBranchJO.setParent(""+feedStats.getStateID());

			FeedStatsBranchJO feedInfoChildJO = new FeedStatsBranchJO();
			feedInfoChildJO.setName("Feed Action:" + feedStats.getAction());
			feedInfoChildJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			feedInfoChildJO.setParent(""+feedStats.getStateID());


			// threshold and volume child
			FeedStatsBranchJO minAbortThresholdJO = new FeedStatsBranchJO();
			minAbortThresholdJO.setName("Min Abort Threshold Value : "+CommonMethods.formatDouble2Decimals( feedStats.getMinAbortThresholdVal()));
			minAbortThresholdJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			minAbortThresholdJO.setParent(""+feedStats.getStateID());
			feedInfoChildJO.addBranchStatsJO(minAbortThresholdJO);

			FeedStatsBranchJO minAlertThresholdJO = new FeedStatsBranchJO();
			minAlertThresholdJO.setName("Min Alert Threshold Value : "+CommonMethods.formatDouble2Decimals(feedStats.getMinAlertThresholdVal()));
			minAlertThresholdJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			minAlertThresholdJO.setParent(""+feedStats.getStateID());
			feedInfoChildJO.addBranchStatsJO(minAlertThresholdJO);

			FeedStatsBranchJO feedVolJO = new FeedStatsBranchJO();
			feedVolJO.setName("Feed Volume:" + feedStats.getVolume());
			feedVolJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			feedVolJO.setParent(""+feedStats.getStateID());
			feedInfoChildJO.addBranchStatsJO(feedVolJO);

			FeedStatsBranchJO maxAlertThresholdJO = new FeedStatsBranchJO();
			maxAlertThresholdJO.setName("Max Alert Threshold Value : "+ CommonMethods.formatDouble2Decimals(feedStats.getMaxAlertThresholdVal()));
			maxAlertThresholdJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			maxAlertThresholdJO.setParent(""+feedStats.getStateID());
			feedInfoChildJO.addBranchStatsJO(maxAlertThresholdJO);

			FeedStatsBranchJO maxAbortThresholdJO = new FeedStatsBranchJO();
			maxAbortThresholdJO.setName("Max Abort Threshold Value : "+CommonMethods.formatDouble2Decimals(feedStats.getMaxAbortThresholdVal()));
			maxAbortThresholdJO.setStatus(Action.valueOf(feedStats.getAction()).getActoinCode());
			maxAbortThresholdJO.setParent(""+feedStats.getStateID());
			feedInfoChildJO.addBranchStatsJO(maxAbortThresholdJO);
			
			statsBranchJO.addBranchStatsJO(feedInfoChildJO);

			FeedStatsBranchJO columnsChildJO = new FeedStatsBranchJO();
			columnsChildJO.setName("Column Action:");
			columnsChildJO.setParent(""+feedStats.getStateID());
			// columnsChildJO.setStatus();
			// columnsChildJO.setText(""); // tool tip text

			statsBranchJO.addBranchStatsJO(columnsChildJO);
		} catch (Exception e) {
			throw new ZebraPortalException(ZebraPortalException.Reason.FEED_STATS_TREE_EXCEPTION, e);
		}
		return statsBranchJO;
	}
	
	
	public static FeedStatsBranchJO mapToColulmnLevelStatsJo(ColumnStats colStats) throws ZebraPortalException{
		FeedStatsBranchJO colStatsBranchJO = new FeedStatsBranchJO();
		try{
			colStatsBranchJO.setName(colStats.getColumnName());
			colStatsBranchJO.setParent(""+colStats.getStateID());
			colStatsBranchJO.setStatus(Action.valueOf(colStats.getAction()).getActoinCode());
			colStatsBranchJO.setText("Distinct Values:"+colStats.getCountDistinctvalues()+", Null Values Count:"+colStats.getCountNullValues() +
				", Average:"+colStats.getAverage() + ", Data type hit:" +colStats.getDataTypeHit() + ", Record Count:"+colStats.getRecordCount() + ", Min Value:"+ colStats.getMinValue()
				+ ", Max Value: "+ colStats.getMaxValue());
		}catch(Exception e){
			throw new ZebraPortalException(ZebraPortalException.Reason.FEED_STATS_TREE_EXCEPTION,e);
		}
		
		return colStatsBranchJO;
	}
	
	
	public static FeedStatsBranchJO mapToColumnRuleLevelStatsJo(ColumnRuleStats colRuleStats) throws ZebraPortalException{
		
		FeedStatsBranchJO colRuleStatsBranchJO = new FeedStatsBranchJO();
		try{
			colRuleStatsBranchJO.setName("Rule:"+RuleCodeConstants.ruleCodeTextMap.get(""+colRuleStats.getRuleID()) +", Hit Count:"+colRuleStats.getDecisionCount());
			colRuleStatsBranchJO.setStatus(Action.valueOf(colRuleStats.getAction()).getActoinCode());
			colRuleStatsBranchJO.setParent(""+colRuleStats.getStateID());
			colRuleStatsBranchJO.setText("");
		}catch(Exception e){
			throw new ZebraPortalException(ZebraPortalException.Reason.FEED_STATS_TREE_EXCEPTION,e);
		}
		return colRuleStatsBranchJO;
	}
	
	public static ColumnMetadata mapToExistingFeedColumnMetadata(ColumnMetadataJO colMdJo, FeedMetadata currentFeed, String userID) throws ZebraPortalException{
		ColumnMetadata colMd = new ColumnMetadata();
		colMd.setColumnID((colMdJo.getColumnID()==null || colMdJo.getColumnID().toString().isEmpty())?null:Long.parseLong(colMdJo.getColumnID()));
		colMd.setFeedID(currentFeed.getFeedID());
		colMd.setFeedName(currentFeed.getFeedName());
		if(userID == null || userID.isEmpty()){
			colMd.setUserID(colMdJo.getUserID());
		}else{
			colMd.setUserID(userID);
		}
		
		colMd.setColumnName(colMdJo.getColumnName());
		colMd.setDataFormat(colMdJo.getDataFormat());
		colMd.setDataType(colMdJo.getDataType());
		try {
			if(colMdJo.getStartDate() == null || colMdJo.getStartDate().trim().isEmpty()){
				//colMd.setStartDate(new Timestamp(new Date().getTime()));
				//here we need to set column metadata start date to current feed start date.
				colMd.setStartDate(currentFeed.getStartDate());
			}else{
				/*try{
					colMd.setStartDate(Timestamp.valueOf(colMdJo.getStartDate()));
				}catch (java.lang.IllegalArgumentException e) {
					logger.info("Couldnt parse date "+colMdJo.getStartDate()+", trying different format MM/dd/yyyy");
				}*/
				colMd.setStartDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(colMdJo.getStartDate()).getTime())));
			}
		} catch (ParseException e) {
			throw new ZebraPortalException("Exception occured while parsing end date",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
		
		if(colMdJo.getEndDate() == null || colMdJo.getEndDate().trim().isEmpty()){
			//colMd.setEndDate(Timestamp.valueOf(DEFAULT_TIME_STAMP));
			//here we need to set colMd end date to end date of corresponding feed metadata end date
			colMd.setEndDate(currentFeed.getEndDate());
		}else{
			/*try{
				colMd.setEndDate(Timestamp.valueOf(colMdJo.getEndDate()));
			}catch (java.lang.IllegalArgumentException e) {
				logger.info("Couldnt parse date "+colMdJo.getEndDate()+" , trying different format MM/dd/yyyy");
			}*/
			try {
				colMd.setEndDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(colMdJo.getEndDate())).getTime()));
			} catch (ParseException e) {
				throw new ZebraPortalException("Exception occured while parsing end date",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
			}
		}
		
		//colMd.setUserID(colMdJo.getUserId());
		
		
		return colMd;
	}

	

	public static ColumnMetadata mapToColumnMetadata(ColumnMetadataJO colMdJo,long feedID, String feedName, String userID) throws ZebraPortalException{
		ColumnMetadata colMd = new ColumnMetadata();
		colMd.setColumnID((colMdJo.getColumnID()==null || colMdJo.getColumnID().toString().isEmpty())?null:Long.parseLong(colMdJo.getColumnID()));
		colMd.setFeedID(feedID);
		colMd.setFeedName(feedName);
		if(userID == null || userID.isEmpty()){
			colMd.setUserID(colMdJo.getUserID());
		}else{
			colMd.setUserID(userID);
		}
		
		colMd.setColumnName(colMdJo.getColumnName());
		colMd.setDataFormat(colMdJo.getDataFormat());
		colMd.setDataType(colMdJo.getDataType());
		try {
			if(colMdJo.getStartDate() == null || colMdJo.getStartDate().trim().isEmpty()){
				colMd.setStartDate(new Timestamp(new Date().getTime()));
			}else{
				/*try{
					colMd.setStartDate(Timestamp.valueOf(colMdJo.getStartDate()));
				}catch (java.lang.IllegalArgumentException e) {
					logger.info("Couldnt parse date "+colMdJo.getStartDate()+", trying different format MM/dd/yyyy");
				}*/
				colMd.setStartDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(colMdJo.getStartDate()).getTime())));
			}
		} catch (ParseException e) {
			throw new ZebraPortalException("Exception occured while parsing end date",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
		
		if(colMdJo.getEndDate() == null || colMdJo.getEndDate().trim().isEmpty()){
			colMd.setEndDate(Timestamp.valueOf(DEFAULT_TIME_STAMP));
		}else{
			/*try{
				colMd.setEndDate(Timestamp.valueOf(colMdJo.getEndDate()));
			}catch (java.lang.IllegalArgumentException e) {
				logger.info("Couldnt parse date "+colMdJo.getEndDate()+" , trying different format MM/dd/yyyy");
			}*/
			try {
				colMd.setEndDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(colMdJo.getEndDate())).getTime()));
			} catch (ParseException e) {
				throw new ZebraPortalException("Exception occured while parsing end date",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
			}
		}
		
		//colMd.setUserID(colMdJo.getUserId());
		
		
		return colMd;
	}

	public static ColumnRuleMetadata mapToColumnRuleMetadata(ColumnRuleMetadataJO colRuleMdJo, long columnID, long feedID, String userID) throws ZebraPortalException{
		ColumnRuleMetadata colRuleMd = new ColumnRuleMetadata();
		
		colRuleMd.setColumnID(columnID);
		colRuleMd.setFeedID(feedID);
		if(userID == null || userID.isEmpty()){
			colRuleMd.setUserID(colRuleMdJo.getUserID());
		}else {
			colRuleMd.setUserID(userID);
		}
		
		colRuleMd.setMaxAbortThreshold((colRuleMdJo.getMaxAbortThreshold() == null || colRuleMdJo.getMaxAbortThreshold().trim().isEmpty())?null : Double.parseDouble(colRuleMdJo.getMaxAbortThreshold()));
		colRuleMd.setMinAbortThreshold((colRuleMdJo.getMinAbortThreshold() == null || colRuleMdJo.getMinAbortThreshold().trim().isEmpty())?null : Double.parseDouble(colRuleMdJo.getMinAbortThreshold()));
		colRuleMd.setMaxAlertThreshold((colRuleMdJo.getMaxAlertThreshold() == null || colRuleMdJo.getMaxAlertThreshold().trim().isEmpty())?null : Double.parseDouble(colRuleMdJo.getMaxAlertThreshold()));
		colRuleMd.setMinAlertThreshold((colRuleMdJo.getMinAlertThreshold() == null || colRuleMdJo.getMinAlertThreshold().trim().isEmpty())?null : Double.parseDouble(colRuleMdJo.getMinAlertThreshold()));
		colRuleMd.setThresholdType((colRuleMdJo.getThresholdType()==null || colRuleMdJo.getThresholdType().trim().isEmpty())?null:colRuleMdJo.getThresholdType());
		
		colRuleMd.setPastRuns((CommonMethods.isNullTextValue(colRuleMdJo.getPastRuns()) || colRuleMdJo.getPastRuns().trim().isEmpty())?null:Integer.parseInt(colRuleMdJo.getPastRuns()));
		colRuleMd.setRuleID(Long.parseLong(colRuleMdJo.getRuleID()));
		colRuleMd.setRuleParameter(colRuleMdJo.getRuleParameter());
		//colRuleMd.setUserID(colRuleMdJo.getUserID());
		
		try {
			if(colRuleMdJo.getStartDate() == null || colRuleMdJo.getStartDate().trim().isEmpty()){
				colRuleMd.setStartDate(new Timestamp(new Date().getTime()));
			}else {
				colRuleMd.setStartDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(colRuleMdJo.getStartDate()).getTime())));
			}
		} catch (ParseException e) {
			throw new ZebraPortalException("Exception occured while parsing end date for column rule",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
		
		if(colRuleMdJo.getEndDate() == null || colRuleMdJo.getEndDate().trim().isEmpty()){
			colRuleMd.setEndDate(Timestamp.valueOf(DEFAULT_TIME_STAMP));
		}else{
			try {
				colRuleMd.setEndDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(colRuleMdJo.getEndDate())).getTime()));
			} catch (ParseException e) {
				throw new ZebraPortalException("Exception occured while parsing end date for column rule",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
			}
		}
		
		return colRuleMd;
	}

	public static StatsTrendJO mapToStatsTrendJOFromFeedStats(List<FeedStats> feedStatsList){
		StatsTrendJO statsTrendJo = new StatsTrendJO();
		if(!feedStatsList.isEmpty()){
			statsTrendJo.setFeedID(""+((FeedStats)feedStatsList.get(0)).getFeedID());
		}
		statsTrendJo.setPastRuns(""+feedStatsList.size());
		
		TrendJO minAbortdataSet =  new TrendJO(MIN_ABORT_THRESHOLD_TEXT);
		TrendJO maxAbortdataSet =  new TrendJO(MAX_ABORT_THRESHOLD_TEXT);
		TrendJO minAlertdataSet =  new TrendJO(MIN_ALERT_THRESHOLD_TEXT);
		TrendJO maxAlertdataSet =  new TrendJO(MAX_ALERT_THRESHOLD_TEXT);
		TrendJO volume = new TrendJO(VOLUME_TEXT);

		
		
		for(TableValueObjectBase stat : feedStatsList){
			FeedStats feedStat = (FeedStats)stat;
			
			minAbortdataSet.addData(new DataJO(""+feedStat.getMinAbortThresholdVal()));
			maxAbortdataSet.addData(new DataJO(""+feedStat.getMaxAbortThresholdVal()));
			minAlertdataSet.addData(new DataJO(""+feedStat.getMinAlertThresholdVal()));
			maxAlertdataSet.addData(new DataJO(""+feedStat.getMaxAlertThresholdVal()));
			volume.addData(new DataJO(""+feedStat.getVolume()));
			
		}
		
		statsTrendJo.addDataSet(volume);
		statsTrendJo.addDataSet(maxAlertdataSet);
		statsTrendJo.addDataSet(minAlertdataSet);
		statsTrendJo.addDataSet(maxAbortdataSet);
		statsTrendJo.addDataSet(minAbortdataSet);
		
		
		return statsTrendJo;
	}
	
	public static StatsTrendJO mapToStatsTrendJOFromColumnRuleStats(List<ColumnRuleStats> colRuleStatsList){
		StatsTrendJO statsTrendJo = new StatsTrendJO();
		if(!colRuleStatsList.isEmpty()) {
			statsTrendJo.setFeedID(""+((ColumnRuleStats)colRuleStatsList.get(0)).getFeedID());
			statsTrendJo.setPastRuns(""+colRuleStatsList.size());
			statsTrendJo.setColumnID(""+((ColumnRuleStats)colRuleStatsList.get(0)).getColumnID());
			statsTrendJo.setRules(""+((ColumnRuleStats)colRuleStatsList.get(0)).getRuleID());
		}
	
		
		TrendJO minAbortdataSet =  new TrendJO(MIN_ABORT_THRESHOLD_TEXT);
		TrendJO maxAbortdataSet =  new TrendJO(MAX_ABORT_THRESHOLD_TEXT);
		TrendJO minAlertdataSet =  new TrendJO(MIN_ALERT_THRESHOLD_TEXT);
		TrendJO maxAlertdataSet =  new TrendJO(MAX_ALERT_THRESHOLD_TEXT);
		TrendJO decisionCount = new TrendJO(VOLUME_TEXT);

		
		
		for(TableValueObjectBase stat : colRuleStatsList){
			ColumnRuleStats colRuleStat = (ColumnRuleStats)stat;
			
			minAbortdataSet.addData(new DataJO(""+colRuleStat.getMinAbortThresholdVal()));
			maxAbortdataSet.addData(new DataJO(""+colRuleStat.getMaxAbortThresholdVal()));
			minAlertdataSet.addData(new DataJO(""+colRuleStat.getMinAlertThresholdVal()));
			maxAlertdataSet.addData(new DataJO(""+colRuleStat.getMaxAlertThresholdVal()));
			decisionCount.addData(new DataJO(""+colRuleStat.getDecisionCount()));
			
		}
		
		statsTrendJo.addDataSet(decisionCount);
		statsTrendJo.addDataSet(maxAlertdataSet);
		statsTrendJo.addDataSet(minAlertdataSet);
		statsTrendJo.addDataSet(maxAbortdataSet);
		statsTrendJo.addDataSet(minAbortdataSet);
		
		
		return statsTrendJo;
	}
	
	public static StatsTrendJO mapToStatsTrendJOFromColumnStats(List<ColumnStats> colStatsList){
		StatsTrendJO statsTrendJo = new StatsTrendJO();
		if(!colStatsList.isEmpty()){
			statsTrendJo.setFeedID(""+((ColumnStats)colStatsList.get(0)).getFeedID());
			statsTrendJo.setPastRuns(""+colStatsList.size());
			statsTrendJo.setColumnID(""+((ColumnStats)colStatsList.get(0)).getColumnID());
		}
		
		TrendJO dataTypeHits =  new TrendJO(DATA_TYPE_HIT_TEXT);
		TrendJO distinctValues =  new TrendJO(DISTINCT_VALUES_TEXT);
		TrendJO nullValues =  new TrendJO(NULL_VALUE_TEXT);
		TrendJO average =  new TrendJO(AVERAGE_VALUES_TEXT);
		TrendJO recordCount = new TrendJO(RECORD_COUNT_TEXT);
		TrendJO minValueCount = new TrendJO(MIN_VALUE_TEXT);
		TrendJO maxValueCount = new TrendJO(MAX_VALUE_TEXT);


		
		for(TableValueObjectBase stat : colStatsList){
			ColumnStats colStat = (ColumnStats)stat;
			
			dataTypeHits.addData(new DataJO(""+colStat.getDataTypeHit()));
			distinctValues.addData(new DataJO(""+colStat.getCountDistinctvalues()));
			nullValues.addData(new DataJO(""+colStat.getCountNullValues()));
			average.addData(new DataJO(""+colStat.getAverage()));
			recordCount.addData(new DataJO(""+colStat.getRecordCount()));
			minValueCount.addData(new DataJO(""+colStat.getMinValue()));
			maxValueCount.addData(new DataJO(""+colStat.getMaxValue()));
			
		}
		
		statsTrendJo.addDataSet(dataTypeHits);
		statsTrendJo.addDataSet(distinctValues);
		statsTrendJo.addDataSet(nullValues);
		statsTrendJo.addDataSet(average);
		statsTrendJo.addDataSet(recordCount);
		statsTrendJo.addDataSet(minValueCount);
		statsTrendJo.addDataSet(maxValueCount);
		
		
		return statsTrendJo;
	}

	public static FeedInfoJO mapToFeedInfoJO(FeedMetadata feedMd){
		return new FeedInfoJO(""+feedMd.getFeedID(),feedMd.getFeedName());
	}
	
	public static ColumnInfoJO mapToColumnInfoJO(ColumnMetadata colMd){
		return new ColumnInfoJO(""+colMd.getColumnID(),colMd.getColumnName());
	}
	
	public static ColumnRuleInfoJO mapToColumnRuleInfoJO(ColumnRuleMetadata colRuleMd){
		return new ColumnRuleInfoJO(""+colRuleMd.getRuleID(),RuleCodeConstants.ruleCodeTextMap.get(""+colRuleMd.getRuleID()));
	}
	
	public static FeedMetadataJO mapToFeedMetadataJOFromFeedMetadata(FeedMetadata feedMd){
		FeedMetadataJO feedMdJo = new FeedMetadataJO();
		feedMdJo.setFeed_Id(""+feedMd.getFeedID());
		feedMdJo.setFeed_name(feedMd.getFeedName());
		feedMdJo.setFeed_frequency(feedMd.getFrequency());
		feedMdJo.setAbort_threshold_max((feedMd.getMaxAbortThreshold()==null) ? null : feedMd.getMaxAbortThreshold().toString());
		feedMdJo.setAlert_threshold_max((feedMd.getMaxAlertThreshold()==null) ? null : feedMd.getMaxAlertThreshold().toString());
		feedMdJo.setAbort_threshold_min((feedMd.getMinAbortThreshold()==null) ? null : feedMd.getMinAbortThreshold().toString());
		feedMdJo.setAlert_threshold_min((feedMd.getMinAlertThreshold()==null) ? null : feedMd.getMinAlertThreshold().toString());
		feedMdJo.setThreshold_type(feedMd.getThresholdType());
		feedMdJo.setFile_format(feedMd.getFileFormat());
		feedMdJo.setFile_format_delimited(feedMd.getColumnDelimiter());
		feedMdJo.setFileHeader(feedMd.getHeader());
		feedMdJo.setFileTrailer(feedMd.getTailer());
		feedMdJo.setRecord_delimiter(feedMd.getRecordDelimiter());
		feedMdJo.setColumn_delimiter(feedMd.getColumnDelimiter());
		feedMdJo.setStart_date(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(feedMd.getStartDate().getTime())));
		feedMdJo.setEnd_date(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(feedMd.getEndDate().getTime())));
		feedMdJo.setPast_runs(""+feedMd.getPastRuns());
		feedMdJo.setEmail_id(feedMd.getEmailID());
		feedMdJo.setUser_id(feedMd.getUserID());
		
		
		feedMdJo.setTicketRoboUI(feedMd.getTicketRobo());
		feedMdJo.setaGrp(feedMd.getAGRP());
		feedMdJo.setrGrp(feedMd.getRGRP());
		
		return feedMdJo;
		
	}
	
	public static ColumnMetadataJO mapToColumnMetadataJO(ColumnMetadata colMd){
		ColumnMetadataJO colMdJo = new ColumnMetadataJO();
		colMdJo.setColumnID(""+colMd.getColumnID());
		colMdJo.setColumnName(colMd.getColumnName());
		colMdJo.setDataFormat(colMd.getDataFormat());
		colMdJo.setDataType(colMd.getDataType());
		colMdJo.setEndDate(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(colMd.getEndDate().getTime())));
		colMdJo.setStartDate(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(colMd.getStartDate().getTime())));
		colMdJo.setUserID(colMd.getUserID());		
		return colMdJo;
	}
	
	public static ColumnRuleMetadataJO mapToColumnRuleMetadataJO(ColumnRuleMetadata colRuleMd,String columnName){
		
		ColumnRuleMetadataJO colRuleMdJo = new ColumnRuleMetadataJO();
		colRuleMdJo.setColumnID(""+colRuleMd.getColumnID());
		colRuleMdJo.setColumnName(columnName);
		colRuleMdJo.setMaxAbortThreshold((colRuleMd.getMaxAbortThreshold()==null) ? null : colRuleMd.getMaxAbortThreshold().toString());
		colRuleMdJo.setMaxAlertThreshold((colRuleMd.getMaxAlertThreshold()==null) ? null : colRuleMd.getMaxAlertThreshold().toString());
		colRuleMdJo.setMinAbortThreshold((colRuleMd.getMinAbortThreshold()==null) ? null : colRuleMd.getMinAbortThreshold().toString());
		colRuleMdJo.setMinAlertThreshold((colRuleMd.getMinAlertThreshold()==null) ? null : colRuleMd.getMinAlertThreshold().toString());
		colRuleMdJo.setPastRuns(""+colRuleMd.getPastRuns());
		colRuleMdJo.setRuleID(""+colRuleMd.getRuleID());
		colRuleMdJo.setRuleParameter(colRuleMd.getRuleParameter());
		colRuleMdJo.setStartDate(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(colRuleMd.getStartDate().getTime())));
		colRuleMdJo.setEndDate(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(colRuleMd.getEndDate().getTime())));
		colRuleMdJo.setThresholdType(colRuleMd.getThresholdType());
		colRuleMdJo.setUserID(colRuleMd.getUserID());
		
		return colRuleMdJo ;
	}
	
	public static SLAMetadata mapToSLAMetadata(FeedMetadataJO feedMdJo, String userId) throws ZebraPortalException{
		SLAMetadata slaMd = null;
		String default_sla_time = "23:59";
		
		if("1".equals(feedMdJo.getSla())){
			slaMd = new SLAMetadata();
			slaMd.setFeedFrequency(feedMdJo.getFeed_frequency());
			slaMd.setFeedName(feedMdJo.getFeed_name());
			if(userId == null || userId.isEmpty()){
				slaMd.setUserID(feedMdJo.getUser_id());
			}else {
				slaMd.setUserID(userId);
			}
			
			if("Last Day of Month".equals(feedMdJo.getMonthDate())){
				slaMd.setDateOfMonth(-1);
			}else if(feedMdJo.getMonthDate()!=null && !feedMdJo.getMonthDate().isEmpty()){
				slaMd.setDateOfMonth(Integer.parseInt(feedMdJo.getMonthDate()));
			}
			if((feedMdJo.getWeekDay()!=null) && !feedMdJo.getWeekDay().isEmpty()){
				slaMd.setDayOfWeek(Integer.parseInt(feedMdJo.getWeekDay()));
			}
			if(feedMdJo.getSla_time_elapsed()!=null){
				slaMd.setElapseTime(CommonMethods.convertTimeToInt(feedMdJo.getSla_time_elapsed()));
			}
			if(feedMdJo.getSla_time()!=null){
				slaMd.setExecTime(CommonMethods.convertTimeToInt(feedMdJo.getSla_time()));
			}else if(feedMdJo.getSla_time()==null && !slaMd.isIntraDay()){
				slaMd.setExecTime(CommonMethods.convertTimeToInt(default_sla_time));
			}
			
			if((feedMdJo.getFeed_Id()!=null) && !feedMdJo.getFeed_Id().isEmpty()){
				slaMd.setFeedID(Long.parseLong(feedMdJo.getFeed_Id()));
			}
			
			if(feedMdJo.getMonthQuarter()!=null && !feedMdJo.getMonthQuarter().isEmpty()){
				slaMd.setMonthOfQuarter(Integer.parseInt(feedMdJo.getMonthQuarter()));
			}
			if(feedMdJo.getSkipDay()!=null && !feedMdJo.getSkipDay().isEmpty()){
				slaMd.setSkipDayOfWeek(Integer.parseInt(feedMdJo.getSkipDay()));
			}
			
		

			if(feedMdJo.getStart_date() == null || feedMdJo.getStart_date().trim().isEmpty()){
				
				slaMd.setStartDate(new java.sql.Timestamp(new java.util.Date().getTime()));	
			}else{
				try {
					slaMd.setStartDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(feedMdJo.getStart_date())).getTime()));
				} catch (ParseException e) {
					throw new ZebraPortalException("Exception occured while parsing start date",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
				}
			}
			
			if(feedMdJo.getEnd_date() == null || feedMdJo.getEnd_date().trim().isEmpty()){
				
				slaMd.setEndDate(Timestamp.valueOf(DEFAULT_TIME_STAMP));
				
			} else{
				try {
					slaMd.setEndDate(new Timestamp((new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(feedMdJo.getEnd_date())).getTime()));
				} catch (ParseException e) {
					throw new ZebraPortalException("Exception occured while parsing end date",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
				}
			}
		}
		
		return slaMd ;
	}


	public static FeedMetadataJO mapToFeedMetadataJOFromSLAMetadata(SLAMetadata slaMd, FeedMetadataJO feedMdJo){
		if(slaMd != null){
			feedMdJo.setSla("1");
			if(slaMd.getSkipDayOfWeek()!=null){
				feedMdJo.setSkipDay(""+slaMd.getSkipDayOfWeek());
			}
			if(slaMd.getExecTime()!=null){
				feedMdJo.setSla_time(CommonMethods.converToTime(slaMd.getExecTime()));
			}
			if(slaMd.getElapseTime()!=null){
				feedMdJo.setSla_time_elapsed(CommonMethods.converToTime(slaMd.getElapseTime()));
			}
			
			if(slaMd.getDateOfMonth()!=null && slaMd.getDateOfMonth() == -1){
				feedMdJo.setMonthDate("Last Day of Month");
			} else if(slaMd.getDateOfMonth()!=null){
				feedMdJo.setMonthDate(""+slaMd.getDateOfMonth());
			}
			
			if(slaMd.getMonthOfQuarter()!=null){
				feedMdJo.setMonthQuarter(""+slaMd.getMonthOfQuarter());
			}
			
			if((slaMd.getDayOfWeek()!=null)){
				feedMdJo.setWeekDay(""+slaMd.getDayOfWeek());
			}
		}

		return feedMdJo ;
	}
	
	public static StatusRespJO mapToStatusRespJO(FeedMetadata feedMd,String respCode,String respMessage,String respType){
		return new StatusRespJO(new StatusJO(
				""+feedMd.getFeedID(),
				feedMd.getFeedName(),
				feedMd.getUserID(),
				respCode,respMessage,respType,
				new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(feedMd.getStartDate().getTime())),
				new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(feedMd.getEndDate().getTime()))));
	}
	
	/** CStone Mapping*/
	
	public static CStoneStorageInfoJO mapToCStoneStorageInfoJO(CStoneStorage cStoneStorage){
		CStoneStorageInfoJO storageInfoJo = new CStoneStorageInfoJO();
		
		storageInfoJo.setStorage_ID(cStoneStorage.getStorage_ID());
		storageInfoJo.setTable_name(cStoneStorage.getTable_name());
		
		return storageInfoJo ;
		
	}
	
	public static StorageStatDataJO mapToCStoneStorageStatDataJO(Object value){
		if(value == null){
			return null ;
		}
		return  new StorageStatDataJO(value);
		
	}
	
	public static CStoneStorageAttrJO mapToCStoneStorageAttrJO(CStoneStorageAttribute storaeAttr) {
		if(storaeAttr == null){
			return null ;
		}
		return  new CStoneStorageAttrJO (storaeAttr.getAttr_id(),storaeAttr.getAttr_name()) ;
	}
	

	
}
