package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.portal.ListFeedDetailsStep;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class ListFeedDetailsServlet extends HttpServlet{

	private final static Logger logger = Logger.getLogger(ListFeedDetailsServlet.class);
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doGet(request,response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	PrintWriter out = response.getWriter();
    	ListFeedDetailsStep listFeedDetailImpl = new ListFeedDetailsStep();
    	out.write(JsonParser.feedDetailListToJson(listFeedDetailImpl.listFeedDetailInfo()));
    	
    }

}
