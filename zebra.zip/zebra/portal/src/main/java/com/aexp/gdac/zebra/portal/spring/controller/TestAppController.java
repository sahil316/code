package com.aexp.gdac.zebra.portal.spring.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Controller
@RequestMapping("/app")
public class TestAppController {

	protected static Logger logger = Logger.getLogger(TestAppController.class.getName());

	@RequestMapping(value = { "/test" }, method = RequestMethod.GET)
	public ModelAndView success() {

		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

	//	String name = auth.getName(); // get logged in username
		
	//	model.addObject("username", name);
		model.setViewName("test");
		return model;

	}
/*
	@RequestMapping(value = { "/podHomePage" }, method = RequestMethod.GET)
	public ModelAndView toPodHomePage() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		String name = auth.getName(); // get logged in username

		model.addObject("username", name);
		model.setViewName("podHomePage");
		return model;

	}

	@RequestMapping(value = { "/leadershipKpi" }, method = RequestMethod.GET)
	public ModelAndView coreKpi() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		String name = auth.getName(); // get logged in username

		model.addObject("username", name);
		model.setViewName("leadershipKpi");
		return model;

	}

	@RequestMapping(value = { "/dceProductInsights" }, method = RequestMethod.GET)
	public ModelAndView dceProductInsights() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		String name = auth.getName(); // get logged in username

		model.addObject("username", name);
		model.setViewName("dceProductInsights");
		return model;

	}

	@RequestMapping(value = { "/visualization" }, method = RequestMethod.GET)
	public ModelAndView visualization() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		String name = auth.getName(); // get logged in username

		model.addObject("username", name);
		model.setViewName("visualization");
		return model;

	}

	@RequestMapping(value = { "/otherReports" }, method = RequestMethod.GET)
	public ModelAndView otherReports() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		String name = auth.getName(); // get logged in username

		model.addObject("username", name);
		model.setViewName("otherReports");
		return model;

	}

	@RequestMapping(value = { "/admin" }, method = RequestMethod.GET)
	public ModelAndView admin() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		String name = auth.getName(); // get logged in username

		model.addObject("username", name);
		model.setViewName("admin");
		return model;

	}
	*/
}
