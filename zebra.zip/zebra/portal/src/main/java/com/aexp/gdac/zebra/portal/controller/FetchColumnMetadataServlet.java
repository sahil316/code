package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;








import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.portal.FetchColumnMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class FetchColumnMetadataServlet extends HttpServlet{

	private final static Logger logger = Logger.getLogger(FetchColumnMetadataServlet.class);
	private static final String PARAM_FEED_ID = "feedID";
	private static final String PARAM_COLUMN_ID = "columnID";
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doGet(request,response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	FetchColumnMetadataStep fecthColMdImpl = new FetchColumnMetadataStep();
    	PrintWriter out = response.getWriter();
    	try {
    		Long columnId = null;
    		Long feedId = Long.parseLong(request.getParameter(PARAM_FEED_ID));
    		if(request.getParameter(PARAM_COLUMN_ID) != null){
    			columnId = Long.parseLong(request.getParameter(PARAM_COLUMN_ID));
    		}
			out.write(JsonParser.fetchColumnMetadataResponseJoToJson(fecthColMdImpl.fetchColumnMetadataResponse(feedId,columnId)));
			
		} catch(NumberFormatException nfe){
			logger.error("FeedID or ColumnID passed not a number ",nfe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID or ColumnID passed not a number  ", "Fetch Column Metadata"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID or ColumnID passed not a number  ", "Fetch Column Metadata"))));
			return ;
			
		}catch (ZebraPortalException zpe) {
			logger.error("Exception Occured while registering column metadata ",zpe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Fetch Column Metadata"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Fetch Column Metadata"))));
			return ;
			
		}catch(Exception e){
			logger.error("Unexpected exception occured ",e);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Column Metadata"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Column Metadata"))));
			return ;
		}
    }
}
