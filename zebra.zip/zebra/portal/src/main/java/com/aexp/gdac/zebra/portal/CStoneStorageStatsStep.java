package com.aexp.gdac.zebra.portal;

import java.util.List;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.CStoneIngestionFeeDQMStatisticsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.CStoneStorageAttributeDAO;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneIngestionFeeDQMStatistics;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneStorageAttribute;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageStatsJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageStatsJO.StorageStatsDatasetJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class CStoneStorageStatsStep {
	
	private CStoneIngestionFeeDQMStatisticsDAO cStoneDqmDAO ;
	private CStoneStorageAttributeDAO cStoneStorageAttDAO ;
	
	public CStoneStorageStatsStep(){
		cStoneDqmDAO = (CStoneIngestionFeeDQMStatisticsDAO)ZebraResourceManager.getBean("cStoneIngestionFeeDQMStatisticsDAO");
		cStoneStorageAttDAO = (CStoneStorageAttributeDAO)ZebraResourceManager.getBean("cStoneStorageAttributeDAO");
	}
	
	
	
	public CStoneStorageStatsJO getCStoneStorageStats (Long storageId, Integer pastRuns) throws ZebraPortalException {
		CStoneStorageStatsJO cStoneStorageStatsJo = new CStoneStorageStatsJO () ;
		cStoneStorageStatsJo.setStorage_ID(storageId);
		
		StorageStatsDatasetJO storageStatsDatasetJo = null ;
		
		try {
			List<CStoneIngestionFeeDQMStatistics> storageStatsList =  cStoneDqmDAO.getStorageVolumeDQMStatistics(storageId, 0, pastRuns) ;
			
			if(!storageStatsList.isEmpty()){
				storageStatsDatasetJo = new StorageStatsDatasetJO ("Volume");
				cStoneStorageStatsJo.setPastRuns(storageStatsList.size());
			}
			
			for(CStoneIngestionFeeDQMStatistics storageStats : storageStatsList){
				storageStatsDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(storageStats.getP_count()));
			}
						
			cStoneStorageStatsJo.addDataset(storageStatsDatasetJo);
			
			List<CStoneStorageAttribute> cStoneStorageAttrList = cStoneStorageAttDAO.getCStoneStorageAttributeByStorageID (storageId,0,-1) ;
			
			for(CStoneStorageAttribute storageAttr: cStoneStorageAttrList){
				cStoneStorageStatsJo.addCStoneStorageJO(JsonMapper.mapToCStoneStorageAttrJO(storageAttr));
			}
			
			cStoneStorageStatsJo.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"cstone storage stats"));
			
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception Occured While Fetching Storage DQM Stats from CStone",ZebraPortalException.Reason.CSTONE_STORAGE_STATS_EXCEPTION,zse);
		} catch (Throwable t){
			throw new ZebraPortalException("Unexpected Exception Occured While Fetching Storage DQM Stats from CStone",ZebraPortalException.Reason.CSTONE_STORAGE_STATS_EXCEPTION,t);
		}
		
		
		return cStoneStorageStatsJo ;
		
	}

}
