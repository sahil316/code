package com.aexp.gdac.zebra.portal;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.SLAMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FetchFeedMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class FetchFeedMetadataStep {
	private final static Logger logger = Logger.getLogger(FetchFeedMetadataStep.class);
	private FeedMetadataDAO feedMdDAO ;
	private SLAMetadataDAO slaMdDAO ;
	
	public FetchFeedMetadataStep(){
		this.feedMdDAO = (FeedMetadataDAO)ZebraResourceManager.getBean("feedMetadataDAO");
		this.slaMdDAO = (SLAMetadataDAO)ZebraResourceManager.getBean("slaMetadataDAO");
		
	}

	public FetchFeedMDResponseJO fetchFeedMetadata(long feedID) throws ZebraPortalException{
		FeedMetadata feedMd = null;
		SLAMetadata slaMd = null ;
		
		try {
			feedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedID);
			slaMd =(SLAMetadata) slaMdDAO.getSLAMetadataByFeedIDAndEndDate(feedID,feedMd.getEndDate());
		} catch (ZebraServiceException e) {
			throw new ZebraPortalException("Couldnot fetch feedMdDAO fomm DB ",ZebraPortalException.Reason.FETCH_FEED_MD_EXCEPTION,e);
		}

		if(feedMd == null){
			throw new ZebraPortalException("No Feed Found for feedId "+feedID,ZebraPortalException.Reason.FETCH_FEED_MD_EXCEPTION);
		}

		FetchFeedMDResponseJO feedMdResJo = new FetchFeedMDResponseJO();
		FeedMetadataJO feedMdJo = JsonMapper.mapToFeedMetadataJOFromFeedMetadata(feedMd);
		
		if(slaMd!=null){
			feedMdJo = JsonMapper.mapToFeedMetadataJOFromSLAMetadata(slaMd, feedMdJo);
		}
		
		feedMdResJo.setResult(feedMdJo);
		feedMdResJo.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"Fetch Feed Metadata"));
		
		return feedMdResJo;
	}
}
