package com.aexp.gdac.zebra.portal.spring.controller;




import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;





import com.aexp.gdac.zebra.common.json.model.CStoneStorageDetailJO;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageStatsJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.FeedInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FeedStatsTreeJO;
import com.aexp.gdac.zebra.common.json.model.FetchColumnMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.FetchFeedMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.RegisterColumnMDJO;
import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatsReportRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.common.json.model.UpdateColumnMDJO;
import com.aexp.gdac.zebra.portal.CStoneStorageAttrStatsStep;
import com.aexp.gdac.zebra.portal.CStoneStorageDetailsStep;
import com.aexp.gdac.zebra.portal.CStoneStorageStatsStep;
import com.aexp.gdac.zebra.portal.ExportColumnMetadataStep;
import com.aexp.gdac.zebra.portal.FetchColumnMetadataStep;
import com.aexp.gdac.zebra.portal.FetchFeedMetadataStep;
import com.aexp.gdac.zebra.portal.ListColumnDetailsStep;
import com.aexp.gdac.zebra.portal.ListFeedDetailsStep;
import com.aexp.gdac.zebra.portal.RegisterStatsStep;
import com.aexp.gdac.zebra.portal.StatsReportStep;
import com.aexp.gdac.zebra.portal.StatsTrendStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;
import com.aexp.gdac.zebra.portal.manager.ColumnMetadataManager;
import com.aexp.gdac.zebra.portal.manager.FeedMetadataManager;
import com.google.gson.JsonParseException;





import java.security.Principal;

import javax.servlet.http.HttpSession;
 
@RestController()
public class ZebraRestController {
	private final static Logger logger = Logger.getLogger(ZebraRestController.class);
	
	
	 @RequestMapping(value = "/rest/hello", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<String> hello(Principal principal, @RequestParam(required=false) String error) {
	 
		 String name = "undefind" ;
		 if(principal!=null){
			 name = principal.getName() ;
		 }
	        return new ResponseEntity<String>(
	                new String("Happy Halloween, " +name +"["+error+"]"+ "!"), HttpStatus.OK);
	    }
	 
	 
	 @RequestMapping(value = "/user", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<String> getLoggedInUser(Principal principal, @RequestParam(required=false) String error) {
		String name = null;
		 
		 if((error == null || !error.equalsIgnoreCase("true"))
				 && principal!=null){
			 
			 name = getLoggedInUser(principal) ;
			 

		 }
		 
		 /*
		  * For getting roles for user if necessary .
		  * Current zebra has no requirement of roles , hence no roles are fetched form ldap 
		  * 
		 String roles = "";
		 java.util.Collection<SimpleGrantedAuthority> authorities = 
				 (java.util.Collection<SimpleGrantedAuthority>) SecurityContextHolder.getContext()
				 .getAuthentication()
				 .getAuthorities();
		 
		 for(SimpleGrantedAuthority authority : authorities){
			 roles = authority.getAuthority() + ", " ;
		 }

		 if(session != null){
    			logger.info("########JSESSIONID:####### "+session.getId()+" ###USER:###### "+name+"####ROLES#######" +roles);
    	 }else{
    			logger.info("########USER:#######"+name listFeedDetailInfo+ "####ROLES#######" +roles);
    	 }
		
		*/
	        return new ResponseEntity<String>(((name==null)?"false":name) , HttpStatus.OK);
	  }
	 
	 
	 
	 @RequestMapping(value = "/fetch_column_md", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FetchColumnMDResponseJO> fetchColumnMetadata(@RequestParam String feedID,
			 @RequestParam(required=false) String columnID){
		 FetchColumnMetadataStep fecthColMdImpl = new FetchColumnMetadataStep();
		 
		 FetchColumnMDResponseJO response = null;

	    	try {
	    		Long columnId = null;
	    		long feedId = Long.parseLong(feedID) ;
	    		if(columnID != null){
	    			columnId = Long.parseLong(columnID);
	    		}
	    		
	    		response = fecthColMdImpl.fetchColumnMetadataResponse(feedId,columnId);
				return new ResponseEntity<FetchColumnMDResponseJO>(response	,HttpStatus.OK);
				
			} catch(NumberFormatException nfe){
				logger.error("FeedID or ColumnID passed not a number ",nfe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID or ColumnID passed not a number  ", "Fetch Column Metadata"))));
				}
				
				response = new FetchColumnMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID or ColumnID passed not a number  ", "Fetch Column Metadata"));

				
			} catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while registering column metadata ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Fetch Column Metadata"))));
				}
				response = new FetchColumnMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Fetch Column Metadata"));
		
				
			} catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Column Metadata"))));
				}
				 response = new FetchColumnMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Column Metadata"));
			
			}
	    	
	    	return new ResponseEntity<FetchColumnMDResponseJO>(response	,HttpStatus.OK);
	 }

	 @RequestMapping(value = "/fetch_feed_md", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FetchFeedMDResponseJO> fetchFeedMetadata(@RequestParam String feedID){
		 FetchFeedMetadataStep fecthFeedMdImpl = new FetchFeedMetadataStep();
		 FetchFeedMDResponseJO response = null ;
	    	try {
	    		long feedId = Long.parseLong(feedID);
	    		response = fecthFeedMdImpl.fetchFeedMetadata(feedId) ;
	    		logger.info("Fetch FeedMd Json : "+response);
	    		
	    		return new ResponseEntity<FetchFeedMDResponseJO>(response, HttpStatus.OK) ;
	    		
			} catch(NumberFormatException nfe){
				
				logger.error("FeedID passed not a number ",nfe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID passed not a number  ", "Fetch Feed Metadata"))));
				}
				response = new FetchFeedMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID passed not a number  ", "Fetch Feed Metadata"));

				
			}catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while registering column metadata ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Fetch Feed Metadata"))));
				}
				response = new FetchFeedMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Fetch Feed Metadata"));

			}catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Feed Metadata"))));
				}
				response = new FetchFeedMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Feed Metadata"));
				
			}
	    	
	    	return new ResponseEntity<FetchFeedMDResponseJO>(response, HttpStatus.OK) ;
	 }

	 
	 /* we can remove feed_column_list API later as this is not used apart from HomeCtrl.js which seems a useless call. */ 
	 @RequestMapping(value = "/feed_column_list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FeedDetailInfoJO> fetchFeedDetails(HttpSession session){  	
			if(session != null){
    			logger.info("########JSESSIONID:#######"+session.getId());
    		}
	    	ListFeedDetailsStep listFeedDetailImpl = new ListFeedDetailsStep();
	    	return new ResponseEntity<FeedDetailInfoJO>(listFeedDetailImpl.listFeedDetailInfo(),HttpStatus.OK);
	    	
	 }
	 
	 @RequestMapping(value = "/feed_list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FeedDetailInfoJO> fetchFeedList(HttpSession session){  	
			if(session != null){
    			logger.info("########JSESSIONID:#######"+session.getId());
    		}
	    	ListFeedDetailsStep listFeedDetailImpl = new ListFeedDetailsStep();
	    	//return new ResponseEntity<FeedDetailInfoJO>(listFeedDetailImpl.listFeedDetailInfo(),HttpStatus.OK);
	    	return new ResponseEntity<FeedDetailInfoJO>(listFeedDetailImpl.listFeedInfo(),HttpStatus.OK);
	 }
	 
	 @RequestMapping(value = "/fetch_columns_rules", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FeedInfoJO> fetchFeedColumnsRulesList(@RequestParam String feedID){  	
			 
		 FeedInfoJO response = null ;
	    	try {
	    		long feedId = Long.parseLong(feedID);
	    		ListColumnDetailsStep listColumnDetailImpl = new ListColumnDetailsStep(feedId);
	    		response = listColumnDetailImpl.listColumnDetailInfo(feedId) ;
	    		logger.info("Fetch column rules Json : "+response);
	    		
	    		return new ResponseEntity<FeedInfoJO>(response, HttpStatus.OK) ;
	    		
			} catch(NumberFormatException nfe){
				
				logger.error("FeedID passed not a number ",nfe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID passed not a number  ", "Fetch columns and rules data"))));
				}
				response = new FeedInfoJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID passed not a number  ", "Fetch columns and rules data"));
				
			} catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch columns and rules data"))));
				}
				response = new FeedInfoJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch columns and rules data"));
			}
	    	
	    	return new ResponseEntity<FeedInfoJO>(response, HttpStatus.OK) ;
	 }
	 

	 @RequestMapping(value = "/register_column", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatusRespJO> registerColumnMetadata(Principal principal, @RequestBody RegisterColumnMDJO regColMdJo) {

	    	try {	   

			 
	    		logger.info("Service[Register Column Metadata] ,User["+getLoggedInUser(principal)+"], Metadata:[ "+regColMdJo +"]");
	    		ColumnMetadataManager registerColMgrImpl = new ColumnMetadataManager();
	    		registerColMgrImpl.registerColumnMetadata(regColMdJo,getLoggedInUser(principal));
	    		
	    		return new ResponseEntity<StatusRespJO>(new StatusRespJO(
	    				new StatusJO(regColMdJo.getFeedID(),regColMdJo.getFeedName()
	    						,regColMdJo.getUserID() ,StatusJO.RESP_CODE_SUCCESS
	    						, StatusJO.RESP_MESSAGE_SUCCESS, "Columns Register"))
	    				,HttpStatus.OK);

			} catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while registering column metadata ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Columns Register"))));
				}
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Columns Register")),HttpStatus.OK);

			}catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Columns Register"))));
				}
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Columns Register")),HttpStatus.OK);
			}
	    	
	 }
	 
	 @RequestMapping(value = "/register_feed", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatusRespJO> registerFeedMetadata(HttpSession session, Principal principal,@RequestBody FeedMetadataJO regFeedMdJo) {
		 StatusJO status = null;
	    	
	    	try {
				if(session != null){
	    			logger.info("########JSESSIONID:#######"+session.getId());
	    		}
	    		logger.info("Register Feed Metadata Request:"+regFeedMdJo);
	    		
	    		FeedMetadataManager registerFeedMgrImpl = new FeedMetadataManager();
	    		status = registerFeedMgrImpl.registerFeedMetadata(regFeedMdJo, getLoggedInUser(principal));
	    		return new ResponseEntity<StatusRespJO>(new StatusRespJO(status),HttpStatus.OK);
				
			} catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while registering feed ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Feed Register"))));
				}
				
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Feed Register")),HttpStatus.OK);

			}catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Register"))));
				}
				
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured "+e.getMessage(), "Feed Register")),HttpStatus.OK);

			}
	 }

	 /*
	  * this api/method should always be kept authentication free as its been called from monitory-util
	  */
	 @RequestMapping(value = "/register_stats", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatusRespJO> registerStats(@RequestBody StatsRegisterRequestJO statsRegReqJo) {
		 try {

	    		
	    		return new ResponseEntity<StatusRespJO>(new StatusRespJO(new RegisterStatsStep().registerStats(statsRegReqJo)),HttpStatus.OK);
				
			} catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while registering stats ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Stats Register"))));
				}
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Stats Register")),HttpStatus.OK);

			}catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Stats Register"))));
				}
				
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Stats Register")),HttpStatus.OK);

			}
	 }

	 @RequestMapping(value = "/stats_report", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FeedStatsTreeJO> getStatsReport(HttpSession session,@RequestBody StatsReportRequestJO statsReqJo){
			
		try{
			if(session != null){
    			logger.info("########JSESSIONID:#######"+session.getId());
    		}
			
	 		StatsReportStep statsTreeReportImpl =  new StatsReportStep();
	 		
	 		return new ResponseEntity<FeedStatsTreeJO>(statsTreeReportImpl.getFeedStatsTree(statsReqJo),HttpStatus.OK);

			
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured !",zpe);
			return new ResponseEntity<FeedStatsTreeJO>( new FeedStatsTreeJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Exception Occured ! ", "Stats Report")),HttpStatus.OK);
		}catch(JsonParseException jpe){
			logger.error("Invalid Request JSON:",jpe);
			return new ResponseEntity<FeedStatsTreeJO>( new FeedStatsTreeJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Invalid Request JSON ", "Stats Report")),HttpStatus.OK);
		}catch(Exception e){
			logger.error("Unexpected exception occured :",e);
			return new ResponseEntity<FeedStatsTreeJO>( new FeedStatsTreeJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Stats Report")),HttpStatus.OK);
		}
	 }

	 @RequestMapping(value = "/stats_trend", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatsTrendJO> getStatsTrend(HttpSession session,@RequestBody StatsTrendRequestJO statsReqJo){

 		try{
			if(session != null){
    			logger.info("########JSESSIONID:#######"+session.getId());
    		}
	 		StatsTrendStep statsTrendStepImpl=  new StatsTrendStep();
			return	new ResponseEntity<StatsTrendJO>(statsTrendStepImpl.getStatsTrends(statsReqJo),HttpStatus.OK);
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured !",zpe);
			return new ResponseEntity<StatsTrendJO>( new StatsTrendJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Exception Occured ["+zpe.getReason().name()+"]", "Stats Report")),HttpStatus.OK);
		} catch(JsonParseException jpe){
			logger.error("Invalid Request JSON:",jpe);
			return new ResponseEntity<StatsTrendJO>( new StatsTrendJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Invalid Request JSON ", "Stats Report")),HttpStatus.OK);
		}catch(Exception e){
			logger.error("Invalid Request JSON:",e);
			return new ResponseEntity<StatsTrendJO>( new StatsTrendJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected Exception Occred ", "Stats Report")),HttpStatus.OK);
		}
	 }

	 @RequestMapping(value = "/update_column_md", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatusRespJO> updateColumnMetadata(Principal principal ,@RequestBody UpdateColumnMDJO updateColMdJo){
			logger.info("Update Column Metadata ["+updateColMdJo+"]");
		
		try{
			ColumnMetadataManager colMgrImpl = new ColumnMetadataManager();
			colMgrImpl.updateColumnMetadata(updateColMdJo, this.getLoggedInUser(principal));
    		return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(updateColMdJo.getFeedID(),updateColMdJo.getFeedName(),updateColMdJo.getUserID() ,StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Column Metadata Update")),HttpStatus.OK);
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured while updating column metadata ",zpe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Column Metadata Update"))));
			}
			return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Column Metadata Update")),HttpStatus.OK);
			
		}catch(Exception e){
			logger.error("Unexpected exception occured ",e);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Column Metadata Update"))));
			}
			return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Column Metadata Update ")),HttpStatus.OK);
		}
	 }

	 @RequestMapping(value = "/update_feed_md", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatusRespJO> updateFeedMetadata(Principal principal ,@RequestBody FeedMetadataJO updateFeedMdJo){
		 
		 try {
	    		logger.info("Update Feed Metadata Request:"+updateFeedMdJo);
	    		FeedMetadataManager registerFeedMgrImpl = new FeedMetadataManager();
	    		return new ResponseEntity<StatusRespJO>(new StatusRespJO(registerFeedMgrImpl.updateFeedMetadata(updateFeedMdJo,getLoggedInUser(principal))),HttpStatus.OK);
				
			} 	catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while updating feed ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Feed Metadata Update"))));
				}
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Feed Metadata Update")),HttpStatus.OK);
			
			}	catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Metadata Update"))));
				}
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Metadata Update")),HttpStatus.OK);
			}
	 }
	 
	 
		 /** Feed Export Functionality */
		 /* @RequestMapping(value = "/export_column_metadata/", method = RequestMethod.GET, produces = "application/csv")
		 public ResponseEntity<InputStreamResource> downloadTestFile() throws IOException {
	
			 		File temp = File.createTempFile("tempfile", ".csv"); 
	 		
			 		//write content in it
		    	    BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
		    	    bw.write("This is the temporary file content");
		    	    bw.close();
		    	    
		    	    FileSystemResource tempFileResouce = new FileSystemResource(temp);
		    	    
		     return ResponseEntity.ok()
		             .contentLength(tempFileResouce.contentLength())
		             .contentType(
		                     MediaType.parseMediaType("application/csv"))
		             .header("Content-disposition", "attachment; filename=filename.txt")
		             .body(new InputStreamResource(tempFileResouce.getInputStream()));
		 }
		 */
	 
		 @RequestMapping(value = "/export_column_metadata/{feedId}", method = RequestMethod.GET)
		 public ResponseEntity<byte[]> exportCoulumnMetadata(@PathVariable Long feedId)  {
			 
			 
			  HttpHeaders responseHeaders = new HttpHeaders();
			  responseHeaders.set("charset", "utf-8");
			  responseHeaders.setContentType(MediaType.valueOf("text/html"));
			  responseHeaders.set("Content-disposition", "attachment; filename="+feedId+"_column_metadata.csv");
			  byte[] output = null ;
			 try {
				 
				 ExportColumnMetadataStep exportColMdStepImpl = new ExportColumnMetadataStep () ;
				 
			     String regData = exportColMdStepImpl.getColumnMetadataTextStream(feedId);
				
			     
			     output = regData.getBytes();
			      
			     responseHeaders.setContentLength(output.length);
			   
	
			     return new ResponseEntity<byte[]>(output, responseHeaders, HttpStatus.OK);
		     
			} catch (ZebraPortalException zpe) {
				output = new String(zpe.getMessage()).getBytes() ;
				return new ResponseEntity<byte[]>(output, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
			} catch (Exception e) {
				output = new String(e.getMessage()).getBytes() ;
				return new ResponseEntity<byte[]>(output, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		 }
	 
	 /** CStone APIs  **/
	 
	 
	 @RequestMapping(value = "/cstone_stats_trend/{storageId}/{pastRuns}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<CStoneStorageStatsJO> getCStoneStorageStatsTrend(@PathVariable Long storageId, @PathVariable Integer pastRuns){

 		try{
 			CStoneStorageStatsStep cStoneStoragestatsTrendStepImpl=  new CStoneStorageStatsStep();
			return	new ResponseEntity<CStoneStorageStatsJO>(cStoneStoragestatsTrendStepImpl.getCStoneStorageStats(storageId, pastRuns),HttpStatus.OK);
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured !",zpe);
			return new ResponseEntity<CStoneStorageStatsJO>( new CStoneStorageStatsJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Exception Occured ["+zpe.getReason().name()+"]", "Storage Stats")),HttpStatus.OK);
		} catch(JsonParseException jpe){
			logger.error("Invalid Request JSON:",jpe);
			return new ResponseEntity<CStoneStorageStatsJO>( new CStoneStorageStatsJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Invalid Request JSON ", "Storage Stats")),HttpStatus.OK);
		}catch(Exception e){
			logger.error("Invalid Request JSON:",e);
			return new ResponseEntity<CStoneStorageStatsJO>( new CStoneStorageStatsJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected Exception Occred ", "Storage Stats")),HttpStatus.OK);
		}
	 }
	 
	 
	 @RequestMapping(value = "/cstone_stats_trend/{storageId}/{attrId}/{pastRuns}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<CStoneStorageStatsJO> getCStoneStorageAttrStatsTrend(@PathVariable Long storageId, @PathVariable Long attrId, @PathVariable Integer pastRuns){

 		try{
 			CStoneStorageAttrStatsStep cStoneStorageAttrStatsTrendStepImpl=  new CStoneStorageAttrStatsStep();
			return	new ResponseEntity<CStoneStorageStatsJO>(cStoneStorageAttrStatsTrendStepImpl.getCStoneStorageAttrStats(storageId, attrId, pastRuns),HttpStatus.OK);
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured !",zpe);
			return new ResponseEntity<CStoneStorageStatsJO>( new CStoneStorageStatsJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Exception Occured ["+zpe.getReason().name()+"]", "Storage Attr Stats")),HttpStatus.OK);
		} catch(JsonParseException jpe){
			logger.error("Invalid Request JSON:",jpe);
			return new ResponseEntity<CStoneStorageStatsJO>( new CStoneStorageStatsJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Invalid Request JSON ", "Storage Attr Stats")),HttpStatus.OK);
		}catch(Exception e){
			logger.error("Invalid Request JSON:",e);
			return new ResponseEntity<CStoneStorageStatsJO>( new CStoneStorageStatsJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected Exception Occred ", "Storage Attr Stats")),HttpStatus.OK);
		}
	 }
	 
	 @RequestMapping(value = "/cstone_storage_list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<CStoneStorageDetailJO> getCStoneStorageList(){

 		try{
 			CStoneStorageDetailsStep cStoneStorageDetailsStepImpl=  new CStoneStorageDetailsStep();
			return	new ResponseEntity<CStoneStorageDetailJO>(cStoneStorageDetailsStepImpl.getCStoneStorageDetails(),HttpStatus.OK);
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured !",zpe);
			return new ResponseEntity<CStoneStorageDetailJO>( new CStoneStorageDetailJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Exception Occured ["+zpe.getReason().name()+"]", "Storage List")),HttpStatus.OK);
		} catch(JsonParseException jpe){
			logger.error("Invalid Request JSON:",jpe);
			return new ResponseEntity<CStoneStorageDetailJO>( new CStoneStorageDetailJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Invalid Request JSON ", "Storage List")),HttpStatus.OK);
		}catch(Exception e){
			logger.error("Invalid Request JSON:",e);
			return new ResponseEntity<CStoneStorageDetailJO>( new CStoneStorageDetailJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected Exception Occred ", "Storage List")),HttpStatus.OK);
		}
	 }	 
	 
	 private static String getLoggedInUser(Principal principal){
		 String username  = null ;
		 if(principal != null){
			 username = principal.getName() ;
		 }
		 
		 return username ;
	 }
	 
	 
	 /*	 
	 @RequestMapping(value = "/promote_feed", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<StatusRespJO> promoteFeed(@RequestParam String feedID){
		 ResponseEntity<FetchFeedMDResponseJO>  feedMDResponseJO = fetchFeedMetadata(feedID);
		 ResponseEntity<FetchColumnMDResponseJO> columnMDResponseJO = fetchColumnMetadata(feedID,null);
		 
		 PromoteFeedMetadataStep promoteFeedMdStep = new PromoteFeedMetadataStep();
		 StatusJO status = null;
		 
	    	try {
	    		status = promoteFeedMdStep.promoteFeed(feedMDResponseJO, columnMDResponseJO);
	    		return new ResponseEntity<StatusRespJO>(new StatusRespJO(status),HttpStatus.OK);
			} catch(NumberFormatException nfe){
				logger.error("FeedID passed not a number ",nfe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "FeedID passed not a number  ", "Fetch Feed Metadata"))));
				}
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,nfe.getLocalizedMessage(), "Feed Register")),HttpStatus.OK);
			} catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Feed Metadata"))));
				}
				//response = new FetchFeedMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Fetch Feed Metadata"));
				return new ResponseEntity<StatusRespJO>(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Columns Register")),HttpStatus.OK);
			}
	    	//return new ResponseEntity<FetchFeedMDResponseJO>(response, HttpStatus.OK) ;
	 }*/

	 /*
	 @RequestMapping(value = "/upload_column_md", method = RequestMethod.POST, consumes =  MediaType.MULTIPART_FORM_DATA_VALUE , produces =MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<FetchColumnMDResponseJO> uploadColumnMetadata(HttpServletRequest request,@RequestParam MultipartFile file, @RequestParam String feedId){
		 logger.info("Upload ColumMetadata Called, File:" + file + ",FeedId:" +feedId);
		 
		 long feed_Id = 0;
		 File colMdFile = null;
		 
		 if(feedId != null){
			 feed_Id = Long.parseLong(feedId);
		 }
		 
		
		 
		 try{
			 
			 colMdFile = File.createTempFile("column-md-file_"+new Date().getTime(), ".tmp"); 
			 file.transferTo(colMdFile);
		 // ##########################################
		 int maxFileSize = 50 * 1024;
		   int maxMemSize = 4 * 1024;
		   String FEED_ID_REQ_PARAM = "feedId";
			 // Check that we have a file upload request
			 

			 
		      boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		     // response.setContentType("text/html");
		   //   java.io.PrintWriter out = response.getWriter( );
		      try{ 
		    	  
		      if( !isMultipart ){
		    	  throw new ZebraPortalException("Multipart content missing, file cannt be found in request",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION);
		      }
		      DiskFileItemFactory factory = new DiskFileItemFactory();
		      // maximum size that will be stored in memory
		      factory.setSizeThreshold(maxMemSize);
		      // Location to save data that is larger than maxMemSize.
		      //factory.setRepository(new File("c:\\temp"));

		      // Create a new file upload handler
		      ServletFileUpload upload = new ServletFileUpload(factory);
		      // maximum file size to be uploaded.
		      upload.setSizeMax( maxFileSize );

		      
		      // Parse the request to get file items.
		      List fileItems = upload.parseRequest(request);
			
		      // Process the uploaded file items
		      Iterator i = fileItems.iterator();
		      File colMdFile = null;
		      long feed_Id = 0;
		      while (i.hasNext()){
		    	 
		    	 
		         FileItem fi = (FileItem)i.next();
		         if( !fi.isFormField() ){
		        	 
		        	 colMdFile = File.createTempFile("column-md-file_"+new Date().getTime(), ".tmp");
		        	 fi.write( colMdFile ) ;
		           
		         }else{
		        	 logger.info("Checking Request Param:"+fi.getFieldName());
		        	 
		        	 if(FEED_ID_REQ_PARAM.equals(fi.getFieldName())
		        		&& fi.getString()!=null 
		        		&& !fi.getString().isEmpty()){
		        		 feed_Id = Long.parseLong(fi.getString());
		        	 }
		         }
		      }
		      //#############################################
		      if(feed_Id == 0 || colMdFile == null){
		    	  throw new ZebraPortalException("Missing feedId or file in request",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION);
		      }
		      
		      logger.info("Uploading file for feedId :"+feed_Id);
		      
		      UploadColumnMetadataStep uploadColMdStep = new UploadColumnMetadataStep();
		      logger.info("Returning Column Metadata json for feedId :"+feed_Id);
		      return new ResponseEntity<FetchColumnMDResponseJO>(uploadColMdStep.uploadColumnMetadata(colMdFile, feed_Id),HttpStatus.OK);

		   }catch(ZebraPortalException zpe) {
			   logger.error(zpe.getReason().getReasonDesc(),zpe);
			   return new ResponseEntity<FetchColumnMDResponseJO>(new FetchColumnMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Upload ColMD")),HttpStatus.OK);

		   }catch(Exception e){
			   logger.error(e.getMessage(),e);
			   return new ResponseEntity<FetchColumnMDResponseJO>(new FetchColumnMDResponseJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,e.getMessage(), "Upload ColMD")),HttpStatus.OK);

		   }
		
	 }
	 
	 */

}
