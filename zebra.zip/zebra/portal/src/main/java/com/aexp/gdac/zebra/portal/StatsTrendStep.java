package com.aexp.gdac.zebra.portal;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.common.json.model.StatsTrendJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class StatsTrendStep {
	private final static Logger logger = Logger.getLogger(StatsTrendStep.class);

	private FeedStatsDAO feedStatsDAO ;
	private ColumnStatsDAO colStatsDAO;
	private ColumnRuleStatsDAO colRuleStatsDAO ;
	
	public StatsTrendStep(){
		feedStatsDAO = (FeedStatsDAO) ZebraResourceManager.getBean("feedStatsDAO");
		colStatsDAO = (ColumnStatsDAO) ZebraResourceManager.getBean("columnStatsDAO");
		colRuleStatsDAO = (ColumnRuleStatsDAO) ZebraResourceManager.getBean("columnRuleStatsDAO");
	}
	
	public StatsTrendJO getStatsTrends(StatsTrendRequestJO statsTrendReqJo) throws ZebraPortalException{
		StatsTrendJO statsTrendJo = new StatsTrendJO() ;
		try {
			
			if(Level.FEED_LEVEL == getRequestLevel(statsTrendReqJo)){
				logger.info("Feed Stats Trending Request :"+statsTrendReqJo);
			
				List<FeedStats> feedStatsList = feedStatsDAO.getFeedStatsPastRuns(Long.parseLong(statsTrendReqJo.getFeedID()), 
						 0,Integer.parseInt(statsTrendReqJo.getPastRuns())) ;
				
				/* arranging in ascending order */
				Collections.sort(feedStatsList);
				
				statsTrendJo = JsonMapper.mapToStatsTrendJOFromFeedStats(feedStatsList);
			
			
			}else if(Level.COLUMN_LEVEL == getRequestLevel(statsTrendReqJo)){
				logger.info("Column Stats Trending Request :"+statsTrendReqJo);
				
				List<ColumnStats> colStatsList = colStatsDAO.getColumnStatsPastRuns(Long.parseLong(statsTrendReqJo.getFeedID()), Long.parseLong(statsTrendReqJo.getColumnID()),
						0, Integer.parseInt(statsTrendReqJo.getPastRuns()));
				
				/* arranging in ascending order */
				Collections.sort(colStatsList);
				
				statsTrendJo = JsonMapper.mapToStatsTrendJOFromColumnStats(colStatsList);
				
			}else if(Level.COLUMN_RULE_LEVEL ==  getRequestLevel(statsTrendReqJo)){
				logger.info("Column Rule Stats Trending Request :"+statsTrendReqJo);
				
				List<ColumnRuleStats> colRuleStatsList =  colRuleStatsDAO.getColumnRuleStatsPastRuns(
						Long.parseLong(statsTrendReqJo.getFeedID()), Long.parseLong(statsTrendReqJo.getColumnID()), 
						Long.parseLong(statsTrendReqJo.getRuleID()), 0, Integer.parseInt(statsTrendReqJo.getPastRuns()));
				
				/* arranging in ascending order */
				Collections.sort(colRuleStatsList);
				
				statsTrendJo = JsonMapper.mapToStatsTrendJOFromColumnRuleStats(colRuleStatsList);
			}
			
			statsTrendJo.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Trending request processed successully"));
			
		} catch (NumberFormatException nfe) {
			logger.error("Numeric expected but not found in request :"+statsTrendReqJo,nfe);
			statsTrendJo.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Numeric expected but not found in request :"+statsTrendReqJo,"Stats Trend"));	
		} catch (ZebraServiceException zse){
			logger.error("Exception occured while fetching stats from DB ",zse);
			statsTrendJo.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE,"Exception occured while fetching stats from DB ","Stats Trend"));
		} catch (Exception e){
			logger.error("Unexpected Exception Occured ",e);
			statsTrendJo.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE,"Unexpected Exception Occured ","Stats Trend"));
		}

		return statsTrendJo;
	}

	private Level getRequestLevel(StatsTrendRequestJO statsTrendReqJo){
		if(statsTrendReqJo.getColumnID() != null && !statsTrendReqJo.getColumnID().isEmpty() 
				&& statsTrendReqJo.getRuleID() != null && !statsTrendReqJo.getRuleID().isEmpty()){
			return Level.COLUMN_RULE_LEVEL ;
		}else if(statsTrendReqJo.getColumnID() != null && !statsTrendReqJo.getColumnID().isEmpty()){
			return Level.COLUMN_LEVEL ;
		}
		
		return Level.FEED_LEVEL ;
	}
}
