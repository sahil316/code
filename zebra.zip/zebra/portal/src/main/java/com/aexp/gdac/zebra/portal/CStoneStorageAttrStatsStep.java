package com.aexp.gdac.zebra.portal;

import java.util.List;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.CStoneIngestionFeeDQMStatisticsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneIngestionFeeDQMStatistics;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageStatsJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageStatsJO.StorageStatsDatasetJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class CStoneStorageAttrStatsStep {
	
	private CStoneIngestionFeeDQMStatisticsDAO cStoneDMQStatsDAO ;
	
	public CStoneStorageAttrStatsStep (){
		this.cStoneDMQStatsDAO = (CStoneIngestionFeeDQMStatisticsDAO) ZebraResourceManager.getBean("cStoneIngestionFeeDQMStatisticsDAO");
	}
	
	
	public CStoneStorageStatsJO getCStoneStorageAttrStats(Long storageId,Long attrId , Integer pastRuns) throws ZebraPortalException{
		
		CStoneStorageStatsJO cStoneStorageAttrStatsJo =  new CStoneStorageStatsJO () ;
		cStoneStorageAttrStatsJo.setStorage_ID(storageId);
		cStoneStorageAttrStatsJo.setAttr_ID(attrId);
		


		
		try {
			List<CStoneIngestionFeeDQMStatistics> cStoneDMQStats = cStoneDMQStatsDAO.getStorageAttributeDQMStatistics(storageId, attrId, 0, pastRuns);
			
			if(!cStoneDMQStats.isEmpty()){
				
				cStoneStorageAttrStatsJo.setPastRuns(cStoneDMQStats.size());
				
				StorageStatsDatasetJO countDatasetJo = new StorageStatsDatasetJO("Count") ;
				StorageStatsDatasetJO nullcountDatasetJo =  new StorageStatsDatasetJO("Null Count") ; 
				StorageStatsDatasetJO stddevDatasetJo =  new StorageStatsDatasetJO("Std Dev") ; 
				StorageStatsDatasetJO varianceDatasetJo =  new StorageStatsDatasetJO("Variance") ; 
				StorageStatsDatasetJO avgDatasetJo =  new StorageStatsDatasetJO("Average") ; 
				StorageStatsDatasetJO minDatasetJo =  new StorageStatsDatasetJO("Min Value") ; 
				StorageStatsDatasetJO maxDatasetJo =  new StorageStatsDatasetJO("Max Value") ;  
				StorageStatsDatasetJO percent5DatasetJo =  new StorageStatsDatasetJO("Percent5") ; 
				StorageStatsDatasetJO percent25DatasetJo =  new StorageStatsDatasetJO("Percent25") ; 
				StorageStatsDatasetJO percent50DatasetJo =  new StorageStatsDatasetJO("Percent50") ; 
				StorageStatsDatasetJO percent75DatasetJo =  new StorageStatsDatasetJO("Percent75") ;
				StorageStatsDatasetJO percent99DatasetJo =  new StorageStatsDatasetJO("Percent99") ;
				
				
				for(CStoneIngestionFeeDQMStatistics stats : cStoneDMQStats){
					countDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_count()));
					nullcountDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_nullcount()));
					stddevDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_stddev()));
					varianceDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_variance()));
					avgDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_avg()));
					minDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_min()));
					maxDatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_max()));
					percent5DatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_percent5()));
					percent25DatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_percent25()));
					percent50DatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_percent50()));
					percent75DatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_percent75()));
					percent99DatasetJo.addData(JsonMapper.mapToCStoneStorageStatDataJO(stats.getP_percent99()));
				}
				
				cStoneStorageAttrStatsJo.addDataset(countDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(nullcountDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(stddevDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(varianceDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(avgDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(minDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(maxDatasetJo);
				cStoneStorageAttrStatsJo.addDataset(percent5DatasetJo);
				cStoneStorageAttrStatsJo.addDataset(percent25DatasetJo);
				cStoneStorageAttrStatsJo.addDataset(percent50DatasetJo);
				cStoneStorageAttrStatsJo.addDataset(percent75DatasetJo);
				cStoneStorageAttrStatsJo.addDataset(percent99DatasetJo);
			}
			
			cStoneStorageAttrStatsJo.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"cstone storage attr stats"));
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception Occured While Fetching Storage Attr DQM Stats from CStone",ZebraPortalException.Reason.CSTONE_STORAGE_ATTR_STATS_EXCEPTION,zse);
		}catch (Throwable t) {
			throw new ZebraPortalException("Unexpected Exception Occured While Fetching Storage Attr DQM Stats from CStone",ZebraPortalException.Reason.CSTONE_STORAGE_ATTR_STATS_EXCEPTION,t);
		}
		
		return cStoneStorageAttrStatsJo ;
		
	}

}
