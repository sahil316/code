package com.aexp.gdac.zebra.portal.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.RegisterColumnMDJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.portal.RegisterFeedMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

public class RegisterFeedMetadataServlet extends HttpServlet{

	private final static Logger logger = Logger.getLogger(RegisterFeedMetadataServlet.class);

	private static final String PARAM_FEED_DATA_JSON ="feed_data_json";

	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	
    	String jsonString = (String)request.getParameter(PARAM_FEED_DATA_JSON);
    	StatusJO status = null;
    	
    	try {
    		if(jsonString == null){
    			jsonString  = JsonParser.jsonFromRequest(request);
    		}
    		logger.info("Register Feed Metadata Request:"+jsonString);
    		
    		FeedMetadataJO regFeedMdJo = JsonParser.jsonToRegisterFeedMDJO(jsonString);
    		RegisterFeedMetadataStep registerFeedMDImpl = new RegisterFeedMetadataStep();
    		status = registerFeedMDImpl.registerFeedMetadata(regFeedMdJo,regFeedMdJo.getUser_id());
    		out.write(JsonParser.statusToJson(new StatusRespJO(status)));
			
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured while registering feed ",zpe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Feed Register"))));
			}
			
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Feed Register"))));
			return ;
		}catch(Exception e){
			logger.error("Unexpected exception occured ",e);
			
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Register"))));
			}
			
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Register"))));
			return ;
		}
    	if(logger.isDebugEnabled()){
    		logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(status)));
    	}
        
    }
    

}
