package com.aexp.gdac.zebra.portal;


public class ZebraPortalException  extends Exception {
	
	private Reason reason ;

	public ZebraPortalException(Exception e) {
		// TODO Auto-generated constructor stub
		super(e);
	}

	public ZebraPortalException(String message){
		super(message);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraPortalException(Reason reason){
		this.reason = reason;
	}
	
	public ZebraPortalException(String message ,Reason reason){
		super(message);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraPortalException(String message , Throwable cause){
		super(message,cause);
	}
	
	public ZebraPortalException(Throwable cause){
		super(cause);
	}
	
	public ZebraPortalException(Reason reason,Throwable cause){
		super(cause);
		this.reason = reason ;
	}
	
	public ZebraPortalException(String message ,Reason reason,Throwable cause){
		super(message,cause);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public Reason getReason() {
		return reason;
	}

	public void setReason(Reason reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "ZebraPortalException [reason=" + reason + " desc:"+reason.getReasonDesc()+"]";
	}
	
	
	public enum Reason{
		OPERATION_NOT_AUTHORIZED("User not authorized to perform operation"),
		CSTONE_STORAGE_DETAIL_EXCEPTION("Exceptino occured while handling List Cstone Storage Detail request"),
		CSTONE_STORAGE_STATS_EXCEPTION("Exceptino occured while handling Cstone Storage Stats request"),
		CSTONE_STORAGE_ATTR_STATS_EXCEPTION("Exceptino occured while handling Cstone Storage Attr Stats request"),
		FEED_MD_REGISTER_EXCEPTION("Exception Occured while registering feed metadata "),
		COLUMN_MD_REGISTER_EXCEPTION("Exception Occured while registering column metadata "),
		STATS_REGISTER_EXCEPTION("Exception Occured while registering stats "),
		FEED_STATS_TREE_EXCEPTION("Exception occured while creating Feed stats tree"),
		FEED_STATS_REPORT_EXCEPTION("Exception occured while handling stats report request"),
		FEED_STATS_TREND_EXCEPTION("Exception occured while handling trending request"),
		LIST_FEED_COLUMN_EXCEPTION("Exception occured while handling Feed Info Detail request"),
		FETCH_FEED_MD_EXCEPTION("Exception occured while fetching feed metadata from DB"),
		FETCH_COLUMN_MD_EXCEPTION("Exception occured while fetching column metadata from DB"),
		COLUMN_MD_UPDATE_EXCEPTION("Exception Occured while updating column metadata "),
		FEED_MD_UPDATE_EXCEPTION("Exception Occured while updating feed metadata "),
		UPLOAD_COLUMN_MD_EXCEPTION("Upload ColumnMetadata file failed"),
		EXPORT_COLUMN_MD_EXCEPTION("Export ColumnMetadata file failed"),
		DUPLICATE_FEED_UPDATE_ERROR("Unable to update feed. Duplicate name in feed."),
		DUPLICATE_FEED_ADD_ERROR("Unable to register feed. Duplicate name in feed."),
		UNEXPECTED_EXCEPTION("Unexpected exception occured"),
		EXPIRED_FEED_COLUMN_MD_UPDATE_EXCEPTION("Exception Occured while updating column metadata of expired feed.");
		
		private String reasonDesc ;
		
		private Reason(){
		}
		
		private Reason(String desc){
			reasonDesc = desc ;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}
		
	}

}
