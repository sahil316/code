package com.aexp.gdac.zebra.portal;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.common.json.model.ColumnMetadataJO;
import com.aexp.gdac.zebra.common.json.model.ColumnRuleMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FetchColumnMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class FetchColumnMetadataStep {
	private final static Logger logger = Logger.getLogger(FetchColumnMetadataStep.class);
	private ColumnRuleMetadataDAO colRuleMdDAO ;
	private ColumnMetadataDAO colMdDAO;
	private FeedMetadataDAO feedMdDAO ;
	
	public FetchColumnMetadataStep(){
		this.feedMdDAO = (FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO");
		this.colRuleMdDAO = (ColumnRuleMetadataDAO) ZebraResourceManager.getBean("columnRuleMetadataDAO");
		this.colMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
	}
	
	
	public FetchColumnMDResponseJO fetchColumnMetadataResponse(Long feedID,Long columnID) throws ZebraPortalException{
		
		FetchColumnMDResponseJO response = new FetchColumnMDResponseJO();
		FetchColumnMDResponseJO.FetchColumnMDResultJO resultJo = new FetchColumnMDResponseJO.FetchColumnMDResultJO();
		
		List<ColumnMetadata> colMdList = new ArrayList<ColumnMetadata>() ;
		try {
			FeedMetadata currFeedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedID);
			
			if(currFeedMd==null){
				throw new ZebraPortalException("Feed Not Fount for ID:"+feedID,ZebraPortalException.Reason.FETCH_COLUMN_MD_EXCEPTION);
			}
			if(columnID == null){
					colMdList=colMdDAO.getColumnMetadataByFeedIDAndEndDate(currFeedMd.getFeedID(),currFeedMd.getEndDate(), 0, -1);
			}else{
					colMdList.add( (ColumnMetadata)colMdDAO.getObjectByColumnIdFeedIDAndEndDate(feedID, columnID, currFeedMd.getEndDate()));
			}
			
			for(ColumnMetadata colMd : colMdList){
				ColumnMetadataJO colMdJo = JsonMapper.mapToColumnMetadataJO(colMd);
				List<ColumnRuleMetadata> colRuleMdList = colRuleMdDAO.getColumnRuleMetadataByColumnIDAndFeedIDAndEndDate(feedID, colMd.getColumnID(), currFeedMd.getEndDate(), 0, -1);
				for(ColumnRuleMetadata colRuleMd : colRuleMdList){
					ColumnRuleMetadataJO colRuleMdJo = JsonMapper.mapToColumnRuleMetadataJO(colRuleMd, colMd.getColumnName());
					colMdJo.addRules(colRuleMdJo);
				}
				resultJo.add(colMdJo);
				
			}
		
			resultJo.setFeedID(""+feedID);
			resultJo.setFileFormat(currFeedMd.getFileFormat());
			
			resultJo.setFeedName(currFeedMd.getFeedName());
			resultJo.setStartDate(new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(currFeedMd.getStartDate().getTime())));
			resultJo.setEndDate(new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(currFeedMd.getEndDate().getTime())));
			
			if(!colMdList.isEmpty() && colMdList.get(0) != null){
				resultJo.setFeedName(colMdList.get(0).getFeedName());
				resultJo.setUserID(colMdList.get(0).getUserID());
			}
	
			
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException(ZebraPortalException.Reason.FETCH_COLUMN_MD_EXCEPTION,zse);
		}

		response.setResult(resultJo);
		response.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"Fetch Column and ColumnRule Metadata"));
		
		return response;
		
	}
}
