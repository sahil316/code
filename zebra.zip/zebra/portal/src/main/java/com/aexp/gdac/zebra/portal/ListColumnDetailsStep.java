package com.aexp.gdac.zebra.portal;

import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.ColumnInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.ColumnRuleInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO.FeedInfoJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class ListColumnDetailsStep {

	private final static Logger logger = Logger.getLogger(ListColumnDetailsStep.class);
	
	private FeedMetadataDAO feedMdDAO ;
	private ColumnMetadataDAO colMdDAO ;
	private ColumnRuleMetadataDAO colRuleMdDAO ;
	private long feedID;
	
	public ListColumnDetailsStep(){
		feedMdDAO = (FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO");
		colMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
		colRuleMdDAO = (ColumnRuleMetadataDAO) ZebraResourceManager.getBean("columnRuleMetadataDAO");
	}
	
	public ListColumnDetailsStep(long feedID){
		feedMdDAO = (FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO");
		colMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
		colRuleMdDAO = (ColumnRuleMetadataDAO) ZebraResourceManager.getBean("columnRuleMetadataDAO");
		this.feedID = feedID;
	}
	
	public FeedInfoJO listColumnDetailInfo(Long feedID){
		FeedInfoJO feedInfoJo = null;
		try {
			FeedMetadata feedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedID);
			feedInfoJo = JsonMapper.mapToFeedInfoJO(feedMd);
			List<TableValueObjectBase> colMdList= colMdDAO.getColumnMetadataByFeedIDAndEndDate(feedMd.getFeedID(), feedMd.getEndDate(), 0, -1);
				
				for(TableValueObjectBase c_metadata : colMdList){
					ColumnMetadata colMd = (ColumnMetadata) c_metadata;
					ColumnInfoJO colInfoJo = JsonMapper.mapToColumnInfoJO(colMd);
					
					List<ColumnRuleMetadata> colRuleMdList = colRuleMdDAO.getColumnRuleMetadataByColumnIDAndFeedIDAndEndDate(colMd.getFeedID(), colMd.getColumnID(), feedMd.getEndDate(), 0, -1);
					
					for(TableValueObjectBase cr_metadata : colRuleMdList){
						ColumnRuleMetadata colRuleMd = (ColumnRuleMetadata) cr_metadata ;
						ColumnRuleInfoJO colRuleInfoJo = JsonMapper.mapToColumnRuleInfoJO(colRuleMd);
						colInfoJo.addColumnRulenfo(colRuleInfoJo);
					}
					feedInfoJo.addColumnInfo(colInfoJo);
				}
				
				/* sorting column data*/
				feedInfoJo.sortColumnList();
				feedInfoJo.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"info"));
			
		} catch (ZebraServiceException zse) {
			logger.error("Exception occured while creating feed info list !",zse);
			feedInfoJo = new FeedInfoJO();
			feedInfoJo.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE,"Exception occured while creating feed info !","info"));
		} catch(Exception e){
			logger.error("Unexpected Exception occured !",e);
			feedInfoJo = new FeedInfoJO();
			feedInfoJo.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE,"Unexpected Exception occured while creating feed info!","info"));
		}
		
		if(logger.isDebugEnabled()){
			logger.debug(JsonParser.statusToJson(feedInfoJo.getStatus()));
		}
		return feedInfoJo ;
	}
	
	
	public long getFeedID() {
		return feedID;
	}

	public void setFeedID(long feedID) {
		this.feedID = feedID;
	}


}
