package com.aexp.gdac.zebra.portal;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.Action;
import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.common.json.model.FeedStatsBranchJO;
import com.aexp.gdac.zebra.common.json.model.FeedStatsTreeJO;
import com.aexp.gdac.zebra.common.json.model.StatsReportRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;


public class StatsReportStep {

	private final static Logger logger = Logger.getLogger(StatsReportStep.class);

	private StatsDAO statsDAO ;
	private FeedStatsDAO feedStatsDAO ;
	private ColumnStatsDAO colStatsDAO ;
	private ColumnRuleStatsDAO colRuleStatsDAO ;
	private int columnStatsLimit = 25 ;
	
	public StatsReportStep() {
		statsDAO = (StatsDAO) ZebraResourceManager.getBean("statsDAO");
		feedStatsDAO = (FeedStatsDAO) ZebraResourceManager.getBean("feedStatsDAO");
		colStatsDAO = (ColumnStatsDAO) ZebraResourceManager.getBean("columnStatsDAO");
		colRuleStatsDAO = (ColumnRuleStatsDAO) ZebraResourceManager.getBean("columnRuleStatsDAO");
	}

	public FeedStatsTreeJO getFeedStatsTree(StatsReportRequestJO statsReqJo) throws ZebraPortalException{
		FeedStatsTreeJO feedStatsTreeJO = new FeedStatsTreeJO();
		try {
			logger.info("Fetching Past "+statsReqJo.getPastRuns()+" Feed Stats from database for FeedID:"+statsReqJo.getFeedID());
			List<Stats> statsList = statsDAO.getStatsPastRuns(new Long(statsReqJo.getFeedID()), 0, Integer.parseInt(statsReqJo.getPastRuns()));
			
			/* arrange fetched result in ascending order */
		//	Collections.sort(statsList);
			
			feedStatsTreeJO.setFeedID(statsReqJo.getFeedID());
			feedStatsTreeJO.setPastRun(statsReqJo.getPastRuns());

			for(TableValueObjectBase stats : statsList){
				if(((Stats)stats).getAction() != null){
				
					FeedStats feedStats = (FeedStats) feedStatsDAO.getObjectByFeedIdAndStateID(((Stats)stats).getFeedID(),((Stats)stats).getStateID());
					FeedStatsBranchJO feedLevelJo = getFeedLevelStatsJo(feedStats,new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format( new Date(((Stats)stats).getProcessDate().getTime()) ));
					feedLevelJo.setStatus(Action.valueOf(((Stats)stats).getAction()).getActoinCode());
					feedStatsTreeJO.addBranchStatsJO(feedLevelJo);
				}
			}
			
			feedStatsTreeJO.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Stats Report request processed successully"));
		} catch (ZebraServiceException zse){
			logger.error("Exception occured while fetching stats from DB ",zse);
			feedStatsTreeJO.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Exception occured while fetching stats from DB ","Stats Report"));
		} catch (Exception e){
			logger.error("Unexpected Exception Occured ",e);
			feedStatsTreeJO.setStatus(new StatusJO(StatusJO.RESP_CODE_FAILURE,"Unexpected Exception Occured ","Stats Report"));
		}
		
		return feedStatsTreeJO;
	}
	
	
	private FeedStatsBranchJO getFeedLevelStatsJo(FeedStats feedStats, String feedStatsName) throws ZebraPortalException{
		FeedStatsBranchJO feedLevelJo = JsonMapper.mapToFeedLevelStatsJo(feedStats,feedStatsName);
		List<TableValueObjectBase> statsList;
		//boolean exceedsColStatsLimit = false ;
		
		try {
			statsList = colStatsDAO.getColumnStatsByFeedIDAndStateID(feedStats.getFeedID(), feedStats.getStateID());
			
//			if(statsList.size() > columnStatsLimit){
//				exceedsColStatsLimit = true ;
//			}
			
			Action columnLevelAction = Action.PASS;
			for(TableValueObjectBase stats : statsList) {
				ColumnStats colStats = (ColumnStats)stats;
				
				FeedStatsBranchJO colStatsBranchJO = getColumnLevelStatsJO(colStats);
				//If there is no rule then above will return null and we don't require to send it in to report.
			    if(colStatsBranchJO == null) 
			    	continue;
				
				if(colStatsBranchJO!=null){
					feedLevelJo.addColumnBranchStatsJO(colStatsBranchJO);
				}
				
				if(Action.valueOf(colStats.getAction()).getActoinCode() > columnLevelAction.getActoinCode()){
					columnLevelAction = Action.valueOf(colStats.getAction());
				}
			}
		
			feedLevelJo.updateColumnBranchStatsAction(columnLevelAction.name(),columnLevelAction.getActoinCode());
			
			
			/* sort data */
			if(feedLevelJo.getChildren()!=null &&
					feedLevelJo.getChildren().get(1)!=null){
				sortColumnByName(feedLevelJo.getChildren().get(1).getChildren());
			}
			
			/*if(feedLevelJo.getStatus() < columnLevelAction.getActoinCode()){
				feedLevelJo.setStatus(columnLevelAction.getActoinCode());
			}*/
			
		} catch (ZebraServiceException zse) {
			logger.error("Exception occured while generating Feed Level Stats JsonObject",zse);
			throw new ZebraPortalException("Exception occured while generating Feed Level Stats JsonObject",ZebraPortalException.Reason.FEED_STATS_REPORT_EXCEPTION,zse);
		}
		
		return feedLevelJo;
		
	}
	
	
	private FeedStatsBranchJO getColumnLevelStatsJO(ColumnStats colStats) throws ZebraPortalException {
		FeedStatsBranchJO colStatsBranchJO = JsonMapper.mapToColulmnLevelStatsJo(colStats);
		
		try{
			List<TableValueObjectBase> statsList = colRuleStatsDAO.getColumnRuleStatsByColumnIDAndStateID(colStats.getColumnID(), colStats.getFeedID(), colStats.getStateID());
			
			if( statsList.isEmpty()){
				return null ;
			}
			
			for(TableValueObjectBase stats : statsList){
				colStatsBranchJO.addBranchStatsJO(JsonMapper.mapToColumnRuleLevelStatsJo((ColumnRuleStats)stats));
				
			}

		}catch (ZebraServiceException zse) {
			logger.error("Exception occured while generating Column Level Stats JsonObject",zse);
			throw new ZebraPortalException("Exception occured while generating Column Level Stats JsonObject",ZebraPortalException.Reason.FEED_STATS_REPORT_EXCEPTION,zse);
		}
		
		return colStatsBranchJO ;
		
	}
	
	private void sortColumnByName(List<FeedStatsBranchJO> children){
		if(children != null){
			Collections.sort(children);
		}
	}

	
}
