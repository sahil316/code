package com.aexp.gdac.zebra.portal;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.SLAMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class RegisterFeedMetadataStep {
	private final static Logger logger = Logger.getLogger(RegisterFeedMetadataStep.class);
	private FeedMetadataDAO feedMDDAO ;
	private SLAMetadataDAO slaMDDAO ;
	

	public RegisterFeedMetadataStep(){
		feedMDDAO = (FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO");
		slaMDDAO = (SLAMetadataDAO) ZebraResourceManager.getBean("slaMetadataDAO");
	}
	
	public RegisterFeedMetadataStep( FeedMetadataDAO feedMDDAO, SLAMetadataDAO slaMDDAO){
		this.feedMDDAO = feedMDDAO;
		this.slaMDDAO = slaMDDAO;
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public StatusJO registerFeedMetadata(FeedMetadataJO feedJO, String userId) throws ZebraPortalException{
		
		try {
			FeedMetadata feedMD = JsonMapper.mapToFeedMetadata(feedJO,userId);
			List<TableValueObjectBase> feedMdList= feedMDDAO.getAllFeedMetadata();
			Map<Long, String> feedMap = new HashMap<Long, String>();
			for(TableValueObjectBase f_metadata : feedMdList){
				FeedMetadata feedMetadata = (FeedMetadata)f_metadata;
					feedMap.put(feedMetadata.getFeedID(), feedMetadata.getFeedName().toUpperCase());
			}
			//logger.debug("Feed Map During register: "+ feedMap);
			if(feedMap.containsValue(feedMD.getFeedName().toUpperCase())){
				logger.info("User is trying to update a feed with same name.");
				throw new ZebraPortalException(ZebraPortalException.Reason.DUPLICATE_FEED_ADD_ERROR);
			}
			
			assertRegisterFeedRequest(feedMD);
			
			Long feedID = (Long)feedMDDAO.create(feedMD);
			//FeedMetadata registerFeedMd = (FeedMetadata)feedMDDAO.getFeedIDByUserIDAndFeedName(feedJO.getEmail_id(), feedJO.getFeed_name());
			logger.info("FeedMetadata Registeration Successfull, id: "+feedID+", name:"+feedMD.getFeedName()+", emailId"+feedMD.getEmailID());
			
			feedJO.setFeed_Id(""+feedID);
			
			SLAMetadata slaMd = JsonMapper.mapToSLAMetadata(feedJO, userId);
			
			if(slaMd != null){
				slaMDDAO.create(slaMd);
			}
			
			return new StatusJO(""+feedID,feedMD.getFeedName(),feedMD.getUserID(),StatusJO.RESP_CODE_SUCCESS, 
					StatusJO.RESP_MESSAGE_SUCCESS, "Feed Register",new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(feedMD.getStartDate().getTime()))
					,new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(feedMD.getEndDate().getTime())),feedMD.getFileFormat()) ;
			
		} catch (ZebraServiceException zse){
			logger.error("Exception Occured while registering feed metadata ",zse);
			throw new IllegalArgumentException("Exception Occured while registering feed in DB");
		}
	}
	
	private void assertRegisterFeedRequest(FeedMetadata feedMd) throws ZebraPortalException{
		if(feedMd.getEndDate().compareTo(new Date()) < 0){
			throw new ZebraPortalException("EndDate in register request is lesser than current date  ",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
		}
		/*
		if(feedMd.getStartDate().compareTo(new Date()) < 0){
			throw new ZebraPortalException("StartDate in register request is lesser than current date  ",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
		}*/
		
		if(feedMd.getStartDate().compareTo(feedMd.getEndDate()) >= 0){
			throw new ZebraPortalException("StartDate in not lesser than EndDate  ",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
		}
	}

	public FeedMetadataDAO getFeedMDDAO() {
		return feedMDDAO;
	}

	public void setFeedMDDAO(FeedMetadataDAO feedMDDAO) {
		this.feedMDDAO = feedMDDAO;
	}

	public SLAMetadataDAO getSlaMDDAO() {
		return slaMDDAO;
	}

	public void setSlaMDDAO(SLAMetadataDAO slaMDDAO) {
		this.slaMDDAO = slaMDDAO;
	}

	
}
