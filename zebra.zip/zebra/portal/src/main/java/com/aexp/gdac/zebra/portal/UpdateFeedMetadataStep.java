package com.aexp.gdac.zebra.portal;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.SLAMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class UpdateFeedMetadataStep  {

	private final static Logger logger = Logger.getLogger(UpdateFeedMetadataStep.class);

	private FeedMetadataDAO feedMdDAO ;
	private ColumnMetadataDAO colMdDAO ;
	private ColumnRuleMetadataDAO colRuleMdDAO ;
	private SLAMetadataDAO slaMdDAO ;
	
	public UpdateFeedMetadataStep(){
		this.feedMdDAO = (FeedMetadataDAO)ZebraResourceManager.getBean("feedMetadataDAO");
		this.colMdDAO = (ColumnMetadataDAO)ZebraResourceManager.getBean("columnMetadataDAO");
		this.colRuleMdDAO = (ColumnRuleMetadataDAO)ZebraResourceManager.getBean("columnRuleMetadataDAO");
		this.slaMdDAO = (SLAMetadataDAO)ZebraResourceManager.getBean("slaMetadataDAO");
	}
	
	
	public UpdateFeedMetadataStep(FeedMetadataDAO feedMdDAO,SLAMetadataDAO slaMdDAO, ColumnMetadataDAO colMdDAO,ColumnRuleMetadataDAO colRuleMdDAO){
		this.feedMdDAO = feedMdDAO;
		this.colMdDAO = colMdDAO;
		this.colRuleMdDAO = colRuleMdDAO;
		this.slaMdDAO = slaMdDAO;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public StatusJO updateFeedMetadata(FeedMetadataJO feedMdJo, String userId) throws ZebraPortalException{

			FeedMetadata feedMd = JsonMapper.mapToFeedMetadata(feedMdJo,userId);
			SLAMetadata slaMd = JsonMapper.mapToSLAMetadata(feedMdJo,userId);
			
			assertUpdateFeedRequest(feedMd);
			updateFeedAndSLAMetadata(feedMd,slaMd);
		
			logger.info("FeedMetadata Updation Successfull, id: "+feedMd.getFeedID()+", name:"+feedMd.getFeedName()+", emailId"+feedMd.getEmailID());
		
			return new StatusJO(""+feedMd.getFeedID(),feedMd.getFeedName(),feedMd.getUserID(),StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Feed Metadata Update") ;
	}
	
	private void updateFeedAndSLAMetadata(FeedMetadata feedMd, SLAMetadata slaMd) throws ZebraPortalException{
		try {
			
			List<TableValueObjectBase> feedMdList= feedMdDAO.getAllFeedMetadata();
			Map<Long, String> feedMap = new HashMap<Long, String>();
			for(TableValueObjectBase f_metadata : feedMdList){
				FeedMetadata feedMetadata = (FeedMetadata)f_metadata;
				if(!feedMetadata.getFeedID().equals(feedMd.getFeedID())){
					feedMap.put(feedMetadata.getFeedID(), feedMetadata.getFeedName().toUpperCase());
				}
			}
			logger.debug("Feed Map during update: "+ feedMap);
			if(feedMap.containsValue(feedMd.getFeedName().toUpperCase())){
				logger.info("User is trying to update a feed with same name : "+feedMd.getFeedName());
				//throw new ZebraServiceException("Feed is already exist with same name.");
				throw new ZebraPortalException(ZebraPortalException.Reason.DUPLICATE_FEED_UPDATE_ERROR);
			}
			
			FeedMetadata currFeedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedMd.getFeedID());			
			//reset end date if it is in future
			if(currFeedMd.getEndDate().compareTo(new Date()) >= 0)
				feedMdDAO.updateFeedMetadataEndDate(currFeedMd);
			
			feedMdDAO.create(feedMd);
			
			
			updateSLAMetadata(slaMd,currFeedMd);
			updateColumnMetadataEndDate(feedMd,currFeedMd);
			updateColumnRuleMetadataEndDate(feedMd,currFeedMd);
			
			
		} catch (ZebraServiceException e) {
			logger.error("Exception Occured while updating feed metadata ",e);
			throw new ZebraPortalException("Exception occured while updating feed metadata :"+feedMd,ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION,e);
		}

	}
	
	private void updateSLAMetadata(SLAMetadata slaMd, FeedMetadata currFeedMd) throws ZebraPortalException{
		try{
				SLAMetadata currentSlaMd = (SLAMetadata) slaMdDAO.getSLAMetadataByFeedIDAndEndDate(currFeedMd.getFeedID(),currFeedMd.getEndDate());
				
				if(currentSlaMd!=null){
				  slaMdDAO.updateSLAMetadataEndDate(currentSlaMd);
				}
				
				if(slaMd!=null){
					slaMdDAO.create(slaMd);
				}

		}catch (ZebraServiceException zse) {
				throw new ZebraPortalException("Failed To update sla metadata EndDate ",ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION,zse);
		}

	}
	
	private void updateColumnMetadataEndDate(FeedMetadata feedUIMd,FeedMetadata currDBFeedMd) throws ZebraPortalException{
		//if feed's end date or start date is changed then update latest version of column metadata
		if(!currDBFeedMd.getEndDate().toString().equals(feedUIMd.getEndDate().toString())
				|| !currDBFeedMd.getStartDate().toString().equals(feedUIMd.getStartDate().toString())){
			try {
//				List<ColumnMetadata> colMdList = colMdDAO.getColumnMetadataByFeedIDAndEndDate(currDBFeedMd.getFeedID(), currDBFeedMd.getEndDate(), 0, -1);
//				
//				logger.info("Fetched ColumnMetadata " +colMdList.size()+" from DB");
//				/** update end date of existing column  metadata for versioning */
//				int updateCount = colMdDAO.updateColumnMetadataEndDateByFeedIDAndEndDate(currDBFeedMd.getFeedID(), currDBFeedMd.getEndDate());
//				
//				logger.info("Updated " +updateCount+" ColumnMetadata in DB");
//				
//				for(ColumnMetadata colMd : colMdList){
//					/** set new start and end date and update in db */
//					//String aQuery = "UPDATE ColumnMetadata SET EndDate=? WHERE FeedID=? AND ColumnID=? AND EndDate=?",feedUIMd.getEndDate(),colMd.getFeedID(),colMd.getColumnID(),currDBFeedMd.getEndDate());
//					colMd.setEndDate(feedUIMd.getEndDate());
//					//colMd.setStartDate(feedUIMd.getStartDate());
//					//colMdDAO.create(colMd);
//					//temporary
//					logger.error(colMd);
//					colMdDAO.update(colMd);
//				}
				colMdDAO.synchColumnMetadataEndDate(feedUIMd.getEndDate(),currDBFeedMd.getEndDate(),currDBFeedMd.getFeedID());
				
			} catch (ZebraServiceException zse) {
				throw new ZebraPortalException("Failed To update column metadata EndDate ",ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION,zse);
			}
			
		}
	}
	
	private void updateColumnRuleMetadataEndDate(FeedMetadata feedUIMd,FeedMetadata currDBFeedMd) throws ZebraPortalException{
		//if feed's end date or start date is changed then update latest version of rule metadata
		if(!currDBFeedMd.getEndDate().toString().equals(feedUIMd.getEndDate().toString())
				|| !currDBFeedMd.getStartDate().toString().equals(feedUIMd.getStartDate().toString())){
			
			try {
//				List<ColumnRuleMetadata> colRuleMdList = colRuleMdDAO.getColumnRuleMetadataByFeedIDAndEndDate(currFeedMd.getFeedID(), currFeedMd.getEndDate(), 0, -1);
//				
//				logger.info("Fetched ColumnRuleMetadata " +colRuleMdList.size()+" from DB");
//				
//					/** update end date of existing column rule metadata for versioning */
//				int updateCount = colRuleMdDAO.updateColumnRuleMetadataEndDateByFeedIDAndEndDate(currFeedMd.getFeedID(), currFeedMd.getEndDate());
//				
//				logger.info("Updated " +updateCount+" ColumnRuleMetadata in DB");
//				
//				for(ColumnRuleMetadata colRuleMd : colRuleMdList){
//					/** set new start and end date and insert in db */
//					colRuleMd.setEndDate(feedMd.getEndDate());
//					colRuleMd.setStartDate(feedMd.getStartDate());
//					//colRuleMdDAO.create(colRuleMd);
//					colRuleMdDAO.update(colRuleMd);
//				}

				colRuleMdDAO.synchColumnRuleMetadataEndDate(feedUIMd.getEndDate(),currDBFeedMd.getEndDate(),currDBFeedMd.getFeedID());
				
			} catch (ZebraServiceException zse) {
				throw new ZebraPortalException("Failed To update column rule metadata EndDate ",ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION,zse);
			}
			
		}
	}
	private void assertUpdateFeedRequest(FeedMetadata feedMd) throws ZebraPortalException{
		if(feedMd.getEndDate().compareTo(new Date()) < 0){
			throw new ZebraPortalException("EndDate in update request is lesser than current date  ",ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION);
		}
		/*
		if(feedMd.getStartDate().compareTo(new Date()) < 0){
			throw new ZebraPortalException("StartDate in update request is lesser than current date  ",ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION);
		}*/
	}


	public FeedMetadataDAO getFeedMdDAO() {
		return feedMdDAO;
	}


	public void setFeedMdDAO(FeedMetadataDAO feedMdDAO) {
		this.feedMdDAO = feedMdDAO;
	}


	public ColumnMetadataDAO getColMdDAO() {
		return colMdDAO;
	}


	public void setColMdDAO(ColumnMetadataDAO colMdDAO) {
		this.colMdDAO = colMdDAO;
	}


	public ColumnRuleMetadataDAO getColRuleMdDAO() {
		return colRuleMdDAO;
	}


	public void setColRuleMdDAO(ColumnRuleMetadataDAO colRuleMdDAO) {
		this.colRuleMdDAO = colRuleMdDAO;
	}


	public SLAMetadataDAO getSlaMdDAO() {
		return slaMdDAO;
	}


	public void setSlaMdDAO(SLAMetadataDAO slaMdDAO) {
		this.slaMdDAO = slaMdDAO;
	}
	
}
