package com.aexp.gdac.zebra.portal;

import java.util.List;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.CStoneStorageDAO;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneStorage;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageDetailJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.CStoneStorageDetailJO.CStoneStorageResultJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class CStoneStorageDetailsStep {
	
	private CStoneStorageDAO cStoneStorageDAO ;
	
	public CStoneStorageDetailsStep(){
		this.cStoneStorageDAO = (CStoneStorageDAO)ZebraResourceManager.getBean("cStoneStorageDAO");
	}
	
	public CStoneStorageDetailJO getCStoneStorageDetails() throws ZebraPortalException{
		CStoneStorageDetailJO cstoneStorageDetailsJo = new CStoneStorageDetailJO ();

		try {
			CStoneStorageResultJO cStoneStorageResultJo = null ;
			
			List<CStoneStorage> cStoneStorageList = cStoneStorageDAO.getAllCStoneStorageDetails() ;
			
			if(!cStoneStorageList.isEmpty()){
				cStoneStorageResultJo = new CStoneStorageResultJO() ;
			}
			
			for(CStoneStorage cStoneStorage : cStoneStorageList){
				cStoneStorageResultJo.addCStoneStorageInfoJO(JsonMapper.mapToCStoneStorageInfoJO(cStoneStorage));
			}
			
			cstoneStorageDetailsJo.setResult(cStoneStorageResultJo);
			cstoneStorageDetailsJo.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"cstone starge info"));
			
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception Occured While Fetching Storage Details from CStone",ZebraPortalException.Reason.CSTONE_STORAGE_DETAIL_EXCEPTION,zse);
		}

		return cstoneStorageDetailsJo;
	}

}
