package com.aexp.gdac.zebra.portal;

import java.util.List;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;

public class ExportColumnMetadataStep {
	
	private ColumnMetadataDAO columnMdDAO ;
	
	public ExportColumnMetadataStep(){
		this.columnMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
	}
	
	
	
	public String getColumnMetadataTextStream(Long feedId) throws ZebraPortalException {
		
		StringBuilder columnMdTextStreanBuilder = new StringBuilder () ;
		
		try {
			List<ColumnMetadata> columnMdList = columnMdDAO.getEligibleColumnMetadataByFeedID(feedId, 0, -1) ;
			
			if(!columnMdList.isEmpty()){
				for(ColumnMetadata columnMd : columnMdList ){
					columnMdTextStreanBuilder.append(columnMd.getColumnName()).append("|")
					.append(columnMd.getDataType()).append("|") ;
					if(columnMd.getDataFormat() != null){
						columnMdTextStreanBuilder.append(columnMd.getDataFormat());
					}
					columnMdTextStreanBuilder.append("\n");
				}
			} else {
				throw new ZebraPortalException("Column metadata for feedId ["+feedId+"] doesnot exist", ZebraPortalException.Reason.EXPORT_COLUMN_MD_EXCEPTION);
			}
			
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception occred while exporting column metadata for feedId ["+feedId+"]", ZebraPortalException.Reason.EXPORT_COLUMN_MD_EXCEPTION, zse);
		}
		
		return columnMdTextStreanBuilder.toString() ;

	}
	
	

}
