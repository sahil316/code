package com.aexp.gdac.zebra.portal.manager;


import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.common.json.model.RegisterColumnMDJO;
import com.aexp.gdac.zebra.common.json.model.UpdateColumnMDJO;
import com.aexp.gdac.zebra.portal.RegisterColumnMetadataStep;
import com.aexp.gdac.zebra.portal.UpdateColumnMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;

public class ColumnMetadataManager {

	private RegisterColumnMetadataStep regColMdStep ;
	private UpdateColumnMetadataStep updateColMdStep;

	public ColumnMetadataManager(){
		this.regColMdStep = (RegisterColumnMetadataStep) ZebraResourceManager.getBean("regColMdStep");
		this.updateColMdStep = (UpdateColumnMetadataStep) ZebraResourceManager.getBean("updateColMdStep");
	}
	
	public RegisterColumnMetadataStep getRegColMdStep() {
		return regColMdStep;
	}

	public void setRegColMdStep(RegisterColumnMetadataStep regColMdStep) {
		this.regColMdStep = regColMdStep;
	}

	public void registerColumnMetadata(RegisterColumnMDJO regColMdJo, String userId) throws ZebraPortalException{
		if(userId == null || userId.isEmpty()){
			throw new ZebraPortalException("Missing userid !!! ",ZebraPortalException.Reason.OPERATION_NOT_AUTHORIZED) ;
		}
		try{
		 regColMdStep.registerColumnMetadata(regColMdJo, userId);
		} catch (IllegalArgumentException iae) {
			throw new ZebraPortalException("Excption Occured while registering column metadata",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
	}
	
	
	public void updateColumnMetadata(UpdateColumnMDJO updateColMdJo, String userId) throws ZebraPortalException{
		if(userId == null || userId.isEmpty()){
			throw new ZebraPortalException("Missing userid !!! ",ZebraPortalException.Reason.OPERATION_NOT_AUTHORIZED) ;
		}
		try{
			updateColMdStep.updateColumnMetadata(updateColMdJo, userId);
		} catch (IllegalArgumentException iae) {
			throw new ZebraPortalException("Excption Occured while updating column metadata",ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION);
		}
	}
	
}
