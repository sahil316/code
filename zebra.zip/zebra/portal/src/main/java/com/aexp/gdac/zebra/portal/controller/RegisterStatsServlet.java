package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.portal.RegisterStatsStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class RegisterStatsServlet extends HttpServlet{

	private final static Logger logger = Logger.getLogger(RegisterStatsServlet.class);
	private static final String PARAM_STATS_REGISTER_REQUEST_JSON = "stats_register_request";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    	PrintWriter out = response.getWriter();
	    	RegisterStatsStep regStatsStepImpl = new RegisterStatsStep();
	    	
	    	String jsonString = (String)request.getParameter(PARAM_STATS_REGISTER_REQUEST_JSON);
	    	
	    	try {
	    		if(jsonString == null){
	    			jsonString  = JsonParser.jsonFromRequest(request);
	    		}
	    		logger.info("Register Stats Register Request:"+jsonString);
	    		
	    		StatsRegisterRequestJO statsRegReqJo = JsonParser.jsonToStatsRegisterRequestJO(jsonString);
	    		
	    		out.write(JsonParser.statusToJson(new StatusRespJO(regStatsStepImpl.registerStats(statsRegReqJo))));
				
			} catch (ZebraPortalException zpe) {
				logger.error("Exception Occured while registering stats ",zpe);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Stats Register"))));
				}
				out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Stats Register"))));
				return ;
			}catch(Exception e){
				logger.error("Unexpected exception occured ",e);
				if(logger.isDebugEnabled()){
					logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Stats Register"))));
				}
				
				out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Stats Register"))));
				return ;
			}
	    	if(logger.isDebugEnabled()){
	    		logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Stats Register"))));
	    	}
	        
	    }
	    
}
