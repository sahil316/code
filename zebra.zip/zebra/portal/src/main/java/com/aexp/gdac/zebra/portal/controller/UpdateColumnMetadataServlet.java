package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.common.json.model.UpdateColumnMDJO;
import com.aexp.gdac.zebra.portal.UpdateColumnMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class UpdateColumnMetadataServlet extends HttpServlet{
	
	private final static Logger logger = Logger.getLogger(UpdateColumnMetadataServlet.class);

	private static final String PARAM_COLUMN_DATA_JSON ="column_data_json";
	
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	try {
    		String jsonString = (String)request.getParameter(PARAM_COLUMN_DATA_JSON);
		
    		if(jsonString == null){
    			jsonString  = JsonParser.jsonFromRequest(request);
    		}
    	
    		logger.info("Update Column Metadata Request:"+jsonString);
    		
    		UpdateColumnMDJO updateColMdJo = JsonParser.jsonToUpdateColumnMDJO(jsonString);
    		
    		logger.info("JSON Object "+updateColMdJo);
    		UpdateColumnMetadataStep updateColMDImpl = new UpdateColumnMetadataStep();
    		updateColMDImpl.updateColumnMetadata(updateColMdJo,updateColMdJo.getUserID());
    		
    		out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(updateColMdJo.getFeedID(),updateColMdJo.getFeedName(),updateColMdJo.getUserID() ,StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Column Metadata Update"))));
    		
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured while updating column metadata ",zpe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Column Metadata Update"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Column Metadata Update"))));
			
			return ;
			
		}catch(Exception e){
			logger.error("Unexpected exception occured ",e);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Column Metadata Update"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Column Metadata Update "))));
			return ;
		}
    	if(logger.isDebugEnabled()){
    		logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Column Metadata Update"))));
    	}
    	 
    }
    
}
