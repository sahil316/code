package com.aexp.gdac.zebra.portal;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.common.json.model.ColumnMetadataJO;
import com.aexp.gdac.zebra.common.json.model.ColumnRuleMetadataJO;
import com.aexp.gdac.zebra.common.json.model.UpdateColumnMDJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class UpdateColumnMetadataStep {

	private final static Logger logger = Logger.getLogger(UpdateColumnMetadataStep.class);
	private ColumnMetadataDAO colMdDAO ;
	private ColumnRuleMetadataDAO colRuleMdDAO;
	private FeedMetadataDAO feedMdDAO ;
	
	public UpdateColumnMetadataStep(){
		this.feedMdDAO = (FeedMetadataDAO)ZebraResourceManager.getBean("feedMetadataDAO");
		this.colRuleMdDAO = (ColumnRuleMetadataDAO)ZebraResourceManager.getBean("columnRuleMetadataDAO");
		this.colMdDAO = (ColumnMetadataDAO)ZebraResourceManager.getBean("columnMetadataDAO");
	}
	
	public UpdateColumnMetadataStep(FeedMetadataDAO feedMdDAO,ColumnMetadataDAO colMdDAO,ColumnRuleMetadataDAO colRuleMdDAO){
		this.feedMdDAO = feedMdDAO ;
		this.colMdDAO = colMdDAO;
		this.colRuleMdDAO = colRuleMdDAO ;
	}
	
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void updateColumnMetadata(UpdateColumnMDJO updateColMdJo, String userID) throws ZebraPortalException{
		try{
			long feedID = Long.parseLong(updateColMdJo.getFeedID());
			String feedName = updateColMdJo.getFeedName() ;
			
			if(userID == null || userID.isEmpty()){
				userID = updateColMdJo.getUserID();
			}

			FeedMetadata currFeedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedID);
			
			//if feed is expired don't update column metadata and throw exception.
			if(currFeedMd.getEndDate().compareTo(new Date()) < 0){
					throw new ZebraPortalException(ZebraPortalException.Reason.EXPIRED_FEED_COLUMN_MD_UPDATE_EXCEPTION);
			}	
				
			updateAdditionalColumn(updateColMdJo.getColumns());
			
			versionColumnAndColumnRuleMetadata(currFeedMd.getFeedID() , currFeedMd.getEndDate());
			
			
			for(ColumnMetadataJO colMdJo :updateColMdJo.getColumns()){
					 ColumnMetadata colMd = JsonMapper.mapToExistingFeedColumnMetadata(colMdJo, currFeedMd, userID);
					 assertUpdateColumnRequest(colMd,currFeedMd);
				     long columnID =colMd.getColumnID();
				     
				     if(colMdJo.getRules()!=null){
				      for(ColumnRuleMetadataJO colRuleMdJo :colMdJo.getRules()){
					     ColumnRuleMetadata colRuleMd = JsonMapper.mapToColumnRuleMetadata(colRuleMdJo,columnID , feedID, userID);
						 assertUpdateColumnRuleRequest(colRuleMd,currFeedMd);
						 if(logger.isDebugEnabled()){
					     	logger.debug("Updating ColumnRuleMetadata: "+colRuleMd);
					     }
					     createColumnRuleMetadata(colRuleMd);
					   }
				     }
				     
					 if(logger.isDebugEnabled()){
					     logger.debug("Updating ColumnMetadata: "+colMd);
					  }
					  
					  createColumnMetadata(colMd);
			}
			
						
		}catch(NumberFormatException nfe){
			logger.error("FeedID is not an number ",nfe);
			throw new ZebraPortalException("FeedID is not an number ",ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION);
		} 
		catch(ZebraPortalException zpe){
			logger.error("ColumnMetadta updated requesred for expired Feed ",zpe);
			throw zpe;
		}
		catch (Exception zse) {
			logger.error("Exception Occured while updating column metadata ",zse);
			throw new IllegalArgumentException("Exception Occured while updating column metadata in DB");
		}
		
	}
	

	private void versionColumnAndColumnRuleMetadata(long feedID, Timestamp endDate) throws ZebraPortalException{
		try {
			colMdDAO.updateColumnMetadataEndDateByFeedIDAndEndDate(feedID ,endDate);
			colRuleMdDAO.updateColumnRuleMetadataEndDateByFeedIDAndEndDate(feedID ,endDate) ;
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception occured while updating version of column and column rule metadata for feedID "+feedID ,ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION, zse);
		}
	}
	
	
	private void createColumnMetadata(ColumnMetadata colMd) throws ZebraPortalException{
		try {
			colMdDAO.create(colMd);
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception occured while inserting column metadata "+colMd ,ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION, zse);
		}
	}

	private void createColumnRuleMetadata(ColumnRuleMetadata colRuleMd) throws ZebraPortalException{
		try {
			colRuleMdDAO.create(colRuleMd);
		} catch (ZebraServiceException zse) {
			throw new ZebraPortalException("Exception occured while updating column rule metadata "+colRuleMd ,ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION, zse);
		}
	}
	
	private void assertUpdateColumnRequest(ColumnMetadata colMd, FeedMetadata currFeedMd) throws ZebraPortalException{
		if(colMd.getEndDate().compareTo(currFeedMd.getEndDate()) != 0){
			throw new ZebraPortalException("EndDate in update request is not equal to feed end date for column update   ",ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION);
		}
		if(colMd.getStartDate().compareTo(currFeedMd.getStartDate()) != 0){
			throw new ZebraPortalException("StartDate in update request is not equal to feed start date for column update   ",ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION);
		}
	}
	
	private void assertUpdateColumnRuleRequest(ColumnRuleMetadata colRuleMd, FeedMetadata currFeedMd) throws ZebraPortalException{
		if(colRuleMd.getEndDate().compareTo(currFeedMd.getEndDate()) != 0){
			throw new ZebraPortalException("EndDate in update request is not equal to feed end date for column rule update  ",ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION);
		}
		
		if(colRuleMd.getStartDate().compareTo(currFeedMd.getStartDate()) != 0){
			throw new ZebraPortalException("Start in update request is not equal to feed start date for column rule update  ",ZebraPortalException.Reason.COLUMN_MD_UPDATE_EXCEPTION);
		}
	}
	
	private void updateAdditionalColumn(List<ColumnMetadataJO> colMdJoList){
		int lastColumnId = 0 ;
		for(ColumnMetadataJO colMdJo : colMdJoList){
			if(null != colMdJo.getColumnID() && !colMdJo.getColumnID().trim().isEmpty()){
				if(Integer.parseInt(colMdJo.getColumnID()) > lastColumnId){
					lastColumnId = 	Integer.parseInt(colMdJo.getColumnID());				
				}
			}
		}
		
		for(ColumnMetadataJO colMdJo : colMdJoList){
			if(null == colMdJo.getColumnID() || colMdJo.getColumnID().trim().isEmpty()){
				   lastColumnId ++ ;
				   
                   colMdJo.setColumnID(""+lastColumnId);
                   
                   for(ColumnRuleMetadataJO colRuleMd : colMdJo.getRules()){
                	   colRuleMd.setColumnID(""+lastColumnId);
                   }
			}
		}
		
	}

	public ColumnMetadataDAO getColMdDAO() {
		return colMdDAO;
	}

	public void setColMdDAO(ColumnMetadataDAO colMdDAO) {
		this.colMdDAO = colMdDAO;
	}

	public ColumnRuleMetadataDAO getColRuleMdDAO() {
		return colRuleMdDAO;
	}

	public void setColRuleMdDAO(ColumnRuleMetadataDAO colRuleMdDAO) {
		this.colRuleMdDAO = colRuleMdDAO;
	}

	public FeedMetadataDAO getFeedMdDAO() {
		return feedMdDAO;
	}

	public void setFeedMdDAO(FeedMetadataDAO feedMdDAO) {
		this.feedMdDAO = feedMdDAO;
	}
	
	
}
