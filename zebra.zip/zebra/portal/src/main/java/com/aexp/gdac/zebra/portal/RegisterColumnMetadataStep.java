package com.aexp.gdac.zebra.portal;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.common.json.model.ColumnMetadataJO;
import com.aexp.gdac.zebra.common.json.model.ColumnRuleMetadataJO;
import com.aexp.gdac.zebra.common.json.model.RegisterColumnMDJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

public class RegisterColumnMetadataStep {
	private final static Logger logger = Logger.getLogger(RegisterColumnMetadataStep.class);
	
	private ColumnMetadataDAO colMdDAO ;
	private ColumnRuleMetadataDAO colRuleMdDAO ;
	private FeedMetadataDAO feedMdDAO ;
	
	public RegisterColumnMetadataStep(){
		feedMdDAO = (FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO");
		colMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
		colRuleMdDAO = (ColumnRuleMetadataDAO) ZebraResourceManager.getBean("columnRuleMetadataDAO");
	}
	
	public RegisterColumnMetadataStep(FeedMetadataDAO feedMdDAO,ColumnMetadataDAO colMdDAO,ColumnRuleMetadataDAO colRuleMdDAO){
		this.feedMdDAO = feedMdDAO ;
		this.colMdDAO = colMdDAO;
		this.colRuleMdDAO = colRuleMdDAO;
	}
	
	
	/* Tables related : FeedMetadata , ColumnMetadata , ColumnRuleMetadata
	 * Tables Updated : ColumnMetadata , ColumnRuleMetadata 
	 * Fetches latest versioned Feed Metadata and Inserts column and
	 * column rule metadata in database .  
	 */
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void registerColumnMetadata(RegisterColumnMDJO regColMdJo, String userId) throws ZebraPortalException{
		
		long feedID = Long.parseLong(regColMdJo.getFeedID());
		String feedName = regColMdJo.getFeedName();
		//String userID = regColMdJo.getUserID();
		
		String userID =  userId ;
		
		long columnIdCounter = 0L;
		try {
			FeedMetadata currFeedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedID);
			
			for(ColumnMetadataJO colMdJo : regColMdJo.getColumns()){
				columnIdCounter ++;
				ColumnMetadata colMd = JsonMapper.mapToColumnMetadata(colMdJo, feedID, feedName, userID);
				colMd.setColumnID(columnIdCounter);
			
				long columnID = colMd.getColumnID() ;
				
				assertRegisterColumnRequest(colMd,currFeedMd);
				
				colMdDAO.create(colMd);

				for(ColumnRuleMetadataJO colRuleMdJo : colMdJo.getRules()){
					ColumnRuleMetadata colRuleMd = JsonMapper.mapToColumnRuleMetadata(colRuleMdJo, columnID, feedID,userID);
					
					assertRegisterColumnRuleRequest(colRuleMd,currFeedMd);
					
					colRuleMdDAO.create(colRuleMd);
				}
				
			}
		} catch (Exception zse) {
			logger.error("Exception Occured while registering column metadata ",zse);
			throw new IllegalArgumentException("Exception Occured while registering column metadata in DB");
		}
		
	}
	
	/*
	 * Checks that StartDate and EndDate must match with latest feed metadata
	 * passed before insertion in DB to maintain proper versioning
	 */
	
	private void assertRegisterColumnRequest(ColumnMetadata colMd, FeedMetadata currFeedMd) throws ZebraPortalException{
		if(colMd.getEndDate().compareTo(currFeedMd.getEndDate()) != 0){
			throw new ZebraPortalException("EndDate in register request is not equal to feed end date for column register   ",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
		if(colMd.getStartDate().compareTo(currFeedMd.getStartDate()) != 0){
			throw new ZebraPortalException("StartDate in register request is not equal to feed start date for column register   ",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
	}
	
	/*
	 * Checks that StartDate and EndDate must match with latest feed metadata
	 * passed before insertion in DB to maintain proper versioning
	 */
	private void assertRegisterColumnRuleRequest(ColumnRuleMetadata colRuleMd, FeedMetadata currFeedMd) throws ZebraPortalException{
		if(colRuleMd.getEndDate().compareTo(currFeedMd.getEndDate()) != 0){
			throw new ZebraPortalException("EndDate in register request is not equal to feed end date for column rule register  ",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
		
		if(colRuleMd.getStartDate().compareTo(currFeedMd.getStartDate()) != 0){
			throw new ZebraPortalException("EndDate in register request is not equal to feed start date for column rule register  ",ZebraPortalException.Reason.COLUMN_MD_REGISTER_EXCEPTION);
		}
	}
	
	public ColumnMetadataDAO getColMdDAO() {
		return colMdDAO;
	}

	public void setColMdDAO(ColumnMetadataDAO colMdDAO) {
		this.colMdDAO = colMdDAO;
	}

	public ColumnRuleMetadataDAO getColRuleMdDAO() {
		return colRuleMdDAO;
	}

	public void setColRuleMdDAO(ColumnRuleMetadataDAO colRuleMdDAO) {
		this.colRuleMdDAO = colRuleMdDAO;
	}

	public FeedMetadataDAO getFeedMdDAO() {
		return feedMdDAO;
	}

	public void setFeedMdDAO(FeedMetadataDAO feedMdDAO) {
		this.feedMdDAO = feedMdDAO;
	}

}
