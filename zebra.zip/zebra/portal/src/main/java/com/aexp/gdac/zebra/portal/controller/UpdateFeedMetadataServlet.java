package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.portal.UpdateFeedMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class UpdateFeedMetadataServlet extends HttpServlet{

	private final static Logger logger = Logger.getLogger(UpdateFeedMetadataServlet.class);

	private static final String PARAM_FEED_DATA_JSON ="feed_data_json";

	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	
    	String jsonString = (String)request.getParameter(PARAM_FEED_DATA_JSON);
    	
    	try {
    		if(jsonString == null){
    			jsonString  = JsonParser.jsonFromRequest(request);
    		}
    		logger.info("Update Feed Metadata Request:"+jsonString);
    		
    		FeedMetadataJO updateFeedMdJo = JsonParser.jsonToRegisterFeedMDJO(jsonString);
    		UpdateFeedMetadataStep updateFeedMDImpl = new UpdateFeedMetadataStep();
    		out.write(JsonParser.statusToJson(new StatusRespJO(updateFeedMDImpl.updateFeedMetadata(updateFeedMdJo,updateFeedMdJo.getUser_id()))));
			
		} 	catch (ZebraPortalException zpe) {
			logger.error("Exception Occured while registering feed ",zpe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Feed Metadata Update"))));
			}
			
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Feed Metadata Update"))));
			return ;
		
		}	catch(Exception e){
			logger.error("Unexpected exception occured ",e);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Metadata Update"))));
			}
			
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Feed Metadata Update"))));
			return ;
		}
    	
    	if(logger.isDebugEnabled()){
    		logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Feed Metadata Update"))));
    	}
        
    }

}
