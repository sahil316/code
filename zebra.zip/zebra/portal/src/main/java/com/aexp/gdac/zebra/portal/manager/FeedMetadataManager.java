package com.aexp.gdac.zebra.portal.manager;



import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.RegisterFeedMetadataStep;
import com.aexp.gdac.zebra.portal.UpdateFeedMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;

public class FeedMetadataManager {

	private RegisterFeedMetadataStep regFeedMdStep ;
	private UpdateFeedMetadataStep updateFeedMdStep  ;
	
	public FeedMetadataManager(){
		this.regFeedMdStep = (RegisterFeedMetadataStep) ZebraResourceManager.getBean("regFeedMdStep");
		this.updateFeedMdStep = (UpdateFeedMetadataStep) ZebraResourceManager.getBean("updateFeedMdStep");
	}
	
	public RegisterFeedMetadataStep getRegFeedMdStep() {
		return regFeedMdStep;
	}

	public void setRegFeedMdStep(RegisterFeedMetadataStep regFeedMdStep) {
		this.regFeedMdStep = regFeedMdStep;
	}

	public StatusJO registerFeedMetadata(FeedMetadataJO feedJO, String userId) throws ZebraPortalException{
		if(userId == null || userId.isEmpty()){
			throw new ZebraPortalException("Missing userid !!! ",ZebraPortalException.Reason.OPERATION_NOT_AUTHORIZED) ;
		}
		
		try{
			return regFeedMdStep.registerFeedMetadata(feedJO,userId);
		} catch (IllegalArgumentException iae) {
			throw new ZebraPortalException("Excption Occured while registering feed metadata",ZebraPortalException.Reason.FEED_MD_REGISTER_EXCEPTION);
		}
	}
	
	public StatusJO updateFeedMetadata(FeedMetadataJO feedJO, String userId) throws ZebraPortalException{
		if(userId == null || userId.isEmpty()){
			throw new ZebraPortalException("Missing userid !!! ",ZebraPortalException.Reason.OPERATION_NOT_AUTHORIZED) ;
		}
		
		try{
			return updateFeedMdStep.updateFeedMetadata(feedJO,userId);
		} catch (IllegalArgumentException iae) {
			throw new ZebraPortalException("Excption Occured while updating feed metadata",ZebraPortalException.Reason.FEED_MD_UPDATE_EXCEPTION);
		}
	}

}
