package com.aexp.gdac.zebra.portal.json;

import java.io.BufferedReader;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO;
import com.aexp.gdac.zebra.common.json.model.FeedMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FeedStatsTreeJO;
import com.aexp.gdac.zebra.common.json.model.FetchColumnMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.FetchFeedMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.RegisterColumnMDJO;
import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatsReportRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendJO;
import com.aexp.gdac.zebra.common.json.model.StatsTrendRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.common.json.model.UpdateColumnMDJO;
import com.aexp.gdac.zebra.portal.ZebraPortalException;


public class JsonParser {

	private final static Logger logger = Logger.getLogger(JsonMapper.class);
	
	private static Gson gson = new GsonBuilder().setPrettyPrinting().create();
	
	public static FeedMetadataJO jsonToRegisterFeedMDJO(String feedMdJsonStr){
		return gson.fromJson(feedMdJsonStr,FeedMetadataJO.class);
	}
	
	public static RegisterColumnMDJO jsonToRegisterColumnMDJO(String registerColumnJsonStr){
		return gson.fromJson(registerColumnJsonStr,RegisterColumnMDJO.class);
	}

	public static String registerFeedToJson(FeedMetadataJO obj){
		return gson.toJson(obj);
	}
	
	public static String feedStatsTreeToJson(FeedStatsTreeJO feedStatsTree){
		return gson.toJson(feedStatsTree);
	}
	
	public static StatsReportRequestJO jsonToStatsRequestJO(String statsRequestJson){
		return gson.fromJson(statsRequestJson, StatsReportRequestJO.class);
	}
	
	public static StatsTrendRequestJO jsonToStatsTrendRequestJO(String statsTrendReq){
		return gson.fromJson(statsTrendReq, StatsTrendRequestJO.class);
	}
	
	public static String statsTrendToJson(StatsTrendJO statsTrendJO){
		return gson.toJson(statsTrendJO);
	}
	
	public static String statusToJson(StatusJO statusJo){
		return gson.toJson(statusJo);
	}
	
	public static String statusToJson(StatusRespJO statusResJo){
		return gson.toJson(statusResJo);
	}
	
	public static String feedDetailListToJson(FeedDetailInfoJO feedListDetailJo){
		return gson.toJson(feedListDetailJo);
	}
	
	public static StatsRegisterRequestJO jsonToStatsRegisterRequestJO(String statRegisterReq){
		return gson.fromJson(statRegisterReq, StatsRegisterRequestJO.class);
	}
	
	public static String fetchFeedMetadataResponseJoToJson(FetchFeedMDResponseJO fetchFeedMDResponseJO){
		return gson.toJson(fetchFeedMDResponseJO);
	}
	
	public static String fetchColumnMetadataResponseJoToJson(FetchColumnMDResponseJO fetchColMDResponseJO){
		return gson.toJson(fetchColMDResponseJO);
	}
	
	public static UpdateColumnMDJO jsonToUpdateColumnMDJO(String updateColumnJsonStr){
		return gson.fromJson(updateColumnJsonStr,UpdateColumnMDJO.class);
	}

	
	public static String jsonFromRequest(HttpServletRequest request) throws ZebraPortalException{
 		StringBuffer jb = new StringBuffer();
		  String line = null;
		  
		  try {
		    BufferedReader reader = request.getReader();
		    while ((line = reader.readLine()) != null)
		      jb.append(line);
		  } catch (Exception e) { 
			  logger.error("Fatal Error while retriving json  ",e);
			  throw new ZebraPortalException("Fatal Error while retriving json",ZebraPortalException.Reason.UNEXPECTED_EXCEPTION,e);
		  }
		  
		 return jb.toString() ;
	}
	
}
