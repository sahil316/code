package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;











import com.aexp.gdac.zebra.common.json.model.RegisterColumnMDJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.portal.RegisterColumnMetadataStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;

public class RegisterColumnMetadataServlet extends HttpServlet{

	private final static Logger logger = Logger.getLogger(RegisterColumnMetadataServlet.class);

	private static final String PARAM_COLUMN_DATA_JSON ="column_data_json";
	
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request,response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	try {
    		String jsonString = (String)request.getParameter(PARAM_COLUMN_DATA_JSON);
		
    		if(jsonString == null){
    			jsonString  = JsonParser.jsonFromRequest(request);
    		}
    	
    		logger.info("Register Column Metadata Request:"+jsonString);
    		
    		RegisterColumnMDJO regColMdJo = JsonParser.jsonToRegisterColumnMDJO(jsonString);
    		
    		logger.info("JSON Object "+regColMdJo);
    		RegisterColumnMetadataStep registerColMDImpl = new RegisterColumnMetadataStep();
    		registerColMDImpl.registerColumnMetadata(regColMdJo,regColMdJo.getUserID());
    		
    		out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(regColMdJo.getFeedID(),regColMdJo.getFeedName(),regColMdJo.getUserID() ,StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Columns Register"))));
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured while registering column metadata ",zpe);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, zpe.getReason().getReasonDesc(), "Columns Register"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE,zpe.getReason().getReasonDesc(), "Columns Register"))));
			return ;
		}catch(Exception e){
			logger.error("Unexpected exception occured ",e);
			if(logger.isDebugEnabled()){
				logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Columns Register"))));
			}
			out.write(JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_FAILURE, "Unexpected exception occured ", "Columns Register"))));
			return ;
		}
    	if(logger.isDebugEnabled()){
    		logger.debug("Status Returned :"+JsonParser.statusToJson(new StatusRespJO(new StatusJO(StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Columns Register"))));
    	}
    	 
    }
    

}
