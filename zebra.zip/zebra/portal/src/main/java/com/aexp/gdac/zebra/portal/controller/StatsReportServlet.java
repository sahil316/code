package com.aexp.gdac.zebra.portal.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.common.json.model.StatsReportRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.portal.StatsReportStep;
import com.aexp.gdac.zebra.portal.ZebraPortalException;
import com.aexp.gdac.zebra.portal.json.JsonParser;
import com.google.gson.JsonParseException;

public class StatsReportServlet  extends HttpServlet{

	private final static Logger logger = Logger.getLogger(StatsReportServlet.class);
	
	private static final String PARAM_STATS_REPORT_REQUEST_JSON = "stats_report_request";
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doGet(request,response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	try {
 		
    		String jsonString = (String)request.getParameter(PARAM_STATS_REPORT_REQUEST_JSON);
    		Enumeration params = request.getParameterNames() ;
    		while(params.hasMoreElements()){
    			String param =params.nextElement().toString();
    			logger.info("PARAM:"+param+" , VALUE:"+request.getParameter(param));
    		}
    		
    		if(jsonString == null){
    			jsonString  = JsonParser.jsonFromRequest(request);
    		}
    		
    		logger.info("Stats request for report :"+jsonString);
		
    		StatsReportRequestJO statsReqJo = JsonParser.jsonToStatsRequestJO(jsonString);
    		StatsReportStep statsTreeReportImpl =  new StatsReportStep();
    		
    		String jsonResponse = JsonParser.feedStatsTreeToJson(statsTreeReportImpl.getFeedStatsTree(statsReqJo));
    		
    		response.setStatus(response.SC_OK);
    		logger.info("response:"+jsonResponse);
			out.write(jsonResponse);
			
		} catch (ZebraPortalException zpe) {
			logger.error("Exception Occured !",zpe);
			out.write("Error!"+zpe.getMessage());
			return ;
		}catch(JsonParseException jpe){
			logger.error("Invalid Request JSON:",jpe);
			throw jpe;
		}catch(Exception e){
			logger.error("Unexpected exception occured :",e);
			out.write("Error!"+e.getMessage());
			return ;
		}
    }

}
