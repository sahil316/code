package com.aexp.gdac.zebra.portal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.DataTypes;
import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.common.json.model.ColumnMetadataJO;
import com.aexp.gdac.zebra.common.json.model.ColumnRuleMetadataJO;
import com.aexp.gdac.zebra.common.json.model.FetchColumnMDResponseJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.portal.json.JsonMapper;

/**
 * 
 * @author 521517
 *	Upload ColumnMetadata response structure must be same as FetchColumnMetadata API resposne
 */
public class UploadColumnMetadataStep {

	private final static Logger logger = Logger.getLogger(UploadColumnMetadataStep.class);
	
	private static final String columnDelimiter = "\\|";
	
	private FeedMetadataDAO feedMdDAO ;
	private ColumnRuleMetadataDAO colRuleMdDAO ;
	
	public UploadColumnMetadataStep(){
		this.feedMdDAO = (FeedMetadataDAO)ZebraResourceManager.getBean("feedMetadataDAO");
		this.colRuleMdDAO = (ColumnRuleMetadataDAO)ZebraResourceManager.getBean("columnRuleMetadataDAO");
	}
	
	public FetchColumnMDResponseJO uploadColumnMetadata(File colMdFile,long feedId) throws ZebraPortalException{
		BufferedReader br  = null; 
		FetchColumnMDResponseJO response = new FetchColumnMDResponseJO();
		FetchColumnMDResponseJO.FetchColumnMDResultJO resultJo = new FetchColumnMDResponseJO.FetchColumnMDResultJO();
		
		try {
			FeedMetadata currFeedMd = (FeedMetadata) feedMdDAO.getLatestFeedMetadataByFeedId(feedId);
			
			if(currFeedMd==null){
				new ZebraPortalException("Feed Not found for Id:"+feedId,ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION);
			}
			
			long colIdCounter = 0;
			br = new BufferedReader(new FileReader(colMdFile));
			
			
			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				if(sCurrentLine==null || sCurrentLine.trim().isEmpty()){
					continue ;
				}
				colIdCounter++;
				
				//logger.info("Conetent : "+sCurrentLine);
				ColumnMetadataJO colMdJo = mapRowToColumnMetadataJO(sCurrentLine,currFeedMd,colIdCounter);
				
				List<ColumnRuleMetadata> colRuleMdList = colRuleMdDAO.getColumnRuleMetadataByColumnIDAndFeedIDAndEndDate(feedId, colIdCounter, currFeedMd.getEndDate(), 0, -1);
				
				for(ColumnRuleMetadata colRuleMd : colRuleMdList){
					ColumnRuleMetadataJO colRuleMdJo = JsonMapper.mapToColumnRuleMetadataJO(colRuleMd, colMdJo.getColumnName());
					colMdJo.addRules(colRuleMdJo);
				}
				
				resultJo.add(colMdJo);
				
			}
			
			resultJo.setFeedID(""+currFeedMd.getFeedID());
			resultJo.setFileFormat(currFeedMd.getFileFormat());
			
			resultJo.setFeedName(currFeedMd.getFeedName());
			resultJo.setStartDate(new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(currFeedMd.getStartDate().getTime())));
			resultJo.setEndDate(new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(currFeedMd.getEndDate().getTime())));
			
			response.setResult(resultJo);
			
			response.setStatus(new StatusJO(StatusJO.RESP_CODE_SUCCESS,StatusJO.RESP_MESSAGE_SUCCESS,"Upload Column Metadata"));
			
			logger.info("Column Metadata Returned for feed:"+feedId);
		} catch (ZebraServiceException zse) {
			 throw new ZebraPortalException(ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,zse);
		} catch (FileNotFoundException fnfe) {
			throw new ZebraPortalException("Exception Occured while reading Stats file",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,fnfe);
		} catch (IOException ioe) {
			throw new ZebraPortalException("Exception Occured while reading Stats file",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,ioe);
		}finally{
			try {
				if(br != null){
					br.close();
				}
			} catch (IOException ioe) {
				throw new ZebraPortalException(ioe);
			}
		}
		
		return response;
	}
	
	private ColumnMetadataJO mapRowToColumnMetadataJO(String colMdRow,FeedMetadata feedMd,long columnID) throws ZebraPortalException{
		ColumnMetadataJO colMdJo = new ColumnMetadataJO();
		String[] fieldValues = colMdRow.split(columnDelimiter);
		
		colMdJo.setColumnID(""+columnID);
		
		try{
			colMdJo.setColumnName(fieldValues[0]);
			colMdJo.setDataType(fieldValues[1].toLowerCase());
			if(fieldValues.length > 2){
				colMdJo.setDataFormat(fieldValues[2]);
			}
		}catch(RuntimeException rte){
			new ZebraPortalException("Upload Column Metadata failed due to row ["+colMdRow +"] , use PIPE (|) as delimiter",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,rte);
		}
		assertDataType(colMdJo.getDataType(),colMdJo.getDataFormat());
		
		colMdJo.setEndDate(new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(feedMd.getEndDate().getTime())));
		colMdJo.setStartDate(new SimpleDateFormat(JsonMapper.DEFAULT_DATE_FORMAT).format(new Date(feedMd.getStartDate().getTime())));
		colMdJo.setUserID(feedMd.getUserID());	
		
		
		return colMdJo ;
	}
	
	private void assertDataType(String dataType,String dataFormat)throws ZebraPortalException{
		try{
			DataTypes.calculateDataLength(dataType, dataFormat);
		}catch(ZebraServiceException zse){
			throw new ZebraPortalException("Problem in datatype ["+dataType+"] or in dataformat[" +dataFormat+"]",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,zse);
		}
		
	}
	/*
	public StatusRespJO uploadColumnMetadata(File colMdFile,long feedId) throws ZebraPortalException{
		BufferedReader br  = null; 
		
		
		try {
			FeedMetadata feedMd = (FeedMetadata) feedMdDAO.getCurrentFeedMetadataByFeedId(feedId);
			
			
			colMdDAO.updateColumnMetadataEndDateByFeedIDAndEndDate(feedMd.getFeedID(), feedMd.getEndDate());
			
			long colIdCounter = 0;
			br = new BufferedReader(new FileReader(colMdFile));
			
			
			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				colIdCounter++;
				if(sCurrentLine==null || sCurrentLine.trim().isEmpty()){
					continue ;
				}
				colMdDAO.create(mapRowToColumnMetadata(sCurrentLine,feedMd,colIdCounter));
			}
			
			return JsonMapper.mapToStatusRespJO(feedMd, StatusJO.RESP_CODE_SUCCESS, StatusJO.RESP_MESSAGE_SUCCESS, "Upload ColMd");
					
			
		} catch (ZebraServiceException zse) {
			 throw new ZebraPortalException(ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,zse);
		} catch (FileNotFoundException fnfe) {
			throw new ZebraPortalException("Exception Occured while reading Stats file",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,fnfe);
		} catch (IOException ioe) {
			throw new ZebraPortalException("Exception Occured while reading Stats file",ZebraPortalException.Reason.UPLOAD_COLUMN_MD_EXCEPTION,ioe);
		}finally{
			try {
				br.close();
			} catch (IOException ioe) {
				throw new ZebraPortalException(ioe);
			}
		}
		
	}
	
	private ColumnMetadata mapRowToColumnMetadata(String colMdRow,FeedMetadata feedMd,long columnID) throws ZebraPortalException{
		ColumnMetadata colMd = new ColumnMetadata();
		
		String[] fieldValues = colMdRow.split(columnDelimiter);
		
		
		colMd.setFeedID(feedMd.getFeedID());
		colMd.setColumnName(fieldValues[0]);
		colMd.setDataType(fieldValues[1].toLowerCase());
		
		if(fieldValues.length > 2){
			colMd.setDataFormat(fieldValues[2]);
		}
		
		assertDataType(colMd.getDataType(),colMd.getDataFormat());
		
		colMd.setColumnID(columnID);
		colMd.setEndDate(feedMd.getEndDate());
		colMd.setFeedName(feedMd.getFeedName());
		colMd.setStartDate(feedMd.getStartDate());
		colMd.setUserID(feedMd.getUserID());
			
		return colMd;
	}
	
	*/
	
}
