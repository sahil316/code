package com.aexp.gdac.zebra.monitor.regstat;


import com.aexp.gdac.zebra.common.ZebraCommonServiceException;
import com.aexp.gdac.zebra.common.client.RestClient;
import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;
import com.aexp.gdac.zebra.monitor.ZebraMonitorUtilException;

public class RegisterStatTrigger {
	private String feedId ;
	private String runDate ;
	private String userid ;
	private String feedName ;
	private String inputFileName ;
	
	public static void main(String args[]){
		if(args.length < 4){
			System.err.print("java com.aexp.gdac.zebra.batches.regstat.RegisterStatTrigger <inputFileName> <feedId> <runDate> <userId> <option-feedName>");
			System.exit(1);
		}
		
		try {
			RegisterStatTrigger regStatTrig = new RegisterStatTrigger();
			regStatTrig.loadParametes(args);
			regStatTrig.registerStat();
		} catch (ZebraMonitorUtilException e) {
			e.printStackTrace();
			System.exit(1);
		} catch(Exception e){
			e.printStackTrace();
			System.exit(1) ;
		}
		
		System.exit(0);
		
	}

	
	private void loadParametes(String args[]){
		inputFileName = args[0];
		feedId = args[1];
		runDate = args[2];
		userid = args[3];
		if(args.length > 4 && args[4] != null){
			feedName = args[4] ;
		}
	}
	
	
	private void registerStat() throws ZebraMonitorUtilException{
		RestClient client = new RestClient() ;
		StatsRegisterRequestJO statsRegReqJo = new StatsRegisterRequestJO ();
		statsRegReqJo.setFeedID(feedId);
		statsRegReqJo.setFeedName(feedName);
		statsRegReqJo.setRunDate(runDate);
		statsRegReqJo.setUserID(userid);
		statsRegReqJo.setUpdateProcessedDate("true");
		statsRegReqJo.setInputFilePath(inputFileName);
		
		StatusRespJO response = null ;
		try {
			response = client.registerStats(statsRegReqJo);
		} catch (ZebraCommonServiceException zcse) {
			throw new ZebraMonitorUtilException("Rest Service Call failed",ZebraMonitorUtilException.Reason.REST_CLIENT_ERROR,zcse);
		} 
		
		if(StatusJO.RESP_CODE_FAILURE.equals(response.getStatus().getResponseCode())){
			throw new ZebraMonitorUtilException(response.getStatus().getResponseMessage(),ZebraMonitorUtilException.Reason.REST_CLIENT_ERROR);
		}
	}
}
