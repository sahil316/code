package com.aexp.gdac.zebra.monitor;


public class ZebraMonitorUtilException extends Exception {
	
	private Reason reason ;

	public ZebraMonitorUtilException(Exception e) {
		// TODO Auto-generated constructor stub
		super(e);
		this.reason = Reason.UNEXPECTED_EXCEPTION ;
	}

	public ZebraMonitorUtilException(String message){
		super(message);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraMonitorUtilException(Reason reason){
		this.reason = reason;
	}
	
	public ZebraMonitorUtilException(String message ,Reason reason){
		super(message);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraMonitorUtilException(String message , Throwable cause){
		super(message,cause);
		this.reason = Reason.UNEXPECTED_EXCEPTION ;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraMonitorUtilException(Throwable cause){
		super(cause);
		this.reason = Reason.UNEXPECTED_EXCEPTION ;
	}
	
	public ZebraMonitorUtilException(Reason reason,Throwable cause){
		super(cause);
		this.reason = reason ;
	}
	
	public ZebraMonitorUtilException(String message ,Reason reason,Throwable cause){
		super(message,cause);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public Reason getReason() {
		return reason;
	}

	public void setReason(Reason reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "ZebraMonitorUtilException [reason=" + reason + " desc:"+reason.getReasonDesc()+"]";
	}
	
	
	public enum Reason{
		REST_CLIENT_ERROR("Exception occred while calling rest service"),
		UNEXPECTED_EXCEPTION("Unexpected exception occured");
		
		private String reasonDesc ;
		
		private Reason(){
		}
		
		private Reason(String desc){
			reasonDesc = desc ;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}
		
	}
	
}
