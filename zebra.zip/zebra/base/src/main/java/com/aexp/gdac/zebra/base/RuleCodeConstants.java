package com.aexp.gdac.zebra.base;

import java.util.HashMap;
import java.util.Map;

public class RuleCodeConstants {
	public static final String COMMAND_MIN_VALUE = "MIN_VALUE";
	public static final String COMMAND_MAX_VALUE = "MAX_VALUE";
	public static final String COMMAND_AVERAGE_VALUE = "6"; //n			
	public static final String COMMAND_DISTINCT_VALUE = "8";  //n		// not now
	public static final String COMMAND_DISTINCT_VALUE_COUNT = "7"; //y
	public static final String COMMAND_NULL_COUNT ="5";  //y
	public static final String COMMAND_NOT_NULL_COUNT ="NOT_NULL_COUNT";
	public static final String COMMAND_RECORD_COUNT ="RECORD_COUNT";
	public static final String COMMAND_IN_RANGE = "9";  //y
	public static final String COMMAND_VALID_VALUE = "11";  //y
	public static final String COMMAND_INVALID_VALUE = "10";  //y
	public static final String COMMAND_DATA_TYPE_CHECK = "1";  //y
	public static final String COMMAND_CM11_CHECK = "2";  //y
	public static final String COMMAND_CM13_CHECK = "3";  //y
	public static final String COMMAND_CM15_CHECK = "4";   //y
	public static final String COMMAND_DUPLICATE_VALUE_COUNT = "12";
	public static final String COMMAND_EMPTY_CHECK = "13";
	
	
	public static Map<String,String> ruleCodeTextMap = new HashMap<String,String>();
	
	static{
		ruleCodeTextMap.put(COMMAND_MIN_VALUE, "MIN_VALUE");
		ruleCodeTextMap.put(COMMAND_MAX_VALUE,"MAX_VALUE");
		ruleCodeTextMap.put(COMMAND_AVERAGE_VALUE, "AVERAGE_VALUE");
		ruleCodeTextMap.put(COMMAND_DISTINCT_VALUE, "DISTINCT_CHECK");
		ruleCodeTextMap.put(COMMAND_DISTINCT_VALUE_COUNT, "DISTINCT_COUNT");
		ruleCodeTextMap.put(COMMAND_NULL_COUNT, "NULL_COUNT");
		ruleCodeTextMap.put(COMMAND_NOT_NULL_COUNT, "NOT_NULL_COUNT");
		ruleCodeTextMap.put(COMMAND_RECORD_COUNT,"RECORD_COUNT");
		ruleCodeTextMap.put(COMMAND_IN_RANGE, "IN_RANGE");
		ruleCodeTextMap.put(COMMAND_VALID_VALUE, "VALID_VALUE");
		ruleCodeTextMap.put(COMMAND_INVALID_VALUE, "INVALID_CHECK");
		ruleCodeTextMap.put(COMMAND_DATA_TYPE_CHECK, "DATA_TYPE_CHECK");
		ruleCodeTextMap.put(COMMAND_CM11_CHECK, "CM11_CHECK");
		ruleCodeTextMap.put(COMMAND_CM13_CHECK, "CM13_CHECK");
		ruleCodeTextMap.put(COMMAND_CM15_CHECK, "CM15_CHECK");
		ruleCodeTextMap.put(COMMAND_DUPLICATE_VALUE_COUNT, "DUPLICATE_COUNT");
		ruleCodeTextMap.put(COMMAND_EMPTY_CHECK, "EMPTY_CHECK");
	}
	
	public static String getRuleName(String ruleCode){
		return ruleCodeTextMap.get(ruleCode);
	}
	
	
}

/*

RuleID Rule Name Rule Description TrendingFlag 

1 Data Type check Checks data type against a column 0 
2 cm11 check checks validity of Card Number 0 
3 cm13 check checks validity of Card Number 0 
4 cm15 check checks validity of Card Number 0 
5 Not Null check Checks if value is not null 1 
6 Average check Checks the average value of a numeric field 1 
7 Count Distinct Counts on distinct values of a column 1 
8 Distinct Value Check Checks if the column has all distinct vallues 0 
9 Range check Checks if a column in within range 0 
10 Invalid Value check Checks if a column does not have the specified values 0 
11 Valid Values Checks if a column is within the specified values 
*/