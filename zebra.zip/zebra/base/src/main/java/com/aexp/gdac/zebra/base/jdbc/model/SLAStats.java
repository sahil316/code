package com.aexp.gdac.zebra.base.jdbc.model;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class SLAStats extends TableValueObjectBase{
	private static final String tableName = "SLAStats";

	private long feedID ;
	private String status ;
	private String message ;
	private Timestamp expectedTimeStamp ;
	private Timestamp calculatedTimeStamp ;
	private String notified;
	private Long stateID ; 
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("Status", "status");
		columnPropertyMap.put("Message", "message");
		columnPropertyMap.put("ExpectedTime", "expectedTimeStamp");
		columnPropertyMap.put("CalculatedTime", "calculatedTimeStamp");
		columnPropertyMap.put("Notified", "notified");
		columnPropertyMap.put("StateID", "stateID");
	}
	
	public long getFeedID() {
		return feedID;
	}

	public void setFeedID(long feedID) {
		this.feedID = feedID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Timestamp getExpectedTimeStamp() {
		return expectedTimeStamp;
	}

	public void setExpectedTimeStamp(Timestamp expectedTimeStamp) {
		this.expectedTimeStamp = expectedTimeStamp;
	}

	public Timestamp getCalculatedTimeStamp() {
		return calculatedTimeStamp;
	}

	public void setCalculatedTimeStamp(Timestamp calculatedTimeStamp) {
		this.calculatedTimeStamp = calculatedTimeStamp;
	}

	public String getNotified() {
		return notified;
	}

	public void setNotified(String notified) {
		this.notified = notified;
	}

	public Long getStateID() {
		return stateID;
	}

	public void setStateID(Long stateID) {
		this.stateID = stateID;
	}

	@Override
	public Map<String, String> getColumnPropertyMap() {
		return columnPropertyMap;
	}

	@Override
	public void setPrimaryKey(Object obj) {
		this.feedID = (Long)obj ;
		
	}

	@Override
	public Object getPrimaryKey() {	
		return this.feedID ;
	}

	@Override
	public String getTableName() {
		return tableName;
	}

	@Override
	public String toString() {
		return "SLAStats [feedID=" + feedID + ", status=" + status
				+ ", message=" + message + ", expectedTime=" + expectedTimeStamp
				+ ", notified=" + notified + ", stateID=" + stateID + "]";
	}

}
