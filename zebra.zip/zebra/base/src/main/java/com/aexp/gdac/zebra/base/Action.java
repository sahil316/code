package com.aexp.gdac.zebra.base;

public enum Action {

		PASS(1),
		ALERT(2),
		ABORT(3);
		
		private int actoinCode ;
		
		private Action(){
		}
		
		 Action(int actoinCode){
			 this.actoinCode = actoinCode ;
		}

		public int getActoinCode() {
			return actoinCode;
		}

		public void setActoinCode(int actoinCode) {
			this.actoinCode = actoinCode;
		}
	

}
