package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.SLAStats;

public class SLAStatsDAO  extends SpringDAOBase implements TableDAO {

	private static org.apache.log4j.Logger log = Logger.getLogger(SLAStatsDAO.class);
	
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey)
			throws ZebraServiceException {
		SLAStats ret = null;
		try {
			StatementObject so = generateSelectStmt(new SLAStats());
			ret = (SLAStats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=?",
					new Object[] { primarykey },
					new ZRowMapper(new SLAStats()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching SLAStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}

	public TableValueObjectBase getObjectByFeedIdAndStateID(long feedID, long stateID) throws ZebraServiceException {
		SLAStats ret = null;
		try {
			StatementObject so = generateSelectStmt(new SLAStats());
			ret = (SLAStats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND StateID=?",
					new Object[] { feedID , stateID},
					new ZRowMapper(new SLAStats()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching SLAStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
	
	public List getUnprocessedSLAStatsByFeedId(Long feedID) throws ZebraServiceException {
		List ret = null;
		try {
			StatementObject so = generateSelectStmt(new SLAStats());
			ret = (List) getJdbcTemplate().query(
					so.getStmt() + " WHERE FeedID=? AND Status is NULL ORDER BY ExpectedTime DESC",
					new Object[] { feedID },
					new ZRowMapperResultSetExtractor(new ZRowMapper(new SLAStats()),0,-1));
			
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching SLAStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
	
	public int updateSLAStatus(TableValueObjectBase svo) throws ZebraServiceException{
        int rowsUpdated=0;
        
        try {
            log.debug("updateSLAStatus(TableValueObjectBase svo) - entry");
            rowsUpdated = getJdbcTemplate().update("update SLAStats set Status=? ,Message=? ,StateID=? ,Notified=? WHERE FeedID=? AND ExpectedTime=?",

                    new Object[] {((SLAStats)svo).getStatus(),((SLAStats)svo).getMessage(),((SLAStats)svo).getStateID() ,((SLAStats)svo).getNotified() 
            			,((SLAStats)svo).getFeedID(),((SLAStats)svo).getExpectedTimeStamp()});
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occred while updating SLAStats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
	}
	
	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting SLAStats to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
