package com.aexp.gdac.zebra.base.jdbc.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class ZebraLogs extends TableValueObjectBase {
	private String application_id ;
	private String user_id ;
	private String log_entry;
	private long stateID ;
	private Timestamp time_stamp ;
	private String tableName = "ZEBRA_LOGS";
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static{
		columnPropertyMap.put("application_id","application_id") ;
		columnPropertyMap.put("user_id", "user_id");
		columnPropertyMap.put("log_entry", "log_entry");
		columnPropertyMap.put("time_stamp", "time_stamp");
		columnPropertyMap.put("StateID", "stateID");
	}
	
	public ZebraLogs(){
		this.time_stamp = new Timestamp(new Date().getTime());
	}
	
	public ZebraLogs(String application_id,String user_id,String log_entry,String stateID){
		this.time_stamp = new Timestamp(new Date().getTime());
		this.application_id = application_id ;
		this.user_id = user_id ;
		this.log_entry = log_entry ;
		if(stateID !=null){
			this.stateID = Long.parseLong(stateID) ;
		}
	}
	
	public ZebraLogs(String application_id,String user_id,String log_entry, Timestamp timestamp){
		this.time_stamp = timestamp;
		this.application_id = application_id ;
		this.user_id = user_id ;
		this.log_entry = log_entry ;
	}
	
	@Override
	public Map<String, String> getColumnPropertyMap() {
		return this.columnPropertyMap;
	}
	
	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}
	
	public String getApplication_id() {
		return application_id;
	}
	
	public void setApplication_id(String application_id) {
		this.application_id = application_id;
	}
	
	public String getUser_id() {
		return user_id;
	}
	
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	
	public String getLog_entry() {
		return log_entry;
	}
	
	public void setLog_entry(String log_entry) {
		this.log_entry = log_entry;
	}
	
	public Timestamp getTime_stamp() {
		return time_stamp;
	}
	
	public void setTime_stamp(Timestamp time_stamp) {
		this.time_stamp = time_stamp;
	}

	public long getStateID() {
		return stateID;
	}

	public void setStateID(long stateID) {
		this.stateID = stateID;
	}

	@Override
	public String toString() {
		return "ZebraLogs [application_id=" + application_id + ", user_id="
				+ user_id + ", log_entry=" + log_entry + ", time_stamp="
				+ time_stamp + "]";
	}
	
	
}
