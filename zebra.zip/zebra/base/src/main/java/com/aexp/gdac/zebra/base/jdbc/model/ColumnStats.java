package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class ColumnStats extends TableValueObjectBase implements Comparable<ColumnStats>{
	private static final String tableName = "ColumnStats";
	
	private long feedID;
	private long columnID;
	private String columnName ;
	private long dataTypeHit ;
	private long countDistinctvalues;
	private long countNullValues ;
	private String average ;
	private long recordCount;
	private String minValue;
	private String maxValue;
	private String action;
	private long stateID;
	
	private String level ;
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	public static HashMap<String,Integer> columnPropertyTypeMap = new HashMap<String,Integer>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("ColumnID", "columnID");
		columnPropertyMap.put("DataTypeHit", "dataTypeHit");
		columnPropertyMap.put("CountDistinctvalues", "countDistinctvalues");
		columnPropertyMap.put("CountNullValues", "countNullValues");
		columnPropertyMap.put("Average", "average");
		columnPropertyMap.put("RecordCount", "recordCount");
		columnPropertyMap.put("MinValue", "minValue");
		columnPropertyMap.put("MaxValue", "maxValue");
		columnPropertyMap.put("Action", "action");
		columnPropertyMap.put("StateID", "stateID");
		columnPropertyMap.put("ColumnName", "columnName");
		
		
		columnPropertyTypeMap.put("minValue",java.sql.Types.VARCHAR);
		columnPropertyTypeMap.put("maxValue",java.sql.Types.VARCHAR);
		columnPropertyTypeMap.put("average",java.sql.Types.VARCHAR);
		
	}
	@Override
	public HashMap getPropertySqlTypesMap() {
		return this.columnPropertyTypeMap;

	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public long getDataTypeHit() {
		return dataTypeHit;
	}
	public void setDataTypeHit(long dataTypeHit) {
		this.dataTypeHit = dataTypeHit;
	}
	public long getCountDistinctvalues() {
		return countDistinctvalues;
	}
	public void setCountDistinctvalues(long countDistinctvalues) {
		this.countDistinctvalues = countDistinctvalues;
	}
	public long getCountNullValues() {
		return countNullValues;
	}
	public void setCountNullValues(long countNullValues) {
		this.countNullValues = countNullValues;
	}
	public long getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}
	public String getMinValue() {
		return minValue;
	}
	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}
	public String getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}
	public long getFeedID() {
		return feedID;
	}
	public void setFeedID(long feedID) {
		this.feedID = feedID;
	}
	public long getColumnID() {
		return columnID;
	}
	public void setColumnID(long columnID) {
		this.columnID = columnID;
	}

	public static void setColumnPropertyMap(
			HashMap<String, String> columnPropertyMap) {
		ColumnStats.columnPropertyMap = columnPropertyMap;
	}

	public String getAverage() {
		return (average==null)?null:CommonMethods.formatNaN(""+average).toString();
	}
	public void setAverage(String average) {
		this.average = average;
	}

	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public long getStateID() {
		return stateID;
	}
	public void setStateID(long stateID) {
		this.stateID = stateID;
	}
	
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	
	/** add to distinct value count*/
	public void updateDistinctValueCount (long count){
		this.countDistinctvalues = this.countDistinctvalues + count ;
	}
	/**
	 * WARNINNG: toString() must not be modified . 
	 * This is called while generating stats in Mapreduce Job.
	 * 
	 * */
	@Override
	public String toString() {
		return  feedID + "|" 
				+ columnID+ "|" 
				+ columnName+ "|"
				+ countDistinctvalues + "|"
				+ countNullValues + "|" 
				+ dataTypeHit + "|"
				+((CommonMethods.isNullTextValue(average))?average:CommonMethods.formatNaN(average)) + "|"
				+ recordCount + "|" 
				+ minValue + "|"
				+ maxValue + "|" 
				+ action + "|" 
				+ stateID + "|" 
				+ level;
	}
	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}
	
	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		this.columnID = (Long)obj;
		
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.columnID;
	}
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}
	@Override
	public int compareTo(ColumnStats o) {
		if(o == null){
			return 1;
		}
		if(this.stateID < o.getStateID()){
			return -1;
		}else if(this.stateID > o.getStateID()){
			return 1  ;
		}
		
		return 0;
	}
	

}
