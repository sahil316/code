package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.util.Calendar;

import com.aexp.gdac.zebra.base.CommonMethods;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(CommonMethods.isNumeric("NaN"));
		
		System.out.println(Double.parseDouble("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
	}

}
