package com.aexp.gdac.zebra.base.jdbc.model;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class Stats extends TableValueObjectBase implements Comparable<Stats>{
	
	private static final String tableName = "Stats";
	
	private Long stateID;
	private Long feedID ;
	private String feedName ;
	private String action ;
	private Timestamp runDate ;
	private Timestamp processDate ;
	private String inputFilePath;
	private String errorMessage ;
	private String userID;
	private ExecMode execMode;
	private Timestamp created;
	private String outputDirPath;
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("StateID", "stateID");
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("FeedName", "feedName");
		columnPropertyMap.put("Action", "action");
		columnPropertyMap.put("RunDate", "runDate");
		columnPropertyMap.put("ProcessDate", "processDate");
		columnPropertyMap.put("InputFilePath", "inputFilePath");
		columnPropertyMap.put("ErrorMessage", "errorMessage");
		columnPropertyMap.put("UserID", "userID");
		columnPropertyMap.put("ExecMode", "execMode");
		columnPropertyMap.put("Created", "created");
		columnPropertyMap.put("OutputDirPath", "outputDirPath");
	}	
	

	public Long getStateID() {
		return stateID;
	}
	public void setStateID(Long stateID) {
		this.stateID = stateID;
	}
	public Long getFeedID() {
		return feedID;
	}
	public void setFeedID(Long feedId) {
		this.feedID = feedId;
	}
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public Timestamp getRunDate() {
		return runDate;
	}
	public void setRunDate(Timestamp runDate) {
		this.runDate = runDate;
	}
	public Timestamp getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Timestamp processDate) {
		this.processDate = processDate;
	}
	
	public String getInputFilePath() {
		return inputFilePath;
	}
	public void setInputFilePath(String inputFilePath) {
		this.inputFilePath = inputFilePath;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public String getExecMode() {
		return (execMode==null)?null:execMode.name();
	}
	public void setExecMode(String execMode) {
		this.execMode = ExecMode.valueOf(execMode);
	}
	
	public Timestamp getCreated() {
		return created;
	}
	public void setCreated(Timestamp created) {
		this.created = created;
	}
	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}
	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		this.stateID= (Long)obj;
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.stateID;
	}
	
	public String getOutputDirPath() {
		return this.outputDirPath;
	}
	public void setOutputDirPath(String outputDirPath) {
		this.outputDirPath = outputDirPath;
	}
	
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}

	@Override
	public String toString() {
		return "Stats [stateID=" + stateID + ", feedID=" + feedID
				+ ", feedName=" + feedName + ", action=" + action
				+ ", runDate=" + runDate + ", processDate=" + processDate
				+ ", inputFilePath=" + inputFilePath 
				+ ", errorMessage=" + errorMessage + ", userID="
				+ userID + "]";
	}
	
	public enum ExecMode{
		AUTO,
		MANUAL;
	}

	@Override
	public int compareTo(Stats o) {
		if(o == null){
			return 1;
		}
		if(this.stateID < o.getStateID()){
			return -1;
		}else if(this.stateID > o.getStateID()){
			return 1  ;
		}
		
		return 0;
	}
	
}
