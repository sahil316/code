package com.aexp.gdac.zebra.base.jdbc.model;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class ColumnRuleMetadata  extends TableValueObjectBase{
	
	private static final String tableName = "ColumnRuleMetadata";
	
	private long feedID;
	private long columnID ;
	private long ruleID;
	private long columnRuleID = 1L;
	private String ruleParameter ;
	private String userID ;
	private Integer pastRuns;
	private Timestamp startDate;
	private Timestamp endDate;
	private String thresholdType;	
	private Double minAlertThreshold;
	private Double minAbortThreshold;
	private Double maxAlertThreshold;
	private Double maxAbortThreshold;
	
public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("ColumnID", "columnID");
		columnPropertyMap.put("RuleID", "ruleID");
		columnPropertyMap.put("RuleParameter", "ruleParameter");
		columnPropertyMap.put("ColumnRuleID", "columnRuleID");
		columnPropertyMap.put("MinAlertThreshold", "minAlertThreshold");
		columnPropertyMap.put("MinAbortThreshold", "minAbortThreshold");
		columnPropertyMap.put("MaxAlertThreshold", "maxAlertThreshold");
		columnPropertyMap.put("MaxAbortThreshold", "maxAbortThreshold");
		columnPropertyMap.put("ThresholdType", "thresholdType");
		columnPropertyMap.put("PastRuns", "pastRuns");
		columnPropertyMap.put("StartDate", "startDate");
		columnPropertyMap.put("EndDate", "endDate");
		columnPropertyMap.put("UserID", "userID");
	}
	
	public long getFeedID() {
		return feedID;
	}
	public void setFeedID(long feedID) {
		this.feedID = feedID;
	}
	public long getColumnID() {
		return columnID;
	}
	public void setColumnID(long columnID) {
		this.columnID = columnID;
	}
	public long getRuleID() {
		return ruleID;
	}
	public void setRuleID(long ruleID) {
		this.ruleID = ruleID;
	}
	public long getColumnRuleID() {
		return columnRuleID;
	}
	public void setColumnRuleID(long columnRuleID) {
		this.columnRuleID = columnRuleID;
	}
	public String getRuleParameter() {
		return ruleParameter;
	}
	public void setRuleParameter(String ruleParameter) {
		this.ruleParameter = ruleParameter;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public Integer getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(Integer pastRuns) {
		this.pastRuns = pastRuns;
	}
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}
	public Timestamp getEndDate() {
		return endDate;
	}
	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}
	public String getThresholdType() {
		return thresholdType;
	}
	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}
	public Double getMinAlertThreshold() {
		return minAlertThreshold;
	}
	public void setMinAlertThreshold(Double minAlertThreshold) {
		this.minAlertThreshold = minAlertThreshold;
	}
	public Double getMinAbortThreshold() {
		return minAbortThreshold;
	}
	public void setMinAbortThreshold(Double minAbortThreshold) {
		this.minAbortThreshold = minAbortThreshold;
	}
	public Double getMaxAlertThreshold() {
		return maxAlertThreshold;
	}
	public void setMaxAlertThreshold(Double maxAlertThreshold) {
		this.maxAlertThreshold = maxAlertThreshold;
	}
	public Double getMaxAbortThreshold() {
		return maxAbortThreshold;
	}
	public void setMaxAbortThreshold(Double maxAbortThreshold) {
		this.maxAbortThreshold = maxAbortThreshold;
	}
	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}
	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		this.columnID = (Long)obj;
		
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.columnID;
	}
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return tableName;
	}
	@Override
	public String toString() {
		return "ColumnRuleMetadata [feedID=" + feedID + ", columnID="
				+ columnID + ", ruleID=" + ruleID + ", columnRuleID="
				+ columnRuleID + ", ruleParameter=" + ruleParameter
				+ ", userID=" + userID + ", pastRuns=" + pastRuns
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", thresholdType=" + thresholdType + ", minAlertThreshold="
				+ minAlertThreshold + ", minAbortThreshold="
				+ minAbortThreshold + ", maxAlertThreshold="
				+ maxAlertThreshold + ", maxAbortThreshold="
				+ maxAbortThreshold + "]";
	}
	
	
	
}
