package com.aexp.gdac.zebra.base.jdbc.dao.core;

import com.aexp.gdac.zebra.base.ZebraServiceException;

public interface TableDAO {
	
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException ;
	public Object create(TableValueObjectBase svo) throws ZebraServiceException;
	public int update(TableValueObjectBase svo) throws ZebraServiceException;
	public int remove(Object invoiceKeyId) throws ZebraServiceException;
	

}
