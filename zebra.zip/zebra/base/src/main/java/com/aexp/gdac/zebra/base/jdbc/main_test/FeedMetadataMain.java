package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.util.List;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;

public class FeedMetadataMain {
	
	public static void main(String args[]) throws ZebraServiceException{
		/*ColumnMetadataDAO columnMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
		List<ColumnMetadata> columMD = columnMdDAO.getColumnMetadataByFeedID(1L, 0, -1);
		
		List<ColumnRuleMetadata> columnRuleMDList =((ColumnRuleMetadataDAO) ZebraResourceManager.getBean("columnRuleMetadataDAO")).getColumnRuleMetadataByColumnID(
				columMD.get(0).getColumnID(), 0, -1);
		
		FeedMetadata feedMetadata = (FeedMetadata) ((FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO")).getFeedMetadataByFeedId(1L);
			System.out.println("Result : "+feedMetadata);
		*/
		
		//Stats stats = (Stats)((StatsDAO) ZebraResourceManager.getBean("statsDAO")).getStatsByFeedId(1L);
		
		((FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO")).create(getSampleFeedMetadata());
		//System.out.println("Result : "+stats);
	}
	
	
	private static FeedMetadata getSampleFeedMetadata(){
		FeedMetadata feedMD = new FeedMetadata();
		feedMD.setFeedID(101L);
		feedMD.setFeedName("SampleMD");
		feedMD.setFileFormat("DELIMITED");
		feedMD.setFrequency("Daily");
		feedMD.setColumnDelimiter("CTRL-A");
		feedMD.setRecordDelimiter("New Line");
		feedMD.setPastRuns(Integer.parseInt("10"));
		
		feedMD.setThresholdType("Absolute");
		feedMD.setMaxAbortThreshold(Double.parseDouble("20"));
		feedMD.setMinAbortThreshold(Double.parseDouble("10"));
		feedMD.setMinAlertThreshold(Double.parseDouble("30")); 
		feedMD.setMaxAlertThreshold(Double.parseDouble("40"));
		
		feedMD.setEmailID("abc@xyz.com");
		
		return feedMD;
	}

}
