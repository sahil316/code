package com.aexp.gdac.zebra.base.metadata;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;





import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraServiceException;

public class MetadataParser {
	
	/* use spring config for setting these */
	//private static String md_read_delimiter = "\\|";
	//private static String md_write_delimiter ="|" ;
	// delimiter never changes so defined final and non configurable  
	private static final char MD_RECORD_DELIMITER = 0x1e;
	private static String md_read_delimiter = Character.toString(MD_RECORD_DELIMITER);
	private static String md_write_delimiter = Character.toString(MD_RECORD_DELIMITER);
	
	private static final String NULL_STRING_VALUE = "null";
	public static int columnCount ;
	
	public static Metadata marshallMetadata(File metadataFile) throws ZebraServiceException{
		Metadata metadata = new Metadata();
		int lineNumber = 0;
		BufferedReader br =null;

		try {
				br = new BufferedReader(new FileReader(metadataFile));
				//reset column count
				columnCount =0;
				
				String sCurrentLine;
				while ((sCurrentLine = br.readLine()) != null) {
					lineNumber++;
					MetadataRow mdRow = new MetadataRow();
					String[] mdSplits =sCurrentLine.split(md_read_delimiter);
					mdRow.setFeedId(new Long(mdSplits[0]));
					mdRow.setFeedName(mdSplits[1]);
					mdRow.setStateId(new Long(mdSplits[2]));
					
					mdRow.setLevel(Level.valueOf(mdSplits[3]));
					mdRow.setFileFormat(mdSplits[4]);
					mdRow.setColumnDelimiter(mdSplits[5]);
					mdRow.setRecordDelimiter(mdSplits[6]);
					
					mdRow.setColumnId(((mdSplits[7])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[7]) || mdSplits[7].isEmpty()? 0 : Long.parseLong(mdSplits[7])));
					mdRow.setColumnName(mdSplits[8]);
					mdRow.setRuleId(((mdSplits[9])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[9]) || mdSplits[9].isEmpty() ? 0 : Long.parseLong(mdSplits[9])));
					mdRow.setColumnRuleId(((mdSplits[10])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[10]) || mdSplits[10].isEmpty()? 0 : Long.parseLong(mdSplits[10])));
					mdRow.setRuleParameter(mdSplits[11]);
					
					mdRow.setDataType(mdSplits[12]);
					mdRow.setDataFormat(mdSplits[13]);
					
					mdRow.setMinAlertThreshold(((mdSplits[14])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[14]) || mdSplits[14].isEmpty())? null : Double.parseDouble(mdSplits[14]));
					mdRow.setMinAbortThreshold(((mdSplits[15])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[15]) || mdSplits[15].isEmpty())? null : Double.parseDouble(mdSplits[15]));
					mdRow.setMaxAlertThreshold(((mdSplits[16])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[16]) || mdSplits[16].isEmpty())? null : Double.parseDouble(mdSplits[16]));
					mdRow.setMaxAbortThreshold(((mdSplits[17])==null || NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[17]) || mdSplits[17].isEmpty())? null : Double.parseDouble(mdSplits[17]));	
					
					mdRow.setThresholdType(mdSplits[18]);
					
					mdRow.setPastRun((((mdSplits[19])==null|| NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[19]) ||mdSplits[19].isEmpty())? null : Integer.parseInt(mdSplits[19])));
										
					mdRow.setTrendingFlag(((mdSplits[20])==null|| NULL_STRING_VALUE.equalsIgnoreCase(mdSplits[20]) || mdSplits[20].isEmpty()? 0 : Integer.parseInt(mdSplits[20])));
					

					
					assertMandatoryFields(mdRow);
					assertColumnLevel(mdRow);
					assertColumnRuleLevel(mdRow);
					
					if(mdRow.getLevel() == Level.COLUMN_LEVEL ){
						columnCount ++;
					}
					
					metadata.addMetadatRow(mdRow);
				}
				assertFeedLevel(metadata);
				
				/** sorting metadata rows*/
				metadata.sortMetadatRows();
				
			} catch (FileNotFoundException e) {
				throw new ZebraServiceException("Metadata file not found: "+metadataFile.getAbsolutePath(),ZebraServiceException.Reason.MD_FILE_EXCEPTION,e);
			} catch (IOException e) {
				throw new ZebraServiceException("Metadata file read failed : "+metadataFile.getAbsolutePath(),ZebraServiceException.Reason.MD_FILE_EXCEPTION,e);
			} catch (Exception e){
				throw new ZebraServiceException("Unexpected error occured at line:"+lineNumber+" in file:"+metadataFile.getAbsolutePath(),ZebraServiceException.Reason.MD_FILE_EXCEPTION,e);
			}
		
		finally{
			try {
				br.close();
			} catch (IOException e) {
				throw new ZebraServiceException("Metadata file closing failed : "+metadataFile.getAbsolutePath(),ZebraServiceException.Reason.MD_FILE_EXCEPTION,e);
			}
		}
		
			return metadata;
	}
	
	public static File unmarshallMetadata(Metadata metadata,String metadataFileName) throws ZebraServiceException{
		
		assertFeedLevel(metadata);
		
		File metadataFile = new File(metadataFileName);
		BufferedWriter bw = null;
		try {
			 bw = new BufferedWriter(new FileWriter(metadataFile));
			int rowCount = 0;
			
			//reset column count 
			columnCount = 0;
			
			for(MetadataRow row : metadata.getMetadataRowList()){
				assertMandatoryFields(row);
				assertColumnLevel(row);
				assertColumnRuleLevel(row);
				
				if(rowCount>0){
					bw.write("\n");
				}
				
				
				StringBuilder rowStrBuilder = new StringBuilder();
				rowStrBuilder.append(row.getFeedId()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getFeedName()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getStateId()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getLevel().name()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getFileFormat()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getColumnDelimiter()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getRecordDelimiter()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getColumnId()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getColumnName()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getRuleId()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getColumnRuleId()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getRuleParameter()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getDataType()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getDataFormat()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getMinAlertThreshold()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getMinAbortThreshold()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getMaxAlertThreshold()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getMaxAbortThreshold()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getThresholdType()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getPastRun()).append(MetadataParser.md_write_delimiter);
				rowStrBuilder.append(row.getTrendingFlag());

				bw.write(rowStrBuilder.toString());
				rowCount++;
				if(row.getLevel() == Level.COLUMN_LEVEL){
					columnCount++;
				}
			}
		} catch (IOException e) {
			throw new ZebraServiceException("Metadata file write failed: "+metadataFile.getAbsolutePath(),ZebraServiceException.Reason.MD_FILE_EXCEPTION,e);
		}

		
		finally{
			try {
				if(bw != null){
					bw.close();
				}
			} catch (IOException e) {
				throw new ZebraServiceException("Metadata file closing failed : "+metadataFile.getAbsolutePath(),ZebraServiceException.Reason.MD_FILE_EXCEPTION,e);
			}
		}
		
		return metadataFile;

	}
	
	private static void assertMandatoryFields(MetadataRow mdRow) throws ZebraServiceException{
		if(mdRow.getFeedId()==null || mdRow.getFeedId().toString().isEmpty() 
				|| mdRow.getFeedName() == null || mdRow.getFeedName().isEmpty() 
				|| mdRow.getStateId() == null || mdRow.getStateId().toString().isEmpty()
				|| mdRow.getLevel() == null
				|| mdRow.getFileFormat()== null || mdRow.getFileFormat().isEmpty()
				|| mdRow.getRecordDelimiter() == null || mdRow.getRecordDelimiter().isEmpty()){
			throw new ZebraServiceException("Mandatory fields missing " + mdRow,ZebraServiceException.Reason.MD_MISSING_MANDATORY_FIELDS);
		}
	}
	
	private static void assertColumnLevel(MetadataRow mdRow) throws ZebraServiceException{
		if(mdRow.getLevel() == Level.COLUMN_LEVEL){
			if(!(mdRow.getColumnId() >0)){
				throw new ZebraServiceException("ColumnId doesnot exists at COLUMN_LEVEL " ,ZebraServiceException.Reason.MD_COLUMN_LEVEL_CHECK_FAILED);
			}else if((mdRow.getRuleId() > 0)){
				throw new ZebraServiceException("RuleId  exists at COLUMN_LEVEL " ,ZebraServiceException.Reason.MD_COLUMN_LEVEL_CHECK_FAILED);
			}else if(mdRow.getColumnName() == null || mdRow.getColumnName().isEmpty()){
				throw new ZebraServiceException("Column Name doesnot exist COLUMN_LEVEL " ,ZebraServiceException.Reason.MD_COLUMN_LEVEL_CHECK_FAILED);
			}
		}
	}
	
	
	private static void assertColumnRuleLevel(MetadataRow mdRow) throws ZebraServiceException{
		if(mdRow.getLevel() == Level.COLUMN_RULE_LEVEL){
			if(!(mdRow.getColumnId() >0)){
				throw new ZebraServiceException("ColumnId doesnot exists at COLUMN_RULE_LEVEL " ,ZebraServiceException.Reason.MD_COLUMN_LEVEL_CHECK_FAILED);
			}else if(!(mdRow.getRuleId() > 0)){
				throw new ZebraServiceException("RuleId dones not exists at COLUMN_RULE_LEVEL " ,ZebraServiceException.Reason.MD_COLUMN_LEVEL_CHECK_FAILED);
			}else if(mdRow.getColumnName() == null || mdRow.getColumnName().isEmpty()){
				throw new ZebraServiceException("Column Name doesnot exist COLUMN_RULE_LEVEL " ,ZebraServiceException.Reason.MD_COLUMN_LEVEL_CHECK_FAILED);
			}
		}
	}
	private static void assertFeedLevel(Metadata metadata) throws ZebraServiceException{
		boolean missing = true;
		for(MetadataRow mdRow : metadata.getMetadataRowList()){
			if(mdRow.getLevel() == Level.FEED_LEVEL){
				missing = false;
				if(mdRow.getFeedId()==null || mdRow.getFeedId().toString().isEmpty()
						|| mdRow.getPastRun() == null){
					throw new ZebraServiceException("FEED_LEVEL Mandatory fields missing " + mdRow,ZebraServiceException.Reason.MD_MISSING_MANDATORY_FIELDS);
				}
				
				
				break;
			}
		}
		
		if(missing){
			throw new ZebraServiceException("FEED_LEVEL metadata missing" ,ZebraServiceException.Reason.MD_FEED_LEVEL_CHECK_FAILED);
		}
	}

	public static String getMd_read_delimiter() {
		return md_read_delimiter;
	}

	public static void setMd_read_delimiter(String md_read_delimiter) {
		MetadataParser.md_read_delimiter = md_read_delimiter;
	}

	public static String getMd_write_delimiter() {
		return md_write_delimiter;
	}

	public static void setMd_write_delimiter(String md_write_delimiter) {
		MetadataParser.md_write_delimiter = md_write_delimiter;
	}

}
