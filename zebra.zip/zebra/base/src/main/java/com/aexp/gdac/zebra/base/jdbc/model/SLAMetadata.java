package com.aexp.gdac.zebra.base.jdbc.model;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class SLAMetadata extends TableValueObjectBase{
	private static final String tableName = "SLAMetadata";
	
	private Long feedID ;
	private String feedName ;
	private Frequency feedFrequency;
	private Integer dayOfWeek ;
	private Integer dateOfMonth ;
	private Integer monthOfQuarter ;
	private Integer skipDayOfWeek ;
	private Integer execTime;
	private Integer elapseTime ;
	private Timestamp startDate  ;
	private Timestamp endDate ;
	private String userID ;
	
public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("FeedName", "feedName");
		columnPropertyMap.put("FeedFrequency", "feedFrequency");
		columnPropertyMap.put("DayOfWeek", "dayOfWeek");
		columnPropertyMap.put("DateOfMonth", "dateOfMonth");
		columnPropertyMap.put("MonthOfQuarter", "monthOfQuarter");
		columnPropertyMap.put("SkipDayOfWeek", "skipDayOfWeek");
		columnPropertyMap.put("ExecTime", "execTime");
		columnPropertyMap.put("ElapseTime", "elapseTime");
		columnPropertyMap.put("StartDate", "startDate");
		columnPropertyMap.put("EndDate", "endDate");
		columnPropertyMap.put("UserID", "userID");
	}
	
	
	public Long getFeedID() {
		return feedID;
	}

	public void setFeedID(Long feedID) {
		this.feedID = feedID;
	}

	public String getFeedName() {
		return feedName;
	}

	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}

	public String getFeedFrequency() {
		if(feedFrequency!=null){
			return feedFrequency.name() ;
		}
		return null;
	}

	public void setFeedFrequency(String feedFrequency) {
		this.feedFrequency = Frequency.valueOf(feedFrequency);
	}

	public Integer getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(Integer dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public Integer getMonthOfQuarter() {
		return monthOfQuarter;
	}

	public void setMonthOfQuarter(Integer monthOfQuarter) {
		this.monthOfQuarter = monthOfQuarter;
	}

	public Integer getSkipDayOfWeek() {
		return skipDayOfWeek;
	}

	public void setSkipDayOfWeek(Integer skipDayOfWeek) {
		this.skipDayOfWeek = skipDayOfWeek;
	}

	public Integer getExecTime() {
		return execTime;
	}

	public void setExecTime(Integer execTime) {
		this.execTime = execTime;
	}

	public Integer getElapseTime() {
		return elapseTime;
	}

	public void setElapseTime(Integer elapseTime) {
		this.elapseTime = elapseTime;
	}

	public Timestamp getStartDate() {
		return startDate;
	}

	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public void setDateOfMonth(Integer dateOfMonth) {
		this.dateOfMonth = dateOfMonth;
	}

	/** -1 is returned in case of last day of month**/
	public Integer getDateOfMonth() {	
		return dateOfMonth;
	}
	
	public Integer getDateOfMonthByCalender(int month){
		if(dateOfMonth == -1){
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.MONTH,month);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			return cal.getTime().getDate();
		}else{
			return dateOfMonth ;
		}
	}
	
	public Integer getDateOfMonthByCalender(Timestamp timestamp){
		if(dateOfMonth == -1){
			Calendar cal = Calendar.getInstance();
			cal.setTime(timestamp);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			return cal.getTime().getDate();
		}else{
			return dateOfMonth ;
		}
	}
	
	public Integer getDateOfMonthByCalender(Date date){
		if(dateOfMonth == -1){
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			return cal.getTime().getDate();
		}else{
			return dateOfMonth ;
		}
	}
	
	
	public boolean isIntraDay(){
		
		if(Frequency.IntraDay.equals(this.feedFrequency)){
			return true ;
		}
		
		return false ;
	}
	
	public boolean isDaily(){
		
		if(Frequency.Daily.equals(this.feedFrequency)){
			return true ;
		}
		
		return false ;
	}
	
	public boolean isWeekly(){
		
		if(Frequency.Weekly.equals(this.feedFrequency)){
			return true ;
		}
		
		return false ;
	}
	
	public boolean isMonthly(){
		
		if(Frequency.Monthly.equals(this.feedFrequency)){
			return true ;
		}
		
		return false ;
	}
	
	public boolean isQuaterly(){
		
		if(Frequency.Quarterly.equals(this.feedFrequency)){
			return true ;
		}
		
		return false ;
	}
	
	
	@Override
	public Map<String, String> getColumnPropertyMap() {
		return columnPropertyMap;
	}
	@Override
	public void setPrimaryKey(Object obj) {
		this.feedID = (Long)obj;
	}
	@Override
	public Object getPrimaryKey() {
		return this.feedID;
	}
	@Override
	public String getTableName() {
		return this.tableName;
	}
	@Override
	public String toString() {
		return "SLAMetadata [feedID=" + feedID + ", feedName=" + feedName
				+ ", feedFrequency=" + feedFrequency + ", dayOfWeek="
				+ dayOfWeek + ", dateOfMonth=" + dateOfMonth
				+ ", monthOfQuarter=" + monthOfQuarter + ", skipDayOfWeek="
				+ skipDayOfWeek + ", execTime=" + execTime + ", elapseTime="
				+ elapseTime + ", startDate=" + startDate + ", endDate="
				+ endDate + ", userID=" + userID + "]";
	}
	
	public enum Frequency {
		IntraDay,
		Daily,
		Weekly,
		Monthly,
		Quarterly;
		
	}

	
}
