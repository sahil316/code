package com.aexp.gdac.zebra.base.jdbc.dao.core;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Vector;

import com.aexp.gdac.zebra.base.ZebraServiceException;

public class CommonMethods {

	public static int[] toIntArray(Object[] oa){
		int[] sa = (int[])Array.newInstance(int.class , oa.length);
		
		for(int i =0 ; i < oa.length ;i ++){
			sa[i] = ((Integer)oa[i]).intValue();
		}
		
		return sa;
	}
	
	public static Object[] toTypeArray(Object[] oa, Class c){
		Object[] sa = (Object[])Array.newInstance(c,oa.length);
		for(int i =0 ; i<oa.length ;i ++){
			sa[i] = oa[i];
		}
		
		return sa;
	}
	
	
	public  static Method[] toMethodArray(Object[] oa){
		return (Method[])toTypeArray(oa,Method.class);
	}
	
	public static Method getMethodByName(String methodName , Method[] methods){
		Method m = null;
		for(int i = 0 ; i < methods.length ; i++){
			if(methods[i].getName().equals(methodName)){
				m = methods[i];
			}
		}
		return m;
	}
	
	
	public static Method[] getMethodsWithPrefix(Class className, String prefix) throws ZebraServiceException{
		
		try{
			Vector v = new Vector();
			Method[] methods = className.getMethods();
			
			for(int i =  0  ; i < methods.length ; i++){
				if(methods[i].getName().startsWith(prefix)){
					v.addElement(methods[i]);
				}
			}
			
			Object[] setMethods = v.toArray();
			Arrays.sort(setMethods,new MethodComparator());
			return toMethodArray(setMethods);
		}catch(Exception e){
			throw new ZebraServiceException("Exception Occured While getting methods for class: "+className +" for prefix :"+prefix,e);
		}

	}
	
	
	static class MethodComparator implements Comparator{

		@Override
		public int compare(Object o1, Object o2) {
			String name1 = null;
			String name2 = null;
			
			if(o1 instanceof Method){
				name1 =((Method)o1).getName();
			}
			
			if(o2 instanceof Method){
				name2 =((Method)o2).getName();
			}			
			
			if(name1 != null && name2 != null){
				return name1.compareTo(name2);
			}else{
				return 0;
			}
		}
		
	}

	public static String firstLetter2Case(String s, Case caseof){
		char[] chars = s.toCharArray();
		boolean found = false ;
		for(int i =0 ; i<chars.length ; i++ ){
			if(!found && Character.isLetter(chars[i])){
				if(caseof == Case.Upper){
					chars[i] = Character.toUpperCase(chars[i]);
					found = true;
				}else{
					chars[i] = Character.toLowerCase(chars[i]);
					found = true;
					
				}
			}else if(Character.isWhitespace(chars[i])){
				found = false;
			}
		}
		
		return String.valueOf(chars);
	}
	
    
	public static String firstLetter2UpperCase(String s) {
		// TODO Auto-generated method stub
		return firstLetter2Case(s, Case.Upper);
	}
	
	public static enum Case{
		Upper,
		Lower
	}
}
