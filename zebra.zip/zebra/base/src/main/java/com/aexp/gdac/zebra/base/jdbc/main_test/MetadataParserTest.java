package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.io.File;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.metadata.Metadata;
import com.aexp.gdac.zebra.base.metadata.MetadataParser;
import com.aexp.gdac.zebra.base.metadata.MetadataRow;
public class MetadataParserTest {
	
	public static void main(String args[]) throws ZebraServiceException{
		File metadataFile = new File("C:\\AATRI\\Workspace\\Zebra\\zebra\\test-package\\SAMPLE_MD");
		Metadata md = MetadataParser.marshallMetadata(metadataFile);
		md.getMetadataRowList().get(0).setDataFormat(null);
		//System.out.println(md);
		
		System.out.println("Feed Level:"+md.getFeedLevelMetadata());
		
		System.out.println("Column Level:"+md.getNextColumnMetadata());
		System.out.println("Column Level:"+md.getNextColumnMetadata());
		System.out.println("Column Level:"+md.getNextColumnMetadata());
		md.resetBookMarks(null);
		System.out.println("Column Level:"+md.getNextColumnMetadata());
		System.out.println("Column Level:"+md.getNextColumnMetadata());
		System.out.println("Column Level:"+md.getNextColumnMetadata());
		
		System.out.println("Column Rule Level:"+md.getNextColumnRuleMetadata());
		System.out.println("Column Rule Level:"+md.getNextColumnRuleMetadata());
		System.out.println("Column Rule Level:"+md.getNextColumnRuleMetadata());
		//md.resetBookMarks(Level.COLUMN_RULE_LEVEL);

		System.out.println("Column Rule Level:"+md.getNextColumnRuleMetadata());
		System.out.println("Column Rule Level:"+md.getNextColumnRuleMetadata());
		System.out.println("Column Rule Level:"+md.getNextColumnRuleMetadata());

		
		MetadataParser.unmarshallMetadata(md, "C:\\AATRI\\Workspace\\Zebra\\zebra\\test-package\\SAMPLE_MD_OUT");
		
		
		
	}

}
