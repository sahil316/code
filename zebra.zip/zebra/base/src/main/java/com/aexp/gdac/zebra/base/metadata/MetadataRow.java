package com.aexp.gdac.zebra.base.metadata;

import com.aexp.gdac.zebra.base.Level;


public class MetadataRow implements Comparable<MetadataRow> {

	private Long feedId;
	private String feedName;
	private Long stateId ;
	private Level level;
	private String fileFormat;
	private String columnDelimiter;
	private String recordDelimiter;
	private long columnId ;
	private String columnName ;
	private long ruleId ;
	private long columnRuleId;
	private String ruleParameter;
	private String dataType;
	private String dataFormat;
	private Double minAlertThreshold;
	private Double maxAlertThreshold;
	private Double minAbortThreshold;
	private Double maxAbortThreshold;
	private String thresholdType;
	private Integer pastRun;
	private int trendingFlag;
	
	public Long getFeedId() {
		return feedId;
	}
	public void setFeedId(Long feedId) {
		this.feedId = feedId;
	}
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public Long getStateId() {
		return stateId;
	}
	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}
	public Level getLevel() {
		return level;
	}
	public void setLevel(Level level) {
		this.level = level;
	}
	public long getColumnId() {
		return columnId;
	}

	public long getRuleId() {
		return ruleId;
	}
	public void setRuleId(long ruleId) {
		this.ruleId = ruleId;
	}
	public long getColumnRuleId() {
		return columnRuleId;
	}
	public void setColumnId(long columnId) {
		this.columnId = columnId;
	}
	public void setColumnRuleId(long columnRuleId) {
		this.columnRuleId = columnRuleId;
	}
	public String getRuleParameter() {
		return ((ruleParameter==null)?"":ruleParameter);
	}
	public void setRuleParameter(String ruleParameter) {
		this.ruleParameter = ruleParameter;
	}
	public String getDataType() {
		return ((dataType==null)?"":dataType);
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDataFormat() {
		return  ((dataFormat==null)?"":dataFormat);
	}
	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}

	public String getThresholdType() {
		return ((thresholdType==null)?"":thresholdType);
	}
	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}

	public Double getMinAlertThreshold() {
		return minAlertThreshold;
	}
	public void setMinAlertThreshold(Double minAlertThreshold) {
		this.minAlertThreshold = minAlertThreshold;
	}
	public Double getMaxAlertThreshold() {
		return maxAlertThreshold;
	}
	public void setMaxAlertThreshold(Double maxAlertThreshold) {
		this.maxAlertThreshold = maxAlertThreshold;
	}
	public Double getMinAbortThreshold() {
		return minAbortThreshold;
	}
	public void setMinAbortThreshold(Double minAbortThreshold) {
		this.minAbortThreshold = minAbortThreshold;
	}
	public Double getMaxAbortThreshold() {
		return maxAbortThreshold;
	}
	public void setMaxAbortThreshold(Double maxAbortThreshold) {
		this.maxAbortThreshold = maxAbortThreshold;
	}
	public Integer getPastRun() {
		return pastRun;
	}
	public void setPastRun(Integer pastRun) {
		this.pastRun = pastRun;
	}
	public int getTrendingFlag() {
		return trendingFlag;
	}
	public void setTrendingFlag(int trendingFlag) {
		this.trendingFlag = trendingFlag;
	}

	public String getFileFormat() {
		return fileFormat;
	}
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	public String getColumnDelimiter() {
		return columnDelimiter;
	}
	public void setColumnDelimiter(String columnDelimiter) {
		this.columnDelimiter = columnDelimiter;
	}
	public String getRecordDelimiter() {
		return recordDelimiter;
	}
	public void setRecordDelimiter(String recordDelimiter) {
		this.recordDelimiter = recordDelimiter;
	}
	
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	@Override
	public String toString() {
		return "MetadataRow [feedId=" + feedId + ", feedName=" + feedName
				+ ", stateId=" + stateId + ", level=" + level + ", fileFormat="
				+ fileFormat + ", columnDelimiter=" + columnDelimiter
				+ ", recordDelimiter=" + recordDelimiter + ", columnId="
				+ columnId + ", columnName=" + columnName + ", ruleId="
				+ ruleId + ", columnRuleId=" + columnRuleId
				+ ", ruleParameter=" + ruleParameter + ", dataType=" + dataType
				+ ", dataFormat=" + dataFormat + ", minAlertThreshold="
				+ minAlertThreshold + ", maxAlertThreshold="
				+ maxAlertThreshold + ", minAbortThreshold="
				+ minAbortThreshold + ", maxAbortThreshold="
				+ maxAbortThreshold + ", thresholdType=" + thresholdType
				+ ", pastRun=" + pastRun + ", trendingFlag=" + trendingFlag
				+ "]";
	}
	
	/** sorting order of metadata rows */
	@Override
	public int compareTo(MetadataRow o) {
		int result = 0; 
		
		if((result=(this.level.compareTo((o).getLevel())))!=0){
			return result;
		}else if((result=(new Long(this.columnId).compareTo(o.getColumnId())))!=0){
			return result ;
		}else if((result=(new Long(this.ruleId).compareTo((o).getRuleId())))!=0){
			return result ;
		}else if((result=(new Long(this.columnRuleId).compareTo((o).getColumnRuleId())))!=0){
			return result;
		}
		
		return result;
	}
	
	
	
	
}
