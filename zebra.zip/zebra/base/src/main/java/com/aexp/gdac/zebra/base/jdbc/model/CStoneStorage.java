package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class CStoneStorage extends TableValueObjectBase {
	
	private static final String tableName = "cstone_storage";
	
	private long storage_ID ;
	private String table_name ;

	
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("storage_id", "storage_ID");
		columnPropertyMap.put("table_name", "table_name");
	}
	
	
	public long getStorage_ID() {
		return storage_ID;
	}

	public void setStorage_ID(long storage_ID) {
		this.storage_ID = storage_ID;
	}

	public String getTable_name() {
		return table_name;
	}

	public void setTable_name(String table_name) {
		this.table_name = table_name;
	}

	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return this.columnPropertyMap;
	}

	@Override
	public void setPrimaryKey(Object obj) {
		this.storage_ID = (Long) obj;
		
	}

	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.storage_ID;
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}

}
