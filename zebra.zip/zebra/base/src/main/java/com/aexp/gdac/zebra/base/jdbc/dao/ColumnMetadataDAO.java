package com.aexp.gdac.zebra.base.jdbc.dao;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;



public class ColumnMetadataDAO extends SpringDAOBase implements TableDAO{

	private final static Logger log = Logger.getLogger(ColumnMetadataDAO.class);
	
	public TableValueObjectBase getObjectByColumnIdFeedIDAndEndDate(long feedID ,long columnId, Timestamp endDate) throws ZebraServiceException {
		ColumnMetadata ret = null;
		try {
			StatementObject so = generateSelectStmt(new ColumnMetadata());
			ret = (ColumnMetadata) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND ColumnID=? AND EndDate=?",
					new Object[] { feedID, columnId, endDate },
					new ZRowMapper(new ColumnMetadata()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching ColumnMetaData form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
	
//	public TableValueObjectBase getLatestObjectByColumnIdFeedID(long feedID ,long columnId) throws ZebraServiceException {
//		ColumnMetadata ret = null;
//			try {
//				StatementObject so = generateSelectStmt(new ColumnMetadata());
//				ret = (ColumnMetadata) getJdbcTemplate().queryForObject(
//						so.getStmt() + " WHERE FeedID=? AND ColumnID=? AND EndDate IN (SELECT MAX(EndDate) FROM "+
//	            								    so.getTableValueObject().getTableName()+" WHERE FeedID=?)",
//						new Object[] { feedID, columnId, feedID },
//						new ZRowMapper(new ColumnMetadata()));
//			} catch (Throwable t) {
//				throw new ZebraServiceException("Exception occured while fetching ColumnMetaData form DB ",ZebraServiceException.Reason.DB_ERROR,t);
//			}
//			return ret;
//	 }
	
//	 public List getLatestColumnMetadataByFeedID(Long feedId,int startIndex, int rowCount) throws ZebraServiceException {
//	        List ret=null;
//	        try {
//	            StatementObject so=generateSelectStmt(new ColumnMetadata());
//	            ret=(List) getJdbcTemplate().query(
//	            									so.getStmt()+" WHERE FeedID=? AND EndDate IN (SELECT MAX(EndDate) FROM "+
//	            								    so.getTableValueObject().getTableName()+" WHERE FeedID=?)" ,
//	                    new Object[] {feedId,feedId}, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnMetadata()),startIndex,rowCount));
//	        } catch (Throwable t) {
//	        	throw new ZebraServiceException("Exception occured while fetching ColumnMetaData from table  form DB ",ZebraServiceException.Reason.DB_ERROR,t);
//	        }
//	        
//	        return ret;
//	        
//	  }
	
    public List getColumnMetadataByFeedIDAndEndDate(Long feedId, Timestamp feedEndDate, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnMetadata());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND EndDate=?",
                    new Object[] {feedId,feedEndDate }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnMetadata()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnMetaData from table  form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
    public List getEligibleColumnMetadataByFeedID(Long feedId, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnMetadata());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND StartDate <= CURRENT_TIMESTAMP AND EndDate >= CURRENT_TIMESTAMP",
                    new Object[] {feedId }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnMetadata()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnMetaData from table  form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
    
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException{
	ColumnMetadata ret = null;
	try {
		StatementObject so = generateSelectStmt(new ColumnMetadata());
		ret = (ColumnMetadata) getJdbcTemplate().queryForObject(
				so.getStmt() + " WHERE columnID=?",
				new Object[] { (Long)primarykey },
				new ZRowMapper(new ColumnMetadata()));
	} catch (Throwable t) {
		throw new ZebraServiceException("Exception occured while fetching FeedStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
	}
		return ret;
	}

	/*public int updateColumnMetadata(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateColumnMetadata(TableValueObjectBase svo) - entry");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET ColumnName=? , DataType=?, DataFormat=? ,UserID=? " 
            		+ " WHERE FeedID=? AND ColumnID=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((ColumnMetadata)svo).getColumnName(),((ColumnMetadata)svo).getDataType(), 
            		((ColumnMetadata)svo).getDataFormat(), ((ColumnMetadata)svo).getUserID(),
            		((ColumnMetadata)svo).getFeedID(),((ColumnMetadata)svo).getColumnID()});
            
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating column metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	
	public int updateColumnMetadataEndDate(TableValueObjectBase svo) throws ZebraServiceException {
	
    int rowsUpdated=0;
    
    try {
        log.debug("updateColumnMetadata(TableValueObjectBase svo) - entry");
       
        rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET EndDate = DATEADD(day ,-1 ,CURRENT_TIMESTAMP ) " 
        		+ " WHERE FeedID=? AND ColumnID=? AND EndDate=?",
               // "UPDATE " + "Stats SET Action=?" +
                 //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                new Object[] {((ColumnMetadata)svo).getFeedID(), ((ColumnMetadata)svo).getColumnID(), ((ColumnMetadata)svo).getEndDate()});
        
       if (rowsUpdated > 1) {
    	   throw new ZebraServiceException("SQL Update WARN , no of updates was more than one : "+rowsUpdated);
      }
       
    } catch (Throwable t) {
    	
        throw new ZebraServiceException("Exception occred while updating column metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
    
    } finally {
        cleanup();
        log.debug("update  - exit");
    }
    return rowsUpdated;

}
*/
	
	
	public int synchColumnMetadataEndDate(Timestamp newEndDate, Timestamp oldEndDate, Long feedID) throws ZebraServiceException {
		
	    int rowsUpdated=0;
	    
	    try {
	        log.debug("updateColumnMetadata entry for feed metadata updation.");
	       
	        rowsUpdated = getJdbcTemplate().update("UPDATE ColumnMetadata SET EndDate = ?" 
	        		+ " WHERE FeedID=? AND EndDate=?",
	                new Object[] {newEndDate, feedID, oldEndDate});
	        
	       if (rowsUpdated < 1) {
	            log.warn("SQL Update failed , update count is lesser than one ");
	      }
	       
	    } catch (Throwable t) {
	    	
	        throw new ZebraServiceException("Exception occred while updating column metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
	    
	    } finally {
	        cleanup();
	        log.debug("update  - exit");
	    }
	    return rowsUpdated;

	}
	
	
	public int updateColumnMetadataEndDateByFeedIDAndEndDate(long feedID ,Timestamp endDate) throws ZebraServiceException {
		
	    int rowsUpdated=0;
	    
	    try {
	        log.debug("updateColumnMetadata(TableValueObjectBase svo) - entry");
	       
	        rowsUpdated = getJdbcTemplate().update("UPDATE ColumnMetadata SET EndDate = DATEADD(day ,-1 ,CURRENT_TIMESTAMP ) " 
	        		+ " WHERE FeedID=? AND EndDate=?",
	               // "UPDATE " + "Stats SET Action=?" +
	                 //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
	                new Object[] {feedID, endDate});
	        
	       if (rowsUpdated < 1) {
	            log.warn("SQL Update failed , update count is lesser than one ");
	      }
	       
	    } catch (Throwable t) {
	    	
	        throw new ZebraServiceException("Exception occred while updating column metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
	    
	    } finally {
	        cleanup();
	        log.debug("update  - exit");
	    }
	    return rowsUpdated;

	}
	
	

	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting ColumnMetadata to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
