package com.aexp.gdac.zebra.base.jdbc.dao;


import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;




public class StatsDAO  extends SpringDAOBase implements TableDAO{

	private static org.apache.log4j.Logger log = Logger.getLogger(StatsDAO.class);
	
    public TableValueObjectBase getNextEligibleStats() throws ZebraServiceException {
    	Stats ret = null;
		try {
			StatementObject so = generateSelectStmt(new Stats());
			/*ret = (Stats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND Action IS NULL AND RunDate IS NULL  ORDER BY ProcessDate",
					new Object[] { feedID },
					new ZRowMapper(new Stats()));
			*/
			List retList = (List) getJdbcTemplate().query(so.getStmt()+" WHERE Action IS NULL AND ProcessDate IS NULL AND RunDate <= CURRENT_TIMESTAMP ORDER BY RunDate",
                    new Object[] {}, new ZRowMapperResultSetExtractor(new ZRowMapper(new Stats()),0,1));
			if(!retList.isEmpty()){
				ret = (Stats)retList.get(0);
			}
			
		} catch (Throwable t) {
			t.printStackTrace();
			throw new ZebraServiceException("Exception occured while fetching Stats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
			
		} finally {
            cleanup();
            log.debug("select Stats - exit");
        }
		return ret;
        
    }
	
    public TableValueObjectBase getNextEligibleStatsByFeedID(long feedId) throws ZebraServiceException {
    	Stats ret = null;
		try {
			StatementObject so = generateSelectStmt(new Stats());
			/*ret = (Stats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND Action IS NULL AND RunDate IS NULL  ORDER BY ProcessDate",
					new Object[] { feedID },
					new ZRowMapper(new Stats()));
			*/
			List retList = (List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND Action IS NULL AND ProcessDate IS NULL AND RunDate <= CURRENT_TIMESTAMP ORDER BY RunDate",
                    new Object[] {feedId}, new ZRowMapperResultSetExtractor(new ZRowMapper(new Stats()),0,1));
			if(!retList.isEmpty()){
				ret = (Stats)retList.get(0);
			}
			
		} catch (Throwable t) {
			t.printStackTrace();
			throw new ZebraServiceException("Exception occured while fetching Stats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
			
		} finally {
            cleanup();
            log.debug("select Stats - exit");
        }
		return ret;
        
    }
	
    @Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primaryKey) throws ZebraServiceException {
    	Stats ret = null;
		try {
			StatementObject so = generateSelectStmt(new Stats());
			ret = (Stats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE StateID=?",
					new Object[] { primaryKey },
					new ZRowMapper(new Stats()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching Stats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
            cleanup();
            log.debug("select Stats - exit");
        }
		return ret;
	}
    
    public List getStatsPastRuns(Long feedID , int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new Stats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? AND Action IS NOT NULL AND ProcessDate IS NOT NULL ORDER BY ProcessDate DESC",
                    new Object[] {feedID}, new ZRowMapperResultSetExtractor(new ZRowMapper(new Stats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching Stats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }

    public List getStatsCreatedBetweenDates(Long feedID , Timestamp firstDate, Timestamp secondDate ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new Stats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? AND Created BETWEEN ? and ?",
                    new Object[] {feedID,firstDate,secondDate}, new ZRowMapperResultSetExtractor(new ZRowMapper(new Stats()),0,-1));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching Stats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
    @Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;
		try {
			svo.setPrimaryKey(getNextSequenceValue());
			
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting Stats to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}


	public int updateStatsAction(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateStatsAction(TableValueObjectBase svo) - entry");
            rowsUpdated = getJdbcTemplate().update("update Stats set Action =? ,ProcessDate=?,ErrorMessage=null where FeedID =? AND StateID=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((Stats)svo).getAction(),((Stats)svo).getProcessDate(),((Stats)svo).getFeedID(), ((Stats)svo).getStateID() });
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occred while updating stats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	
	
	public int updateStatsExecDetails(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateStatsAction(TableValueObjectBase svo) - entry");
            rowsUpdated = getJdbcTemplate().update("update Stats set ProcessDate=?,ExecMode=? where FeedID =? AND StateID=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((Stats)svo).getProcessDate(),((Stats)svo).getExecMode(),((Stats)svo).getFeedID(), ((Stats)svo).getStateID() });
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occred while updating stats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}

	public int updateStatsErrorMessage(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateStatsErrorMessage(TableValueObjectBase svo) - entry");
            rowsUpdated = getJdbcTemplate().update("UPDATE Stats SET ErrorMessage=?, ProcessDate=null WHERE StateID=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((Stats)svo).getErrorMessage(), ((Stats)svo).getStateID() });
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
        } catch (Throwable t) {
        	t.printStackTrace();
           // throw new ZebraServiceException("Exception occred while updating stats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	
	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}


	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	
}
