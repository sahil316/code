package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneIngestionFeeDQMStatistics;

public class CStoneIngestionFeeDQMStatisticsDAO  extends SpringDAOBase implements TableDAO {
	private final static Logger log = Logger.getLogger(CStoneIngestionFeeDQMStatisticsDAO.class);
	
    public List<CStoneIngestionFeeDQMStatistics> getStorageAttributeDQMStatistics(Long storage_ID, Long attr_id, int startIndex, int rowCount ) throws ZebraServiceException {
        List<CStoneIngestionFeeDQMStatistics> ret=null;
        try {
            StatementObject so=generateSelectStmt(new CStoneIngestionFeeDQMStatistics());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE storage_id=? AND attr_id=? ORDER BY file_id DESC",
                    new Object[] {storage_ID,attr_id}, new ZRowMapperResultSetExtractor(new ZRowMapper(new CStoneIngestionFeeDQMStatistics()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching CStoneStorageAttribute from DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
    public List<CStoneIngestionFeeDQMStatistics> getStorageVolumeDQMStatistics(Long storage_ID, int startIndex, int rowCount ) throws ZebraServiceException {
        List<CStoneIngestionFeeDQMStatistics> ret=null;
        try {
            StatementObject so=generateSelectStmt(new CStoneIngestionFeeDQMStatistics());
            ret=(List) getJdbcTemplate().query("SELECT MAX(p_count) AS p_count, storage_id, file_id "
            		+ "FROM cstone_ingestion_feed_dqm_statistics WHERE storage_id=? GROUP BY file_id ORDER BY file_id DESC",
                    new Object[] {storage_ID}, new ZRowMapperResultSetExtractor(new ZRowMapper(new CStoneIngestionFeeDQMStatistics()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching FeedMetaData from table  form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }

	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		 throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
