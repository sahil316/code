package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.ArrayList;
import java.util.List;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;


public class ColumnStatsDAO extends SpringDAOBase implements TableDAO{

    public List getColumnStatsByColumnID(Long columnID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE ColumnID=?",
                    new Object[] {columnID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
	
    public List getColumnStatsByFeedID(Long feedId, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=?",
                    new Object[] {feedId }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
    public List getColumnStatsPastRuns(Long feedID ,Long columnID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? AND ColumnID=? ORDER BY StateID DESC",
                    new Object[] {feedID,columnID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
    public List getColumnStatsByFeedIDAndStateID(Long feedId, Long stateID) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND StateID=?",
                    new Object[] {feedId , stateID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnStats()),0,-1));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
    }

	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting ColumnStats to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey)
			throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
