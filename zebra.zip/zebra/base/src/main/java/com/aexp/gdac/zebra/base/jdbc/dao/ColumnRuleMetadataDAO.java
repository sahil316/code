package com.aexp.gdac.zebra.base.jdbc.dao;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;


public class ColumnRuleMetadataDAO extends SpringDAOBase implements TableDAO{
	
	private static org.apache.log4j.Logger log = Logger.getLogger(ColumnRuleMetadataDAO.class);
	
	public TableValueObjectBase getObjectByColumnRuleId(Object columnId) throws ZebraServiceException {
		ColumnRuleMetadata ret = null;
		try {
			StatementObject so = generateSelectStmt(new ColumnRuleMetadata());
			ret = (ColumnRuleMetadata) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE columnRuleID=?",
					new Object[] { columnId },
					new ZRowMapper(new ColumnRuleMetadata()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching ColumnRuleMetaData form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
	
	
    public List getColumnRuleMetadataByColumnIDAndFeedIDAndEndDate(Long feedID ,Long columnID, Timestamp endDate, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleMetadata());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND ColumnID=? AND EndDate=?",
                    new Object[] {feedID, columnID, endDate}, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleMetadata()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleMetaData form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
    public List getColumnRuleMetadataByFeedIDAndEndDate(Long feedId, Timestamp feedEndDate, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleMetadata());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND EndDate=?",
                    new Object[] {feedId,feedEndDate }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleMetadata()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleMetaData from table  form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    public List getEligibleColumnRuleMetadataByColumnIDAndFeedID(Long feedID ,Long columnID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleMetadata());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? AND ColumnID=? AND StartDate <= CURRENT_TIMESTAMP AND EndDate >= CURRENT_TIMESTAMP",
                    new Object[] {feedID,columnID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleMetadata()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleMetaData form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
    
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException{
	ColumnRuleMetadata ret = null;
	try {
		StatementObject so = generateSelectStmt(new ColumnRuleMetadata());
		ret = (ColumnRuleMetadata) getJdbcTemplate().queryForObject(
				so.getStmt() + " WHERE columnID=?",
				new Object[] { (Long)primarykey },
				new ZRowMapper(new ColumnRuleMetadata()));
	} catch (Throwable t) {
		throw new ZebraServiceException("Exception occured while fetching Column Rule Meta Data form DB ",ZebraServiceException.Reason.DB_ERROR,t);
	}
	return ret;
	}


	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting ColumnRuleMetadata to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

	public int updateColumnRuleMetadata(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateColumnRuleMetadata(TableValueObjectBase svo) - entry");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET RuleParameter=? , MinAlertThreshold=?, MinAbortThreshold=?,"
            		+ "MaxAlertThreshold=? ,MaxAbortThreshold=? , ThresholdType=?, PastRuns=? ,UserID=? "
            		+ " WHERE FeedID=? AND ColumnID=? AND RuleID=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((ColumnRuleMetadata)svo).getRuleParameter(),((ColumnRuleMetadata)svo).getMinAlertThreshold(), 
            		((ColumnRuleMetadata)svo).getMinAbortThreshold() , ((ColumnRuleMetadata)svo).getMaxAlertThreshold(), 
            		((ColumnRuleMetadata)svo).getMaxAbortThreshold() , ((ColumnRuleMetadata)svo).getThresholdType(),
            		((ColumnRuleMetadata)svo).getPastRuns(),((ColumnRuleMetadata)svo).getUserID(),
            		((ColumnRuleMetadata)svo).getFeedID(),((ColumnRuleMetadata)svo).getColumnID(),((ColumnRuleMetadata)svo).getRuleID()});
            
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating stats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	
	
	
	public int synchColumnRuleMetadataEndDate(Timestamp newEndDate, Timestamp oldEndDate, Long feedID) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateColumnRuleMetadata entry for feed metadata updation.");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE ColumnRuleMetadata SET EndDate = ? WHERE FeedID=? AND EndDate=?",
            		new Object[] {newEndDate, feedID, oldEndDate});
            
            if (rowsUpdated < 1) {
	            log.warn("SQL Update failed , update count is lesser than one ");
	      }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating stats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	
	
	public int updateColumnRuleMetadataEndDate(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateColumnRuleMetadata(TableValueObjectBase svo) - entry");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET EndDate = DATEADD(day ,-1 ,CURRENT_TIMESTAMP ) "
            		+ " WHERE FeedID=? AND ColumnID=? AND RuleID=? AND EndDate=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((ColumnRuleMetadata)svo).getFeedID(),((ColumnRuleMetadata)svo).getColumnID(),((ColumnRuleMetadata)svo).getRuleID(), ((ColumnRuleMetadata)svo).getEndDate()});
            
           if (rowsUpdated > 1) {
                throw new ZebraServiceException("SQL Update WARN , more than one rows updated");
          }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating stats" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	
	public int updateColumnRuleMetadataEndDateByFeedIDAndEndDate(long feedID ,Timestamp endDate) throws ZebraServiceException {
		
	    int rowsUpdated=0;
	    
	    try {
	        log.debug("updateColumnRuleMetadata(TableValueObjectBase svo) - entry");
	       
	        rowsUpdated = getJdbcTemplate().update("UPDATE ColumnRuleMetadata SET EndDate = DATEADD(day ,-1 ,CURRENT_TIMESTAMP ) " 
	        		+ " WHERE FeedID=? AND EndDate=?",
	               // "UPDATE " + "Stats SET Action=?" +
	                 //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
	                new Object[] {feedID, endDate});
	        
	       if (rowsUpdated < 1) {
	            log.warn("SQL Update failed, Rows updated are lesser than one");
	      }
	       
	    } catch (Throwable t) {
	    	
	        throw new ZebraServiceException("Exception occred while updating column rule metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
	    
	    } finally {
	        cleanup();
	        log.debug("update  - exit");
	    }
	    
	    return rowsUpdated;
	
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
