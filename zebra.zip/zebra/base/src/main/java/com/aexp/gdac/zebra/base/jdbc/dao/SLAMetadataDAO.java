package com.aexp.gdac.zebra.base.jdbc.dao;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;

public class SLAMetadataDAO extends SpringDAOBase implements TableDAO {
	private final static Logger log = Logger.getLogger(SLAMetadataDAO.class);

	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException {
		SLAMetadata ret = null;
			try {
				 StatementObject so=generateSelectStmt(new SLAMetadata());
		            List retList=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? ORDER BY EndDate DESC ",
		                    new Object[] { primarykey }, new ZRowMapperResultSetExtractor(new ZRowMapper(new SLAMetadata()),0,1));
		            
		            if(!retList.isEmpty()){
		            	ret =(SLAMetadata) retList.get(0);
		            }
		            
			} catch (Throwable t) {
				throw new ZebraServiceException("Exception occured while fetching SLAMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
			}
			return ret;
	}

    public SLAMetadata getEligibleSLAMetadataByFeedId(Long feedId ) throws ZebraServiceException {
    	SLAMetadata ret = null;
		try {
			StatementObject so = generateSelectStmt(new SLAMetadata());
			ret = (SLAMetadata) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND StartDate <= CURRENT_TIMESTAMP AND EndDate >= CURRENT_TIMESTAMP",
					new Object[] { feedId },
					new ZRowMapper(new SLAMetadata()));
		} catch(org.springframework.dao.EmptyResultDataAccessException erdae){
			ret = null ;
		//	log.error("No entry found for metadata in DB ",erdae);
			
		}catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching SLAMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
        
   }
    
    public List getEligibleSLAMetadataList( ) throws ZebraServiceException {
    	List ret=null;
		try {
			StatementObject so = generateSelectStmt(new SLAMetadata());
			ret = (List) getJdbcTemplate().query(
					so.getStmt() + " WHERE StartDate <= CURRENT_TIMESTAMP AND EndDate >= CURRENT_TIMESTAMP",
					new Object[] {},
					new ZRowMapperResultSetExtractor(new ZRowMapper(new SLAMetadata()),0,-1));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching SLAMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
        
   }
    
    public TableValueObjectBase getCurrentSLAMetadataByFeedId(Long feedId ) throws ZebraServiceException {
    	SLAMetadata ret = null;
		try {
			 StatementObject so=generateSelectStmt(new SLAMetadata());
	            List retList=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? ORDER BY EndDate DESC ",
	                    new Object[] { feedId }, new ZRowMapperResultSetExtractor(new ZRowMapper(new SLAMetadata()),0,1));
	            
	            if(!retList.isEmpty()){
	            	ret =(SLAMetadata) retList.get(0);
	            }
	            
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching SLAMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		
		return ret;
        
    }
    
    public TableValueObjectBase getSLAMetadataByFeedIDAndEndDate(Long feedId, Timestamp feedEndDate) throws ZebraServiceException {
        SLAMetadata ret=null;
        try {
            StatementObject so=generateSelectStmt(new SLAMetadata());
            ret= (SLAMetadata)getJdbcTemplate().queryForObject(so.getStmt()+" WHERE FeedID=? AND EndDate=?",
                    new Object[] {feedId,feedEndDate }, new ZRowMapper(new SLAMetadata()));
        }catch(org.springframework.dao.EmptyResultDataAccessException ex){
        	return null ;
        }catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching SLAMetadata from table form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }


    
    @Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;
		try {
			if(svo.getPrimaryKey() == null){
				svo.setPrimaryKey(getNextSequenceValue());
			}
			
			log.info("Inserting SLAMetadata :" + svo);
			
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting SLAMetadata to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

    public int updateSLAMetadataEndDate(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateSLAMetadataEndDate(TableValueObjectBase svo) - entry");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET EndDate = DATEADD(day ,-1 ,CURRENT_TIMESTAMP ) "
            		+ " WHERE FeedID=? AND EndDate=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((SLAMetadata)svo).getFeedID(), ((SLAMetadata)svo).getEndDate()});
            
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed, Rows updated for slametadata are more than or less than 1");
          }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating sla Metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
