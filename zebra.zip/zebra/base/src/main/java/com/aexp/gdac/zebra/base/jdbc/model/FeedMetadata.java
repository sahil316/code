package com.aexp.gdac.zebra.base.jdbc.model;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class FeedMetadata extends TableValueObjectBase{
	private static final String tableName = "FeedMetadata";
	
	private Long feedID;
	private String feedName;
	private String frequency;
	private String fileFormat;
	private String columnDelimiter;
	private String recordDelimiter;
	private String header;
	private String tailer;
	private Double minAlertThreshold;
	private Double minAbortThreshold;
	private Double maxAlertThreshold;
	private Double maxAbortThreshold;
	private String thresholdType;
	private int pastRuns;
	private Timestamp startDate;
	private Timestamp endDate;
	private String userID;
	private String emailID;
	private String RGRP ;
	private String AGRP ;
	private String ticketRobo ;
	
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("FeedName", "feedName");
		columnPropertyMap.put("Frequency", "frequency");
		columnPropertyMap.put("FileFormat", "fileFormat");
		columnPropertyMap.put("ColumnDelimiter", "columnDelimiter");
		columnPropertyMap.put("RecordDelimiter", "recordDelimiter");
		columnPropertyMap.put("Header", "header");
		columnPropertyMap.put("Tailer", "tailer");
		columnPropertyMap.put("MinAlertThreshold", "minAlertThreshold");
		columnPropertyMap.put("MinAbortThreshold", "minAbortThreshold");
		columnPropertyMap.put("MaxAlertThreshold", "maxAlertThreshold");
		columnPropertyMap.put("MaxAbortThreshold", "maxAbortThreshold");
		columnPropertyMap.put("ThresholdType", "thresholdType");
		columnPropertyMap.put("PastRuns", "pastRuns");
		columnPropertyMap.put("StartDate", "startDate");
		columnPropertyMap.put("EndDate", "endDate");
		columnPropertyMap.put("UserID", "userID");
		columnPropertyMap.put("EmailID", "emailID");
		columnPropertyMap.put("RGRP", "RGRP");
		columnPropertyMap.put("AGRP", "AGRP");
		columnPropertyMap.put("TicketRobo", "ticketRobo");
		// required for getting latest feedId registered
		columnPropertyMap.put("MAX(FeedID)", "feedID");
		columnPropertyMap.put("MAX(EndDate)", "endDate");
	}
	
	public Long getFeedID() {
		return feedID;
	}
	public void setFeedID(Long feedID) {
		this.feedID = feedID;
	}
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getFileFormat() {
		return fileFormat;
	}
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	public String getColumnDelimiter() {
		return columnDelimiter;
	}
	public void setColumnDelimiter(String columnDelimiter) {
		this.columnDelimiter = columnDelimiter;
	}
	public String getRecordDelimiter() {
		return recordDelimiter;
	}
	public void setRecordDelimiter(String recordDelimiter) {
		this.recordDelimiter = recordDelimiter;
	}
	public Double getMinAlertThreshold() {
		return minAlertThreshold;
	}
	public void setMinAlertThreshold(Double minAlertThreshold) {
		this.minAlertThreshold = minAlertThreshold;
	}
	public Double getMinAbortThreshold() {
		return minAbortThreshold;
	}
	public void setMinAbortThreshold(Double minAbortThreshold) {
		this.minAbortThreshold = minAbortThreshold;
	}
	public Double getMaxAlertThreshold() {
		return maxAlertThreshold;
	}
	public void setMaxAlertThreshold(Double maxAlertThreshold) {
		this.maxAlertThreshold = maxAlertThreshold;
	}
	public Double getMaxAbortThreshold() {
		return maxAbortThreshold;
	}
	public void setMaxAbortThreshold(Double maxAbortThreshold) {
		this.maxAbortThreshold = maxAbortThreshold;
	}
	public String getThresholdType() {
		return thresholdType;
	}
	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}
	public int getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(int pastRuns) {
		this.pastRuns = pastRuns;
	}
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}
	public Timestamp getEndDate() {
		return endDate;
	}
	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getTailer() {
		return tailer;
	}
	public void setTailer(String tailer) {
		this.tailer = tailer;
	}

	public String getRGRP() {
		return RGRP;
	}
	public void setRGRP(String rGRP) {
		RGRP = rGRP;
	}
	public String getAGRP() {
		return AGRP;
	}
	public void setAGRP(String aGRP) {
		AGRP = aGRP;
	}
	public String getTicketRobo() {
		return ticketRobo;
	}
	public void setTicketRobo(String ticketRobo) {
		this.ticketRobo = ticketRobo;
	}
	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}
	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		this.feedID = (Long) obj;
		
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.feedID;
	}
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}
	@Override
	public String toString() {
		return "FeedMetadata [feedID=" + feedID + ", feedName=" + feedName + ", frequency=" + frequency
				+ ", fileFormat=" + fileFormat + ", columnDelimiter=" + columnDelimiter + ", recordDelimiter="
				+ recordDelimiter + ", header=" + header + ", tailer=" + tailer + ", minAlertThreshold="
				+ minAlertThreshold + ", minAbortThreshold=" + minAbortThreshold + ", maxAlertThreshold="
				+ maxAlertThreshold + ", maxAbortThreshold=" + maxAbortThreshold + ", thresholdType=" + thresholdType
				+ ", pastRuns=" + pastRuns + ", startDate=" + startDate + ", endDate=" + endDate + ", userID=" + userID
				+ ", emailID=" + emailID + ", RGRP=" + RGRP + ", AGRP=" + AGRP + ", ticketRobo=" + ticketRobo + "]";
	}
	
}
