package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;




public class FeedMetadataDAO  extends SpringDAOBase implements TableDAO{

	private final static Logger log = Logger.getLogger(FeedMetadataDAO.class);
	
    public TableValueObjectBase getLatestFeedMetadataByFeedId(Long feedId ) throws ZebraServiceException {
    	FeedMetadata ret = null;
		try {
			 StatementObject so=generateSelectStmt(new FeedMetadata());
	            List retList=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? ORDER BY EndDate DESC ",
	                    new Object[] { feedId }, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedMetadata()),0,1));
	            
	            if(!retList.isEmpty()){
	            	ret =(FeedMetadata) retList.get(0);
	            }
	            
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching FeedMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
        
    }
	
    public TableValueObjectBase getEligibleFeedMetadataByFeedId(Long feedId ) throws ZebraServiceException {
    	FeedMetadata ret = null;
		try {
			StatementObject so = generateSelectStmt(new FeedMetadata());
			ret = (FeedMetadata) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND StartDate <= CURRENT_TIMESTAMP AND EndDate >= CURRENT_TIMESTAMP",
					new Object[] { feedId },
					new ZRowMapper(new FeedMetadata()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching FeedMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
   }
    
    /* to fetch latest feedId registerd by user 
    public TableValueObjectBase getFeedIDByUserIDAndFeedName(String emailID, String feedName) throws ZebraServiceException{
    	FeedMetadata ret = null;
		try {
			StatementObject so = generateSelectStmt(new FeedMetadata());
			ret = (FeedMetadata) getJdbcTemplate().queryForObject(
					"SELECT MAX(FeedID) AS FeedID,FeedName,EmailID,StartDate,EndDate,UserID from FeedMetadata " + "GROUP BY EmailID,UserID,FeedName,EndDate,StartDate HAVING  EmailID=? AND FeedName=? AND EndDate >= CURRENT_TIMESTAMP",
					new Object[] { emailID, feedName},
					new ZRowMapper(new FeedMetadata()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching FeedMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
    }
    */
    
    /* This method will fetch the all the latest feed's Name and ID from DB, regardless it expired or not */
    public List getAllFeedMetadata() throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new FeedMetadata());
            ret=(List) getJdbcTemplate().query("SELECT FeedID, FeedName, EndDate FROM FeedMetadata WHERE EndDate "
            		+ "IN (SELECT DISTINCT(MAX(EndDate)) AS EndDate FROM FeedMetadata GROUP BY FeedID)",
                    new Object[] {}, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedMetadata()),0,-1));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching FeedMetaData from table  form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
	
    @Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primaryKey) throws ZebraServiceException {
    	FeedMetadata ret = null;
		try {
			 StatementObject so=generateSelectStmt(new FeedMetadata());
	            List retList=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=? ORDER BY EndDate DESC ",
	                    new Object[] { primaryKey }, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedMetadata()),0,1));
	            
	            if(!retList.isEmpty()){
	            	ret =(FeedMetadata) retList.get(0);
	            }
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching FeedMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
    
    public int updateFeedMetadata(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateFeedMetadata(TableValueObjectBase svo) - entry");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET Frequency=? , FeedName=?, FileFormat=?,"
            		+ "ColumnDelimiter=? ,MinAlertThreshold=? , MinAbortThreshold=?, MaxAlertThreshold=? ,MaxAbortThreshold=?, "
            		+ "ThresholdType=?, PastRuns=?, UserID=?,  EmailID=?, Header=?, Tailer=? "
            		+ " WHERE FeedID=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((FeedMetadata)svo).getFrequency(),((FeedMetadata)svo).getFeedName(), 
            		((FeedMetadata)svo).getFileFormat() , ((FeedMetadata)svo).getColumnDelimiter(),
            		((FeedMetadata)svo).getMinAlertThreshold() , ((FeedMetadata)svo).getMinAbortThreshold(),
            		((FeedMetadata)svo).getMaxAlertThreshold() , ((FeedMetadata)svo).getMaxAbortThreshold(),
            		((FeedMetadata)svo).getThresholdType() , ((FeedMetadata)svo).getPastRuns(),
            		((FeedMetadata)svo).getUserID() , ((FeedMetadata)svo).getEmailID(),((FeedMetadata)svo).getHeader(),
            		((FeedMetadata)svo).getTailer(),((FeedMetadata)svo).getFeedID()});
            
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed");
          }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating feed Metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
    
    public int updateFeedMetadataEndDate(TableValueObjectBase svo) throws ZebraServiceException {
		
        int rowsUpdated=0;
        
        try {
            log.debug("updateFeedMetadata(TableValueObjectBase svo) - entry");
           
            rowsUpdated = getJdbcTemplate().update("UPDATE "+svo.getTableName()+" SET EndDate = DATEADD(day ,-1 ,CURRENT_TIMESTAMP ) "
            		+ " WHERE FeedID=? AND EndDate=?",
                   // "UPDATE " + "Stats SET Action=?" +
                     //                      " WHERE " + "FeedID" + "= ? "+ "AND StateID" + "= ?",
                    new Object[] {((FeedMetadata)svo).getFeedID(), ((FeedMetadata)svo).getEndDate()});
            
           if (rowsUpdated != 1) {
                throw new ZebraServiceException("SQL Update failed, Rows updated for feedmetadata are more than or less than 1");
          }
           
        } catch (Throwable t) {
        	
            throw new ZebraServiceException("Exception occred while updating feed Metadata" ,ZebraServiceException.Reason.DB_ERROR, t);
        
        } finally {
            cleanup();
            log.debug("update  - exit");
        }
        return rowsUpdated;
    
	}
    
    
	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;
		try {
			if(svo.getPrimaryKey() == null){
				svo.setPrimaryKey(getNextSequenceValue());
			}
			
			log.info("Inserting FeedMetadata :" + svo);
			
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting FeedMetadata to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

//	public FeedMetadata getFeedMetadataByName(String feedName) throws ZebraServiceException {
//		FeedMetadata ret = null;
//		try {
//    		 feedName = feedName.trim();
//			 StatementObject so=generateSelectStmt(new FeedMetadata());
//	         List retList=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedName=?",
//	                 new Object[] { feedName }, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedMetadata()),0,1));
//	            
//	            if(!retList.isEmpty())
//	            	ret =(FeedMetadata) retList.get(0);
//	            
//	            
//		} catch (Throwable t) {
//			throw new ZebraServiceException("Exception occured while fetching FeedMetadata form DB ",ZebraServiceException.Reason.DB_ERROR,t);
//		}
//		return ret;
//	}
	
	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	
}
