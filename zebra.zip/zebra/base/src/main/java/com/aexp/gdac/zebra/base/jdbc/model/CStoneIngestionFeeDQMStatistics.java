package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class CStoneIngestionFeeDQMStatistics extends TableValueObjectBase{
	private static final String tableName = "cstone_ingestion_feed_dqm_statistics";

	private long file_id;
	private long storage_id ;
	private long attr_id;
	private String attr_name ;
	private long p_nullcount ;
	private long p_count ;
	private double p_stddev ;
	private double p_variance ;
	private double p_avg;
	private String p_min ;
	private String p_max ;
	private double p_percent5;
	private double p_percent25;
	private double p_percent50;
	private double p_percent75;
	private double p_percent99;
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("file_id", "file_id");
		columnPropertyMap.put("storage_id", "storage_id");
		columnPropertyMap.put("attr_id", "attr_id");
		columnPropertyMap.put("attr_name", "attr_name");
		columnPropertyMap.put("p_count", "p_count");
		columnPropertyMap.put("p_nullcount", "p_nullcount");
		columnPropertyMap.put("p_stddev", "p_stddev");
		columnPropertyMap.put("p_variance", "p_variance");
		columnPropertyMap.put("p_avg", "p_avg");
		columnPropertyMap.put("p_min", "p_min");
		columnPropertyMap.put("p_max", "p_max");
		columnPropertyMap.put("p_percent5", "p_percent5");
		columnPropertyMap.put("p_percent25", "p_percent25");
		columnPropertyMap.put("p_percent50", "p_percent50");
		columnPropertyMap.put("p_percent75", "p_percent75");
		columnPropertyMap.put("p_percent99", "p_percent99");
	}

	
	public long getFile_id() {
		return file_id;
	}

	public void setFile_id(long file_id) {
		this.file_id = file_id;
	}

	public long getStorage_id() {
		return storage_id;
	}

	public void setStorage_id(long storage_id) {
		this.storage_id = storage_id;
	}

	public long getAttr_id() {
		return attr_id;
	}

	public void setAttr_id(long attr_id) {
		this.attr_id = attr_id;
	}

	public String getAttr_name() {
		return attr_name;
	}

	public void setAttr_name(String attr_name) {
		this.attr_name = attr_name;
	}

	public long getP_nullcount() {
		return p_nullcount;
	}

	public void setP_nullcount(long p_nullcount) {
		this.p_nullcount = p_nullcount;
	}

	public long getP_count() {
		return p_count;
	}

	public void setP_count(long p_count) {
		this.p_count = p_count;
	}

	public double getP_stddev() {
		return p_stddev;
	}

	public void setP_stddev(double p_stddev) {
		this.p_stddev = p_stddev;
	}

	public double getP_variance() {
		return p_variance;
	}

	public void setP_variance(double p_variance) {
		this.p_variance = p_variance;
	}

	public double getP_avg() {
		return p_avg;
	}

	public void setP_avg(double p_avg) {
		this.p_avg = p_avg;
	}

	public String getP_min() {
		return p_min;
	}

	public void setP_min(String p_min) {
		this.p_min = p_min;
	}

	public String getP_max() {
		return p_max;
	}

	public void setP_max(String p_max) {
		this.p_max = p_max;
	}

	public double getP_percent5() {
		return p_percent5;
	}

	public void setP_percent5(double p_percent5) {
		this.p_percent5 = p_percent5;
	}

	public double getP_percent25() {
		return p_percent25;
	}

	public void setP_percent25(double p_percent25) {
		this.p_percent25 = p_percent25;
	}

	public double getP_percent50() {
		return p_percent50;
	}

	public void setP_percent50(double p_percent50) {
		this.p_percent50 = p_percent50;
	}

	public double getP_percent75() {
		return p_percent75;
	}

	public void setP_percent75(double p_percent75) {
		this.p_percent75 = p_percent75;
	}

	public double getP_percent99() {
		return p_percent99;
	}

	public void setP_percent99(double p_percent99) {
		this.p_percent99 = p_percent99;
	}

	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return this.columnPropertyMap;
	}

	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}

}
