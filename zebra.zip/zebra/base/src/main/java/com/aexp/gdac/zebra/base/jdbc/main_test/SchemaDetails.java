package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

import java.sql.ResultSet;

public class SchemaDetails {

	public static void main(String args[]) throws Exception {

		String databaseName = "test_sg";
		String userName = "bd_apps_user";
		String password = "passw0rd";
		String mySQLPort = "3306";
		String hostUrl = "lgpbd1050.gso.aexp.com";

		// Setup the connection with the DB

		Class.forName("com.mysql.jdbc.Driver");

		Connection conn = DriverManager.getConnection("jdbc:mysql://" + hostUrl
				+ ":" + mySQLPort, userName, password);

		// --- LISTING DATABASE SCHEMA NAMES ---

	  ResultSet resultSet = conn.getMetaData().getCatalogs();
		while (resultSet.next()) {

			System.out.println("Schema Name = "
					+ resultSet.getString("TABLE_CAT"));

		}

		resultSet.close();

		// --- LISTING DATABASE TABLE NAMES ---

		String[] types = { "TABLE" };

		resultSet = conn.getMetaData()
				.getTables(databaseName, null, "%", types);
		
		String tableName = "";
		while (resultSet.next()) {
			tableName = resultSet.getString(3);
			System.out.println("Table Name = " + tableName);
		}

		resultSet.close();

		// --- LISTING DATABASE COLUMN NAMES ---

		DatabaseMetaData meta = conn.getMetaData();
		 tableName = "tbl_FeedStats";
		 resultSet = meta.getColumns(databaseName, null, tableName, "%");


		while (resultSet.next()) {
			System.out.println(resultSet.getString(4) + ","

			+ resultSet.getString(12) + " " +resultSet.getString(6));
		}

	}

}