package com.aexp.gdac.zebra.base.jdbc.dao.core;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlTypeValue;
import org.springframework.util.Assert;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.model.ZTableValueTypeObjectBase;

/**
 *  Spring Framwork based JDBC base class
 *  Doesnot support CLOB and BLOB Types
 * 
 * 
 */

public abstract class SpringDAOBase {
	
	private static org.apache.log4j.Logger log = Logger.getLogger(SpringDAOBase.class);

	private JdbcTemplate jdbcTemplate;
	private String sequenceName ;
	
	public String getSequenceName() {
		return sequenceName;
	}

	public void setSequenceName(String sequenceName) {
		this.sequenceName = sequenceName;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setDataSource(DataSource ds) {
		jdbcTemplate = new JdbcTemplate(ds);

	}

	// ###############################################################3 Inner
	// Classes #############################################################
	public class StatementObject {
		private String stmt;
		private List values;
		private List types;
		private TableValueObjectBase tableValueObject;

		public StatementObject(String stmt, List values, List types,
				TableValueObjectBase vo) {
			if(log.isDebugEnabled()){
				log.debug("Argument  Values : "+values + ", Argument Types:"+types);
			}
			this.stmt = stmt;
			this.values = values;
			this.types = types;
			this.tableValueObject = vo;

		}

		public String getStmt() {
			return stmt;
		}

		public void setStmt(String stmt) {
			this.stmt = stmt;
		}

		public List getValues() {
			return values;
		}

		public Object[] getValuesArray() {
			return values.toArray();
		}

		public Object[] getTypesArray() {
			return types.toArray();
		}

		public void setValues(List values) {
			this.values = values;
		}

		public List getTypes() {
			return types;
		}

		public void setTypes(List types) {
			this.types = types;
		}

		public TableValueObjectBase getTableValueObject() {
			return tableValueObject;
		}

		public void setTableValueObject(TableValueObjectBase tableValueObject) {
			this.tableValueObject = tableValueObject;
		}
	}
	 /**
     * ZRowMapperResultSetExtractor with capability to start query from given start index and stop 
     * at given rowcount
     * @author kilpopas
     *
     */
    public class ZRowMapperResultSetExtractor implements ResultSetExtractor {


        private final RowMapper rowMapper;


        private final int rowsExpected;
        
        private final int startIndex;//start offset
        private final int rowCount;//count of rows returned
        




        /**
         * Create a new RowMapperResultSetExtractor.
         * @param rowMapper the RowMapper which creates an object for each row
         */
        public ZRowMapperResultSetExtractor(RowMapper rowMapper,int startIndex, int rowCount) {
            this(rowMapper, 0, startIndex, rowCount);
            
        }


        /**
         * Create a new RowMapperResultSetExtractor.
         * @param rowMapper the RowMapper which creates an object for each row
         * @param rowsExpected the number of expected rows
         * (just used for optimized collection handling)
         */
        public ZRowMapperResultSetExtractor(RowMapper rowMapper, int rowsExpected,int startIndex, int rowCount) {
            Assert.notNull(rowMapper, "RowMapper is required");
            this.rowMapper = rowMapper;
            this.rowsExpected = rowsExpected;
            this.startIndex=startIndex;
            this.rowCount=rowCount;
        }


		@Override
        public Object extractData(ResultSet rs) throws SQLException {
            List results = (this.rowsExpected > 0 ? new ArrayList(this.rowsExpected) : new ArrayList());
            
            int rowNum=0;
            int resultsAdded=0;
            
            while (rs.next()&&
            		(rowCount < 0 || resultsAdded<rowCount)) {
                //go to startIndex, indexing starts from 0
                if (rowNum<startIndex){
                    rowNum++;
                    continue;
                }
                
                results.add(this.rowMapper.mapRow(rs, rowNum++));
                resultsAdded++;
            }
            return results;
        }

    }
    
    
   
	public class ZRowMapper implements RowMapper {

		private TableValueObjectBase vo;
		private Method[] setMethods;
		private Map columnPropertyMap;
		private Class className;

		/**
		 * Common RowMapper class used with Spring JdbcTemplate
		 * 
		 * @param vo
		 */
		public ZRowMapper(TableValueObjectBase vo) {
			this.vo = vo;
			// ValueObject is not set, cannot parse!
			if (vo == null) {

				throw new NullPointerException();
			}
			// get the ValueObject's class
			className = vo.getClass();

			// Find Class's columnPropertyMap
			// HashMap
			// columnPropertyMap=CommonMethods.getColumnPropertyMap(className,
			// "getColumnPropertyMap")
			columnPropertyMap = vo.getColumnPropertyMap();

			// Find Class's set-methods
			try {
				 setMethods = CommonMethods.getMethodsWithPrefix(className,
						"set");
			} catch (Exception e) {
				throw new IllegalArgumentException(e);
			}
		}

		/**
		 * Calls parserow to construct Object from resultset
		 */
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			try {
				return parseRow(className, columnPropertyMap, rs);
			} catch (Exception e) {
				throw new IllegalArgumentException("parseRow failed", e);
			}
		}
	}

	public class ZGenericRowMapper implements RowMapper {

		private TableValueObjectBase vo;
		private Map columnPropertyMap;


		/**
		 * Common RowMapper class used with Spring JdbcTemplate
		 * 
		 * @param vo
		 */
		public ZGenericRowMapper(TableValueObjectBase vo) {
			this.vo = vo;
			// ValueObject is not set, cannot parse!
			if (vo == null) {
				throw new NullPointerException();
			}
			// Find Class's columnPropertyMap
			// HashMap
			// columnPropertyMap=CommonMethods.getColumnPropertyMap(className,
			// "getColumnPropertyMap")
			columnPropertyMap = vo.getColumnPropertyMap();

		}

		/**
		 * Calls parserow to construct Object from resultset
		 */
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			try {
				return parseRow(columnPropertyMap, rs);
			} catch (Exception e) {
				throw new IllegalArgumentException("parseRow failed", e);
			}
		}
	}

	// ####################################################################################################3


	/**
	 * Generates column list ("FROM >>>...<<< WHERE") for SQL query statements.
	 * This default implementation just comma-concatenates the list of columns.
	 * 
	 * @param columnPropertyMap
	 * @param selectStmt
	 */
	protected void appendColumnList(Map columnPropertyMap,
			StringBuffer selectStmt) {
		boolean firstDone = false;
		for (Object columnName : columnPropertyMap.keySet()) {
			
			if(skipAggreegateColumns((String)columnName)){
				continue ;
			}
			
			if (firstDone) {
				selectStmt.append(",");
			}
			selectStmt.append((String) columnName);
			firstDone = true;
		}
	}

	protected String getPropertyNameForColumn(Map columnPropertyMap,
			String columnName) {
		return (String) columnPropertyMap.get(columnName);
	}

	/**
	 * Parses one row from ResultSet to the given type of an object
	 * 
	 * @param className
	 *            Object's class
	 * @param columnPropertyMap
	 *            Objects column, property pairs
	 * @param rs
	 *            ResultSet
	 * @return Object parsed from resultset
	 * @throws ZebraServiceException
	 */
	protected Object parseRow(Class clazz, Map columnPropertyMap, ResultSet rs) throws ZebraServiceException{
		String methodName = null;
		String propertyName = null;
		String methodParamType = null;
		String columnName = null;
		String columnType = null;
		Object param = null;
		boolean fetchClobAsString;
		// Method[] methods=null;
		int rsIndex = 0;
		Object resultSetValue = null;
		try {

			// Create new instance ...
			Object o = clazz.newInstance();
			// ... and fill it with information
			for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {

				// resultSetValue = rs.getObject(i);
				columnName = rs.getMetaData().getColumnName(i);
				//System.out.println(columnName);
				columnType = rs.getMetaData().getColumnTypeName(i);
				int columnTypes = rs.getMetaData().getColumnType(i);
				
				propertyName = getPropertyNameForColumn(columnPropertyMap,
						columnName);
				
				
				
				if(log.isDebugEnabled()){
					log.debug("resultSetValue="+resultSetValue+", columnName="+columnName+", columnType="+columnType+", columnTypes="+columnTypes);
				}
				
				if (propertyName == null) {
					throw new
					 IllegalArgumentException("Could not find property name for column="+columnName+"in class ="+clazz.getName());			
					 
					
				}


				Method m = MethodsHelper.getMethodByProperty(clazz, "set",
						propertyName);
				//System.out.println(m.getName());
				if (m == null) {
					throw new IllegalArgumentException(
							"Could not get set method for property="
									+ propertyName + ", in class=" + clazz);
				}
				Class setMethodParamtype = m.getParameterTypes()[0];

				param = rs.getObject(i);

				if(log.isDebugEnabled())
					log.debug("rs.getObject(i)="+ (param == null ? "null" : param.getClass().getName()));
				if(param == null ){
					param = rs.getObject(i);
				} else if ((setMethodParamtype.getName().equals(
						java.lang.Integer.class.getName()) || setMethodParamtype
						.getName().equals(int.class.getName()))
						&& param != null
						&& !setMethodParamtype.getName().equals(
								param.getClass().getName())) {
					param = new Integer(rs.getInt(i));
				} else if (setMethodParamtype.getName().equals(
						java.lang.Boolean.class.getName())
						|| setMethodParamtype.getName().equals(
								boolean.class.getName())) {
					param = new Boolean(rs.getBoolean(i));
				} else if (setMethodParamtype.getName().equals(
						java.sql.Timestamp.class.getName())) {
					param = rs.getTimestamp(i);
				} else if (setMethodParamtype.getName().equals(
						java.lang.Long.class.getName())
						|| setMethodParamtype.getName().equals(
								long.class.getName())) {
					param = rs.getLong(i);
				} else if (setMethodParamtype.getName().equals(
						java.lang.Float.class.getName())
						|| setMethodParamtype.getName().equals(
								float.class.getName())) {
					param = rs.getFloat(i);
				} else if (setMethodParamtype.getName().equals(
						java.lang.Short.class.getName())
						|| setMethodParamtype.getName().equals(
								short.class.getName())) {
					param = rs.getShort(i);
				} else if (setMethodParamtype.getName().equals(
						java.lang.Double.class.getName())
						|| setMethodParamtype.getName().equals(
								double.class.getName())) {
					param = rs.getDouble(i);
				} else {// fallback to rs.getObject
					param = rs.getObject(i);

				}
				//System.out.println(param);

				Object[] args = { param };
				if(log.isDebugEnabled()){
					log.debug("Invoking method: "+m.getName()+", type="+setMethodParamtype);
				}
				
				if (args[0] != null) {
					//System.out.println("Test : "+m.getName()+" "+ args[0].getClass());
					m.invoke(o, args);
					
				}
				
			}
			//System.out.println("Test :"+o.toString());
			return o;
		} catch (Throwable t) {
			throw new ZebraServiceException("Parsing failed when parsing for method: "
					+ methodName + " with parametertype: " + methodParamType
					+ ", index of the resultSet was: " + rsIndex
					+ ", the name and type of the column was: " + columnName
					+ "," + columnType + ", value from the result set was: "
					+ param + " " + t);

		}

	}
	
	
	/**
	 * Parses one row from ResultSet to TableValueTypeObjectBase 
	 * @param columnPropertyMap
	 *            Objects column, property pairs
	 * @param rs
	 *            ResultSet
	 * @return Object parsed from resultset
	 * @throws ZebraServiceException
	 */
	protected Object parseRow(Map columnPropertyMap, ResultSet rs) throws ZebraServiceException {

		String columnName = null;
		String columnType = null;
		Object param = null;

		// Create new instance ...
		ZTableValueTypeObjectBase o = new ZTableValueTypeObjectBase();
		try {			
			// ... and fill it with information
			for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {

				// resultSetValue = rs.getObject(i);
				columnName = rs.getMetaData().getColumnName(i);
				
				if(columnPropertyMap.containsKey(columnName)){
					columnType = (String)columnPropertyMap.get(columnName);
				}else{
					 throw new
					 IllegalArgumentException("Could not find property name for column="+columnName+"in class ="+"in columnValueMap of class ="+ "TableValueTypeObjectBase");
				}



				param = rs.getObject(i);
				if(log.isDebugEnabled())
					log.debug("rs.getObject(i)="+ (param == null ? "null" : param.getClass().getName()));

				if (ZTableValueTypeObjectBase.INT.equals(columnType)) {
					param = new Integer(rs.getInt(i));
				} else if (ZTableValueTypeObjectBase.BOOLEAN.equals(columnType)) {
					param = new Boolean(rs.getBoolean(i));
				} else if (ZTableValueTypeObjectBase.TIMESTAMP.equals(columnType)) {
					param = rs.getTimestamp(i);
				} else if (ZTableValueTypeObjectBase.LONG.equals(columnType)) {
					param = rs.getLong(i);
				} else if (ZTableValueTypeObjectBase.FLOAT.equals(columnType)) {
					param = rs.getFloat(i);
				} else if (ZTableValueTypeObjectBase.SHORT.equals(columnType)) {
					param = rs.getShort(i);
				} else if (ZTableValueTypeObjectBase.DOUBLE.equals(columnType)) {
					param = rs.getDouble(i);
				} else if(ZTableValueTypeObjectBase.STRING.equals(columnType)){
					param = rs.getString(i);
				}else {// fallback to rs.getObject
					param = rs.getObject(i);

				}
				o.addColumnValuePair(columnName, param);
				
			}
			o.setColumnPropertyMap(columnPropertyMap);
			if(log.isDebugEnabled()){
				log.debug("TableValueTypeObjectBase Object prepared for table:"+o.getTableName());
			}
			
		} catch (Throwable t) {
			throw new ZebraServiceException("Parsing failed when parsing resultset : "
					+", the name and type of the column was: " + columnName
					+ "," + columnType + ", value from the result set was: "
					+ param + " " + t);
		}

		return o;
	}
	

	// ########################################## CURD OPERATIONS
		

	/**
	 * Generates select statement and object[] array to be used with Spring
	 * Jdbctemplate.
	 * 
	 * @param vo
	 * @return StatementObject holds generated statement and object[] array
	 * @throws ZebraServiceException 
	 * 
	 */
	protected StatementObject generateSelectStmt(TableValueObjectBase vo) throws ZebraServiceException {
		if (vo == null) {
			throw new IllegalArgumentException("Cannot generate select on vo="
					+ vo);
		}

		String tableName = vo.getTableName();

		Map columnPropertyMap = vo.getColumnPropertyMap();
		StringBuffer selectStmt = new StringBuffer("SELECT ");
		StringBuffer fromPart = new StringBuffer(" FROM " + tableName);
		try {
			appendColumnList(columnPropertyMap, selectStmt);
		} catch (Throwable t) {
			throw new ZebraServiceException(t);
		}
		//System.out.println((selectStmt.toString() +fromPart.toString()));
		return new StatementObject(selectStmt.append(fromPart).toString(),
				null, null, vo);
	}

	protected StatementObject generateSelectStmtSystId(TableValueObjectBase vo) throws ZebraServiceException{
		if (vo == null) {
			throw new IllegalArgumentException("Cannot generate select on vo="
					+ vo);
		}

		String tableName = vo.getTableName();

		Map columnPropertyMap = vo.getColumnPropertyMap();
		StringBuffer selectStmt = new StringBuffer("SELECT ");
		StringBuffer fromPart = new StringBuffer(" FROM " + tableName);
		try {
			for (Object columnName : columnPropertyMap.keySet()) {
				if(skipAggreegateColumns((String)columnName)){
					continue ;
				}
				String propertyName = (String) columnPropertyMap
						.get(columnName);
				selectStmt.append(propertyName + ",");
			}
			selectStmt.deleteCharAt(selectStmt.length() - 1);
		} catch (Throwable t) {
			throw new ZebraServiceException(t);
		}
		return new StatementObject(selectStmt.append(fromPart).toString(),
				null, null, vo);
	}
	 /**
     * Generates update statement, object[] array and type[] array to be used with Spring Jdbctemplate.
     * @param vo
     * @return StatementObject holds generated statement and object[] array and type[] array
     * @throws ZebraServiceException
     */
    protected StatementObject generateUpdateStmt(TableValueObjectBase vo) throws ZebraServiceException{
		if (vo == null) {
			throw new IllegalArgumentException("Cannot generate update on vo="
					+ vo);
		}
		if (log.isDebugEnabled())
			log.debug("generateUpdateStmt(ValueObjectBase vo, String tableName)");
		String tableName = vo.getTableName();
		// Method[] methods=vo.getClass().getMethods();
		Map columnPropertyMap = vo.getColumnPropertyMap();
		List objects = new ArrayList();
		List types = new ArrayList();
		StringBuffer updateStmt = new StringBuffer("UPDATE " + tableName
				+ " SET ");

		Class clazz = vo.getClass();
		// String className=clazz.getName();

		try {
			for (Object columnName : columnPropertyMap.keySet()) {
				if(skipAggreegateColumns((String)columnName)){
					continue ;
				}
				String propertyName = (String) columnPropertyMap
						.get(columnName);
				updateStmt.append((String) columnName + "=?,");
				Method m = MethodsHelper.getMethodByProperty(clazz, "get",
						propertyName);
				Object[] args = null;
				Object value = m.invoke(vo, args);
				if (log.isDebugEnabled())
					log.debug("Adding objects, propertyName=" + propertyName
							+ ", value=" + value);
				objects.add(value);
				types.add(SqlTypeValue.TYPE_UNKNOWN);
			}

			updateStmt.deleteCharAt(updateStmt.length() - 1);

			if (log.isDebugEnabled())
				log.debug("updateStmt" + updateStmt + ", objects="
						+ objects.toArray());
		} catch (Throwable t) {
			throw new ZebraServiceException(
					ZebraServiceException.Reason.DB_ERROR, t);
		}
		return new StatementObject(updateStmt.toString(), objects, types, vo);
    }
    
    /**
     * Updates table
     * @param svo
     * @throws ZebraServiceException
     */
    protected int update(TableValueObjectBase svo, String wherePart, List whereObjects) throws ZebraServiceException{
		int rowsUpdated = 0;
		try {
			StatementObject so = generateUpdateStmt(svo);
			List objects = so.getValues();
			objects.addAll(whereObjects);
			rowsUpdated = getJdbcTemplate().update(so.getStmt() + wherePart,
					objects.toArray());
			if (rowsUpdated != 1) {
				throw new ZebraServiceException("SQL Update failed");
			}
		} catch (Throwable t) {
			throw new ZebraServiceException(
					ZebraServiceException.Reason.DB_ERROR, t);
		} finally {
			cleanup();
		}
		return rowsUpdated;
    }

	
	/**
	 * Generates insert statement and object array to be used with Spring Jdbctemplate
	 * @param vo
	 * @return StatementObject
	 * @throws Exception
	 */
	
	protected StatementObject generateInsertStmt(TableValueObjectBase vo)
			throws Exception {
		if (vo == null) {
			throw new IllegalArgumentException("Cannot generate insert on vo=" + vo);
		}
		String tableName = vo.getTableName();
		if(log.isDebugEnabled()){
			log.debug("generateInsertStmt(ValueObjectBase vo, String tableName)");
		}

		// MethodsHelper.getMethodByName(vo.getClass(), propertyName, "get")
		// Method[] methods=vo.getClass().getMethods();
		Map columnPropertyMap = vo.getColumnPropertyMap();
		List objects = new ArrayList();
		List types = new ArrayList();
		StringBuffer insertStmt = new StringBuffer("INSERT INTO " + tableName + " (");
		StringBuffer valuesPart = new StringBuffer(" VALUES (");

		Class clazz = vo.getClass();
		try {
			for (Object columnName : columnPropertyMap.keySet()) {
				if(skipAggreegateColumns((String)columnName)){
					continue ;
				}
				String propertyName = (String) columnPropertyMap
						.get(columnName);
				insertStmt.append((String) columnName + ",");

				if(log.isDebugEnabled()){
					log.debug("MethodsHelper.getMethodByProperty(clazz, get, propertyName)");
				}
				Method m = MethodsHelper.getMethodByProperty(clazz, "get",
						propertyName);
				if (m == null) {
					throw new IllegalArgumentException(
							"Could not get get method for property=" + propertyName + ", in class=" + clazz);
				}

				// log.debug("getMethodByProperty(class), class="+clazz);
				// log.debug("Invoking method="+m.getName());
				// log.debug("Invoking method declaring class="+m.getDeclaringClass());

				if(log.isDebugEnabled()){
					log.debug("Adding objects, propertyName=" + propertyName);
				}
				
				Object[] args = null;

				Object value = m.invoke(vo, args);


				objects.add(value);

				// setup sql types
				valuesPart.append(" ?,");
				if (vo.getPropertySqlTypesMap() != null
						&& vo.getPropertySqlTypesMap().get(propertyName) != null) {
					types.add(vo.getPropertySqlTypesMap().get(propertyName));
				} else {
					types.add(SqlTypeValue.TYPE_UNKNOWN);
				}
			}

			insertStmt.deleteCharAt(insertStmt.length() - 1).append(")");
			valuesPart.deleteCharAt(valuesPart.length() - 1).append(")");

		} catch (Throwable t) {
			throw new ZebraServiceException(this.getClass().getName(), t);
		}
		return new StatementObject(insertStmt.append(valuesPart).toString(),
				objects, types, vo);
	}

	/**
	 * Generates insert statement for given table value object and calls Spring
	 * JdbcTemplate update method to insert row into database
	 * @return Object
	 * @param svo
	 * 
	 */
	protected Object insert(TableValueObjectBase svo) throws Exception {

		Object primaryKey = null;
		try {

			// generate primary key with random number for now

			//primaryKey = Math.random();
			
			//svo.setPrimaryKey(primaryKey);
			primaryKey = svo.getPrimaryKey();
			
			StatementObject so = generateInsertStmt(svo);
			// int rowsUpdated =
			// getJdbcTemplate().update(so.getStmt(),so.getValuesArray(),CommonMethods.toIntArray(so.getTypesArray()));
			int rowsUpdated = getJdbcTemplate().update(
					so.getStmt(),
					new ZebraArgTypePreparedStatementSetter(
							so.getValuesArray(), CommonMethods.toIntArray(so
									.getTypesArray())));
			if (rowsUpdated != 1) {
				throw new Exception("SQL Insert failed");
			}
		} catch (Throwable t) {
			primaryKey = null;
			log.error("Error when inserting instance="+ svo.toString());
//			t.printStackTrace();
			throw new Exception("Exception in database handling", t);
		} finally {
			cleanup();
		}
		return primaryKey;
	}

	protected void cleanup() {

	}
	
	protected boolean skipAggreegateColumns(String columnName){
		if(columnName.startsWith("MAX")
				||columnName.startsWith("MIN")
				||columnName.startsWith("SUM")){
			return true ;
		}
		
		return false;
	}
	
	protected Long getNextSequenceValue(){
		if(this.sequenceName == null ){
			return null ;
		}
		return (Long)getJdbcTemplate().queryForObject(
				"SELECT NEXT VALUE FOR "+this.sequenceName, new Object[] {}, Long.class);
	}
}