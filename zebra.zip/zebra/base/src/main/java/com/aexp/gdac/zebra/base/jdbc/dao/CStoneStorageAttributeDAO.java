package com.aexp.gdac.zebra.base.jdbc.dao;


import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneStorageAttribute;

public class CStoneStorageAttributeDAO  extends SpringDAOBase implements TableDAO{
	private final static Logger log = Logger.getLogger(CStoneStorageAttributeDAO.class);

    public List<CStoneStorageAttribute> getCStoneStorageAttributeByStorageID(Long storage_ID, int startIndex, int rowCount ) throws ZebraServiceException {
        List<CStoneStorageAttribute> ret=null;
        try {
            StatementObject so=generateSelectStmt(new CStoneStorageAttribute());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE storage_ID=? ORDER BY attr_name",
                    new Object[] {storage_ID}, new ZRowMapperResultSetExtractor(new ZRowMapper(new CStoneStorageAttribute()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching CStoneStorageAttribute from DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException {

		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {

		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

}
