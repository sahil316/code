package com.aexp.gdac.zebra.base.jdbc.dao;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class ZebraLogsDAO extends SpringDAOBase implements TableDAO{

	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey)
			throws ZebraServiceException {
		throw new ZebraServiceException("Unsupported Operation ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting Zebra_Logs to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Unsupported Operation ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Unsupported Operation ",ZebraServiceException.Reason.DB_ERROR);
	}

}
