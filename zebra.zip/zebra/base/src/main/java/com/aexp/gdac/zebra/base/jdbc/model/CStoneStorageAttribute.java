package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class CStoneStorageAttribute extends TableValueObjectBase{
	
private static final String tableName = "cstone_storage_attribute";
	
	private long storage_ID ;
	private long attr_id;
	private String attr_name ;
	private String attr_type ;
	private String attr_format; 
	

	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("storage_id", "storage_ID");
		columnPropertyMap.put("attr_id", "attr_id");
		columnPropertyMap.put("attr_name", "attr_name");
		columnPropertyMap.put("attr_type", "attr_type");
		columnPropertyMap.put("attr_format", "attr_format");
	}


	public long getStorage_ID() {
		return storage_ID;
	}


	public void setStorage_ID(long storage_ID) {
		this.storage_ID = storage_ID;
	}


	public long getAttr_id() {
		return attr_id;
	}


	public void setAttr_id(long attr_id) {
		this.attr_id = attr_id;
	}


	public String getAttr_name() {
		return attr_name;
	}


	public void setAttr_name(String attr_name) {
		this.attr_name = attr_name;
	}


	public String getAttr_type() {
		return attr_type;
	}


	public void setAttr_type(String attr_type) {
		this.attr_type = attr_type;
	}


	public String getAttr_format() {
		return attr_format;
	}


	public void setAttr_format(String attr_format) {
		this.attr_format = attr_format;
	}


	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return this.columnPropertyMap;
	}


	@Override
	public void setPrimaryKey(Object obj) {
		this.attr_id = (Long)obj;
		
	}


	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.attr_id;
	}


	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}
	

}
