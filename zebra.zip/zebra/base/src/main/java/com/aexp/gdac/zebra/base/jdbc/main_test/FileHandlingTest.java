package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.io.File;
import java.io.FilenameFilter;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;

public class FileHandlingTest {
	
	private static String filePattern  = "columnstats";
	public static void main(String args[]) throws ZebraServiceException{
		/*File dir = new File("C:\\AATRI\\Workspace\\Zebra\\ZebraCombinedProj_v3\\test-resources");
		
		File [] files = dir.listFiles(new FilenameFilter() {
		    @Override
		    public boolean accept(File dir, String name) {
		        return name.startsWith(filePattern);
		    }
		});

		for (File statsFile : files) {
		    System.out.println(statsFile);
		}
		*/
		
		StatsDAO statsDAO = (StatsDAO) ZebraResourceManager.getBean("statsDAO");
		Stats stats = new Stats();
		stats.setFeedID(1L);
		stats.setStateID(1L);
		stats.setAction(null);
		//System.out.println(statsDAO.updateStatsAction(stats));
		
		ColumnRuleStatsDAO columnRuleStatsDAO = (ColumnRuleStatsDAO) ZebraResourceManager.getBean("columnRuleStatsDAO");
		System.out.println(columnRuleStatsDAO.getColumnRuleStatsPastRuns(1L, 4L, 1L, 0, 30));
	}
}
