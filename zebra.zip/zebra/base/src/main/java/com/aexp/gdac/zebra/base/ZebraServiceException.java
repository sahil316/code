package com.aexp.gdac.zebra.base;




public class ZebraServiceException extends Exception {
	private Reason reason;
	
	public ZebraServiceException(){
		super();
		this.reason = Reason.UNEXPECTED_EXCEPTION;
	}
	
	public ZebraServiceException(String message){
		super(message);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraServiceException(Reason reason){
		this.reason = reason;
	}
	
	public ZebraServiceException(String message ,Reason reason){
		super(message);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraServiceException(String message , Throwable cause){
		super(message,cause);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
	}
	
	public ZebraServiceException(Throwable cause){
		super(cause);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
	}
	
	public ZebraServiceException(Reason reason,Throwable cause){
		super(cause);
		this.reason = reason ;
	}
	
	public ZebraServiceException(String message ,Reason reason,Throwable cause){
		super(message,cause);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public void setReason(Reason reason){
		this.reason = reason;
	}
	
	public Reason getReason(){
		return this.reason;
	}
	
	@Override
	public String toString() {
		return "ZebraServiceException [reason=" + reason + " desc:"+reason.getReasonDesc()+"]";
	}
	
	
	public enum Reason{
		Other(""),
		DB_ERROR("Exception Occured while Accessing DB "),
		MD_FILE_EXCEPTION("Exception Occured while reading MD file"),
		MD_MISSING_MANDATORY_FIELDS("Mandatory fields not present"),
		MD_FEED_LEVEL_METADATA_NOT_FOUND("Missing feed level metadata"),
		MD_COLUMN_LEVEL_CHECK_FAILED("MD Column Level Check failed"),
		MD_FEED_LEVEL_CHECK_FAILED("MD Feed Level Check failed"),
		UNEXPECTED_EXCEPTION("Unexpected exception occured");
		
		private String reasonDesc ;
		
		private Reason(){
		}
		
		private Reason(String desc){
			reasonDesc = desc ;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}
		
	}
	
}
