package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class ColumnRuleStats extends TableValueObjectBase implements Comparable<ColumnRuleStats>{
	
	private static final String tableName = "ColumnRuleStats";
	
	private long feedID;
	private long columnID;
	private long ruleID;
	private long columnRuleID;
	private long decisionCount;
	private double decisionRate;
	private Double minAlertThresholdVal;
	private Double minAbortThresholdVal;
	private Double maxAlertThresholdVal;
	private Double maxAbortThresholdVal;
	private String action ;
	private long stateID ;
	private double mean ;
	private double stdDev  ;
	/** result of the command */
	private Object value ;
	
	/** carry forward from MD  */
	private String thresholdType;	
	private Double minAlertThreshold;
	private Double minAbortThreshold;
	private Double maxAlertThreshold;
	private Double maxAbortThreshold;
	private Integer pastRuns;
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("ColumnID", "columnID");
		columnPropertyMap.put("RuleID", "ruleID");
		columnPropertyMap.put("ColumnRuleID", "columnRuleID");
		columnPropertyMap.put("DecisionCount", "decisionCount");
		columnPropertyMap.put("DecisionRate", "decisionRate");
		columnPropertyMap.put("MinAlertThresholdVal", "minAlertThresholdVal");
		columnPropertyMap.put("MinAbortThresholdVal", "minAbortThresholdVal");
		columnPropertyMap.put("MaxAlertThresholdVal", "maxAlertThresholdVal");
		columnPropertyMap.put("MaxAbortThresholdVal", "maxAbortThresholdVal");
		columnPropertyMap.put("Action", "action");
		columnPropertyMap.put("StateID", "stateID");
		columnPropertyMap.put("Mean", "mean");
		columnPropertyMap.put("StdDev", "stdDev");		
	}
	
	public long getFeedID() {
		return feedID;
	}
	public void setFeedID(long feedID) {
		this.feedID = feedID;
	}
	public long getColumnID() {
		return columnID;
	}
	public void setColumnID(long columnID) {
		this.columnID = columnID;
	}
	public long getRuleID() {
		return ruleID;
	}
	public void setRuleID(long ruleID) {
		this.ruleID = ruleID;
	}
	public long getColumnRuleID() {
		return columnRuleID;
	}
	public void setColumnRuleID(long columnRuleID) {
		this.columnRuleID = columnRuleID;
	}
	public long getDecisionCount() {
		return decisionCount;
	}
	public void setDecisionCount(long decisionCount) {
		this.decisionCount = decisionCount;
	}
	public double getDecisionRate() {
		return decisionRate;
	}
	public void setDecisionRate(double decisionRate) {
		this.decisionRate = decisionRate;
	}
	public static void setColumnPropertyMap(
			HashMap<String, String> columnPropertyMap) {
		ColumnRuleStats.columnPropertyMap = columnPropertyMap;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	
	
	public Double getMinAlertThresholdVal() {
		return minAlertThresholdVal;
	}
	public void setMinAlertThresholdVal(Double minAlertThresholdVal) {
		this.minAlertThresholdVal = minAlertThresholdVal;
	}
	public Double getMinAbortThresholdVal() {
		return minAbortThresholdVal;
	}
	public void setMinAbortThresholdVal(Double minAbortThresholdVal) {
		this.minAbortThresholdVal = minAbortThresholdVal;
	}
	public Double getMaxAlertThresholdVal() {
		return maxAlertThresholdVal;
	}
	public void setMaxAlertThresholdVal(Double maxAlertThresholdVal) {
		this.maxAlertThresholdVal = maxAlertThresholdVal;
	}
	public Double getMaxAbortThresholdVal() {
		return maxAbortThresholdVal;
	}
	public void setMaxAbortThresholdVal(Double maxAbortThresholdVal) {
		this.maxAbortThresholdVal = maxAbortThresholdVal;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public long getStateID() {
		return stateID;
	}
	public void setStateID(long stateID) {
		this.stateID = stateID;
	}
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}

	public double getStdDev() {
		return stdDev;
	}
	public void setStdDev(double stdDev) {
		this.stdDev = stdDev;
	}
	
	public String getThresholdType() {
		return thresholdType;
	}
	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}
	
	public Double getMinAlertThreshold() {
		return minAlertThreshold;
	}
	public void setMinAlertThreshold(Double minAlertThreshold) {
		this.minAlertThreshold = minAlertThreshold;
	}
	public Double getMinAbortThreshold() {
		return minAbortThreshold;
	}
	public void setMinAbortThreshold(Double minAbortThreshold) {
		this.minAbortThreshold = minAbortThreshold;
	}
	public Double getMaxAlertThreshold() {
		return maxAlertThreshold;
	}
	public void setMaxAlertThreshold(Double maxAlertThreshold) {
		this.maxAlertThreshold = maxAlertThreshold;
	}
	public Double getMaxAbortThreshold() {
		return maxAbortThreshold;
	}
	public void setMaxAbortThreshold(Double maxAbortThreshold) {
		this.maxAbortThreshold = maxAbortThreshold;
	}
	public Integer getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(Integer pastRuns) {
		this.pastRuns = pastRuns;
	}
	
	public void updateDistinctValueCount(Long count){
		if(this.value == null){
			this.value = new Long(0);
		}
		Long updatedCount = Long.parseLong(this.value.toString()) + count ;
		this.value = updatedCount; 
	}
	/**
	 * WARNINNG: toString() must not be modified . 
	 * This is called while generating stats in Mapreduce Job.
	 * 
	 * */
	@Override
	public String toString() {
		return  feedID + "|"
				+ columnID + "|" 
				+ ruleID + "|"
				+ columnRuleID + "|" 
				+ decisionCount + "|" 
				+ decisionRate + "|" 
				+ minAlertThresholdVal + "|" 
				+ minAbortThresholdVal + "|" 
				+ maxAlertThresholdVal+ "|"
				+ maxAbortThresholdVal+ "|" 
				+ action + "|" 
				+ stateID + "|" 
				+ mean + "|" 
				+ stdDev + "|" 
				+ value  + "|" 
				+ thresholdType  + "|"    //carry forward fields
				+ minAlertThreshold + "|" 
				+ minAbortThreshold + "|" 
				+ maxAlertThreshold + "|" 
				+ maxAbortThreshold + "|" 
				+ pastRuns;
	}
	
	
	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}
	@Override
	public void setPrimaryKey(Object obj) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return tableName;
	}
	@Override
	public int compareTo(ColumnRuleStats o) {
		if(o == null){
			return 1;
		}
		if(this.stateID < o.getStateID()){
			return -1;
		}else if(this.stateID > o.getStateID()){
			return 1  ;
		}
		
		return 0;
	}

}
