package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.util.List;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;




public interface TableObjectDAO {
	//Create
	public void save(TableValueObjectBase employee);
	//Read
	public TableValueObjectBase getById(int id);
	//Update
	public void update(TableValueObjectBase employee);
	//Delete
	public void deleteById(int id);
	//Get All
	public List<TableValueObjectBase> getAll();
}
