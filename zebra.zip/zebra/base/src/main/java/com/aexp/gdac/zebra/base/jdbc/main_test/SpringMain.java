package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aexp.gdac.zebra.base.jdbc.dao.FeedStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ZTableColumnValueDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStatsOld;
import com.aexp.gdac.zebra.base.jdbc.model.ZTableValueTypeObjectBase;


public class SpringMain {

	public static void main(String[] args) throws Exception{
		//Get the Spring Context
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		
		
		//TableObjectDAO feedStatsDAO = ctx.getBean("feedStatsDAOExample", TableObjectDAO.class);
		FeedStatsDAO feedStatsDAO = ctx.getBean("feedStatsDAO", FeedStatsDAO.class);
		
		ZTableColumnValueDAO feedStatsGenericDAO = ctx.getBean("feedStatsGenericDAO", ZTableColumnValueDAO.class);

		//System.out.println(((TableValueTypeObjectBase)feedStatsGenericDAO.getObjectByPrimaryKey(166)).toString());
		//Run some tests for JDBC CRUD operations
		
		//feedStatsCURDCalls(feedStatsDAO);
		
	//	System.out.println(((FeedStats)feedStatsDAO.getObjectByPrimaryKey(166)).toString());
		//feedStatsDAO.create(createFeedStatsObject());
		
		//List<TableValueObjectBase> feedStatsList = feedStatsGenericDAO.getObjectListByColumnValue("FeedName", "FeedName_Zebra", 0, -1);

		List<TableValueObjectBase> feedStatsList = feedStatsGenericDAO.getObjectListByColumnValue();
		
		for(TableValueObjectBase tableObj:feedStatsList){
		System.out.println(tableObj);
		}
		
		
		
		//Close Spring Context
		ctx.close();
		
		System.out.println("DONE");
	}

	
	private static void feedStatsCURDCalls(TableObjectDAO feedStatsDAO){
		FeedStatsOld feedStats = createFeedStatsObject();
		//Create
		feedStatsDAO.save(feedStats);
		
		
		
		//Read
		//FeedStats feedStats1 = (FeedStats) feedStatsDAO.getById(166);
		//System.out.println("FeedStat Retirved Retrieved::"+feedStats1);
		
		//Update
		//feedStats1.setFeedName(feedStats1.getFeedName()+"_update");
		//feedStatsDAO.update(feedStats1);
		
		
		
		
		
		//Delete
		//feedStatsDAO.deleteById(629);
		
		
		
		//Get All
		List<TableValueObjectBase> feedStatsList = feedStatsDAO.getAll();
		for(TableValueObjectBase tableObj:feedStatsList){
		System.out.println(tableObj);
		}
	}
	
	
	private static FeedStatsOld createFeedStatsObject(){
		FeedStatsOld feedStats = new FeedStatsOld();
		int rand = new Random().nextInt(1000);
		feedStats.setId(rand);
		feedStats.setFeedName("FeedName_"+"Zebra"); 
		feedStats.setFeedKey(rand*100); 
		feedStats.setFileName("FileName_"+rand); 
		feedStats.setRunDate(new Date()); 
		feedStats.setVolume(rand * 1000);
		feedStats.setRunNumber(rand % 100); 
		feedStats.setMean(rand*100.0); 
		feedStats.setFormat("Format_"+rand) ; 
		feedStats.setMinVal(rand*0.50) ; 
		feedStats.setMaxVal(rand*1000.0); 
		feedStats.setAction("Alert");
		System.out.println("Feed Stats Object:"+feedStats);
		return feedStats;
	}
	

}
