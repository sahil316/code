package com.aexp.gdac.zebra.base;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class CommonMethods {

	public static boolean isNullTextValue(String nullText){
		if(nullText == null 
				|| nullText.trim().equalsIgnoreCase("NULL")){

			return true ;
		}
		
		return false ;
		
	}
	
	public static String formatDouble2Decimals(Double val) {
		if(val == null){
			return null;
		}
		
		try{
			DecimalFormat df2 = new DecimalFormat("#.###");
        	return BigDecimal.valueOf(Double.valueOf(df2.format(val))).toPlainString();
		}catch(NumberFormatException e){
			return val.toString();
		}
	}
	
	
	public static String formatDouble2Decimals(String val) {
		if(val == null){
			return null;
		}
		
		if(!val.contains(".")){
			return val ;
		}
		
		try{
			DecimalFormat df2 = new DecimalFormat("#.###");
        	return BigDecimal.valueOf(Double.valueOf(df2.format(new Double(val)))).toPlainString();
		}catch(NumberFormatException e){
			return val.toString();
		}
	}
	
	
	public static double calPercentage(double failValue, long recordCount){
		return Double.parseDouble(formatDouble2Decimals(failValue/100*recordCount));
		
	}
	
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    long d =(long) Double.parseDouble(str);  
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	}

	public static double calMean(double[] values ){
		
		double sum = 0;
		for(int i=0 ; i< values.length ; i++ ){
			sum = sum+ (double)values[i] ;
		}
		return sum/values.length;
	}
	
	public static double calStandatdDev(double[] values){
		
		double mean = calMean(values);
		double squareSum = 0; 
       
		for (int i = 0; i < values.length; i++) { 
			squareSum += Math.pow(values[i] - mean, 2); 
		}
		
		return Math.sqrt((squareSum) / (values.length - 1)); 
	}
	
	public static Double formatNaN(String str){
		
		if(null == str) {
			return null;
		}
		
		if(str != null && str.equalsIgnoreCase("NaN")) {	
			return 0.0;
		}
		return Double.parseDouble(str);
	}
	
	public static int getHours(int seconds){
		return seconds/3600 ;
	}
	
	public static int getMinutes(int seconds){
		return (seconds % 3600) / 60 ;
	}

	public static String converToTime(int time){
		if(time == 0){
			return null ;
		}
		String hrs = ""+getHours(time) ;
		if(hrs.length() == 1){
			hrs = "0"+hrs;
		}
		String mins = ""+getMinutes(time);
		
		if(mins.length() == 1){
			mins = "0"+mins;
		}
	
		return hrs+":"+mins;
	}
	
	public static Integer convertTimeToInt(String time){
		if(time!=null && !time.isEmpty()){
			
			String args[] = time.split(":");
			int hourInSec = Integer.parseInt(args[0]) * 3600 ;
			int minInSec = Integer.parseInt(args[1]) * 60 ;
			
			return (hourInSec + minInSec) ;
		}
		return null;
		
	}
	
	public static String exceptionStackTrace(Throwable t){
		if(t == null ){
			return "" ;
		}
		String stackTrace = t.getMessage();
		
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		t.printStackTrace(new PrintStream(outStream));
		
		stackTrace = outStream.toString() ;

		return stackTrace ;
	}
}
