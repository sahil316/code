package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.Date;
import java.util.HashMap;





import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class FeedStatsOld extends TableValueObjectBase{
	
	private static final String tableName = "tbl_FeedStats";
	
	private int id ;
	private String feedName;
	private long feedKey;
	private String fileName;
	private Date runDate;
	private long volume;
	private int runNumber ;
	private double mean;
	private double stdDev;
	private String format;
	private double minVal;
	private double maxVal;
	private String action;
	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("ID", "id");
		columnPropertyMap.put("FeedName", "feedName");
		columnPropertyMap.put("FeedKey", "feedKey");
		columnPropertyMap.put("FileName", "fileName");
		columnPropertyMap.put("runDate", "runDate");
		columnPropertyMap.put("Volume", "volume");
		columnPropertyMap.put("runNumber", "runNumber");
		columnPropertyMap.put("Mean", "mean");
		columnPropertyMap.put("StdDev", "stdDev");
		columnPropertyMap.put("Format", "format");
		columnPropertyMap.put("Min_Val", "minVal");
		columnPropertyMap.put("Max_Val", "maxVal");
		columnPropertyMap.put("Action", "action");

	}
	//@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return this.tableName;
	}
	@Override
	public HashMap<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}
	@Override
	public void setPrimaryKey(Object obj) {
		this.id = (Integer)obj;
		
	}
	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return new Integer(this.id);
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public long getFeedKey() {
		return feedKey;
	}
	public void setFeedKey(long feedKey) {
		this.feedKey = feedKey;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public long getVolume() {
		return volume;
	}
	public void setVolume(long volume) {
		this.volume = volume;
	}
	public int getRunNumber() {
		return runNumber;
	}
	public void setRunNumber(int runNumber) {
		this.runNumber = runNumber;
	}
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}
	public double getStdDev() {
		return stdDev;
	}
	public void setStdDev(double stdDev) {
		this.stdDev = stdDev;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public double getMinVal() {
		return minVal;
	}
	public void setMinVal(double minVal) {
		this.minVal = minVal;
	}
	public double getMaxVal() {
		return maxVal;
	}
	public void setMaxVal(double maxVal) {
		this.maxVal = maxVal;
	}

	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	@Override
	public String toString() {
		return "FeedStats [id=" + id + ", feedName=" + feedName + ", runDate="
				+ runDate + "]";
	}		
}
