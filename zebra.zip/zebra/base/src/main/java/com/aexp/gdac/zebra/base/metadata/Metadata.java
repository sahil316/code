package com.aexp.gdac.zebra.base.metadata;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraServiceException;

public class Metadata {

	private List<MetadataRow> metadataRowList = new ArrayList<MetadataRow>();
	private Set<Long> columnLevelBookMark = new HashSet<Long>();
	private Set<Long> columnRuleLevelBookMark = new HashSet<Long>();
	
	
	public void addMetadatRow(MetadataRow metadataRow){
		metadataRowList.add(metadataRow);
	}
	
	public void setMetadataList(List<MetadataRow> metadataRowList){
		this.metadataRowList = metadataRowList;
	}
	
	public List<MetadataRow> getMetadataRowList(){
		sortMetadatRows();
		return metadataRowList;
	}
	
	/* sorting metadata row **/
	
	public void sortMetadatRows(){
		if(this.metadataRowList != null){
			Collections.sort(this.metadataRowList);
		}
	}
	/**
	 * Feed Level Metadata row is returned
	 * @return
	 * @throws ZebraServiceException
	 */
	public MetadataRow getFeedLevelMetadata(){
		for(MetadataRow row : metadataRowList){
			if(row.getLevel() == Level.FEED_LEVEL){
				return row;
			}
		}
		
		return null;
	}
		

	/**
	 * Returns list of COLUMN MD for complete column
	 * @return
	 */
	
	public MetadataRow getNextColumnMetadata(){
	
		MetadataRow nextColumnMD = null;
		
		Long nextColumnId = null;
		
		for(MetadataRow row : metadataRowList){
			if(row.getLevel() != Level.COLUMN_LEVEL){
				continue ;
			}else if(columnLevelBookMark.contains(row.getColumnId())){
				continue ;
			}
			
			nextColumnMD = row ;
			nextColumnId = row.getColumnId();
			break;
		
		}
		
		columnLevelBookMark.add(nextColumnId);
		
		return nextColumnMD;
	}

	/**
	 * Returns list of COLUMN RULE MD data for complete column
	 * @return
	 */
	public List<MetadataRow> getNextColumnRuleMetadata(){
		List<MetadataRow> nextColumnRuleMDList = new ArrayList<MetadataRow>();
		
		Long nextColumnId = null;
		
		for(MetadataRow row : metadataRowList){
			if(row.getLevel() != Level.COLUMN_RULE_LEVEL){
				continue ;
			}else if(columnRuleLevelBookMark.contains(row.getColumnId())){
				continue ;
			}

			if(nextColumnId == null && row.getColumnId() > 0){
				nextColumnId = row.getColumnId();
				
			}
			
			if(row.getColumnId() == nextColumnId){
				nextColumnRuleMDList.add(row);
			}
		
		}
		columnRuleLevelBookMark.add(nextColumnId);
		
		return nextColumnRuleMDList;
	}


	public MetadataRow getColumnRuleLevelMetadata(long columnId, long ruleId ,long colummRuleId){
		MetadataRow retRow = null;
		for(MetadataRow mdRow :metadataRowList){
			if(mdRow.getLevel() == Level.COLUMN_RULE_LEVEL){
				if(mdRow.getColumnId() == columnId
						&& mdRow.getColumnRuleId() == colummRuleId
						&& mdRow.getRuleId() == ruleId){
					retRow = mdRow ;
					break ;
				}
			}
		}
		
		return retRow;
	}
	
	public MetadataRow getColumnLevelMetadata(long columnId){
		MetadataRow retRow = null;
		for(MetadataRow mdRow :metadataRowList){
			if(mdRow.getLevel() == Level.COLUMN_LEVEL){
				if(mdRow.getColumnId() == columnId){
					retRow = mdRow ;
					break ;
				}
			}
		}
		
		return retRow;
	}
	
	
	/**
	 * Reset bookmarks . This must be done when you want to begin iteration again .
	 * @param level
	 */
	public void resetBookMarks(Level level){
		if(level == Level.COLUMN_LEVEL){
			this.columnLevelBookMark.clear();
		}else if(level == Level.COLUMN_RULE_LEVEL){
			this.columnRuleLevelBookMark.clear();
		}else if(level == Level.COLUMN_COMPLEX_RULE_LEVEL){
			this.columnLevelBookMark.clear();
		}else{
			this.columnLevelBookMark.clear();
			this.columnRuleLevelBookMark.clear();
		}
	}
	

	
	@Override
	public String toString() {
		return "Metadata [metadataRowList=" + metadataRowList + "]";
	}

	

}
