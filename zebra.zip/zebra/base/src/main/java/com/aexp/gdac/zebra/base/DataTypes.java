package com.aexp.gdac.zebra.base;


public class DataTypes {
	/* supported data type checks */
	public static final String INT ="int";
	public static final String DOUBLE = "double" ;
	public static final String STRING = "string";
	public static final String BIGINT = "bigint";
	public static final String DECIMAL = "decimal";
	public static final String DATETIME = "datetime";
	public static final String DATE = "date";
	public static final String VARCHAR = "varchar";
	public static final String CHAR = "char";
	public static final String INTEGER = "integer";
	public static final String SMALLINT = "smallint";
	public static final String TINYINT = "tinyint";
	

	
	
	public static final char startBraceChar ='(';
	public static final char endBraceChar =')';
	public static final String splitChar = ",";
	public static final String precisionChar = ".";
	
	
	
	public static int calculateDataLength(String dataType, String dataFormat) throws ZebraServiceException{
		
		try{
			if(dataType.contains(VARCHAR) || dataType.contains(STRING)){
				int startIndex = dataType.indexOf(startBraceChar);
				int endIndex = dataType.indexOf(endBraceChar);
				return Integer.parseInt(dataType.substring(startIndex+1,endIndex));
			}else if(dataType.equalsIgnoreCase(CHAR)){
				return 1;
			}else if(dataType.trim().equalsIgnoreCase(BIGINT)){
				return 20;
			}else if(dataType.trim().equalsIgnoreCase(INT) ||
					dataType.trim().equalsIgnoreCase(INTEGER)){
				return 11;
			}else if(dataType.trim().equalsIgnoreCase(SMALLINT)){
				return 6;
			}else if(dataType.trim().equalsIgnoreCase(TINYINT)){
				return 4;
			}else if(dataType.trim().equalsIgnoreCase(DATETIME) ||
					dataType.trim().equalsIgnoreCase(DATE)){
				return dataFormat.trim().length();
			}else if(dataType.trim().contains(DOUBLE) || dataType.trim().contains(DECIMAL)){
				int startIndex = dataType.indexOf(startBraceChar);
				int endIndex = dataType.indexOf(endBraceChar);
				String range = dataType.substring(startIndex+1,endIndex);
				String[] rangeArr=	range.split(splitChar);
				if(rangeArr.length > 1){
					if(Integer.parseInt(rangeArr[1]) == 0){
						return Integer.parseInt(rangeArr[0])+Integer.parseInt(rangeArr[1]);
					} else{
						return Integer.parseInt(rangeArr[0])+Integer.parseInt(rangeArr[1]) +1;
						
					}
				}else{
					return Integer.parseInt(range);
				}			
				
			}else{
				throw new ZebraServiceException("DataType Check : DataType["+dataType+"] not recognized ",ZebraServiceException.Reason.Other);
			}
		}catch(Exception e){
			throw new ZebraServiceException("DataType Check : DataType["+dataType+"] syntax error ",ZebraServiceException.Reason.Other);
		}

	}
	
	public static int calculatePrecision(String dataType){
		
		if(dataType.contains(DECIMAL) || dataType.contains(DOUBLE)){
			int startIndex = dataType.indexOf(startBraceChar);
			int endIndex = dataType.indexOf(endBraceChar);
			String range = dataType.substring(startIndex+1,endIndex);
			String[] rangeArr=	range.split(splitChar);
			if(rangeArr.length > 1){
					return Integer.parseInt(rangeArr[1]);
			}	
		}
		
		return 0;
	}
}
