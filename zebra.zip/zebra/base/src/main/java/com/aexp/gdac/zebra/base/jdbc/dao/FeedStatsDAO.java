package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.List;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;

public class FeedStatsDAO extends SpringDAOBase implements TableDAO {

	public FeedStatsDAO() {

	}

	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primaryKey) throws ZebraServiceException {
		FeedStats ret = null;
		try {
			StatementObject so = generateSelectStmt(new FeedStats());
			ret = (FeedStats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=?",
					new Object[] { primaryKey },
					new ZRowMapper(new FeedStats()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching FeedStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}


	
	public TableValueObjectBase getObjectByFeedIdAndStateID(long feedID, long stateID) throws ZebraServiceException {
		FeedStats ret = null;
		try {
			StatementObject so = generateSelectStmt(new FeedStats());
			ret = (FeedStats) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE FeedID=? AND StateID=?",
					new Object[] { feedID , stateID},
					new ZRowMapper(new FeedStats()));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching FeedStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
    public List getFeedStatsByFeedName(String feedName, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new FeedStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedName=?",
                    new Object[] {feedName }, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedStats()),startIndex,rowCount));
        } catch (Throwable t) {
            
        }
        
        return ret;
        
    }

    public List getFeedStatsPastRuns(Long feedID , int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new FeedStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? ORDER BY StateID DESC",
                    new Object[] {feedID}, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
    public List getFeedStatsPassedPastRuns(Long feedID , int startIndex, int rowCount ) throws ZebraServiceException {
        List ret=null;
        try {
            StatementObject so=generateSelectStmt(new FeedStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? AND Action='PASS' ORDER BY StateID DESC",
                    new Object[] {feedID}, new ZRowMapperResultSetExtractor(new ZRowMapper(new FeedStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {

		Object obj = null;;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting FeedStat to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);

	}

}
