package com.aexp.gdac.zebra.base.jdbc.dao.core;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * ValueObjectBase class extended by DAO value object 
 */
public abstract class TableValueObjectBase implements Serializable {
	/**
	 * Abstract method implemented in DAO value object class
	 * 
	 * @return HashMap containing column property pairs
	 */
	public abstract Map<String, String> getColumnPropertyMap();

	public abstract void setPrimaryKey(Object obj);

	public abstract Object getPrimaryKey();

	public abstract String getTableName();

	/**
	 * Returns sql types for column property map. Override this in implementing
	 * table value object class, however this is optional and required only for
	 * valueobjects/tables containing CLOB/BLOB columns
	 * 
	 * @return
	 */
	public HashMap getPropertySqlTypesMap() {
		return null;

	}

	public String getColumnNameByProperty(String propertyName) {
		HashMap map = (HashMap) getColumnPropertyMap();
		if (map == null) {
			return null;
		}
		Set keySet = map.keySet();
		for (Object key : keySet) {
			String propertyInMap = (String) map.get(key);
			if (propertyInMap.equals(propertyName)) {
				return (String) key;
			}

		}
		return null;
	}

	public String getStatisticsName() {
		return getTableName();
	}
}
