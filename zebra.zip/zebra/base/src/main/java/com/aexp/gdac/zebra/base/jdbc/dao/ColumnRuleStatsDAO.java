package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.ArrayList;
import java.util.List;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;


public class ColumnRuleStatsDAO extends SpringDAOBase implements TableDAO {

    public List getColumnRuleStatsByColumnID(Long columnID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE ColumnID=?",
                    new Object[] {columnID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;        
    }
    
    public List getColumnRuleStatsByColumnIDAndStateID(Long columnID,Long feedID,Long stateID) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE ColumnID=? AND FeedID=? AND StateID=?",
                    new Object[] {columnID ,feedID , stateID}, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleStats()),0,-1));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;        
    }
	
    public List getColumnRuleStatsByRuleID(Long ruleID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE RuleID=?",
                    new Object[] {ruleID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
    public List getColumnRuleStatsPastRuns(Long feedID ,Long columnID ,Long ruleID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? AND ColumnID=? AND RuleID=? ORDER BY StateID DESC",
                    new Object[] {feedID,columnID,ruleID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
    public List getColumnRuleStatsPassedPastRuns(Long feedID ,Long columnID ,Long ruleID, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleStats());
            
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID =? AND ColumnID=? AND RuleID=? AND Action='PASS' ORDER BY StateID DESC ",
                    new Object[] {feedID,columnID,ruleID }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleStats()),startIndex,rowCount));
            
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;      
    }
    
    public List getColumnRuleStatsByFeedID(Long feedId, int startIndex, int rowCount ) throws ZebraServiceException {
        List ret= new ArrayList();
        try {
            StatementObject so=generateSelectStmt(new ColumnRuleStats());
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE FeedID=?",
                    new Object[] {feedId }, new ZRowMapperResultSetExtractor(new ZRowMapper(new ColumnRuleStats()),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching ColumnRuleStats form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
    }
    
	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		Object obj = null;;
		try {
			obj = this.insert(svo);
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while inserting ColumnStats to DB ",ZebraServiceException.Reason.DB_ERROR,t);
		} finally {
			cleanup();
		}
		return obj;
	}
	
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey)
			throws ZebraServiceException {
		
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}


	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	
	}

}
