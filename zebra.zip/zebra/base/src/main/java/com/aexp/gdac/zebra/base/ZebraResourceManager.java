package com.aexp.gdac.zebra.base;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aexp.gdac.zebra.base.jdbc.dao.ZTableColumnValueDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ZTableValueTypeObjectBase;
import com.aexp.gdac.zebra.base.metadata.MetadataParser;

/*
 *  Gets Spring configured bean object .
 */

public class ZebraResourceManager {
	private static ClassPathXmlApplicationContext ctx ;
	
	static{
		createSpringContext();
	}
	
	private static void createSpringContext(){
		if(ctx == null){
			ctx =  new ClassPathXmlApplicationContext("spring-config.xml");
		}
	}
	
	public static ZTableValueTypeObjectBase getZTableValueTypeObjectBean(String beanName){
		 return ctx.getBean(beanName, ZTableValueTypeObjectBase.class);
	}
	
	public static Object getBean(String beanName){
		return ctx.getBean(beanName);
	}
	
	public static ZTableColumnValueDAO getZTableColumnValueDAO(String beanName){
		return ctx.getBean(beanName,ZTableColumnValueDAO.class);
	}
	
	public static MetadataParser getMetadataParser(){
		return ctx.getBean("metadataParser",MetadataParser.class);
	}
	
	
}
