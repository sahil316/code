package com.aexp.gdac.zebra.base.jdbc.model;


import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;

public class ColumnMetadata extends TableValueObjectBase{
	
	private static final String tableName = "ColumnMetadata";
	
	private Long feedID ;
	private String feedName;
	private Long columnID ;
	private String columnName ;
	private String dataType ;
	private String dataFormat ;
	private Timestamp startDate ;
	private Timestamp endDate ;
	private String userID ;

	
	public static HashMap<String,String> columnPropertyMap = new HashMap<String,String>();
	
	
	static {
		columnPropertyMap.put("FeedID", "feedID");
		columnPropertyMap.put("FeedName", "feedName");
		columnPropertyMap.put("ColumnID", "columnID");
		columnPropertyMap.put("ColumnName", "columnName");
		columnPropertyMap.put("DataType", "dataType");
		columnPropertyMap.put("DataFormat", "dataFormat");
		columnPropertyMap.put("StartDate", "startDate");
		columnPropertyMap.put("EndDate", "endDate");
		columnPropertyMap.put("UserID", "userID");
	}
	
	
	public Long getFeedID() {
		return feedID;
	}

	public void setFeedID(Long feedID) {
		this.feedID = feedID;
	}

	public String getFeedName() {
		return feedName;
	}

	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}

	public Long getColumnID() {
		return columnID;
	}

	public void setColumnID(Long columnID) {
		this.columnID = columnID;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDataFormat() {
		return dataFormat;
	}

	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}

	public Timestamp getStartDate() {
		return startDate;
	}

	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	@Override
	public Map<String, String> getColumnPropertyMap() {
		// TODO Auto-generated method stub
		return columnPropertyMap;
	}

	@Override
	public void setPrimaryKey(Object obj) {
		this.columnID = (Long)obj;
		
	}

	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return this.columnID;
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return tableName;
	}

	@Override
	public String toString() {
		return "ColumnMetadata [feedID=" + feedID + ", feedName=" + feedName
				+ ", columnID=" + columnID + ", columnName=" + columnName
				+ ", dataType=" + dataType + ", dataFormat=" + dataFormat
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", userID=" + userID + "]";
	}

}
