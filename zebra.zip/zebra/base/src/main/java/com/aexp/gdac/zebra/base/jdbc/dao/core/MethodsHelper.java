package com.aexp.gdac.zebra.base.jdbc.dao.core;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public abstract class MethodsHelper {

	/**
	 * Holds get methods by object
	 */
	private static HashMap<Class, HashMap<String, Method>> getMethodsByObject = new HashMap<Class, HashMap<String, Method>>();

	/**
	 * Holds set methods by object
	 */
	private static HashMap<Class, HashMap<String, Method>> setMethodsByObject = new HashMap<Class, HashMap<String, Method>>();


	public static Method getMethodByProperty(Class clazz, String propertyType,
			String propertyName) throws IllegalArgumentException,
			SecurityException, IllegalAccessException, NoSuchFieldException {
		
		HashMap methodsMap = null;
		if ("get".equals(propertyType)) {
			methodsMap = getMethodsByObject;
		} else if ("set".equals(propertyType)) {
			methodsMap = setMethodsByObject;
		}
		if (methodsMap.get(clazz) == null) {
			HashMap<String, Method> methodMap = initMethodsMap(clazz,
					propertyType);
			methodsMap.put(clazz, methodMap);
		}
		HashMap<String, Method> methodMap = (HashMap<String, Method>) methodsMap
				.get(clazz);
		Method m = (Method) methodMap.get(propertyName);

		return m;
	}

	private static HashMap<String, Method> initMethodsMap(Class clazz,
			String getOrSet) throws IllegalArgumentException,
			SecurityException, IllegalAccessException, NoSuchFieldException {

		HashMap<String, Method> methodMap = new HashMap<String, Method>();
		Method[] methods = clazz.getMethods();
		HashMap columnPropertyMap = (HashMap) clazz.getField(
				"columnPropertyMap").get(null);
		for (Object columnName : columnPropertyMap.keySet()) {
			String propertyName = (String) columnPropertyMap.get(columnName);
			Method m = CommonMethods
					.getMethodByName(
							getOrSet
									+ CommonMethods
											.firstLetter2UpperCase(propertyName),
							methods);
			methodMap.put(propertyName, m);

		}
		return methodMap;

	}

}
