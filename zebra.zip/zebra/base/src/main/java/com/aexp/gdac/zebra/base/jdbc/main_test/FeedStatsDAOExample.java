package com.aexp.gdac.zebra.base.jdbc.main_test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStatsOld;


public class FeedStatsDAOExample implements TableObjectDAO{
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	@Override
	public void save(TableValueObjectBase tableObjectDO) {
		String query = "insert into "+tableObjectDO.getTableName()+" (ID,FeedName,FeedKey,FileName,runDate,Volume,runNumber,Mean,StdDev,Format,Min_Val,Max_Val,Action)"
				+ " values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		FeedStatsOld feedStats = (FeedStatsOld) tableObjectDO;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		
		Object[] args = new Object[] {feedStats.getId(), feedStats.getFeedName(), feedStats.getFeedKey(), feedStats.getFileName(), feedStats.getRunDate(), feedStats.getVolume(),
				feedStats.getRunNumber(), feedStats.getMean(), feedStats.getStdDev(), feedStats.getFormat() , feedStats.getMinVal() , feedStats.getMaxVal(), feedStats.getAction()};
		
		int out = jdbcTemplate.update(query, args);
		
		if(out !=0){
			System.out.println("FeedStats saved with id="+feedStats.getId());
		}else System.out.println("FeedStats save failed with id="+feedStats.getId());
	}

	@Override
	public FeedStatsOld getById(int id) {
		String query = "select ID,FeedName,FeedKey,FileName,runDate,Volume,runNumber,Mean,StdDev,Format,Min_Val,Max_Val,Action from tbl_FeedStats where ID = ?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		
		//using RowMapper anonymous class, we can create a separate RowMapper for reuse
		FeedStatsOld feedStats = jdbcTemplate.queryForObject(query, new Object[]{id}, new RowMapper<FeedStatsOld>(){

			@Override
			public FeedStatsOld mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				FeedStatsOld feedStats = new FeedStatsOld();
				feedStats.setId(rs.getInt("ID")); 
				feedStats.setFeedName(rs.getString("FeedName")); 
				feedStats.setFeedKey(rs.getLong("FeedKey")); 
				feedStats.setFileName(rs.getString("FileName")); 
				feedStats.setRunDate(rs.getDate("runDate")); 
				feedStats.setVolume(rs.getLong("Volume"));
				feedStats.setRunNumber(rs.getInt("runNumber")); 
				feedStats.setMean(rs.getDouble("Mean")); 
				feedStats.setStdDev(rs.getDouble("StdDev"));
				feedStats.setFormat(rs.getString("Format")) ; 
				feedStats.setMinVal(rs.getDouble("Min_Val")) ; 
				feedStats.setMaxVal(rs.getDouble("Max_Val")); 
				//feedStats.setAction(Action.valueOf(rs.getString("Action")));
				return feedStats;
			}});
		
		return feedStats;
	}

	@Override
	public void update(TableValueObjectBase tableObjectDO) {
		String query = "update "+tableObjectDO.getTableName()+" set FeedName=?,FeedKey=?,FileName=?,runDate=?,Volume=?,runNumber=?,Mean=?,StdDev=?,Format=?,Min_Val=?,Max_Val=?,Action=? where ID=?";
		
		FeedStatsOld feedStats = (FeedStatsOld) tableObjectDO;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		Object[] args = new Object[] { feedStats.getFeedName(), feedStats.getFeedKey(), feedStats.getFileName(), feedStats.getRunDate(), feedStats.getVolume(),
				feedStats.getRunNumber(), feedStats.getMean(), feedStats.getStdDev(), feedStats.getFormat() , feedStats.getMinVal() , feedStats.getMaxVal(), feedStats.getAction(), feedStats.getId()};
		
		int out = jdbcTemplate.update(query, args);
		if(out !=0){
			System.out.println("FeedStats updated with id="+feedStats.getId());
		}else System.out.println("No FeedStats found with id="+feedStats.getId());
	}

	@Override
	public void deleteById(int id) {

		String query = "delete from tbl_FeedStats where id=?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		
		int out = jdbcTemplate.update(query, id);
		if(out !=0){
			System.out.println("FeedStats deleted with id="+id);
		}else System.out.println("No FeedStats found with id="+id);
	}

	@Override
	public List<TableValueObjectBase> getAll() {
		String query = "select ID,FeedName,FeedKey,FileName,runDate,Volume,runNumber,Mean,StdDev,Format,Min_Val,Max_Val,Action from tbl_FeedStats";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<TableValueObjectBase> feedStatsList = new ArrayList<TableValueObjectBase>();

		List<Map<String,Object>> feedStatsListRows = jdbcTemplate.queryForList(query);
		
		for(Map<String,Object> feedStatsRow : feedStatsListRows){
			FeedStatsOld feedStats = new FeedStatsOld();
		
			feedStats.setId(Integer.parseInt(String.valueOf(feedStatsRow.get("ID")))); 
			feedStats.setFeedName(String.valueOf(feedStatsRow.get("FeedName"))); 
			feedStats.setFeedKey(Long.parseLong(String.valueOf(feedStatsRow.get("FeedKey")))); 
			feedStats.setFileName(String.valueOf(feedStatsRow.get("FileName"))); 
			try {
				Date  date = new SimpleDateFormat("yyyy-MM-DD hh:mm:ss").parse(String.valueOf(feedStatsRow.get("runDate")));
				feedStats.setRunDate(date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			feedStats.setVolume(Long.parseLong(String.valueOf(feedStatsRow.get("Volume"))));
			feedStats.setRunNumber(Integer.valueOf(String.valueOf(feedStatsRow.get("runNumber")))); 
			feedStats.setMean(Double.parseDouble(String.valueOf(feedStatsRow.get("Mean")))); 
			feedStats.setStdDev(Double.parseDouble(String.valueOf(feedStatsRow.get("StdDev"))));
			feedStats.setFormat(String.valueOf(feedStatsRow.get("Format"))) ; 
			feedStats.setMinVal(Double.parseDouble(String.valueOf(feedStatsRow.get("Min_Val")))) ; 
			feedStats.setMaxVal(Double.parseDouble(String.valueOf(feedStatsRow.get("Max_Val")))); 
			//feedStats.setAction(Action.valueOf(String.valueOf(feedStatsRow.get("Action"))));
			
			feedStatsList.add(feedStats);			
		}
		return feedStatsList;
	}



}
