package com.aexp.gdac.zebra.base.jdbc.model;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;





import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;


/**
 * Data Object class for configurable sql statements.
 * Used in creating sql statements and holding fetched values.
 * 
 */

public class ZTableValueTypeObjectBase extends TableValueObjectBase {
	
	/* SQL Types supported **/
	
	public static final String INT ="INT";
	public static final String DOUBLE = "DOUBLE";
	public static final String BOOLEAN = "BOOLEAN";
	public static final String FLOAT = "FLOAT";
	public static final String SHORT = "SHORT";
	public static final String TIMESTAMP = "TIMESTAMP";
	public static final String LONG = "LONG";
	public static final String STRING = "LONG";
	
	/* keeps column name and column type pair */
	public static Map<String,String> columnPropertyMap = new LinkedHashMap<String,String>();
	
	/* keeps column namee and column value pair */
	private Map<String,Object> columnValueMap = new HashMap<String,Object>();
	
	private static String tableName;
	
	private String primaryKeyColumn ;

	private String columnName;
	
	private String columnValue ;
	
	private Integer startIndex ;
	
	private Integer rowCount ;

	private boolean devModeOn ;
	
	private String whereClause ;
	
	private String orderByClause ="";
	
	
	public void addColumnValuePair(String columnName , Object value){
		columnValueMap.put(columnName, value);
	}
	
	@Override
	public Map<String, String> getColumnPropertyMap() {
		return columnPropertyMap;
	}
	
	public void setColumnPropertyMap( Map<String,String> columnPropertyMap) {

		this.columnPropertyMap = columnPropertyMap;
	}
	
	/* returns value for corrosponding column name */
	public Object getColumnValue(String columnName){
		return columnValueMap.get(columnName);
	}
	
	@Override
	public void setPrimaryKey(Object obj) {
		
		columnValueMap.put(columnName,obj);
	}

	@Override
	public Object getPrimaryKey() {
		// TODO Auto-generated method stub
		return columnValueMap.get(columnName);
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return tableName;
	}
	
	
	public void setTableName(String tableName){
		this.tableName = tableName ;
	}
	

	public  String getColumnName() {
		return columnName;
	}

	public  void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public Map<String, Object> getColumnValueMap() {
		return columnValueMap;
	}

	public void setColumnValueMap(Map<String, Object> columnValueMap) {
		this.columnValueMap = columnValueMap;
	}
	
	
	public String getPrimaryKeyColumn() {
		return primaryKeyColumn;
	}

	public void setPrimaryKeyColumn(String primaryKeyColumn) {
		this.primaryKeyColumn = primaryKeyColumn;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getRowCount() {
		return rowCount;
	}

	public void setRowCount(Integer rowCount) {
		this.rowCount = rowCount;
	}

	public String getColumnValue() {
		return columnValue;
	}

	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}

	
	public boolean getDevModeOn() {
		return devModeOn;
	}

	public void setDevModeOn(boolean isDevModeOn) {
		this.devModeOn = isDevModeOn;
	}

	public String getWhereClause() {
		return whereClause;
	}

	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}

	public String getOrderByClause() {
		return orderByClause;
	}

	public void setOrderByClause(String orderByClause) {
		this.orderByClause = orderByClause;
	}

	@Override
	public String toString() {
		return "TableValueTypeObjectBase [columnValueMap=" + columnValueMap
				+ "]";
	}

	
}
