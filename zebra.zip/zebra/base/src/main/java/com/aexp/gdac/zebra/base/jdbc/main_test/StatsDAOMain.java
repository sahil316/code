package com.aexp.gdac.zebra.base.jdbc.main_test;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleStatsDAO;

public class StatsDAOMain {
	public static void main(String args[]) throws ZebraServiceException{
		ColumnRuleStatsDAO columnRuleDAO = (ColumnRuleStatsDAO) ZebraResourceManager.getBean("columnRuleStatsDAO");
		
		System.out.println(columnRuleDAO.getColumnRuleStatsPastRuns(1L, 3L, 11l, 0, 30));
	}
}
