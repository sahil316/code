package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStatsOld;
import com.aexp.gdac.zebra.base.jdbc.model.ZTableValueTypeObjectBase;

/**
 *  Handles configurable table sql queries.
 *  Currently supports select statements.
 *
 */

public class ZTableColumnValueDAO extends SpringDAOBase implements TableDAO{
	

	private static String tableBeanName ;
	
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primaryKey) throws ZebraServiceException {
		ZTableValueTypeObjectBase ret = ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName);
		try {
			StatementObject so = generateSelectStmt(ret);
			ret = (ZTableValueTypeObjectBase) getJdbcTemplate().queryForObject(
					so.getStmt() + " WHERE "+primaryKey+"=?",
					new Object[] { primaryKey },
					new ZGenericRowMapper(ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName)));
		} catch (Throwable t) {
			throw new ZebraServiceException("Exception occured while fetching row from table "+ret.getTableName()+" form DB ",ZebraServiceException.Reason.DB_ERROR,t);
		}
		return ret;
	}
	
	
    public List getObjectListByColumnValue(String column ,String value, int startIndex, int rowCount ) throws Exception {
        List ret=null;
    	ZTableValueTypeObjectBase vo = ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName);
        try {
            StatementObject so=generateSelectStmt(vo);
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE "+column+"=?",
                    new Object[] {value }, new ZRowMapperResultSetExtractor(new ZGenericRowMapper(ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName)),startIndex,rowCount));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching rows from table "+vo.getTableName()+" form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        return ret;
        
    }
    
    public List getObjectListByColumnValue() throws Exception {
        List ret=null;
        
        int startIndex = 0;
        int rowCount = -1; // for selecting all records
        ZTableValueTypeObjectBase vo = ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName);
        
        if(vo.getStartIndex()!=null){
        	startIndex = vo.getStartIndex() ;
        }
        
        if(vo.getRowCount() != null){
        	rowCount = vo.getRowCount();
        }

        try {
            StatementObject so=generateSelectStmt(vo);
            if(!vo.getDevModeOn()){
            ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE "+vo.getColumnName()+"=?",
            //ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE "+"FileName"+"='FileName_767' ORDER BY Volume DESC",
                    new Object[] { vo.getColumnValue() }, new ZRowMapperResultSetExtractor(new ZGenericRowMapper(ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName)),startIndex,rowCount));
            }else{
                ret=(List) getJdbcTemplate().query(so.getStmt()+" WHERE "+vo.getWhereClause()+" "+vo.getOrderByClause(),
                new Object[] {  }, new ZRowMapperResultSetExtractor(new ZGenericRowMapper(ZebraResourceManager.getZTableValueTypeObjectBean(tableBeanName)),startIndex,rowCount));
            }
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching rows from table "+vo.getTableName()+" form DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        return ret;
        
    }
    
	public static String getTableBeanName() {
		return tableBeanName;
	}

	public static void setTableBeanName(String tableBeanName) {
		ZTableColumnValueDAO.tableBeanName = tableBeanName;
	}

	@Override
	public Object create(TableValueObjectBase svo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(TableValueObjectBase svo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int remove(Object invoiceKeyId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
