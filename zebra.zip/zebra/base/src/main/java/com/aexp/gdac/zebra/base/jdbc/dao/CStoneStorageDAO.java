package com.aexp.gdac.zebra.base.jdbc.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.StatementObject;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapper;
import com.aexp.gdac.zebra.base.jdbc.dao.core.SpringDAOBase.ZRowMapperResultSetExtractor;
import com.aexp.gdac.zebra.base.jdbc.model.CStoneStorage;

public class CStoneStorageDAO extends SpringDAOBase implements TableDAO {
	
	private final static Logger log = Logger.getLogger(CStoneStorageDAO.class);

    public List<CStoneStorage> getAllCStoneStorageDetails() throws ZebraServiceException {
        List<CStoneStorage> ret=null;
        try {
            StatementObject so=generateSelectStmt(new CStoneStorage());
            ret=(List<CStoneStorage>) getJdbcTemplate().query(so.getStmt() + " ORDER BY table_name",
                    new Object[] {}, new ZRowMapperResultSetExtractor(new ZRowMapper(new CStoneStorage()),0,-1));
        } catch (Throwable t) {
        	throw new ZebraServiceException("Exception occured while fetching CStoneStorage from DB ",ZebraServiceException.Reason.DB_ERROR,t);
        }
        
        return ret;
        
    }
    
	@Override
	public TableValueObjectBase getObjectByPrimaryKey(Object primarykey) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public Object create(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int update(TableValueObjectBase svo) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}

	@Override
	public int remove(Object invoiceKeyId) throws ZebraServiceException {
		// TODO Auto-generated method stub
		throw new ZebraServiceException("Operation Not supported  ",ZebraServiceException.Reason.DB_ERROR);
	}
	
	

}
