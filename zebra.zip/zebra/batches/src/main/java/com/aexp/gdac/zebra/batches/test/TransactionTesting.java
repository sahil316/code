package com.aexp.gdac.zebra.batches.test;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.transaction.annotation.Transactional;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;


public class TransactionTesting {
	
	ZebraBatchDAO dao ;
	StatsDAO statDAO ;
	
	public TransactionTesting(){
		dao = new ZebraBatchDAO();
		statDAO = (StatsDAO) ZebraResourceManager.getBean("statsDAO");
	}
	
	public static void main(String args[]) throws ZebraBatchException, ZebraServiceException{
		
		System.out.println("Started");
		TransactionTesting tx = new TransactionTesting();
		tx.execute();
		
		System.out.println("Finnished");
	}
	
	
	@Transactional
	private void execute() throws ZebraBatchException, ZebraServiceException{
		Stats stat = createStats() ;
		
		Long pk  = (Long)insertStat(stat);
		System.out.println("Stat inserted "+pk);
		if(pk!=null){
			System.out.println("Throwing expception ..........");
			throw new ZebraBatchException("Transaction testing ",ZebraBatchException.Reason.UNEXPECTED_EXCEPTION);
		}
		
		pk  = (Long)insertStat(stat);
	}
	
	private Long insertStat(Stats stat) throws ZebraBatchException, ZebraServiceException{
		//return dao.registerStats(stat);
		return (Long) statDAO.create(stat);
	}
	
	private Stats createStats(){
		Stats stat = new Stats();
		stat.setFeedID(1L);
		stat.setFeedName("Seasonaltiy");
		stat.setInputFilePath("/idn/home/aatri1/feed_fiel");
		stat.setRunDate(new Timestamp(new Date().getTime()));
		return stat ;
	}
}
