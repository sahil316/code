package com.aexp.gdac.zebra.batches.mdgen;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tools.ant.DirectoryScanner;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.base.metadata.MetadataRow;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;

public class MetadataRowMapper {
	private static org.apache.log4j.Logger log = Logger.getLogger(MetadataRowMapper.class);

	private ZebraBatchDAO zebraBatchDAO ;
	private Stats currentStat ;
	public MetadataRowMapper(){
		this.zebraBatchDAO = new ZebraBatchDAO(); 
	}
	
	
	public List<MetadataRow> getMetadataRowList() throws ZebraBatchException{
		
		
		Stats stat = null;
		
		if(null == MetadataFileCreator.feedId){
			stat = zebraBatchDAO.getNextEligibleStats();
		}else if(MetadataFileCreator.stateId != null ){
			stat = zebraBatchDAO.getStatsByStateID(Long.parseLong(MetadataFileCreator.stateId));
		}else{
			stat = zebraBatchDAO.getNextEligibleStatsByFeedId(Long.parseLong(MetadataFileCreator.feedId));
		}
		
		
		
		log.info("Stats Fetched From DB:"+stat);
		
		if(stat == null){
			throw new ZebraBatchException("No StateID found to process ",ZebraBatchException.Reason.NOTHING_TO_PROCESS);
		}
		
		ZebraBatchDAO.log(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,"Fetching metadata from DB started FeedID:"+stat.getFeedID() ,""+stat.getStateID());
		
		
		// set current stat instance. This is used in writing .stats file and updating stats run status.
		setCurrentStat(stat);
		
		/** try{ */
				/* TODO - filename must be passed from stats fetched */
				assertInputFileAccess(stat.getInputFilePath());
				
				List<MetadataRow> mdRowList = new ArrayList<MetadataRow>();
				long stateId = stat.getStateID() ;
				FeedMetadata feedMd = zebraBatchDAO.getEligibleFeedMetadata(stat.getFeedID());
				
				log.info("Gennerating Metadata for Feed :"+feedMd);
				
				if(feedMd == null){
					throw new ZebraBatchException("FeedMetadata Not Found , cannot proceed",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION) ;
				}
				//setting target email ID , header and tailer for sending mail notification and mapreduce job
				MetadataFileCreator.targetEmailId = feedMd.getEmailID() ;
				MetadataFileCreator.header = feedMd.getHeader();
				MetadataFileCreator.tailer = feedMd.getTailer() ;
				
				mdRowList.add(getFeedLevelMdRow(feedMd,stat.getStateID()));
				
				String columnDelimiter = feedMd.getColumnDelimiter() ;
				String recordDelimiter = feedMd.getRecordDelimiter() ;
				String fileFormat = feedMd.getFileFormat() ;
				String feedName = feedMd.getFeedName() ;
				
		    	List<ColumnMetadata> columnMDList = zebraBatchDAO.getEligibleColumnMetadata(stat.getFeedID());
				for(ColumnMetadata columnMd : columnMDList){
					String dataType = columnMd.getDataType();
					String dataFormat = columnMd.getDataFormat() ;
					String columnName = columnMd.getColumnName();
					
					mdRowList.add(getColumnLevelMdRow(columnMd,stateId,feedName,fileFormat,columnDelimiter,recordDelimiter));
					
					List<ColumnRuleMetadata> columnRuleMDList = zebraBatchDAO.getEligibleColumRuleMetadata(columnMd.getFeedID(),columnMd.getColumnID());
						
					for(ColumnRuleMetadata columnRuleMD : columnRuleMDList ){
						
						mdRowList.add(getColumRuleLevelMdRow(columnRuleMD,stateId,feedName,columnName,fileFormat,columnDelimiter,recordDelimiter,dataType,dataFormat));
					}
						
					
				}
				
				ZebraBatchDAO.log(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,"Fetching metadata from DB finnished FeedID:"+stat.getFeedID() , ""+stat.getStateID());
				
				return mdRowList;
		/** update STATS table for reason to abort
		}catch(ZebraBatchException zbe){
			 
			if(zbe.getReason() == ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION){
				stat.setErrorMessage(zbe.getReason().getReasonDesc());
				zebraBatchDAO.updateStatsErrorMessage(stat);
			}
			
			throw zbe ;
		}*/
	}
	
	private MetadataRow getFeedLevelMdRow(FeedMetadata feedMd,long stateId){
		MetadataRow mdRow = new MetadataRow();
		
		mdRow.setLevel(Level.FEED_LEVEL);
		mdRow.setFeedId(feedMd.getFeedID());
		mdRow.setStateId(stateId);
		mdRow.setFeedName(feedMd.getFeedName());
		mdRow.setFileFormat(feedMd.getFileFormat());
		mdRow.setColumnDelimiter(feedMd.getColumnDelimiter());
		mdRow.setRecordDelimiter(feedMd.getRecordDelimiter());
		mdRow.setMaxAbortThreshold(feedMd.getMaxAbortThreshold());
		mdRow.setMaxAlertThreshold(feedMd.getMaxAlertThreshold());
		mdRow.setMinAbortThreshold(feedMd.getMinAbortThreshold());
		mdRow.setMinAlertThreshold(feedMd.getMinAlertThreshold());
		mdRow.setThresholdType(feedMd.getThresholdType());	
		mdRow.setPastRun(feedMd.getPastRuns());
		
		if(mdRow.getPastRun()!=null && mdRow.getPastRun() > 0){
			mdRow.setTrendingFlag(1);
		}
		
		return mdRow ;
		
	}
	
	private MetadataRow getColumnLevelMdRow(ColumnMetadata columnMd,long stateId,String feedName,
			String fileFormat, String columnDelimiter,String recordDelimiter){
		MetadataRow mdRow = new MetadataRow();
		
		mdRow.setFeedId(columnMd.getFeedID());
		mdRow.setLevel(Level.COLUMN_LEVEL);
		
		mdRow.setStateId(stateId);
		mdRow.setFeedName(feedName);
		mdRow.setFileFormat(fileFormat);
		mdRow.setColumnDelimiter(columnDelimiter);
		mdRow.setRecordDelimiter(recordDelimiter);
		mdRow.setDataFormat(columnMd.getDataFormat());
		mdRow.setDataType(columnMd.getDataType());
		mdRow.setColumnId(columnMd.getColumnID());
		mdRow.setColumnName(columnMd.getColumnName());
		
		return mdRow ;
		
	}
	
	private MetadataRow getColumRuleLevelMdRow(ColumnRuleMetadata columnRuleMd,long stateId,String feedName,String columnName, 
			String fileFormat, String columnDelimiter,String recordDelimiter, String dataType, String dataFormat){
		MetadataRow mdRow = new MetadataRow();
		
		mdRow.setFeedId(columnRuleMd.getFeedID());
		mdRow.setLevel(Level.COLUMN_RULE_LEVEL);
		mdRow.setStateId(stateId);
		mdRow.setFeedName(feedName);
		mdRow.setColumnName(columnName);
		mdRow.setFileFormat(fileFormat);
		mdRow.setColumnDelimiter(columnDelimiter);
		mdRow.setRecordDelimiter(recordDelimiter);
		mdRow.setDataFormat(dataFormat);
		mdRow.setDataType(dataType);
		mdRow.setRuleParameter(columnRuleMd.getRuleParameter());
		mdRow.setColumnId(columnRuleMd.getColumnID());
		mdRow.setColumnRuleId(columnRuleMd.getColumnRuleID());
		mdRow.setRuleId(columnRuleMd.getRuleID());
		mdRow.setMaxAbortThreshold(columnRuleMd.getMaxAbortThreshold());
		mdRow.setMaxAlertThreshold(columnRuleMd.getMaxAlertThreshold());
		mdRow.setMinAbortThreshold(columnRuleMd.getMinAbortThreshold());
		mdRow.setMinAlertThreshold(columnRuleMd.getMinAlertThreshold());
		mdRow.setThresholdType(columnRuleMd.getThresholdType());
		mdRow.setPastRun(columnRuleMd.getPastRuns());
		
		if(mdRow.getPastRun()!= null && mdRow.getPastRun() > 0){
			mdRow.setTrendingFlag(1);
		}
		
		
		return mdRow ;
		
	}


	
	public Stats getCurrentStat() {
		return currentStat;
	}


	public void setCurrentStat(Stats currentStat) {
		this.currentStat = currentStat;
	}


	/** checks for file existence and read access , throws CANNOT_PROCEED_EXCEPTION*/
	private void assertInputFileAccess(String fileName)throws ZebraBatchException{
		if(fileName == null || fileName.trim().isEmpty()){
			throw new ZebraBatchException("Input Feed file name missing ",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
		}
		
		/* check for wild card chars [*,?] */
		boolean hasWildCard = false ;
		if(fileName.contains("*") || fileName.contains("?")){
			hasWildCard = true ;
		}
		
		if(hasWildCard){
			String basePath = ".";
			
			int wildCardIndex = fileName.indexOf('*');
			if(wildCardIndex > 0){
				int splitIndex = fileName.substring(0,wildCardIndex).lastIndexOf('/') ;
				if(splitIndex > 0){
					basePath = fileName.substring(0,splitIndex+1) ;
				}
				fileName = fileName.substring(splitIndex+1);
			}

			DirectoryScanner scanner = new DirectoryScanner();
			scanner.setIncludes(new String[]{fileName});
			scanner.setBasedir(basePath);
			scanner.setCaseSensitive(false);
			scanner.scan();
			String[] files = scanner.getIncludedFiles();
			String[] dirs = scanner.getIncludedDirectories();

			if(!(dirs.length > 0 || files.length > 0)){
				throw new ZebraBatchException("Input Feed file ["+basePath+fileName+"] doesnot exist ",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
			}
		}
		
		if(!hasWildCard && !new java.io.File(fileName).exists()){
			throw new ZebraBatchException("Input Feed file ["+fileName+"] doesnot exist ",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
		}
		
		/*
		 * always throw exception 
		 * try{
			java.security.AccessController.checkPermission(new java.io.FilePermission(fileName, "read"));
		}catch(java.security.AccessControlException ace){
			throw new ZebraBatchException("Input Feed file "+fileName+" doesnot have read access ",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
		}*/
		/**
		 *  might not work on window with jdk lower than 1.7
		 */
		if(!hasWildCard && !new java.io.File(fileName).canRead()){
			throw new ZebraBatchException("Input Feed file ["+fileName+"] doesnot have read access ",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
		}
	}
}
