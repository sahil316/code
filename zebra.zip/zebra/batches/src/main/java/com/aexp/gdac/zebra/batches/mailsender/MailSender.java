package com.aexp.gdac.zebra.batches.mailsender;

import java.io.IOException;

import com.aexp.gdac.zebra.batches.ZebraBatchException;

public class MailSender {
	
	private static final String VAR_SUBJECT = "<mail-subject>";
	private static final String VAR_MESSAGE = "<mail-message>";
	private static final String VAR_RECEIVER = "<mail-receiver>";
	//private static final String DEFAULT_RECEIVER = "avneesh.atri@aexp.com" ;
	private static final String DEFAULT_RECEIVER = "GDAC_ZEBRA@aexp.com" ;
	private static String mailCommandTemplate = "echo '"+ VAR_MESSAGE +"' |mail -s '"+VAR_SUBJECT+"' "+VAR_RECEIVER ;
	
//	private static String defaultReceiver = "avneesh.atri@aexp.com";

	public static void main(String args[]) throws ZebraBatchException{
		sendMail(args[0],args[1],args[2]);
	}
	
	
	public static void sendMail(String subject, String receiver, String text) throws ZebraBatchException{
		
		if(receiver == null || receiver.trim().isEmpty()){
			receiver = DEFAULT_RECEIVER;
		}
			
		if(subject == null || subject.trim().isEmpty()
				|| receiver == null || receiver.trim().isEmpty()
				|| text == null || text.trim().isEmpty()){
			 throw new ZebraBatchException("Missing input parameters ",ZebraBatchException.Reason.MAIL_SENDER_EXCEPTION);
		}
		
		String mailCommand = mailCommandTemplate.replace(VAR_MESSAGE, text)
								.replace(VAR_SUBJECT, subject).replace(VAR_RECEIVER, receiver);
		
		//System.out.println("Executing mail command "+mailCommand);
		
		try {
			Runtime.getRuntime().exec(new String[]{"bash","-c",mailCommand});
		} catch (IOException e) {
			e.printStackTrace();
			throw new ZebraBatchException(ZebraBatchException.Reason.MAIL_SENDER_EXCEPTION,e);
		}
	}
	
	public static void sendMailToGroup(String subject, String text) throws ZebraBatchException{
		sendMail(subject,DEFAULT_RECEIVER,text);
	}

}
