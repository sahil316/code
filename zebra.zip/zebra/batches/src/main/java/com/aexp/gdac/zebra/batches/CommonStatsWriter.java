package com.aexp.gdac.zebra.batches;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class that writes the statistics
 * into file.
*/
public class CommonStatsWriter {

	private BufferedWriter writer;
	
	private List<String> headerrows = new ArrayList<String>();
	private List<String> datarows = new ArrayList<String>();
	private List<String> metadatarows = new ArrayList<String>();
	
	private Date start, finish;
	
	private SimpleDateFormat df;
	protected String path = "";
	
	protected static final String STATS_PATHENV = "ZEBRA_STAGING";
	protected static final String STATS_FILE_PATHENV = "ZEBRA_STATS_FILE";
	
	
	private boolean isHtml ;
	private boolean ignoreExeInfo ;
	


	
	public CommonStatsWriter(String filepath,boolean isHtml, boolean ignoreExeInfo) {
		
		this.isHtml = isHtml ;
		this.ignoreExeInfo = ignoreExeInfo ;
		
		df = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		
		if (null != System.getenv(STATS_PATHENV) && !"".equals(System.getenv(STATS_PATHENV))) {
			path = System.getenv(STATS_PATHENV) + "/";
		}
		
		if(filepath == null || filepath.trim().isEmpty()){
			//filepath = path + System.getenv(STATS_FILE_PATHENV);
			throw new IllegalArgumentException("****** interm file path not specified ********");
		}
		
		start = new Date();
		if(isHtml){
			addHTMLRow("Started at", df.format(start), false);
		}else{
			addRow("Started at", df.format(start), false);
		}
		
		try {
			writer = new BufferedWriter(new FileWriter(filepath, false));
		} catch (IOException e) {
			System.err.println("Error creating writer: " + e.getMessage());
		}
	}
	
	public CommonStatsWriter(String filepath,boolean isHtml) {
		this(filepath,isHtml,false);
	}
	
	public CommonStatsWriter(String filepath) {
		this(filepath,false,false);
	}
	
	/**
	 * Method that adds html format statistics
	 * row data into list.
	 * 
	 * @param label
	 * @param value
	 * @param isLast true if last row to be written into file.
	 */
	public void insertHTMLRow(String label, String value, boolean isLast) {
		addHTMLRow(label, value, true);
		
		if (isLast) {
			finish = new Date();
			addHTMLRow("Finished at", df.format(finish), false);
			addHTMLRow("Total processing time", getDuration(), false);
			writeHTMLStatsFile();
		}
	}
	
	
	/**
	 * Method that adds statistics
	 * row data into list.
	 * 
	 * @param label
	 * @param value
	 * @param isLast true if last row to be written into file.
	 */
	public void insertRow(String label, String value, boolean isLast) {
		addRow(label, value, true);
		
		if (isLast) {
			finish = new Date();
			addRow("Finished at", df.format(finish), false);
			addRow("Total processing time", getDuration(), false);
			writeStatsFile();
		}
	}
	
	public void insertMetadataRow(String label, String value){
		addMetadataRow(label, value);
	}
	
	public String getStart() {
		return df.format(start);
	}
	
	public String getFinish() {
		return df.format(finish);
	}
	
	public String getDuration() {
		return formatTime(finish.getTime() - start.getTime());
	}
	
	private void addMetadataRow(String label, String value){
		metadatarows.add(label + ":" + value + "\n");
	}
	
	private void addRow(String label, String value, boolean isDatarow) {
		if (isDatarow) {
			datarows.add(label + ": " + value + "\n");
		} else {
			headerrows.add(label + ": " + value + "\n");
		}
	}
	
	
	private void addHTMLRow(String label, String value, boolean isDatarow) {
		if (isDatarow) {
			datarows.add("<tr><td style='border: 1px solid black;'>"+label 
					+ "</td><td style='border: 1px solid black;'> " + value + "</td></tr>\n");
		} else {
			headerrows.add("<tr><td style='border: 1px solid black;'>"+label 
					+ "</td><td style='border: 1px solid black;'> " + value + "</td></tr>\n");
		}
	}
	
	
	/**
	 * Writes the statistics
	 * into file in the end.
	 * 
	 * First header rows are written
	 * and then data rows.
	 */
	private void writeStatsFile() {
		try {
			if(!ignoreExeInfo){
				for (int i = 0; i < headerrows.size(); i++) {
					writer.write(headerrows.get(i));
				}
			}
			
			writer.write("\n");
			
			for (int i = 0; i < datarows.size(); i++) {
				writer.write(datarows.get(i));
			}
			
			writer.close();
		} catch (IOException e) {
			System.err.println("Error writing statistics file: " + e.getMessage());
		}
		
	}
	
	
	/**
	 * Writes the statistics in html format
	 * into file in the end.
	 * 
	 * First header rows are written
	 * and then data rows.
	 */
	private void writeHTMLStatsFile() {
		try {

			for (int i = 0; i < metadatarows.size(); i++) {
					writer.write(metadatarows.get(i));
			}

			
			/* wirte html start*/
			writer.write("<html> "
					+"<body>"
					+"<table style='width:100%; border-collapse:collapse; border: 1px solid black;' >");
			
			if(!ignoreExeInfo){
				for (int i = 0; i < headerrows.size(); i++) {
					writer.write(headerrows.get(i));
				}
			}
			
			writer.write("\n");
			
			for (int i = 0; i < datarows.size(); i++) {
				writer.write(datarows.get(i));
			}
			
			writer.write("</table> </body> </html>");
			writer.close();
		} catch (IOException e) {
			System.err.println("Error writing statistics file: " + e.getMessage());
		}
		
	}
	
	/**
	 * Formats given time as milliseconds
	 * into String representation.
	 * 
	 * @param time
	 * @return String representation of given time
	 */
	private String formatTime(long time) {
		DecimalFormat df = new DecimalFormat();
		DecimalFormat df2 = new DecimalFormat();
		df.applyPattern("00");
		df2.applyPattern("000");
		
		int milliSeconds = (int) time;
		int hours = milliSeconds / 3600000;
		milliSeconds = milliSeconds - (hours * 3600000);
		int minutes = milliSeconds / 60000;
		milliSeconds = milliSeconds - (minutes * 60000);
		int seconds = milliSeconds / 1000;
		milliSeconds = milliSeconds - (seconds * 1000);

		return df.format(hours) + ":" + df.format(minutes) + ":" + df.format(seconds) + ":" + df2.format(milliSeconds);
	}
	
}

