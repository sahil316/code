package com.aexp.gdac.zebra.batches;

public class TaskInputParams {
	
	public static String task_stats_output_dir;
	public static String task_md_output_dir ;
	public static String task_queue_name ;
	public static String task_reducer_count;
	public static String task_userid;
	public static String task_feed_id ;
	public static String task_target_email_id;
	public static String task_state_id;
	public static String task_input_file_path ;
	public static String task_feed_name ;
	public static String task_interm_file ;
	public static String task_portal_url ;
	public static String task_run_date ;
	public static String task_ticketrobo_interm_file ;
	//set default value in badRecRejectCount to avoid null pointer in task runner run.
	public static String badRecRejectCount="-1";
	
	public static String mdgen_output_dir;
	public static String mdgen_userid;
	public static String mdgen_feedid;
	public static String mdgen_stateid;
	public static String mdgen_interm_file ;
	public static String mdgen_master_run ;

	public static String mr_reducer_count;
	public static String mr_input_feed ;
	public static String mr_output_dir;
	public static String mr_md_file ;
	public static String mr_queue_name ;
	public static String mr_header ;
	public static String mr_tailer ;
	public static String mr_stateId ;
	public static String mr_feedId;
	
	public static String stl_input_dir ;
	public static String stl_stateId;
	public static String stl_userId;
	public static String stl_master_run;
	public static String stl_interm_file ;
	public static String stl_action ;
	
	public static String master_run = "true";
	
	/*named paramters keys*/
	public static final String statsOutDir = "--statsOutDir" ;
	public static final String mdOutDir = "--mdOutDir";
	public static final String queueName = "--queueName" ;
	public static final String reducerCount = "--reducerCount";
	public static final String userId = "--userId" ;
	public static final String feedId = "--feedId" ;
	public static final String inputFeedPath = "--inputFeedPath";
	public static final String feedName = "--feedName" ;
	public static final String intermFile = "--intermFile" ; 
	public static final String stateId = "--stateId" ;
	public static final String masterRun="--masterRun";
	public static final String trimHeader="--trimHeader";
	public static final String trimTailer="--trimTailer";
	public static final String mdFilePath="--mdFilePath";
	public static final String portalUrl="--portalUrl";
	public static final String runDate="--runDate";
	public static final String ticketRoboIntermFile = "--tktRoboIntermFile" ;
	public static final String badRecordRejectCount = "--badRecordRejectCount";
	
	
	public static String[] getMetadataGenInputArgs(){
		mdgen_output_dir = getArgumentPair(mdOutDir,task_md_output_dir);
		mdgen_userid = getArgumentPair(userId,task_userid) ;
		mdgen_feedid = getArgumentPair(feedId, task_feed_id);
		mdgen_stateid = getArgumentPair(stateId, task_state_id);
		mdgen_master_run = getArgumentPair(masterRun, master_run);
		mdgen_interm_file = getArgumentPair(intermFile, task_interm_file);
		return new String[]{mdgen_output_dir,mdgen_userid,mdgen_feedid,mdgen_stateid,mdgen_interm_file,mdgen_master_run};
	}
	
	
	public static String[] getStatsGeneratorInputArgs(String feedFile, String mdFile, String header, String tailer, String stateId){
		
		mr_output_dir = task_stats_output_dir;
		mr_queue_name = task_queue_name;
		mr_reducer_count = task_reducer_count;
		mr_input_feed = feedFile;
		mr_md_file = mdFile;
		mr_header = header;
		mr_tailer = tailer;
		mr_stateId = stateId ;
		
		return new String[]{mr_input_feed,mr_output_dir,mr_md_file,mr_queue_name,mr_header,mr_tailer,mr_stateId,mr_reducer_count,master_run,badRecRejectCount};
	}
	
	public static String[] getStatsLoaderInputArgs(){
		stl_stateId = getArgumentPair(stateId,mr_stateId) ;
		stl_input_dir = getArgumentPair(statsOutDir,task_stats_output_dir);
		stl_userId = getArgumentPair(userId,task_userid);
		stl_master_run = getArgumentPair(masterRun, master_run);
		stl_interm_file = getArgumentPair(intermFile, task_interm_file);
		return new String[]{stl_input_dir,stl_stateId,stl_userId,stl_interm_file,stl_master_run};
	}
	
	public static void assertMandatoryParameters() throws ZebraBatchException{
		if(task_stats_output_dir==null || task_stats_output_dir.isEmpty()
				|| task_md_output_dir==null || task_md_output_dir.isEmpty()
				|| task_queue_name==null || task_queue_name.isEmpty()
				|| task_reducer_count==null || task_reducer_count.isEmpty()
				|| task_userid==null || task_userid.isEmpty()
				|| task_feed_id==null || task_feed_id.isEmpty()){
			
			throw new ZebraBatchException("mandatory parameter missing",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
		}
	}
	
	private static String getArgumentPair(String paramName, String paramValue){
		if(paramName == null || paramName.isEmpty()){
			return null ;
		}
		return paramName.trim() + "="+ paramValue;
	}
	
	
	public static String getParameterValue(String keyValue){
		try{
			if(keyValue==null){
				return null ;
			}
			return keyValue.split("=")[1];
		}catch(StringIndexOutOfBoundsException saiob){
			return null ;
		}catch(java.lang.ArrayIndexOutOfBoundsException aiob){
			return null ;
		}
	}
}
