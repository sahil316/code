package com.aexp.gdac.zebra.batches.slahandler;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAStats;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.batches.CommonStatsWriter;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;

public class SLAStatsUpdater {
	private ZebraBatchDAO zebraBatchDAO ;
	private static org.apache.log4j.Logger log = Logger.getLogger(SLAStatsUpdater.class);
	
	private static final String PASS = "PASS";
	private static final String FAIL = "FAIL";
	
	public SLAStatsUpdater(){
		this.zebraBatchDAO = new ZebraBatchDAO();
	}
		
	
	public void createAndUpdateStats(SLAMetadata slaMd) throws ZebraBatchException{
		List<SLAStats> slaStatsList = zebraBatchDAO.getUnprocessedSLAStatsByFeedId(slaMd.getFeedID());
		
		log.info("No or SLAStats Fetched for feed "+slaMd.getFeedID()+":"+slaStatsList.size());
		
		if(slaStatsList.isEmpty()){	
			createStats(slaMd);
		}else{
			for(SLAStats slaStat : slaStatsList){
					updateSLAStatsStatus(slaStat,slaMd);									
				}
		}
	}
	
	
	private void updateSLAStatsStatus(SLAStats slaStat, SLAMetadata slaMd) throws ZebraBatchException{

		Timestamp current_timestamp = new Timestamp(new Date().getTime());
		

			if(current_timestamp.compareTo(slaStat.getExpectedTimeStamp()) > 0){
				List<Stats> statsList = zebraBatchDAO.getStatsCreatedBetweenDates(slaStat.getFeedID(), slaStat.getCalculatedTimeStamp(), slaStat.getExpectedTimeStamp());
				
				log.info("No of Registered Stats found for feed "+slaMd.getFeedID() +":"+statsList.size());
				
				if(statsList.isEmpty()){
					FeedMetadata feedMd = (FeedMetadata)zebraBatchDAO.getEligibleFeedMetadata(slaStat.getFeedID());
					
					slaStat.setStatus(FAIL);
					if(slaMd.isIntraDay()){
						slaStat.setMessage("No request found for processing for last "
								+ CommonMethods.getHours(slaMd.getElapseTime())+" hr " 
								+ CommonMethods.getMinutes(slaMd.getElapseTime())
								+ " mins for feedId: "+ slaStat.getFeedID() +" feed Name:"+feedMd.getFeedName());
					}else {
						slaStat.setMessage("No request found for processing for last "
								+ CommonMethods.getHours(slaMd.getExecTime())+" hr " 
								+ CommonMethods.getMinutes(slaMd.getExecTime())
								+ " mins for feedId: "+ slaStat.getFeedID() +" feed Name:"+feedMd.getFeedName());
					}
					
					
					log.info("Sending Mail to "+feedMd.getEmailID());
					
					try{
						//MailSender.sendMail("Zebra SLA Alert", feedMd.getEmailID(), slaStat.getMessage());
						
						CommonStatsWriter statsWriter = new CommonStatsWriter(SLAHandler.intermFile+"."+feedMd.getFeedID(),true,true);
						statsWriter.insertMetadataRow("Receiver", feedMd.getEmailID());
						
						statsWriter.insertMetadataRow("Subject", "Zebra Real Time Utility - ALERT - Feed ID "+feedMd.getFeedID()+"- Status -"+slaStat.getStatus());


						statsWriter.insertHTMLRow("FeedId", ""+feedMd.getFeedID(), false);
						statsWriter.insertHTMLRow("Status", ""+slaStat.getStatus(), false);
						statsWriter.insertHTMLRow("Message", ""+slaStat.getMessage(), true);
						
					}catch(Exception e){
						slaStat.setNotified("false");
						log.info("Creating Mail File for id "+feedMd.getEmailID() + "Failed !");
					}
					
					slaStat.setNotified("true");
					
				}else {
					slaStat.setStatus(PASS);
					slaStat.setStateID(statsList.get(0).getStateID());
					
				}
				log.info("Updating SLA Stats for FeedID:"+slaStat.getFeedID() + " with status:"+slaStat.getStatus());
				zebraBatchDAO.updateSLAStatus(slaStat);
			}

	}

	
	private void createStats(SLAMetadata slaMd) throws ZebraBatchException{
		log.info("Creating SLA Stats Entry for FeedID:"+slaMd.getFeedID());
		
		SLAStats slaStat = new SLAStats() ;
		slaStat.setFeedID(slaMd.getFeedID());
		
		
		Timestamp calculatedTimeStamp = calculateExpectedTime(slaMd) ;
		Timestamp expectedTimeStamp = (Timestamp)calculatedTimeStamp.clone() ;
		
		
		if(slaMd.isIntraDay()){
			slaStat.setCalculatedTimeStamp(calculatedTimeStamp);
			
			expectedTimeStamp.setHours(expectedTimeStamp.getHours() + CommonMethods.getHours(slaMd.getElapseTime()));
			expectedTimeStamp.setMinutes(expectedTimeStamp.getMinutes() + CommonMethods.getMinutes(slaMd.getElapseTime()));
			
			slaStat.setExpectedTimeStamp(expectedTimeStamp);
		}else {
			calculatedTimeStamp.setHours(0);
			calculatedTimeStamp.setMinutes(0);
			calculatedTimeStamp.setSeconds(0);
			slaStat.setCalculatedTimeStamp(calculatedTimeStamp);
			
			
			slaStat.setExpectedTimeStamp(expectedTimeStamp);
		}
		
		if(!(slaMd.getEndDate().compareTo(slaStat.getExpectedTimeStamp()) < 0)){
			zebraBatchDAO.insertSLAStats(slaStat);
		}
	
	}
	

	@SuppressWarnings("deprecation")
	private static Timestamp calculateExpectedTime(SLAMetadata slaMd){
		Timestamp expectedTime = null ;
		Timestamp currentTimestamp = new Timestamp(new Date().getTime()) ;
		currentTimestamp.setSeconds(0);
		currentTimestamp.setNanos(0);
		
		
		if(slaMd.isIntraDay()){
			expectedTime = (Timestamp)currentTimestamp.clone();
		
			if(slaMd.getSkipDayOfWeek()!=null 
					&& slaMd.getSkipDayOfWeek() == new Date().getDay()){
				expectedTime.setDate(currentTimestamp.getDate()+1);
			} else if(slaMd.getSkipDayOfWeek()!=null 
					&& slaMd.getSkipDayOfWeek() == 7 && new Date().getDay() == 0){ //check for weekends
				expectedTime.setDate(currentTimestamp.getDate()+1);		
			} else if(slaMd.getSkipDayOfWeek()!=null 
					&& slaMd.getSkipDayOfWeek() == 7 && new Date().getDay() == 6){
				expectedTime.setDate(currentTimestamp.getDate()+2);		
			}
			
			
		}else if(slaMd.isDaily()){
			expectedTime = (Timestamp)currentTimestamp.clone();
			
			if(CommonMethods.getHours(slaMd.getExecTime()) < expectedTime.getHours()){
				expectedTime.setDate(currentTimestamp.getDate()+1);
			} else if(CommonMethods.getHours(slaMd.getExecTime()) == expectedTime.getHours()
					&& CommonMethods.getMinutes(slaMd.getExecTime()) < expectedTime.getMinutes()){
				expectedTime.setDate(currentTimestamp.getDate()+1);
			}
			
			if(slaMd.getSkipDayOfWeek()!=null
					&& slaMd.getSkipDayOfWeek() == expectedTime.getDay()){
				expectedTime.setDate(currentTimestamp.getDate()+1);
			} else if(slaMd.getSkipDayOfWeek()!=null 
					&& slaMd.getSkipDayOfWeek() == 7 && new Date().getDay() == 0){ //check for weekends
				expectedTime.setDate(currentTimestamp.getDate()+1);		
			} else if(slaMd.getSkipDayOfWeek()!=null 
					&& slaMd.getSkipDayOfWeek() == 7 && new Date().getDay() == 6){
				expectedTime.setDate(currentTimestamp.getDate()+2);		
			}
			
			
			expectedTime.setHours(CommonMethods.getHours(slaMd.getExecTime()));
			expectedTime.setMinutes(CommonMethods.getMinutes(slaMd.getExecTime()));
			
		}else if(slaMd.isWeekly()){
			expectedTime = (Timestamp)currentTimestamp.clone();
			if(currentTimestamp.getDay() < slaMd.getDayOfWeek() ){
				expectedTime.setDate(currentTimestamp.getDate() + (slaMd.getDayOfWeek()-currentTimestamp.getDay()));

			}else if(currentTimestamp.getDay() > slaMd.getDayOfWeek() ){
				expectedTime.setDate(currentTimestamp.getDate() + (7-currentTimestamp.getDay()+slaMd.getDayOfWeek()));
				
			} else if(CommonMethods.getHours(slaMd.getExecTime()) < expectedTime.getHours()){
				expectedTime.setDate(currentTimestamp.getDate()+7);
			} else if(CommonMethods.getHours(slaMd.getExecTime()) == expectedTime.getHours()
					&& CommonMethods.getMinutes(slaMd.getExecTime()) < expectedTime.getMinutes()){
				expectedTime.setDate(currentTimestamp.getDate()+7);
			}
			
			expectedTime.setHours(CommonMethods.getHours(slaMd.getExecTime()));
			expectedTime.setMinutes(CommonMethods.getMinutes(slaMd.getExecTime()));
			
		}else if(slaMd.isMonthly()){
			expectedTime = (Timestamp)currentTimestamp.clone();
			if(expectedTime.getDate() < slaMd.getDateOfMonthByCalender(expectedTime) ){
				expectedTime.setDate(slaMd.getDateOfMonthByCalender(expectedTime));

			}else if(expectedTime.getDate() > slaMd.getDateOfMonthByCalender(expectedTime) ){
				expectedTime.setMonth(currentTimestamp.getMonth()+1);
				expectedTime.setDate(slaMd.getDateOfMonthByCalender(expectedTime));
				
			}else if(CommonMethods.getHours(slaMd.getExecTime()) < expectedTime.getHours()){
				expectedTime.setMonth(currentTimestamp.getMonth()+1);
				expectedTime.setDate(slaMd.getDateOfMonthByCalender(expectedTime));
			}else if(CommonMethods.getHours(slaMd.getExecTime()) == expectedTime.getHours()
					&& CommonMethods.getMinutes(slaMd.getExecTime()) < expectedTime.getMinutes()){
				expectedTime.setMonth(currentTimestamp.getMonth()+1);
				expectedTime.setDate(slaMd.getDateOfMonthByCalender(expectedTime));
			}
			
			expectedTime.setHours(CommonMethods.getHours(slaMd.getExecTime()));
			expectedTime.setMinutes(CommonMethods.getMinutes(slaMd.getExecTime()));
			
		}	else if(slaMd.isQuaterly()) {
			expectedTime = (Timestamp)currentTimestamp.clone();
			int expectedMonthOfQuater = slaMd.getMonthOfQuarter() ;
			int currentMonthOfQuater = (currentTimestamp.getMonth()+1)%3;
			
			int expectedDateOfMonth =slaMd.getDateOfMonthByCalender(expectedTime);
			
			if(currentMonthOfQuater == 0){
				currentMonthOfQuater =3;
			}

			if(currentMonthOfQuater < expectedMonthOfQuater ){
				expectedTime.setMonth(currentTimestamp.getMonth() + (expectedMonthOfQuater - currentMonthOfQuater));
			}else if(currentMonthOfQuater > expectedMonthOfQuater ){
				expectedTime.setMonth(currentTimestamp.getMonth() +3-currentMonthOfQuater+expectedMonthOfQuater);
			}else if(currentMonthOfQuater == expectedMonthOfQuater){
				if(expectedDateOfMonth < currentTimestamp.getDate()){
					expectedTime.setMonth(currentTimestamp.getMonth()+3);
				}else if(expectedDateOfMonth == currentTimestamp.getDate()){
					
					if(CommonMethods.getHours(slaMd.getExecTime()) < expectedTime.getHours()){
						expectedTime.setMonth(currentTimestamp.getMonth()+3);
					
					}else if(CommonMethods.getHours(slaMd.getExecTime()) == expectedTime.getHours() 
							&& CommonMethods.getMinutes(slaMd.getExecTime()) < expectedTime.getMinutes()){
						expectedTime.setMonth(currentTimestamp.getMonth()+3);
					}
				}
					
			}
			
			expectedTime.setDate(slaMd.getDateOfMonthByCalender(expectedTime));
			expectedTime.setHours(CommonMethods.getHours(slaMd.getExecTime()));
			expectedTime.setMinutes(CommonMethods.getMinutes(slaMd.getExecTime()));
			
		}
		
		return expectedTime;
	}


}
