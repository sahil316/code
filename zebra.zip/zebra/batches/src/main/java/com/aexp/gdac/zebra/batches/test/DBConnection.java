package com.aexp.gdac.zebra.batches.test;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

  public static void main(String[] argv) {

        System.out.println("-------- MS SQL Server JDBC Connection Testing ------------");

        try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
                System.out.println("Where is your MySQL JDBC Driver?");
                e.printStackTrace();
                return;
        }

        System.out.println("MySQL JDBC Driver Registered!");
        Connection connection = null;

        try {
                connection = DriverManager
                .getConnection("jdbc:sqlserver://WPQSCLUSTJ1.ads.aexp.com:3000;DatabaseName=Zebra","ZEBRA_ID", "IDN1a2s3d");

                Statement statement = connection.createStatement();
                String queryString = "select * from Stats";
                ResultSet rs = statement.executeQuery(queryString);
                while (rs.next()) {
                   System.out.println(rs.getString(1));
                   System.out.println(rs.getString(3));
                   System.out.println(rs.getString(5));
                }
                
        } catch (SQLException e) {
                System.out.println("Connection Failed! Check output console");
                e.printStackTrace();
                return;
        }



        if (connection != null) {
                System.out.println("You made it, take control your database now!");
        } else {
                System.out.println("Failed to make connection!");
        }
  }
}

