package com.aexp.gdac.zebra.batches.slahandler;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.batches.TaskInputParams;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;

/**
 * Fetches SLA Metadata from database for feeds which are in active state ( EndDate is greater than current time ) .
 * Checks if any exists in SLAStats table for which ExpectedTime is lesser than CURRENT_TIEMSTAMP. 
 * If entry in not found than an entry is created in SLAStats table for next expected run .
 * If entry is found  than STATS table is checked for any user request between SLAStats.CalculatedTime and SLAStats.ExpectedTime.
 * If user request is found than SLAStats Status is updated as PASS .
 * If user request is not found than  SLAStats Status is updated as FAIL.
 * 
 * @author 521517
 *
 */
public class SLAHandler {
	private ZebraBatchDAO zebraBatchDAO ;
	private static org.apache.log4j.Logger log = Logger.getLogger(SLAHandler.class);
	public static final String  application_id = "slaHandler" ;
	public static String intermFile ;

	
	
	public static void main(String args[]){
		if(args.length < 1){
			System.err.println("java com.aexp.gdac.zebra.batches.slahandler.SLAHandler --intermFile=<interm-file>");
			
		}
		
		SLAHandler handler = new SLAHandler(args);
		log.info("Started at "+ new Timestamp(System.currentTimeMillis()));
		
		try {
			handler.executesStatsUpdate();
		} catch (ZebraBatchException e) {
			log.error("Excpetion Occured ! ",e);
			e.printStackTrace();
			System.exit(1) ;
		} catch (Exception e){
			log.error("Unexpected Excpetion Occured ! ",e);
			e.printStackTrace();
			System.exit(1);
		}
		
		log.info("Finished at " + new Timestamp(System.currentTimeMillis()));
		System.exit(0) ;
	}

	private SLAHandler(String[] args){
		loadNamedParemeters(args);
	//	this.statsWriter = new CommonStatsWriter(this.intermFile, true);
		this.zebraBatchDAO = new ZebraBatchDAO();
	}
	
	
	private void loadNamedParemeters(String[] args){
		for(String arg : args){
			if(arg == null){
				continue ;
			}
			if(arg.contains(TaskInputParams.intermFile)){
				this.intermFile =TaskInputParams.getParameterValue(arg);
			}
		}
	}
	
	
	private void executesStatsUpdate() throws ZebraBatchException{
		
		List<SLAMetadata> slaMdList = zebraBatchDAO.getEligibleSLAMetadata();
		
		log.info("No. of SLA Metadata fetched "+slaMdList.size());
		
		SLAStatsUpdater updater = new SLAStatsUpdater();
		
		for(SLAMetadata slaMd : slaMdList){
			updater.createAndUpdateStats(slaMd);
		}
		
	}
}
