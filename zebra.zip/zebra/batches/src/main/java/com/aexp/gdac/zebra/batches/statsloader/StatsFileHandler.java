package com.aexp.gdac.zebra.batches.statsloader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.batches.StatsFileConstants;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;

public class StatsFileHandler {
	private static org.apache.log4j.Logger log = Logger.getLogger(StatsFileHandler.class);
	
	private static File statsDir ;
	private List<String> statsFilePatterns ;
	
/*	private static final String feedStatsFilePattern = "feedstats";
	private static final String columStatsFilePattern = "columnstats";
	private static final String columRuleStatsFilePattern = "columnrulestats";
	private static final String complexColumRuleStatsFilePattern = "columncomplexrulestats";
	private static final String complexColumStatsFilePattern = "columncomplexstats"; 
	private static final String columnDelimiter = "\\|";
	*/
	public static boolean updatesCollected ;
	
	private List<TableValueObjectBase> feedStatsList ;
	private List<TableValueObjectBase> columnStatsList ;
	private List<TableValueObjectBase> columnRuleStatsList;
	
	
	public StatsFileHandler(String statsDir) throws ZebraBatchException	{
		this.statsDir = new File(statsDir) ;
		if(!this.statsDir.exists()){
			throw new ZebraBatchException("Input Directory '"+statsDir+"' doesnot exist ! ",ZebraBatchException.Reason.STATS_LOADER_EXCEPTION);
		}
	}
	



	public List<TableValueObjectBase> getColumnRuleStatsByColumnId(long columnID){
		List<TableValueObjectBase> statsList = new ArrayList<TableValueObjectBase>();
		
		for(TableValueObjectBase stats : columnRuleStatsList){
			ColumnRuleStats colRuleStats = (ColumnRuleStats)stats;
			if(columnID == colRuleStats.getColumnID()){
				statsList.add(colRuleStats);
			}
		}
		
		return statsList ;
	}
 
	public List<TableValueObjectBase> getStatsByLevel(Level level){
		if(level == Level.FEED_LEVEL){
			return feedStatsList;
		}else if(level == Level.COLUMN_LEVEL){
			return columnStatsList;
		}else if(level == Level.COLUMN_RULE_LEVEL){
			return columnRuleStatsList ;
		}else{
			return null ;
		}
	}
	
	public void collectStats() throws ZebraBatchException{
		ZebraBatchDAO.log(StatsFileLoader.application_id,StatsFileLoader.user_Id,"Stats file read started",""+StatsFileLoader.stateId);
		
		feedStatsList = readStatsByLevel(Level.FEED_LEVEL);
		
		columnStatsList = readStatsByLevel(Level.COLUMN_LEVEL);
		
		columnRuleStatsList = readStatsByLevel(Level.COLUMN_RULE_LEVEL);
		
		updatesCollected =  true;
		
		
		if(!feedStatsList.isEmpty())
			StatsFileLoader.stateId = ((FeedStats)feedStatsList.get(0)).getStateID() ;
		
		ZebraBatchDAO.log(StatsFileLoader.application_id,StatsFileLoader.user_Id,"Stats file read finished",""+StatsFileLoader.stateId);
		
	}
	
	public List<TableValueObjectBase> readStatsByLevel(Level level) throws ZebraBatchException {
		
		List<TableValueObjectBase> statsList = new ArrayList<TableValueObjectBase>();
		
		statsFilePatterns = new ArrayList<String> () ;
		
		if(level == Level.FEED_LEVEL){
			this.statsFilePatterns.add(StatsFileConstants.MR_OUT_FEED_LEVEL_FILE_NAME);		
		}else if(level == Level.COLUMN_LEVEL){
			this.statsFilePatterns.add(StatsFileConstants.MR_OUT_COLUMN_LEVEL_FILE_NAME);
			this.statsFilePatterns.add(StatsFileConstants.MR_OUT_COMPLEX_COLUMN_LEVEL_FILE_NAME);
		}else if(level == Level.COLUMN_RULE_LEVEL){
			this.statsFilePatterns.add(StatsFileConstants.MR_OUT_COLUMN_RULE_LEVEL_FILE_NAME);
			this.statsFilePatterns.add(StatsFileConstants.MR_OUT_COMPLEX_COLUMN_RULE_LEVEL_FILE_NAME);
		}
		
		File []  statsFileNameArr =  getStatsFiles();
		
		for(File statfile : statsFileNameArr){
			int lineNumber = 0;
			BufferedReader br =null;
			
			try {
				br = new BufferedReader(new FileReader(statfile));
				lineNumber++;
				String sCurrentLine;
				while ((sCurrentLine = br.readLine()) != null) {
					
					if(Level.FEED_LEVEL == level){
						statsList.add(mapFeedStatsRow(sCurrentLine));
						
					}else if(Level.COLUMN_LEVEL == level){
						
						statsList.add(mapColumnStatsRow(sCurrentLine));
						
					}else if(Level.COLUMN_RULE_LEVEL == level){
						
						statsList.add(mapColumnRuleStatsRow(sCurrentLine));
					}
					
				}
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			finally{
				try {
					br.close();
				} catch (IOException e) {
					throw new ZebraBatchException(e);
				}
			}
		}
		
		if(Level.COLUMN_LEVEL == level){
			mergeColumnLevelStatsDistinctValueCount(statsList);
		}else if(Level.COLUMN_RULE_LEVEL == level){
			mergeColumnRuleLevelStatsDistinctValueCount(statsList);
		}
		
		return statsList;
		
	}
	
	public  File [] getStatsFiles(){
		File [] files = statsDir.listFiles(new FilenameFilter() {
		    @Override
		    public boolean accept(File dir, String name) {
		    	boolean result = false ;
		        for(String statsFilePattern : statsFilePatterns ){
		        	result = name.startsWith(statsFilePattern) ;
		        	if(result){
		        		return result;
		        	}
		        }
		        
		        return result ;
		    }
		});
		return files;
	}
	
	private List<TableValueObjectBase> mergeColumnLevelStatsDistinctValueCount(List<TableValueObjectBase> columnStats){
		
		int cursor = 0 ;

		for(int i=0 ;i < columnStats.size() ; i++){

			//System.out.println("Comparing cursor:"+cursor + "["+columnStats.get(cursor)+"] with index value:["+columnStats.get(i)+"]");
			if(cursor!=i && ((ColumnStats)columnStats.get(cursor)).getColumnID() == ((ColumnStats)columnStats.get(i)).getColumnID()) {
				if(((ColumnStats)columnStats.get(i)).getLevel().equals(Level.COLUMN_LEVEL.name())){
					((ColumnStats)columnStats.get(i)).updateDistinctValueCount(((ColumnStats)columnStats.get(cursor)).getCountDistinctvalues());
					columnStats.set(cursor, columnStats.get(i)) ;
					
				}else if(((ColumnStats)columnStats.get(cursor)).getLevel().equals(Level.COLUMN_LEVEL.name())){
					((ColumnStats)columnStats.get(cursor)).updateDistinctValueCount(((ColumnStats)columnStats.get(i)).getCountDistinctvalues());
				}else{
					((ColumnStats)columnStats.get(cursor)).updateDistinctValueCount(((ColumnStats)columnStats.get(i)).getCountDistinctvalues());
				}
			//	System.out.println("Removing Index:"+i);
				columnStats.remove(i);
				i=-1 ;
				continue ;
			}
			
			if(i == (columnStats.size()-1)){
				
				cursor ++ ;
			//	System.out.println("Resetting cursor to :"+cursor);
				i=-1;
			}
			
			if(cursor == columnStats.size()){
				break ;
			}
		}
		
		return columnStats ;
	}
	
	private List<TableValueObjectBase> mergeColumnRuleLevelStatsDistinctValueCount(List<TableValueObjectBase> columnRuleStats){
		
		int cursor = 0 ;
		for(int i=0 ;i < columnRuleStats.size() ; i++){
			//System.out.println("Comparing cursor:"+cursor + "["+columnRuleStats.get(cursor)+"] with index value:["+columnRuleStats.get(i)+"]");
			if(cursor!=i 
					&& ((ColumnRuleStats)columnRuleStats.get(cursor)).getColumnID() == ((ColumnRuleStats)columnRuleStats.get(i)).getColumnID()
					&& ((ColumnRuleStats)columnRuleStats.get(cursor)).getRuleID() == ((ColumnRuleStats)columnRuleStats.get(i)).getRuleID()
					&& ((ColumnRuleStats)columnRuleStats.get(cursor)).getRuleID() == Long.parseLong(RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT)) {
				

				Long count = Long.parseLong(((ColumnRuleStats)columnRuleStats.get(i)).getValue().toString());
				((ColumnRuleStats)columnRuleStats.get(cursor)).updateDistinctValueCount(count);

				//System.out.println("Removing Index:"+i);
				columnRuleStats.remove(i);
				i=-1 ;
				continue ;
			}
			
			if(i == (columnRuleStats.size()-1)) {
				cursor ++ ;
				//System.out.println("Resetting cursor to :"+cursor);
				i=-1;
			}
			
			if(cursor == columnRuleStats.size()){
				break ;
			}
		}
		
		return columnRuleStats ;
	}
	
	
	public FeedStats mapFeedStatsRow(String statsRow){
		
		String[] fieldValues = statsRow.split(StatsFileConstants.columnDelimiter);
		
		FeedStats stat = new FeedStats();
		stat.setFeedID(Long.parseLong(fieldValues[0]));
		stat.setVolume(Long.parseLong(fieldValues[1]));
		/*
		stat.setMinAlertThresholdVal((CommonMethods.isNullTextValue(fieldValues[2]))?null:Double.parseDouble(fieldValues[2]));
		stat.setMinAbortThresholdVal((CommonMethods.isNullTextValue(fieldValues[3]))?null:Double.parseDouble(fieldValues[3]));
		stat.setMaxAlertThresholdVal((CommonMethods.isNullTextValue(fieldValues[4]))?null:Double.parseDouble(fieldValues[4]));
		stat.setMaxAbortThresholdVal((CommonMethods.isNullTextValue(fieldValues[5]))?null:Double.parseDouble(fieldValues[5]));
		*/
		stat.setAction(fieldValues[6]);
		stat.setStateID (Long.parseLong(fieldValues[7]));
		stat.setMean(Double.parseDouble(fieldValues[8]));
		stat.setStdDev(Double.parseDouble(fieldValues[9]));
		stat.setThresholdType(fieldValues[10]);   
		stat.setMinAlertThreshold((CommonMethods.isNullTextValue(fieldValues[11]))?null:Double.parseDouble(fieldValues[11]));
		stat.setMinAbortThreshold((CommonMethods.isNullTextValue(fieldValues[12]))?null:Double.parseDouble(fieldValues[12]));
		stat.setMaxAlertThreshold((CommonMethods.isNullTextValue(fieldValues[13]))?null:Double.parseDouble(fieldValues[13]));
		stat.setMaxAbortThreshold((CommonMethods.isNullTextValue(fieldValues[14]))?null:Double.parseDouble(fieldValues[14]));
		stat.setPastRuns((CommonMethods.isNullTextValue(fieldValues[15]))?null : Integer.parseInt(fieldValues[15]));
		
		return stat;
	}
	

	public ColumnStats mapColumnStatsRow(String statsRow){
		ColumnStats stats = new ColumnStats();
		
		String[] fieldValues = statsRow.split(StatsFileConstants.columnDelimiter);
		
		stats.setFeedID (Long.parseLong(fieldValues[0]));
		stats.setColumnID(Long.parseLong(fieldValues[1]));
		stats.setColumnName(fieldValues[2]);
		stats.setCountDistinctvalues(Long.parseLong(fieldValues[3]));
		stats.setCountNullValues (Long.parseLong(fieldValues[4]));
		stats.setDataTypeHit(Long.parseLong(fieldValues[5]));
		stats.setAverage(fieldValues[6]);
		stats.setRecordCount (Long.parseLong(fieldValues[7]));
		stats.setMinValue(fieldValues[8]);
		stats.setMaxValue (fieldValues[9]);
		stats.setAction (fieldValues[10]);
		stats.setStateID(Long.parseLong(fieldValues[11]));
		stats.setLevel(fieldValues[12]);
		
		return stats;
	}
	
	public ColumnRuleStats mapColumnRuleStatsRow(String statsRow){
		ColumnRuleStats stats = new ColumnRuleStats();
		
		String[] fieldValues = statsRow.split(StatsFileConstants.columnDelimiter);
		
		stats.setFeedID(Long.parseLong(fieldValues[0]));
		stats.setColumnID(Long.parseLong(fieldValues[1])); 
		stats.setRuleID(Long.parseLong(fieldValues[2]));
		stats.setColumnRuleID(Long.parseLong(fieldValues[3])); 
		stats.setDecisionCount(Long.parseLong(fieldValues[4])); 
		stats.setDecisionRate(CommonMethods.isNumeric(fieldValues[5])?Double.parseDouble(fieldValues[5]):0.0); 
		/*
		stats.setMinAlertThresholdVal((CommonMethods.isNullTextValue(fieldValues[6]))?null:Double.parseDouble(fieldValues[6])); 
		stats.setMinAbortThresholdVal((CommonMethods.isNullTextValue(fieldValues[7]))?null:Double.parseDouble(fieldValues[7])); 
		stats.setMaxAlertThresholdVal((CommonMethods.isNullTextValue(fieldValues[8]))?null:Double.parseDouble(fieldValues[8]));
		stats.setMaxAbortThresholdVal((CommonMethods.isNullTextValue(fieldValues[9]))?null:Double.parseDouble(fieldValues[9]));
		*/
		stats.setAction(fieldValues[10]); 
		stats.setStateID(Long.parseLong(fieldValues[11])); 
		stats.setMean(Double.parseDouble(fieldValues[12]));
		stats.setStdDev(Double.parseDouble(fieldValues[13])); 
		stats.setValue (fieldValues[14]); 
		stats.setThresholdType (fieldValues[15]);   
		stats.setMinAlertThreshold((CommonMethods.isNullTextValue(fieldValues[16]))?null:Double.parseDouble(fieldValues[16])); 
		stats.setMinAbortThreshold((CommonMethods.isNullTextValue(fieldValues[17]))?null:Double.parseDouble(fieldValues[17])); 
		stats.setMaxAlertThreshold((CommonMethods.isNullTextValue(fieldValues[18]))?null:Double.parseDouble(fieldValues[18])); 
		stats.setMaxAbortThreshold((CommonMethods.isNullTextValue(fieldValues[19]))?null:Double.parseDouble(fieldValues[19])); 
		stats.setPastRuns((CommonMethods.isNullTextValue(fieldValues[20]))?null : Integer.parseInt(fieldValues[20]));
		
		return stats;
	}
}
