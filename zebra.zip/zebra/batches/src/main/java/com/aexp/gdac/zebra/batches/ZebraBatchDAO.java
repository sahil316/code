package com.aexp.gdac.zebra.batches;

import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.SLAMetadataDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.SLAStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ZebraLogsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAStats;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.base.jdbc.model.ZebraLogs;

public class ZebraBatchDAO {

	private static org.apache.log4j.Logger log = Logger.getLogger(ZebraBatchDAO.class);
	
	private FeedMetadataDAO feedMdDAO ;
	private ColumnMetadataDAO columnMdDAO ;
	private ColumnRuleMetadataDAO columnRuleMdDAO ;
	private StatsDAO statsDAO ;
	private FeedStatsDAO feedStatsDAO ;
	private ColumnStatsDAO columnStatsDAO;
	private ColumnRuleStatsDAO columnRuleStatsDAO ;
	private SLAMetadataDAO slaMdDAO ;
	private SLAStatsDAO slaStatsDAO ;
	private static ZebraLogsDAO zebraLogsDAO ;


	static{
		zebraLogsDAO = (ZebraLogsDAO) ZebraResourceManager.getBean("zebraLogsDAO");
	}
	
	/*
	public ZebraBatchDAO(){
		feedMdDAO = new FeedMetadataDAO();
		columnMdDAO = new ColumnMetadataDAO();
		columnRuleMdDAO = new ColumnRuleMetadataDAO();
		statsDAO = new StatsDAO();
		feedStatsDAO = new FeedStatsDAO();
		columnStatsDAO = new ColumnStatsDAO();
		columnRuleStatsDAO = new ColumnRuleStatsDAO();
		slaMdDAO = new SLAMetadataDAO();
		slaStatsDAO = new SLAStatsDAO();
		zebraLogsDAO = new ZebraLogsDAO();
		
	}
	
	public void setDataSource(DataSource ds) {

		feedMdDAO.setDataSource(ds);
		columnMdDAO.setDataSource(ds);
		columnRuleMdDAO.setDataSource(ds);
		statsDAO.setDataSource(ds);
		feedStatsDAO.setDataSource(ds);
		columnStatsDAO.setDataSource(ds);
		columnRuleStatsDAO.setDataSource(ds);
		slaMdDAO.setDataSource(ds);
		slaStatsDAO.setDataSource(ds);
		zebraLogsDAO.setDataSource(ds);
		
		
	}
	
*/

	
	public ZebraBatchDAO(){

		 statsDAO = (StatsDAO) ZebraResourceManager.getBean("statsDAO");
		 
		 feedMdDAO = (FeedMetadataDAO) ZebraResourceManager.getBean("feedMetadataDAO");
		 columnMdDAO = (ColumnMetadataDAO) ZebraResourceManager.getBean("columnMetadataDAO");
		 columnRuleMdDAO = (ColumnRuleMetadataDAO) ZebraResourceManager.getBean("columnRuleMetadataDAO");

		 feedStatsDAO = (FeedStatsDAO) ZebraResourceManager.getBean("feedStatsDAO");
		 columnStatsDAO = (ColumnStatsDAO) ZebraResourceManager.getBean("columnStatsDAO");
		 columnRuleStatsDAO = (ColumnRuleStatsDAO) ZebraResourceManager.getBean("columnRuleStatsDAO");
		 
		 slaStatsDAO = (SLAStatsDAO) ZebraResourceManager.getBean("slaStatsDAO") ;
		 slaMdDAO =  (SLAMetadataDAO) ZebraResourceManager.getBean("slaMetadataDAO") ;
		 

	}

	
	
	public Stats getNextEligibleStats() throws ZebraBatchException{
		Stats stats = null;
		try{
			stats = (Stats) statsDAO.getNextEligibleStats();
		}catch(ZebraServiceException zse){
			log.error("Error Occured While fetching Stats ",zse);
			throw new ZebraBatchException("Error Occured While fetching Stats ",ZebraBatchException.Reason.DB_ERROR,zse);
		}
		return stats;
	}
	
	public Stats getStatsByStateID(long stateId) throws ZebraBatchException{
		Stats stats = null;
		try{
			stats = (Stats) statsDAO.getObjectByPrimaryKey(stateId);
		}catch(ZebraServiceException zse){
			log.error("Error Occured While fetching Stats ",zse);
			throw new ZebraBatchException("Error Occured While fetching Stats ",ZebraBatchException.Reason.DB_ERROR,zse);
		}
		return stats;
	}
	
	public Stats getNextEligibleStatsByFeedId(long feedId) throws ZebraBatchException{
		Stats stats = null;
		try{
			stats = (Stats) statsDAO.getNextEligibleStatsByFeedID(feedId);
		}catch(ZebraServiceException zse){
			log.error("Error Occured While fetching Stats ",zse);
			throw new ZebraBatchException("Error Occured While fetching Stats ",ZebraBatchException.Reason.DB_ERROR,zse);
		}
		return stats;
	}
	
	public FeedMetadata getEligibleFeedMetadata(long feedId) throws ZebraBatchException{
		FeedMetadata feedMd = null;
		try{
			feedMd = (FeedMetadata) feedMdDAO.getEligibleFeedMetadataByFeedId(feedId);		
		}catch(ZebraServiceException zse){
			log.error("Error Occured while fetching FeedMetadata for FeedID "+feedId,zse);
			throw new ZebraBatchException("Error Occured while fetching FeedMetadata for FeedID "+feedId,ZebraBatchException.Reason.DB_ERROR);
		}
		
		return feedMd;
	}
	
	public List<ColumnMetadata> getEligibleColumnMetadata(long feedId) throws ZebraBatchException{
	try{
			return columnMdDAO.getEligibleColumnMetadataByFeedID(feedId, 0, -1);
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Fetching ColumnMetadata for FeedID "+feedId,zse);
			throw new ZebraBatchException("Exception Occured while Fetching ColumnMetadata for FeedID "+feedId,ZebraBatchException.Reason.DB_ERROR);
		}

	}
	
	public List<ColumnRuleMetadata> getEligibleColumRuleMetadata(long feedID,long columnId)  throws ZebraBatchException{
		try{
			return columnRuleMdDAO.getEligibleColumnRuleMetadataByColumnIDAndFeedID(feedID,columnId, 0, -1);
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Fetching ColumnRuleMetadata for FeedId"+feedID+""+columnId,zse);
			throw new ZebraBatchException("Exception Occured while Fetching ColumnRuleMetadata for FeedId"+feedID+""+columnId,ZebraBatchException.Reason.DB_ERROR);
		}
	}
	
	public Long registerStats(Stats stat) throws ZebraBatchException{
		try {
			return (Long)statsDAO.create(stat);
		} catch (ZebraServiceException zse) {
			log.error("Error Occured While inserting Stats ",zse);
			throw new ZebraBatchException("Error Occured While inserting Stats ",ZebraBatchException.Reason.DB_ERROR,zse);
		}
	}
	
	
	public void updateStatsErrorMessage(Stats stat) throws ZebraBatchException{
		try {
			statsDAO.updateStatsErrorMessage(stat);
		} catch (ZebraServiceException zse) {
			log.error("Error Occured While updating Stats ErrorMessage ",zse);
			throw new ZebraBatchException("Error Occured While updating Stats error message ",ZebraBatchException.Reason.DB_ERROR,zse);
		}
	}
	
	public List<Stats> getStatsCreatedBetweenDates(long feedID, Timestamp firstDate, Timestamp secondDate) throws ZebraBatchException{
		try{
			return statsDAO.getStatsCreatedBetweenDates(feedID, firstDate, secondDate) ;
		}catch(ZebraServiceException zse) {
			log.error("Error Occured While fetching Stats ErrorMessage ",zse);
			throw new ZebraBatchException("Error Occured While fetching Stats  ",ZebraBatchException.Reason.DB_ERROR,zse);
		}
	}
	
	
	public List getFeedStatsPassedPastRuns(long feedId,int pastRuns) throws ZebraServiceException{
		List ret = feedStatsDAO.getFeedStatsPassedPastRuns(feedId, 0, pastRuns);
		//log.info("FeedStats:"+ret.size()+" past run fetched for FeedID "+feedId);
		return ret;
		
	}
	
	public List getColumnRuleStatsPassedPastRuns(long feedId, long columnId, long ruleId,int pastRuns) throws ZebraServiceException{
		List ret = columnRuleStatsDAO.getColumnRuleStatsPassedPastRuns(feedId, columnId, ruleId, 0, pastRuns);
		//log.info("ColumnRuleStats:"+ret.size()+" past run fetched for FeedID "+feedId+", ColumnID "+columnId+", RuleID "+ruleId);
		return ret;  
		
	}
	
	public long updateStatsAction(Stats svo) throws ZebraServiceException{
		return statsDAO.updateStatsAction(svo);
	}
	
	public long updateStatsExecDetails(Stats svo) throws ZebraServiceException{
		return statsDAO.updateStatsExecDetails(svo);
	}
	
	public void insetColumnRuleStats(ColumnRuleStats colRuleStat) throws ZebraServiceException{
		columnRuleStatsDAO.create(colRuleStat);
	}
	
	public void insetColumnStats(ColumnStats colStat) throws ZebraServiceException{
		columnStatsDAO.create(colStat);
	}
	
	public void insertFeedStats(FeedStats feedStat) throws ZebraServiceException{
		feedStatsDAO.create(feedStat);
	}
	
	
	public static void log(String application_id,String user_id,String log_entry,String stateID) throws ZebraBatchException{
			ZebraLogs log = new ZebraLogs(application_id,user_id,log_entry,stateID);
			insertLogs(log);

	}
	
	
	public static void logError(String application_id, String user_id, String stateID, Throwable t) throws ZebraBatchException{
		String log_entry = CommonMethods.exceptionStackTrace(t);
		
		if(log_entry.length() > 7999){
			log_entry = log_entry.substring(0,7999);
		}
		
		ZebraLogs log = new ZebraLogs(application_id,user_id,log_entry,stateID);
		insertLogs(log);

	}

	
	public List<SLAMetadata> getEligibleSLAMetadata()  throws ZebraBatchException{
		try{
			return slaMdDAO.getEligibleSLAMetadataList();
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Fetching SLAMetadata ",zse);
			throw new ZebraBatchException("Exception Occured while Fetching SLAMetadata",ZebraBatchException.Reason.DB_ERROR);
		}
	}
	
	public SLAMetadata getEligibleSLAMetadataByFeedId(long feedId)  throws ZebraBatchException{
		try{
			return slaMdDAO.getEligibleSLAMetadataByFeedId(feedId);
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Fetching SLAMetadata ",zse);
			throw new ZebraBatchException("Exception Occured while Fetching SLAMetadata",ZebraBatchException.Reason.DB_ERROR);
		}
	}
	
	public List getUnprocessedSLAStatsByFeedId(long feedID) throws ZebraBatchException{
		try{
			return slaStatsDAO.getUnprocessedSLAStatsByFeedId(feedID) ;
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Fetching SLAStats ",zse);
			throw new ZebraBatchException("Exception Occured while Fetching SLAStats",ZebraBatchException.Reason.DB_ERROR);
		}
	}
	
	public int updateSLAStatus(SLAStats slaStat) throws ZebraBatchException{
		try{
			return slaStatsDAO.updateSLAStatus(slaStat) ;
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Updating SLAStats ",zse);
			throw new ZebraBatchException("Exception Occured while Updating SLAStats",ZebraBatchException.Reason.DB_ERROR);
		}
	}
	
	public Object insertSLAStats(SLAStats slaStat) throws ZebraBatchException{
		try{
			return slaStatsDAO.create(slaStat) ;
		}catch(ZebraServiceException zse){
			log.error("Exception Occured while Fetching SLAStats ",zse);
			throw new ZebraBatchException("Exception Occured while inserting SLAStats",ZebraBatchException.Reason.DB_ERROR);
		}
	}
	
	public static void insertLogs(ZebraLogs zebraLog) throws ZebraBatchException{
		try {
			if(zebraLogsDAO==null){
				zebraLogsDAO = (ZebraLogsDAO) ZebraResourceManager.getBean("zebraLogsDAO");
			}
			zebraLogsDAO.create(zebraLog);
			
		} catch (ZebraServiceException zse) {
			throw new ZebraBatchException("Exception while db logging ", ZebraBatchException.Reason.DB_ERROR ,zse);
		}
	}
}
