package com.aexp.gdac.zebra.batches;

import java.io.IOException;


public class ZebraBatchException extends Exception {
	
	private Reason reason ;

	public ZebraBatchException(Exception e) {
		// TODO Auto-generated constructor stub
		super(e);
		this.reason = Reason.UNEXPECTED_EXCEPTION ;
	}

	public ZebraBatchException(String message){
		super(message);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraBatchException(Reason reason){
		this.reason = reason;
	}
	
	public ZebraBatchException(String message ,Reason reason){
		super(message);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraBatchException(String message , Throwable cause){
		super(message,cause);
		this.reason = Reason.UNEXPECTED_EXCEPTION ;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraBatchException(Throwable cause){
		super(cause);
		this.reason = Reason.UNEXPECTED_EXCEPTION ;
	}
	
	public ZebraBatchException(Reason reason,Throwable cause){
		super(cause);
		this.reason = reason ;
	}
	
	public ZebraBatchException(String message ,Reason reason,Throwable cause){
		super(message,cause);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public Reason getReason() {
		return reason;
	}

	public void setReason(Reason reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "ZebraBatchException [reason=" + reason + " desc:"+reason.getReasonDesc()+"]";
	}
	
	
	public enum Reason{
		SKIP_DAY_EXCEPTION("Exception Occured While Checking Skip Day"),
		REST_CLIENT_ERROR("Exception occred while calling rest service"),
		DB_ERROR("Exception Occured while Accessing DB "),
		METADATA_GENERATOR_EXCEPTION("Exception occured while generating md file"),
		STATS_GENERATOR_EXCEPTION("Exception occured while generating stats using MR JOB file"),
		STATS_LOADER_EXCEPTION("Exception occured while loading stats file"),
		NOTHING_TO_PROCESS("Request not found for processing"),
		CANNOT_PROCEED_EXCEPTION("Insufficent Input , Cannot proceed"),
		MAIL_SENDER_EXCEPTION("Exception occured while sending mail"),
		UNEXPECTED_EXCEPTION("Unexpected exception occured"),
		BAD_RECORD_EXCEPTION("Exception occred while processing bad records");
		
		private String reasonDesc ;
		
		private Reason(){
		}
		
		private Reason(String desc){
			reasonDesc = desc ;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}
		
	}
	
}
