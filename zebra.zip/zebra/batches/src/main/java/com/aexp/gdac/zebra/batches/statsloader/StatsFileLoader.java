package com.aexp.gdac.zebra.batches.statsloader;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.batches.CommonStatsWriter;
import com.aexp.gdac.zebra.batches.TaskInputParams;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;
import java.sql.Timestamp;
import org.apache.log4j.Logger;

public class StatsFileLoader
{
  private static Logger log = Logger.getLogger(StatsFileLoader.class);
  private CommonStatsWriter stats;
  public static final String application_id = "StatsFileLoader";
  
  public static String user_Id;
  private static String interm_file ;
  
  
  public static int feed_stats_count;
  public static int column_stats_count;
  public static int column_rule_stats_count;
  public static String action;
  public static StringBuilder failedRule = new StringBuilder("");
  public static long stateId;
  private static String statsOutputDir;
  private static boolean masterRun;
  private StatsDecisionHandler decisionHandler;
  
  public static void main(String[] args)
    throws ZebraBatchException
  {
    if (args.length < 2)
    {
      log.error("java com.aexp.gdac.zebra.batches.statsloader.StatsFileLoader --statsOutDir=<stats-files-directory> --stateId=<state-id>"
      		+ " --userId=<optional-user-id> --masterRun=<optional-master-run> --intermFile=<job-intermediate-file>");
      System.exit(1);
    }
    
    /*
    statsOutputDir = args[0];
    stateId = Long.parseLong(args[1]);
    if (args.length > 2) {
      user_Id = args[2];
    }
    if ((args.length > 3) && ("true".equals(args[3]))) {
      masterRun = true;
    }
    */
    log.info("Started at " + new Timestamp(System.currentTimeMillis()));
    ZebraBatchDAO.log("StatsFileLoader", user_Id, "Started at " + new Timestamp(System.currentTimeMillis()) , "" + stateId);
    
    StatsFileLoader statsLoader = new StatsFileLoader(args);
    statsLoader.loadStatsFromFiles(statsOutputDir);
    
    log.info("Finished at " + new Timestamp(System.currentTimeMillis()));
    ZebraBatchDAO.log("StatsFileLoader", user_Id, "Finished at " + new Timestamp(System.currentTimeMillis()) , "" + stateId);
    if (!masterRun)
    {
      statsLoader.printStats();
      System.exit(0);
    }
  }
  
  private StatsFileLoader(String[] args)
  {
	loadNamedParemeters(args);
    this.stats = new CommonStatsWriter(interm_file);
    this.decisionHandler = ((StatsDecisionHandler)ZebraResourceManager.getBean("statsDecisionHandler"));
  }
  
	private void loadNamedParemeters(String[] args){
		
		StringBuilder user_args = new StringBuilder("");
		
		for(String arg : args){
			if(arg == null){
				continue ;
			}
			
			user_args.append(arg + " ");
			
			if(arg.contains(TaskInputParams.stateId)){
				this.stateId = Long.parseLong(TaskInputParams.getParameterValue(arg)); 
			}else if(arg.contains(TaskInputParams.statsOutDir)){
				this.statsOutputDir = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.userId)){
				this.user_Id = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.masterRun)){
				this.masterRun = Boolean.parseBoolean(TaskInputParams.getParameterValue(arg)); 
			}else if(arg.contains(TaskInputParams.intermFile)){
				this.interm_file = TaskInputParams.getParameterValue(arg);
			}
		}
		
		log.info("USER ARGS : ["+ user_args.toString() + "]");
	}
  
  private void loadStatsFromFiles(String statsDirectory)
    throws ZebraBatchException
  {
    try
    {
      StatsFileHandler fileHandler = new StatsFileHandler(statsDirectory);
      fileHandler.collectStats();
      
      this.decisionHandler.setStatsFileHandler(fileHandler);
      
      ZebraBatchDAO.log("StatsFileLoader", user_Id, "Stats DB loading started","" + stateId);
      
      int attempt = 0;
      boolean success = false;
      while (!success) {
        try
        {
          this.decisionHandler.updateStats();
          success = true;
        }
        catch (IllegalArgumentException iae)
        {
          if (attempt < this.decisionHandler.getRetryCount())
          {
            attempt++;
            log.info("Stats Load Failed , Retry : " + attempt);
          }
          else
          {
            throw iae;
          }
        }
      }
      ZebraBatchDAO.log("StatsFileLoader", user_Id, "Stats DB loading finished ","" + stateId);
    }
    catch (IllegalArgumentException iae) {
      log.error("Unexpected Excpetion Occured , Loaded data is RolledBack! ", iae);
      ZebraBatchDAO.logError("StatsFileLoader", user_Id, ""+stateId,iae);
      
      System.err.print("Unexpected Excpetion Occured, Loaded date is RolledBack! , Check logs " + iae.getMessage());
      if (!masterRun)
      {
        writeStatsRow("Error Message", "Unexpected Excpetion Occured for Stats Dir :" + statsOutputDir + ", Check logs " + iae.getMessage(), true);
        updateStatus(stateId, iae.getMessage());
        System.exit(1);
      }
      ZebraBatchDAO.logError("StatsFileLoader", user_Id ,"" + stateId,iae);
      
      throw new ZebraBatchException(ZebraBatchException.Reason.STATS_LOADER_EXCEPTION, iae);
    }
    catch (ZebraBatchException zbe)
    {
      log.error("Batch Job Failed ! ", zbe);
      System.err.print("Batch Job Failed , Check logs " + zbe.getMessage());
      if (!masterRun)
      {
        writeStatsRow("Error Message", "Batch Job Failed for Stats Dir :" + statsOutputDir + ", Check logs " + zbe.getMessage(), true);
        updateStatus(stateId, zbe.getMessage());
        System.exit(1);
      }
      ZebraBatchDAO.logError("StatsFileLoader", user_Id,"" + stateId,zbe);
      
      throw zbe;
    }
    catch (Exception e)
    {
      log.error("Unexpected Excpetion Occured ! ", e);
      System.err.print("Unexpected Excpetion Occured , Check logs " + e.getMessage());
      if (!masterRun)
      {
        writeStatsRow("Error Message", "Unexpected Excpetion Occured for Stats Dir :" + statsOutputDir + ", Check logs " + e.getMessage(), true);
        updateStatus(stateId, e.getMessage());
        System.exit(1);
      }
      ZebraBatchDAO.logError("StatsFileLoader", user_Id,"" + stateId,e);
      
      throw new ZebraBatchException(ZebraBatchException.Reason.STATS_LOADER_EXCEPTION, e);
    }
  }
  
  private void printStats() {	
	
    writeStatsRow("Stats Input Dir", statsOutputDir, false);
    writeStatsRow("Feed Stats Count", "" + feed_stats_count, false);
    writeStatsRow("Column Stats Count", "" + column_stats_count, false);
    writeStatsRow("Column Rule Stats Count", "" + column_rule_stats_count, false);
    writeStatsRow("Action", "" + action, true);
  }
  
  private void writeStatsRow(String label, String value, boolean isLast)
  {
    this.stats.insertRow(label, value, isLast);
  }
  
  private static void updateStatus(long stateID, String message)
    throws ZebraBatchException
  {
    Stats stat = new Stats();
    
    stat.setStateID(Long.valueOf(stateID));
    stat.setErrorMessage(message);
    
    StatsDAO statsDAO = (StatsDAO)ZebraResourceManager.getBean("statsDAO");
    try
    {
      statsDAO.updateStatsErrorMessage(stat);
    }
    catch (ZebraServiceException e)
    {
      throw new ZebraBatchException("Exception Occured while updating stats status ", ZebraBatchException.Reason.UNEXPECTED_EXCEPTION, e);
    }
  }
}
