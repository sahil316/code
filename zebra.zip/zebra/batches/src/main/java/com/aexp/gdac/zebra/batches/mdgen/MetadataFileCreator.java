package com.aexp.gdac.zebra.batches.mdgen;

import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.model.Stats.ExecMode;
import com.aexp.gdac.zebra.base.metadata.Metadata;
import com.aexp.gdac.zebra.base.metadata.MetadataParser;
import com.aexp.gdac.zebra.batches.CommonStatsWriter;
import com.aexp.gdac.zebra.batches.TaskInputParams;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;


/**
 * Program performs following operations
 * 1) Generates Metadata File for the next STATS entry to be processed for the day.
 * 2) Validates input feed file 
 * 
 * @author a.atri
 *
 */

public class MetadataFileCreator {
	private static org.apache.log4j.Logger log = Logger.getLogger(MetadataFileCreator.class);
	
	public static final String application_id = "MetadataFileCreator";
	public static String user_Id ;
	
	private CommonStatsWriter stats ;
	private ZebraBatchDAO zebraBatchDAO ;
	public static String inputFilePath ;
	public static String header="false" ;
	public static String tailer="false" ;
	public static String metadataFile;
	public static String feedName;
	public static String statsOutPutDir;
	public static String targetEmailId;
	public static String stateId;
	public static String feedId;
	public static String mdOutDir ;
	
	private static String intermFile ;
	

	
	public static boolean masterRun ;
	
	
	public static void main(String args[]) throws ZebraBatchException{
		if(args.length < 1 ){
			System.out.println("java com.aexp.gdac.zebra.batches.mdgen.MetadataFileCreator --mdOutDir=<md-out-dir> --userId=<optional-userid>"
					+ " --feedId=<optional-feedid> --masterRun=<optional-master-run> --intermFile=<interm-file> --stateId=<state-id>");
			System.exit(1);
		}
		/*mdOutDir = args[0];
		
		if(args.length > 1){		
			user_Id = args[1];
		}
		
		if(args.length > 2){
			feedId = args[2];
		}
		
		if(args.length > 3){
			stateId = args[3] ;
		}
		
		if(args.length > 4 && "true".equals(args[4])){
			masterRun = true ;
		}
		*/
		
		log.info("Metadata Generation Started at "+ new Timestamp(System.currentTimeMillis()));
		
		ZebraBatchDAO.log(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,"Metadata Generation Started at "+ new Timestamp(System.currentTimeMillis()),MetadataFileCreator.stateId);

		
		MetadataFileCreator mdGen = new MetadataFileCreator(args);
		mdGen.generateMetadataFile(mdOutDir);

		log.info("Metadata Generation Finished at " + new Timestamp(System.currentTimeMillis()));
		
		ZebraBatchDAO.log(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,"Metadata Generation Finished at " + new Timestamp(System.currentTimeMillis()),MetadataFileCreator.stateId);
		
		if(!masterRun){
			mdGen.printStats();
			System.exit(0);
		}
	}
	
	public MetadataFileCreator(String[] args){
		loadNamedParemeters(args);
		stats = new CommonStatsWriter(this.intermFile);
		zebraBatchDAO = new ZebraBatchDAO();
	}
	
	private void loadNamedParemeters(String[] args){
		StringBuilder user_args = new StringBuilder("");
		
		for(String arg : args){
			if(arg == null){
				continue ;
			}
			
			user_args.append(arg + " ");

			if(arg.contains(TaskInputParams.feedId)){
				this.feedId =TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.stateId)){
				this.stateId = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.mdOutDir)){
				this.mdOutDir = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.userId)){
				this.user_Id = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.masterRun)){
				this.masterRun = Boolean.parseBoolean(TaskInputParams.getParameterValue(arg)); 
			}else if(arg.contains(TaskInputParams.intermFile)){
				this.intermFile = TaskInputParams.getParameterValue(arg);
			}
			
		}
		
		log.info("USER ARGS : ["+ user_args.toString() + "]");
	}
	

	private void generateMetadataFile(String metadataOutDir) throws ZebraBatchException{
		MetadataRowMapper mdRowMapper = new MetadataRowMapper();
		try {

			Metadata metadata = new Metadata();
			metadata.setMetadataList(mdRowMapper.getMetadataRowList());
			
			/* Marks feed run in progress */
			if(mdRowMapper.getCurrentStat() != null){
				mdRowMapper.getCurrentStat().setProcessDate(new Timestamp(new Date().getTime()));
				
				if(masterRun){
					mdRowMapper.getCurrentStat().setExecMode(ExecMode.MANUAL.name());
				}else{
					mdRowMapper.getCurrentStat().setExecMode(ExecMode.AUTO.name());
				}
				
				zebraBatchDAO.updateStatsExecDetails(mdRowMapper.getCurrentStat());
			}
			
			setProperties(mdRowMapper,metadataOutDir);
			
			try {
				ZebraBatchDAO.log(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,"Metadata file generation started",MetadataFileCreator.stateId);
				
				MetadataParser.unmarshallMetadata(metadata, MetadataFileCreator.metadataFile);
				
				ZebraBatchDAO.log(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,"Metadata file generation finished",MetadataFileCreator.stateId);
			} catch (ZebraServiceException zse) {
				ZebraBatchDAO.logError(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,MetadataFileCreator.stateId,zse);
				log.error("Error Occured while unmarsahlling metadata ",zse);
				throw new ZebraBatchException("Error Occured while unmarsahlling metadata ",ZebraBatchException.Reason.METADATA_GENERATOR_EXCEPTION,zse);
			}

			
		} catch (ZebraBatchException zbe) {
			if(!masterRun){
					if(zbe.getReason() == ZebraBatchException.Reason.NOTHING_TO_PROCESS){
						log.info(zbe.getReason().getReasonDesc());
						System.err.println(zbe.getReason().getReasonDesc()+" Exiting process");
						
						try {
							if(mdRowMapper.getCurrentStat() != null){
								mdRowMapper.getCurrentStat().setErrorMessage("Message:"+zbe.getReason().getReasonDesc());
								zebraBatchDAO.updateStatsErrorMessage(mdRowMapper.getCurrentStat());
							}
						} catch (Exception e) {
							log.error("Failed while updating stats:"+stats,e);
						}
						writeStatsRow("Message:",zbe.getReason().getReasonDesc(),true);
						
						System.exit(0);
						System.out.println("Process Exited");
						
					}else{
						log.error("Metadata Generation Failed ! ",zbe);
						System.err.println("Metadata Generation Failed , Check logs "+zbe.getMessage());
						
							try {
								if(mdRowMapper.getCurrentStat() != null){
									mdRowMapper.getCurrentStat().setErrorMessage("Message:"+zbe.getReason().getReasonDesc());
									zebraBatchDAO.updateStatsErrorMessage(mdRowMapper.getCurrentStat());
								}
							} catch (Exception e) {
								log.error("Metadata Generation Failed while updating stats:"+stats,e);
							}
							
							writeStatsRow("Message:","Batch Job Failed , Check logs : "+zbe.getReason().getReasonDesc(),true);
							System.exit(1);
					}
			}else{
				log.error("Metadata Generation Failed !",zbe);
			}
			
			ZebraBatchDAO.logError(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,MetadataFileCreator.stateId,zbe);
			
			throw zbe;
			
		}	catch(Exception e){
		  log.error("Metadata Generation Failed ,Unexpected Excpetion Occured ! ",e);
		  System.err.println("Unexpected Excpetion Occured , Check logs "+e.getMessage());
		  if(!masterRun){
			   try {
					if(mdRowMapper.getCurrentStat() != null){
						mdRowMapper.getCurrentStat().setErrorMessage("Message:"+e.getMessage());
						zebraBatchDAO.updateStatsErrorMessage(mdRowMapper.getCurrentStat());
					}
				} catch (Exception ex) {
					log.error("Failed while updating stats:"+stats,ex);
				}
				
				writeStatsRow("Message:","Unexpected Excpetion Occured , Check logs "+e.getMessage(),true);
				
				System.exit(1);
		  }
		  
		  ZebraBatchDAO.logError(MetadataFileCreator.application_id,MetadataFileCreator.user_Id,MetadataFileCreator.stateId,e);
		  
		  throw new ZebraBatchException("Unexpected Exception Occured "+e.getMessage() ,e);
		  
		}

	}
	
	private void setProperties(MetadataRowMapper mdRowMapper,String metadataOutDir){
		MetadataFileCreator.inputFilePath = mdRowMapper.getCurrentStat().getInputFilePath();
		MetadataFileCreator.feedName = mdRowMapper.getCurrentStat().getFeedName() ;
		long timeStamp =new Date().getTime();
		MetadataFileCreator.metadataFile = metadataOutDir+"/"+mdRowMapper.getCurrentStat().getFeedName().replace(" ", "_")
										+"_"+mdRowMapper.getCurrentStat().getFeedID()
										+"_"+mdRowMapper.getCurrentStat().getStateID()
										+"_"+timeStamp
										+".md";
		MetadataFileCreator.stateId = ""+mdRowMapper.getCurrentStat().getStateID();
		MetadataFileCreator.feedId = ""+mdRowMapper.getCurrentStat().getFeedID();
		//MetadataFileCreator.headerTailer = mdRowMapper.getCurrentStat().getHeaderTailer();
		MetadataFileCreator.statsOutPutDir= metadataOutDir+"/MR_OUTPUT_DIR_"+mdRowMapper.getCurrentStat().getFeedName().replace(" ", "_")
				+"_"+mdRowMapper.getCurrentStat().getFeedID()
				+"_"+mdRowMapper.getCurrentStat().getStateID()
				+"_"+timeStamp;
	}
	
	private void printStats(){
		writeStatsRow("StateID",MetadataFileCreator.stateId,false);
		writeStatsRow("FeedID",MetadataFileCreator.feedId,false);
		writeStatsRow("MetadataFile",MetadataFileCreator.metadataFile,false);
		writeStatsRow("InputFilePath",MetadataFileCreator.inputFilePath,false);
		writeStatsRow("Header",MetadataFileCreator.header,false);
		writeStatsRow("Tailer",MetadataFileCreator.tailer,false);
		writeStatsRow("FeedName",MetadataFileCreator.feedName,false);
		writeStatsRow("EmailId",MetadataFileCreator.targetEmailId,false);
		writeStatsRow("MROutputDir",MetadataFileCreator.statsOutPutDir,true);

	}
	
	private void writeStatsRow(String label, String value, boolean isLast) {
		stats.insertRow(label, value, isLast);

    }
	

}
