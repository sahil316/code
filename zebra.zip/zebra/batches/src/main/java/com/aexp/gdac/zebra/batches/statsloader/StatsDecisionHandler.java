package com.aexp.gdac.zebra.batches.statsloader;

import com.aexp.gdac.zebra.base.Action;
import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnRuleStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.ColumnStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.FeedStatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.batches.ZebraBatchException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class StatsDecisionHandler
{
  private static Logger log = Logger.getLogger(StatsDecisionHandler.class);
  private StatsFileHandler statsFileHandler;
  private StatsDAO statsDAO;
  private FeedStatsDAO feedStatsDAO;
  private ColumnStatsDAO columnStatsDAO;
  private ColumnRuleStatsDAO columnRuleStatsDAO;
  private int retryCount;
  
  public int getRetryCount()
  {
    return this.retryCount;
  }
  
  public void setRetryCount(int retryCount)
  {
    this.retryCount = retryCount;
  }
  
  public void setStatsDAO(StatsDAO statsDAO)
  {
    this.statsDAO = statsDAO;
  }
  
  public void setFeedStatsDAO(FeedStatsDAO feedStatsDAO)
  {
    this.feedStatsDAO = feedStatsDAO;
  }
  
  public void setColumnStatsDAO(ColumnStatsDAO columnStatsDAO)
  {
    this.columnStatsDAO = columnStatsDAO;
  }
  
  public void setColumnRuleStatsDAO(ColumnRuleStatsDAO columnRuleStatsDAO)
  {
    this.columnRuleStatsDAO = columnRuleStatsDAO;
  }
  
  public void setStatsFileHandler(StatsFileHandler statsFileHandler)
  {
    this.statsFileHandler = statsFileHandler;
  }
  
  @Transactional(propagation=Propagation.REQUIRED)
  public void updateStats()
  {
    try
    {
      if (!StatsFileHandler.updatesCollected) {
        this.statsFileHandler.collectStats();
      }
      
      FeedStats feedStat = (FeedStats)this.statsFileHandler.getStatsByLevel(Level.FEED_LEVEL).get(0);
      
      Action feedLevelAction = updateFeedStats(feedStat);
      
      Action columLevelAction = updateColumnAndColumnRuleStats();
      
      Stats stats = new Stats();
      stats.setFeedID(Long.valueOf(feedStat.getFeedID()));
      stats.setStateID(Long.valueOf(feedStat.getStateID()));
      
      if (columLevelAction.getActoinCode() > feedLevelAction.getActoinCode()) {
        stats.setAction(columLevelAction.name());
      } else {
        stats.setAction(feedLevelAction.name());
      }
      
      stats.setProcessDate(new Timestamp(new Date().getTime()));
      
      StatsFileLoader.action = stats.getAction();
      
      log.info("Updating Stats Action:" + stats);
      
      this.statsDAO.updateStatsAction(stats);

    }
    catch (ZebraServiceException zse)
    {
      throw new IllegalArgumentException("Exception Occured while updating Stats in DB ", zse);
    }
    catch (ZebraBatchException zbe)
    {
      throw new IllegalArgumentException("Exception Occured while loading Stats ", zbe);
    }
  }
  
  public Action updateFeedStats(FeedStats feedStat)
    throws ZebraServiceException, ZebraBatchException
  {
    double compareValue = 0.0D;
    if (Function.Percentage.name().equals(feedStat.getThresholdType()))
    {
      if (feedStat.getPastRuns() == null) {
        feedStat.setPastRuns(Integer.valueOf(0));
      }
      double mean = 0.0D;
      compareValue = feedStat.getVolume();
      
      List feedStatsPastRunList = this.feedStatsDAO.getFeedStatsPassedPastRuns(Long.valueOf(feedStat.getFeedID()), 0, feedStat.getPastRuns().intValue());
      if (feedStatsPastRunList.isEmpty()) {
        mean = feedStat.getVolume();
      } else {
        mean = CommonMethods.formatNaN("" + calculatePastRunMean(feedStatsPastRunList, Level.FEED_LEVEL));
      }
      double stdDev = CommonMethods.formatNaN("" + calculatePastRunStdDev(feedStatsPastRunList, Level.FEED_LEVEL));
      if (feedStat.getMaxAbortThreshold() != null) {
        feedStat.setMaxAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMaxAbortThreshold().doubleValue() / 100.0D * mean))));
      }
      if (feedStat.getMinAbortThreshold() != null) {
        feedStat.setMinAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMinAbortThreshold().doubleValue() / 100.0D * mean))));
      }
      if (feedStat.getMinAlertThreshold() != null) {
        feedStat.setMinAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMinAlertThreshold().doubleValue() / 100.0D * mean))));
      }
      if (feedStat.getMaxAlertThreshold() != null) {
        feedStat.setMaxAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMaxAlertThreshold().doubleValue() / 100.0D * mean))));
      }
      feedStat.setMean(mean);
      feedStat.setStdDev(stdDev);
    }
    else if (Function.StandardDeviation.name().equals(feedStat.getThresholdType()))
    {
      if (feedStat.getPastRuns() == null) {
        feedStat.setPastRuns(Integer.valueOf(0));
      }
      double mean = 0.0D;
      compareValue = feedStat.getVolume();
      
      List<TableValueObjectBase> feedStatsPastRunList = this.feedStatsDAO.getFeedStatsPassedPastRuns(Long.valueOf(feedStat.getFeedID()), 0, feedStat.getPastRuns().intValue());
      if (feedStatsPastRunList.isEmpty()) {
        mean = feedStat.getVolume();
      } else {
        mean = CommonMethods.formatNaN("" + calculatePastRunMean(feedStatsPastRunList, Level.FEED_LEVEL));
      }
      double stdDev = CommonMethods.formatNaN("" + calculatePastRunStdDev(feedStatsPastRunList, Level.FEED_LEVEL));
      if (feedStat.getMaxAbortThreshold() != null) {
        feedStat.setMaxAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMaxAbortThreshold().doubleValue() * stdDev))));
      }
      if (feedStat.getMinAbortThreshold() != null) {
        feedStat.setMinAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMinAbortThreshold().doubleValue() * stdDev))));
      }
      if (feedStat.getMinAlertThreshold() != null) {
        feedStat.setMinAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMinAlertThreshold().doubleValue() * stdDev))));
      }
      if (feedStat.getMaxAlertThreshold() != null) {
        feedStat.setMaxAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + feedStat.getMaxAlertThreshold().doubleValue() * stdDev))));
      }
      feedStat.setMean(mean);
      feedStat.setStdDev(stdDev);
    }
    else if (Function.Absolute.name().equals(feedStat.getThresholdType()))
    {
      compareValue = feedStat.getVolume();
      
      feedStat.setMaxAbortThresholdVal(feedStat.getMaxAbortThreshold());
      feedStat.setMinAbortThresholdVal(feedStat.getMinAbortThreshold());
      feedStat.setMinAlertThresholdVal(feedStat.getMinAlertThreshold());
      feedStat.setMaxAlertThresholdVal(feedStat.getMaxAlertThreshold());
    }
    if (((feedStat.getMinAbortThresholdVal() != null) && (compareValue < feedStat.getMinAbortThresholdVal().doubleValue())) || ((feedStat.getMaxAbortThresholdVal() != null) && (compareValue > feedStat.getMaxAbortThresholdVal().doubleValue()))) {
      feedStat.setAction(Action.ABORT.name());
    } else if (((feedStat.getMinAlertThresholdVal() != null) && (compareValue < feedStat.getMinAlertThresholdVal().doubleValue())) || ((feedStat.getMaxAlertThresholdVal() != null) && (compareValue > feedStat.getMaxAlertThresholdVal().doubleValue()))) {
      feedStat.setAction(Action.ALERT.name());
    } else {
      feedStat.setAction(Action.PASS.name());
    }
    this.feedStatsDAO.create(feedStat);
    StatsFileLoader.feed_stats_count += 1;
    
    
    /** check action and add in summary */
    if(Action.valueOf(feedStat.getAction()) != Action.PASS){
    	StatsFileLoader.failedRule.append( "Feed:"+feedStat.getFeedID() 
    					+ ", Volumn:" + feedStat.getVolume()
    					+ ", Action:" + feedStat.getAction() 
    					+"\n");
    }
    
    return Action.valueOf(feedStat.getAction());
  }
  
  private Action updateColumnAndColumnRuleStats()
    throws ZebraServiceException, ZebraBatchException
  {
    Action feedAction = Action.PASS;
    for (TableValueObjectBase tableValObjBase : this.statsFileHandler.getStatsByLevel(Level.COLUMN_LEVEL))
    {
      ColumnStats colStats = (ColumnStats)tableValObjBase;
      
      colStats.setAction(updateColumRuleStats(colStats).name());
      if (Action.valueOf(colStats.getAction()).getActoinCode() > feedAction.getActoinCode()) {
        feedAction = Action.valueOf(colStats.getAction());
      }
      this.columnStatsDAO.create(colStats);
      StatsFileLoader.column_stats_count += 1;
    }
    return feedAction;
  }
  
  private Action updateColumRuleStats(ColumnStats colStats)
    throws ZebraServiceException, ZebraBatchException
  {
    Action colAction = Action.PASS;
    for (TableValueObjectBase tableValObjBase : this.statsFileHandler.getColumnRuleStatsByColumnId(colStats.getColumnID()))
    {
      ColumnRuleStats colRuleStat = (ColumnRuleStats)tableValObjBase;
      
      colRuleStat.setDecisionCount(getDecisionCount(colRuleStat.getRuleID(), colStats, colRuleStat.getValue()));
      
      if(colStats.getRecordCount()!=0){
    	  colRuleStat.setDecisionRate(colRuleStat.getDecisionCount() / colStats.getRecordCount());
      }
    	  
      
      
      double compareValue = 0.0D;
      if (Function.Percentage.name().equals(colRuleStat.getThresholdType()))
      {
        if (colRuleStat.getPastRuns() == null) {
          colRuleStat.setPastRuns(Integer.valueOf(0));
        }
        double mean = 0.0D;
        compareValue = colRuleStat.getDecisionCount();
        
        List colRuleStatsPastRunList = this.columnRuleStatsDAO.getColumnRuleStatsPassedPastRuns(Long.valueOf(colRuleStat.getFeedID()), Long.valueOf(colRuleStat.getColumnID()), Long.valueOf(colRuleStat.getRuleID()), 0, colRuleStat.getPastRuns().intValue());
        if (colRuleStatsPastRunList.isEmpty()) {
          mean = colRuleStat.getDecisionCount();
        } else {
          mean = CommonMethods.formatNaN("" + calculatePastRunMean(colRuleStatsPastRunList, Level.COLUMN_RULE_LEVEL));
        }
        double stdDev = CommonMethods.formatNaN("" + calculatePastRunStdDev(colRuleStatsPastRunList, Level.COLUMN_RULE_LEVEL));
        if (colRuleStat.getMaxAbortThreshold() != null) {
          colRuleStat.setMaxAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMaxAbortThreshold().doubleValue() / 100.0D * mean))));
        }
        if (colRuleStat.getMinAbortThreshold() != null) {
          colRuleStat.setMinAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMinAbortThreshold().doubleValue() / 100.0D * mean))));
        }
        if (colRuleStat.getMinAlertThreshold() != null) {
          colRuleStat.setMinAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMinAlertThreshold().doubleValue() / 100.0D * mean))));
        }
        if (colRuleStat.getMaxAlertThreshold() != null) {
          colRuleStat.setMaxAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMaxAlertThreshold().doubleValue() / 100.0D * mean))));
        }
        colRuleStat.setMean(mean);
        colRuleStat.setStdDev(stdDev);
      }
      else if (Function.StandardDeviation.name().equals(colRuleStat.getThresholdType()))
      {
        if (colRuleStat.getPastRuns() == null) {
          colRuleStat.setPastRuns(Integer.valueOf(0));
        }
        double mean = 0.0D;
        compareValue = colRuleStat.getDecisionCount();
        
        List<TableValueObjectBase> colRuleStatsPastRunList = this.columnRuleStatsDAO.getColumnRuleStatsPassedPastRuns(Long.valueOf(colRuleStat.getFeedID()), Long.valueOf(colRuleStat.getColumnID()), Long.valueOf(colRuleStat.getRuleID()), 0, colRuleStat.getPastRuns().intValue());
        if (colRuleStatsPastRunList.isEmpty()) {
          mean = colRuleStat.getDecisionCount();
        } else {
          mean = CommonMethods.formatNaN("" + calculatePastRunMean(colRuleStatsPastRunList, Level.COLUMN_RULE_LEVEL));
        }
        double stdDev = CommonMethods.formatNaN("" + calculatePastRunStdDev(colRuleStatsPastRunList, Level.COLUMN_RULE_LEVEL));
        if (colRuleStat.getMaxAbortThreshold() != null) {
          colRuleStat.setMaxAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMaxAbortThreshold().doubleValue() * stdDev))));
        }
        if (colRuleStat.getMinAbortThreshold() != null) {
          colRuleStat.setMinAbortThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMinAbortThreshold().doubleValue() * stdDev))));
        }
        if (colRuleStat.getMinAlertThreshold() != null) {
          colRuleStat.setMinAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMinAlertThreshold().doubleValue() * stdDev))));
        }
        if (colRuleStat.getMaxAlertThreshold() != null) {
          colRuleStat.setMaxAlertThresholdVal(Double.valueOf(CommonMethods.formatNaN("" + (mean + colRuleStat.getMaxAlertThreshold().doubleValue() * stdDev))));
        }
        colRuleStat.setMean(mean);
        colRuleStat.setStdDev(stdDev);
      }
      else if (Function.Absolute.name().equals(colRuleStat.getThresholdType()))
      {
        compareValue = colRuleStat.getDecisionCount();
        
        colRuleStat.setMaxAbortThresholdVal(colRuleStat.getMaxAbortThreshold());
        colRuleStat.setMinAbortThresholdVal(colRuleStat.getMinAbortThreshold());
        colRuleStat.setMinAlertThresholdVal(colRuleStat.getMinAbortThreshold());
        colRuleStat.setMaxAlertThresholdVal(colRuleStat.getMaxAlertThreshold());
      }
      
   /*   log.info("Comapre Value :"+compareValue +" with Min Abort Val:"+ colRuleStat.getMinAbortThresholdVal() 
      +", Max Abort Val: "+colRuleStat.getMaxAbortThresholdVal()  
      +", Min Alert Val:"+ colRuleStat.getMinAlertThresholdVal()
      +", Max Alert Val:"+ colRuleStat.getMaxAlertThresholdVal());
     */ 
      if (((colRuleStat.getMinAbortThresholdVal() != null) && (compareValue < colRuleStat.getMinAbortThresholdVal().doubleValue())) || ((colRuleStat.getMaxAbortThresholdVal() != null) && (compareValue > colRuleStat.getMaxAbortThresholdVal().doubleValue()))) {
        colRuleStat.setAction(Action.ABORT.name());
      } else if (((colRuleStat.getMinAlertThresholdVal() != null) && (compareValue < colRuleStat.getMinAlertThresholdVal().doubleValue())) || ((colRuleStat.getMaxAlertThresholdVal() != null) && (compareValue > colRuleStat.getMaxAlertThresholdVal().doubleValue()))) {
        colRuleStat.setAction(Action.ALERT.name());
      } else {
        colRuleStat.setAction(Action.PASS.name());
      }
      if (Action.valueOf(colRuleStat.getAction()).getActoinCode() > colAction.getActoinCode()) {
        colAction = Action.valueOf(colRuleStat.getAction());
      }
      this.columnRuleStatsDAO.create(colRuleStat);
      /** check acction and add in summary */
      if(Action.valueOf(colRuleStat.getAction()) != Action.PASS){
    	  StatsFileLoader.failedRule.append("Column Name:"+ colStats.getColumnName() 
      			+ ", Rule Name:"+RuleCodeConstants.getRuleName(""+colRuleStat.getRuleID()) 
      			+ ", HitCount:" +colRuleStat.getDecisionCount()
      			+ ", Action:" + colRuleStat.getAction()
      			+ "\n");
      }
      
      StatsFileLoader.column_rule_stats_count += 1;
    }
    return colAction;
  }
  
  private long getDecisionCount(long ruleId, ColumnStats colStats, Object value)
  {
    long decisionCount = 0L;
    if ("1".equals("" + ruleId)) {
      decisionCount = Long.parseLong(value.toString());
    } else if ("2".equals("" + ruleId)) {
      decisionCount = Long.parseLong(value.toString());
    } else if ("3".equals("" + ruleId)) {
      decisionCount = Long.parseLong(value.toString());
    } else if ("4".equals("" + ruleId)) {
      decisionCount = Long.parseLong(value.toString());
    } else if ("5".equals("" + ruleId)) {
      decisionCount = Long.parseLong(value.toString());
    }else if ("12".equals("" + ruleId)) {
        decisionCount = colStats.getRecordCount() - colStats.getCountDistinctvalues();
    }else if ("13".equals("" + ruleId)) {
    	decisionCount = Long.parseLong(value.toString());
    }
    
    else if (!"6".equals("" + ruleId)) {
      if ("7".equals("" + ruleId)) {
        decisionCount = Long.parseLong(value.toString());
      } else if (!"8".equals("" + ruleId)) {
        if ("9".equals("" + ruleId)) {
          decisionCount = Long.parseLong(value.toString());
        } else if ("10".equals("" + ruleId)) {
          decisionCount = Long.parseLong(value.toString());
        } else if ("11".equals("" + ruleId)) {
          decisionCount = Long.parseLong(value.toString());
        }
        
      }
    }
    return decisionCount;
  }
  
  private double calculatePastRunMean(List<TableValueObjectBase> pastStatsList, Level level)
  {
    double[] valueArray = new double[pastStatsList.size()];
    for (int i = 0; i < pastStatsList.size(); i++) {
      if (Level.FEED_LEVEL == level) {
        valueArray[i] = ((FeedStats)pastStatsList.get(i)).getVolume();
      } else if (Level.COLUMN_RULE_LEVEL == level) {
        valueArray[i] = ((ColumnRuleStats)pastStatsList.get(i)).getDecisionCount();
      }
    }
    return CommonMethods.calMean(valueArray);
  }
  
  private double calculatePastRunStdDev(List<TableValueObjectBase> pastStatsList, Level level)
  {
    double[] valueArray = new double[pastStatsList.size()];
    for (int i = 0; i < pastStatsList.size(); i++) {
      if (Level.FEED_LEVEL == level) {
        valueArray[i] = ((FeedStats)pastStatsList.get(i)).getVolume();
      } else if (Level.COLUMN_RULE_LEVEL == level) {
        valueArray[i] = ((ColumnRuleStats)pastStatsList.get(i)).getDecisionCount();
      }
    }
    return CommonMethods.calStandatdDev(valueArray);
  }
  
  private static enum Function
  {
    Percentage,  Mean,  StandardDeviation,  Absolute;
    
    private Function() {}
  }
}
