package com.aexp.gdac.zebra.batches;

public class StatsFileConstants {

	public static final String MR_OUT_FEED_LEVEL_FILE_NAME = "feedstats";
	public static final String MR_OUT_COLUMN_LEVEL_FILE_NAME = "columnstats";
	public static final String MR_OUT_COLUMN_RULE_LEVEL_FILE_NAME = "columnrulestats";
	public static final String MR_OUT_COMPLEX_COLUMN_RULE_LEVEL_FILE_NAME = "columncomplexrulestats";
	public static final String MR_OUT_COMPLEX_COLUMN_LEVEL_FILE_NAME = "columncomplexstats";
	public static final String MR_INPUT_FILE_FORMAT_FIXED = "FIXED";
	public static final String MR_INPUT_FILE_FORMAT_DELIMITER = "DELIMITER";
	public static final String columnDelimiter = "\\|";
	
	
}
