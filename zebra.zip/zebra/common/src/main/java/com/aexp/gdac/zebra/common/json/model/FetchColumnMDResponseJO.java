package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FetchColumnMDResponseJO {
	
	private FetchColumnMDResultJO result ;
	private StatusJO status;
	
	public FetchColumnMDResponseJO(){}
	
	public FetchColumnMDResponseJO(StatusJO status ){
		this.status = status ;
	}
	public FetchColumnMDResultJO getResult() {
		return result;
	}

	public void setResult(FetchColumnMDResultJO result) {
		this.result = result;
	}

	public StatusJO getStatus() {
		return status;
	}

	public void setStatus(StatusJO status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "FetchColumnMDResponseJO [result=" + result + ", status="
				+ status + "]";
	}
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class FetchColumnMDResultJO{
		
		private String feedID;
		private String feedName;
		private String fileFormat ;
		private String userID;
		private String startDate ;
		private String endDate ;

		private List<ColumnMetadataJO> columns;

		public FetchColumnMDResultJO(){}
		
		public void add(ColumnMetadataJO columnMdJo){
			if(this.columns == null){
				this.columns = new ArrayList<ColumnMetadataJO>();
			}
			this.columns.add(columnMdJo);
		}
		public String getFeedID() {
			return feedID;
		}
		public void setFeedID(String feedID) {
			this.feedID = feedID;
		}
		public String getFeedName() {
			return feedName;
		}
		public void setFeedName(String feedName) {
			this.feedName = feedName;
		}
		public List<ColumnMetadataJO> getColumns() {
			return columns;
		}
		public void setColumns(List<ColumnMetadataJO> columns) {
			this.columns = columns;
		}
		
		public String getUserID() {
			return userID;
		}

		public void setUserID(String userID) {
			this.userID = userID;
		}
		public String getFileFormat() {
			return fileFormat;
		}

		public void setFileFormat(String fileFormat) {
			this.fileFormat = fileFormat;
		}
		
		public String getStartDate() {
			return startDate;
		}

		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}

		public String getEndDate() {
			return endDate;
		}

		public void setEndDate(String endDate) {
			this.endDate = endDate;
		}

		@Override
		public String toString() {
			return "FetchColumnMDResultJO [feedID=" + feedID + ", feedName="
					+ feedName + ", userID=" + userID + ", columns=" + columns
					+ "]";
		}
	}
	
}
