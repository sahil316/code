package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FetchFeedMDResponseJO {
	private FeedMetadataJO result;
	private StatusJO status;
	
	public FetchFeedMDResponseJO(){}
	
	public FetchFeedMDResponseJO(StatusJO status){
		this.status = status ;
	}
	public FeedMetadataJO getResult() {
		return result;
	}
	public void setResult(FeedMetadataJO result) {
		this.result = result;
	}
	public StatusJO getStatus() {
		return status;
	}
	public void setStatus(StatusJO status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "FetchFeedMDResponseJO [result=" + result + ", status=" + status
				+ "]";
	}
	
}
