package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ColumnMetadataJO {
	private String columnID;
	private String columnName ;
	private String dataType;
	private String dataFormat;
	private String startDate ;
	private String endDate ;
	private String userID;
	private boolean showRule;
	
	private List<ColumnRuleMetadataJO> rules = new ArrayList<ColumnRuleMetadataJO>();
	
	public void addRules(ColumnRuleMetadataJO colRuleMdJo){
		if(rules == null){
			rules = new ArrayList<ColumnRuleMetadataJO>();
		}
		rules.add(colRuleMdJo);
	}
	
	public String getColumnID() {
		return columnID;
	}

	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}

	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public List<ColumnRuleMetadataJO> getRules() {
		return rules;
	}

	public void setRules(List<ColumnRuleMetadataJO> rules) {
		this.rules = rules;
	}

	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDataFormat() {
		return dataFormat;
	}
	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public boolean isShowRule() {
		return showRule;
	}

	public void setShowRule(boolean showRule) {
		this.showRule = showRule;
	}

	@Override
	public String toString() {
		return "ColumnMetadataJO [columnID=" + columnID + ", columnName="
				+ columnName + ", dataType=" + dataType + ", dataFormat="
				+ dataFormat + ", startDate=" + startDate + ", endDate="
				+ endDate + ", userId=" + userID + ", showRule=" + showRule
				+ ", rules=" + rules + "]";
	}


	
}
