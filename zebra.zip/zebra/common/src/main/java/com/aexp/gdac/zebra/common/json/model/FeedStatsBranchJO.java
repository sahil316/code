package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedStatsBranchJO implements Comparable<FeedStatsBranchJO>{

	private String name;
	private String text ;
	private int status;
	private String parent;
	
	private List<FeedStatsBranchJO> children ;
	
	public void addBranchStatsJO(FeedStatsBranchJO statsBranchJo){
		if(children == null){
			children = new ArrayList<FeedStatsBranchJO>();
		}
		children.add(statsBranchJo);
	}
	
	public void addColumnBranchStatsJO(FeedStatsBranchJO statsBranchJo){
		children.get(1).addBranchStatsJO(statsBranchJo);
		
	}

	public void updateColumnBranchStatsAction(String action,int actionCode){
		children.get(1).setName("Column Action:"+action);
		children.get(1).setStatus(actionCode);
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public List<FeedStatsBranchJO> getChildren() {
		return children;
	}

	public void setChildren(List<FeedStatsBranchJO> children) {
		this.children = children;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	@Override
	public String toString() {
		return "FeedStatsBranchJO [name=" + name + ", text=" + text
				+ ", status=" + status + ", parent=" + parent + ", children="
				+ children + "]";
	}

	@Override
	public int compareTo(FeedStatsBranchJO o) {
		int result = -1; 
		if(o == null){
			result = 1 ;
		} else if(this.name != null ){
			result = this.name.compareToIgnoreCase(o.getName());
		}
		return result;
	}

	
}
