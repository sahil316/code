package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CStoneStorageAttrJO {
	
	private Long columnID ;
	private String columnName ;
	
	public CStoneStorageAttrJO(){}
	
	public CStoneStorageAttrJO(Long columnID, String columnName){
		this.columnID = columnID ;
		this.columnName = columnName ;
	}
	
	public Long getColumnID() {
		return columnID;
	}
	public void setColumnID(Long columnID) {
		this.columnID = columnID;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	@Override
	public String toString() {
		return "CStoneStorageAttrJO [columnID=" + columnID + ", columnName=" + columnName + "]";
	}
	
	
}
