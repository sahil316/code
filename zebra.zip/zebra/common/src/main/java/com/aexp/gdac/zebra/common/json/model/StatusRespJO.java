package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusRespJO {
	private StatusJO status ;
	
	public StatusRespJO(){
	}
	
	public StatusRespJO(StatusJO status){
		this.status = status ;
	}

	public StatusJO getStatus() {
		return status;
	}

	public void setStatus(StatusJO status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "StatusRespJO [status=" + status + "]";
	}

	
}
