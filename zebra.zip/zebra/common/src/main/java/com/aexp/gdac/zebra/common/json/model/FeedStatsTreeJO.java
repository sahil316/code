package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedStatsTreeJO {

	private String feedID ;
	private String pastRun;
	private List<FeedStatsBranchJO> result;
	private StatusJO status;
	
	public FeedStatsTreeJO(){}
	
	public FeedStatsTreeJO(StatusJO status){
		this.status = status ;
	}
	
	public void addBranchStatsJO(FeedStatsBranchJO feedStatsBranchJO){
		if(result == null){
			result = new ArrayList<FeedStatsBranchJO>();
		}
		
		result.add(feedStatsBranchJO);
	}
	
	public String getFeedID() {
		return feedID;
	}
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	public String getPastRun() {
		return pastRun;
	}
	public void setPastRun(String pastRun) {
		this.pastRun = pastRun;
	}
	public List<FeedStatsBranchJO> getResult() {
		return result;
	}
	public void setResult(List<FeedStatsBranchJO> result) {
		this.result = result;
	}
	
	public StatusJO getStatus() {
		return status;
	}

	public void setStatus(StatusJO status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "FeedTreeJO [feedID=" + feedID + ", pastRun=" + pastRun
				+ ", result=" + result + "]";
	}
	
	
}
