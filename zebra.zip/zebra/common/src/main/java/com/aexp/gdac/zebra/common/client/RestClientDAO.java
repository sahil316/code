package com.aexp.gdac.zebra.common.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate ;

import com.aexp.gdac.zebra.common.ZebraCommonServiceException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RestClientDAO {
	
	
	private  int defaultMaxConPerRoute ;
	private  int defaultMaxTotalCon ;
	private  String baseUri ;
	private  String routeUri ;
	private  int routCon;
	
	private static RestTemplate restTemplate ;
	
	public Object getForObject(String uri,Class classz) throws ZebraCommonServiceException{
		try{
			return  restTemplate().getForObject(baseUri + uri, classz);
		}catch(Exception ex){
			throw new ZebraCommonServiceException("Exception Occured while calling rest service",ZebraCommonServiceException.Reason.REST_CLIENT_EXCEPTION,ex);
		}
	}
	
	
	public  Object postForObject(String uri,Object userReqObj ,Class classz ,Object uriVars) throws ZebraCommonServiceException{
		try{
			if(uriVars == null ){
				return restTemplate().postForEntity(baseUri + uri, userReqObj, classz).getBody();
			}else{
				return restTemplate().postForEntity(baseUri + uri, userReqObj, classz, uriVars).getBody();
			}
		}catch(Exception ex){
			throw new ZebraCommonServiceException("Exception Occured while calling rest service",ZebraCommonServiceException.Reason.REST_CLIENT_EXCEPTION,ex);
		}
	}
	
	private RestTemplate restTemplate() {
		
		if(restTemplate != null ){
			return restTemplate;
		}
		
		restTemplate = new RestTemplate(httpRequestFactory());
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
                
	    List<HttpMessageConverter<?>> converters = restTemplate.getMessageConverters();
	    for (HttpMessageConverter<?> converter : converters) {
	        if (converter instanceof MappingJackson2HttpMessageConverter) {
	            MappingJackson2HttpMessageConverter jsonConverter = (MappingJackson2HttpMessageConverter) converter;
	            jsonConverter.setObjectMapper(new ObjectMapper());
	            
	            List<MediaType> mediaTypeList = new ArrayList<MediaType>();
	            mediaTypeList.add(new MediaType("application", "json", MappingJackson2HttpMessageConverter.DEFAULT_CHARSET));
	            mediaTypeList.add(new MediaType("text", "javascript", MappingJackson2HttpMessageConverter.DEFAULT_CHARSET));
	            mediaTypeList.add(new MediaType("application", "octet-stream", MappingJackson2HttpMessageConverter.DEFAULT_CHARSET));
	            jsonConverter.setSupportedMediaTypes(mediaTypeList);
	         
	        }
	    }
	    return restTemplate;
	}
	

	private  ClientHttpRequestFactory httpRequestFactory() {
	    return new HttpComponentsClientHttpRequestFactory(httpClient());
	}

	public  HttpClient httpClient() {
	    PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
	    CloseableHttpClient closeableHttpClient = HttpClientBuilder.create().setConnectionManager(connectionManager).build();
	    connectionManager.setMaxTotal(defaultMaxTotalCon);
	    connectionManager.setDefaultMaxPerRoute(defaultMaxConPerRoute);
	    connectionManager.setMaxPerRoute(new HttpRoute(new HttpHost(routeUri)), routCon);
	    return closeableHttpClient;
	}

	public int getDefaultMaxConPerRoute() {
		return defaultMaxConPerRoute;
	}

	public void setDefaultMaxConPerRoute(int defaultMaxConPerRoute) {
		this.defaultMaxConPerRoute = defaultMaxConPerRoute;
	}

	public int getDefaultMaxTotalCon() {
		return defaultMaxTotalCon;
	}

	public void setDefaultMaxTotalCon(int defaultMaxTotalCon) {
		this.defaultMaxTotalCon = defaultMaxTotalCon;
	}

	public String getBaseUri() {
		return baseUri;
	}

	public void setBaseUri(String baseUri) {
		this.baseUri = baseUri;
	}

	public String getRouteUri() {
		return routeUri;
	}

	public void setRouteUri(String routeUri) {
		this.routeUri = routeUri;
	}

	public int getRoutCon() {
		return routCon;
	}
	
	public void setRoutCon(int routCon) {
		this.routCon = routCon;
	}

}
