package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedMetadataJO {

	private String feed_Id;
	private String feed_name;
	private String feed_frequency;
	private String file_format;
	private String file_format_delimited;
	private String column_delimiter ;
	private String record_delimiter;
	private String threshold_type ;
	private String alert_threshold_min;
	private String alert_threshold_max;
	private String abort_threshold_min;
	private String abort_threshold_max;
	private String past_runs;
	private String start_date;
	private String end_date;
	private String user_id;
	private String email_id;
	private String fileTrailer;
    private String fileHeader;

    /* sla parmeters*/
    private String sla;
    private String sla_time;
    private String monthQuarter;
    private String monthDate;
    private String weekDay;
    private String skipDay;
    private String sla_time_elapsed;
    
    /* ticket robo parameter*/
	private String rGrp ;
	private String aGrp ;
	private String ticketRobo ;
	
	public String getFileTrailer() {
		return fileTrailer;
	}
	public void setFileTrailer(String fileTrailer) {
		if("1".equals(fileTrailer)){
			this.fileTrailer = "true" ;
		}else if("true".equalsIgnoreCase(fileTrailer)){
			this.fileTrailer = "true" ;
		}else {
			this.fileTrailer = "false";
		}
	}
	public String getFileHeader() {
		return fileHeader;
	}
	public void setFileHeader(String fileHeader) {
		if("1".equals(fileHeader)){
			this.fileHeader = "true" ;
		}else if("true".equalsIgnoreCase(fileHeader)){
			this.fileHeader = "true" ;
		}else {
			this.fileHeader = "false";
		}
	}
	public String getFeed_name() {
		return feed_name;
	}
	public void setFeed_name(String feed_name) {
		this.feed_name = feed_name;
	}
	public String getFeed_frequency() {
		return feed_frequency;
	}
	public void setFeed_frequency(String feed_frequency) {
		this.feed_frequency = feed_frequency;
	}
	public String getFile_format() {
		return file_format;
	}
	public void setFile_format(String file_format) {
		this.file_format = file_format;
	}
	public String getFile_format_delimited() {
		return file_format_delimited;
	}
	public void setFile_format_delimited(String file_format_delimited) {
		this.file_format_delimited = file_format_delimited;
	}
	public String getRecord_delimiter() {
		return record_delimiter;
	}
	public void setRecord_delimiter(String record_delimiter) {
		this.record_delimiter = record_delimiter;
	}
	public String getThreshold_type() {
		return threshold_type;
	}
	public void setThreshold_type(String threshold_type) {
		this.threshold_type = threshold_type;
	}
	public String getAlert_threshold_min() {
		return alert_threshold_min;
	}
	public void setAlert_threshold_min(String alert_threshold_min) {
		this.alert_threshold_min = alert_threshold_min;
	}
	public String getAlert_threshold_max() {
		return alert_threshold_max;
	}
	public void setAlert_threshold_max(String alert_threshold_max) {
		this.alert_threshold_max = alert_threshold_max;
	}
	public String getAbort_threshold_min() {
		return abort_threshold_min;
	}
	public void setAbort_threshold_min(String abort_threshold_min) {
		this.abort_threshold_min = abort_threshold_min;
	}
	public String getAbort_threshold_max() {
		return abort_threshold_max;
	}
	public void setAbort_threshold_max(String abort_threshold_max) {
		this.abort_threshold_max = abort_threshold_max;
	}
	public String getPast_runs() {
		return past_runs;
	}
	public void setPast_runs(String past_runs) {
		this.past_runs = past_runs;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getFeed_Id() {
		return feed_Id;
	}
	public void setFeed_Id(String feed_Id) {
		this.feed_Id = feed_Id;
	}
	
	public String getSla() {
		return sla;
	}
	public void setSla(String sla) {
		this.sla = sla;
	}
	public String getSla_time() {
		return sla_time;
	}
	public void setSla_time(String sla_time) {
		this.sla_time = sla_time;
	}
	public String getMonthQuarter() {
		return monthQuarter;
	}
	public void setMonthQuarter(String monthQuarter) {
		this.monthQuarter = monthQuarter;
	}
	public String getMonthDate() {
		return monthDate;
	}
	public void setMonthDate(String monthDate) {
		this.monthDate = monthDate;
	}
	public String getWeekDay() {
		return weekDay;
	}
	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}
	public String getSkipDay() {
		return skipDay;
	}
	public void setSkipDay(String skipDay) {
		this.skipDay = skipDay;
	}
	public String getSla_time_elapsed() {
		return sla_time_elapsed;
	}
	public void setSla_time_elapsed(String sla_time_elapsed) {
		this.sla_time_elapsed = sla_time_elapsed;
	}
	public String getColumn_delimiter() {
		return column_delimiter;
	}
	public void setColumn_delimiter(String column_delimiter) {
		this.column_delimiter = column_delimiter;
	}
	
	public String getrGrp() {
		return rGrp;
	}
	public void setrGrp(String rGrp) {
		this.rGrp = rGrp;
	}
	public String getaGrp() {
		return aGrp;
	}
	public void setaGrp(String aGrp) {
		this.aGrp = aGrp;
	}
	public String getTicketRobo() {
		return ticketRobo;
	}
	public void setTicketRobo(String ticketRobo) {
		if("1".equals(ticketRobo)){
			this.ticketRobo = "true" ;
		}else if("true".equalsIgnoreCase(ticketRobo)){
			this.ticketRobo = "true" ;
		}else {
			this.ticketRobo = "false";
		}
	}

	public void setTicketRoboUI(String ticketRobo) {
		if("true".equals(ticketRobo)){
			this.ticketRobo = "1" ;
		}else if("1".equalsIgnoreCase(ticketRobo)){
			this.ticketRobo = "1" ;
		}else {
			this.ticketRobo = "0";
		}
	}
	
	public boolean hasTicketRoboDetails(){
		if("true".equals(ticketRobo)){
			return true ;
		}else if("1".equalsIgnoreCase(ticketRobo)){
			return true ;
		}else {
			return false ;
		}
	}
	
	@Override
	public String toString() {
		return "FeedMetadataJO [feed_Id=" + feed_Id + ", feed_name=" + feed_name + ", feed_frequency=" + feed_frequency
				+ ", file_format=" + file_format + ", file_format_delimited=" + file_format_delimited
				+ ", column_delimiter=" + column_delimiter + ", record_delimiter=" + record_delimiter
				+ ", threshold_type=" + threshold_type + ", alert_threshold_min=" + alert_threshold_min
				+ ", alert_threshold_max=" + alert_threshold_max + ", abort_threshold_min=" + abort_threshold_min
				+ ", abort_threshold_max=" + abort_threshold_max + ", past_runs=" + past_runs + ", start_date="
				+ start_date + ", end_date=" + end_date + ", user_id=" + user_id + ", email_id=" + email_id
				+ ", fileTrailer=" + fileTrailer + ", fileHeader=" + fileHeader + ", sla=" + sla + ", sla_time="
				+ sla_time + ", monthQuarter=" + monthQuarter + ", monthDate=" + monthDate + ", weekDay=" + weekDay
				+ ", skipDay=" + skipDay + ", sla_time_elapsed=" + sla_time_elapsed + ", rGrp=" + rGrp + ", aGrp="
				+ aGrp + ", ticketRobo=" + ticketRobo + "]";
	}
	
	
	
}
