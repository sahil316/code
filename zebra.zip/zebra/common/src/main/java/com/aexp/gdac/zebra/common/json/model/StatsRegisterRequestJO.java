package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatsRegisterRequestJO {
	private String feedID;
	private String feedName;
	private String inputFilePath;
	private String runDate;
	private String userID;
	private String password;
	private String updateProcessedDate ;

	@Override
	public String toString() {
		return "StatsRequestJO [feedID=" + feedID + ", feedName=" + feedName
				+ ", inputFilePath=" + inputFilePath + ", runDate=" + runDate
				+ ", userID=" + userID
				+ ", password=" + password 
				+ ", updateProcessedDate="+updateProcessedDate+"]";
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFeedID() {
		return feedID;
	}
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public String getInputFilePath() {
		return inputFilePath;
	}
	public void setInputFilePath(String inputFilePath) {
		this.inputFilePath = inputFilePath;
	}
	public String getRunDate() {
		return runDate;
	}
	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}
	public String getUpdateProcessedDate() {
		return updateProcessedDate;
	}
	public void setUpdateProcessedDate(String updateProcessedDate) {
		this.updateProcessedDate = updateProcessedDate;
	}
}
