package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ColumnTrendRequestJO {
	private String feedID;
	private String columnID;
	private String rules;
	private String pastRuns;
	private String requestChart;
	@Override
	public String toString() {
		return "ColumnTrendRequestJO [feedID=" + feedID + ", columnID="
				+ columnID + ", rules=" + rules + ", pastRuns=" + pastRuns
				+ ", requestChart=" + requestChart + "]";
	}
	public String getFeedID() {
		return feedID;
	}
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	public String getColumnID() {
		return columnID;
	}
	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}
	public String getRules() {
		return rules;
	}
	public void setRules(String rules) {
		this.rules = rules;
	}
	public String getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(String pastRuns) {
		this.pastRuns = pastRuns;
	}
	public String getRequestChart() {
		return requestChart;
	}
	public void setRequestChart(String requestChart) {
		this.requestChart = requestChart;
	}
	

}
