package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusJO {
	private String feedID;
	private String feedName ;
	private String fileFormat ;
	private String userID;
	private String responseMessage;
	private String responseType;
	private String responseCode;
	private String startDate;
	private String endDate;
	
	public StatusJO(){}
	
	public StatusJO(String respCode, String respMessage, String respType){
		this.responseCode = respCode;
		this.responseMessage = respMessage ;
		this.responseType = respType;
	}
	
	public StatusJO(String feedID, String feedName, String userID,String respCode, String respMessage, String respType){
		this.feedID = feedID;
		this.feedName = feedName;
		this.userID = userID;
		
		this.responseCode = respCode;
		this.responseMessage = respMessage ;
		this.responseType = respType;
	}
	
	public StatusJO(String feedID, String feedName, String userID,String respCode, String respMessage, String respType,String startDate,String endDate){
		this.feedID = feedID;
		this.feedName = feedName;
		this.userID = userID;
		
		this.responseCode = respCode;
		this.responseMessage = respMessage ;
		this.responseType = respType;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	
	public StatusJO(String feedID, String feedName, String userID,
			String respCode, String respMessage, String respType
			,String startDate,String endDate, String fileFormat){
		this.feedID = feedID;
		this.feedName = feedName;
		this.userID = userID;
		
		this.responseCode = respCode;
		this.responseMessage = respMessage ;
		this.responseType = respType;
		this.startDate = startDate;
		this.endDate = endDate;
		this.fileFormat = fileFormat ;
	}
	
	public static final String RESP_CODE_SUCCESS = "200";
	public static final String RESP_MESSAGE_SUCCESS = "OK";
	public static final String RESP_CODE_FAILURE = "500";
	
	public String getFeedID() {
		return feedID;
	}
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getResponseType() {
		return responseType;
	}
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	@Override
	public String toString() {
		return "StatusJO [feedID=" + feedID + ", feedName=" + feedName
				+ ", responseMessage=" + responseMessage + ", responseType="
				+ responseType + ", responseCode=" + responseCode + "]";
	}
	
}
