package com.aexp.gdac.zebra.common.client;

import com.aexp.gdac.zebra.common.ZebraCommonResourceManager;
import com.aexp.gdac.zebra.common.ZebraCommonServiceException;
import com.aexp.gdac.zebra.common.json.model.FeedDetailInfoJO;
import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;
import com.aexp.gdac.zebra.common.json.model.StatusJO;
import com.aexp.gdac.zebra.common.json.model.StatusRespJO;


public class RestClient {

	
	public StatusRespJO registerStats(StatsRegisterRequestJO statsRegReqJo) throws ZebraCommonServiceException{
		return (StatusRespJO) ZebraCommonResourceManager.getRestClientDAO().postForObject("/register_stats/",(Object)statsRegReqJo, StatusRespJO.class,null);
		
	}
	
	public FeedDetailInfoJO getFeedColumnDetails() throws ZebraCommonServiceException{
		return (FeedDetailInfoJO)  ZebraCommonResourceManager.getRestClientDAO().getForObject("/feed_column_list/", FeedDetailInfoJO.class) ;
	}
}
