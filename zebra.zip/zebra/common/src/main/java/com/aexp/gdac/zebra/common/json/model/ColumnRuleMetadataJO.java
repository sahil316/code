package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ColumnRuleMetadataJO {
	private String columnID;
	private String columnName;
	private String ruleID;
	private String ruleParameter;
	private String pastRuns;
	private String userID;
	private String startDate;
	private String endDate ;
	private String thresholdType;
	private String minAlertThreshold;
	private String minAbortThreshold;
	private String maxAlertThreshold;
	private String maxAbortThreshold;
	
	
	public String getColumnID() {
		return columnID;
	}
	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getRuleID() {
		return ruleID;
	}
	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}
	public String getRuleParameter() {
		return ruleParameter;
	}
	public void setRuleParameter(String ruleParameter) {
		this.ruleParameter = ruleParameter;
	}
	public String getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(String pastRuns) {
		this.pastRuns = pastRuns;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getThresholdType() {
		return thresholdType;
	}
	public void setThresholdType(String thresholdType) {
		this.thresholdType = thresholdType;
	}
	public String getMinAlertThreshold() {
		return minAlertThreshold;
	}
	public void setMinAlertThreshold(String minAlertThreshold) {
		this.minAlertThreshold = minAlertThreshold;
	}
	public String getMinAbortThreshold() {
		return minAbortThreshold;
	}
	public void setMinAbortThreshold(String minAbortThreshold) {
		this.minAbortThreshold = minAbortThreshold;
	}
	public String getMaxAlertThreshold() {
		return maxAlertThreshold;
	}
	public void setMaxAlertThreshold(String maxAlertThreshold) {
		this.maxAlertThreshold = maxAlertThreshold;
	}
	public String getMaxAbortThreshold() {
		return maxAbortThreshold;
	}
	public void setMaxAbortThreshold(String maxAbortThreshold) {
		this.maxAbortThreshold = maxAbortThreshold;
	}
	@Override
	public String toString() {
		return "ColumnRuleMetadataJO [columnName=" + columnName + ", ruleID="
				+ ruleID + ", ruleParameter=" + ruleParameter + ", pastRuns="
				+ pastRuns + ", userID=" + userID + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", thresholdType=" + thresholdType
				+ ", minAlertThreshold=" + minAlertThreshold
				+ ", minAbortThreshold=" + minAbortThreshold
				+ ", maxAlertThreshold=" + maxAlertThreshold
				+ ", maxAbortThreshold=" + maxAbortThreshold + "]";
	}

}
