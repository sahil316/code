package com.aexp.gdac.zebra.common;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aexp.gdac.zebra.common.client.RestClientDAO;

public class ZebraCommonResourceManager {
	private static ClassPathXmlApplicationContext ctx ;
	
	static{
		createSpringContext();
	}
	
	private static void createSpringContext(){
		if(ctx == null){
			ctx =  new ClassPathXmlApplicationContext("spring-common-config.xml");
		}
	}
	
	
	public static Object getBean(String beanName){
		return ctx.getBean(beanName);
	}
	
	public static RestClientDAO getRestClientDAO(){
		return ctx.getBean("restClientDAO",RestClientDAO.class);
	}
	
}
