package com.aexp.gdac.zebra.common.client;

import com.aexp.gdac.zebra.common.ZebraCommonServiceException;
import com.aexp.gdac.zebra.common.json.model.StatsRegisterRequestJO;

public class RestClientTestMain {
	public static void main(String args[]) throws ZebraCommonServiceException{
		RestClient client = new RestClient() ;
		StatsRegisterRequestJO statsRegReqJo = new StatsRegisterRequestJO ();
		statsRegReqJo.setFeedID("1");
		statsRegReqJo.setFeedName("Seasonality");
		statsRegReqJo.setRunDate("2015-12-10");
		statsRegReqJo.setUserID("aatri1");
		
		System.out.println(client.registerStats(statsRegReqJo));
	}
}
