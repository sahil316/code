package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CStoneStorageDetailJO {
	private CStoneStorageResultJO result ;
	private StatusJO status ;
	
	public CStoneStorageDetailJO(){}
	
	public CStoneStorageDetailJO(StatusJO statusJo){
		this.status = statusJo;		
	}
	
	@Override
	public String toString() {
		return "CStoneStorageDetailJO [result=" + result + ", statusJo=" + status + "]";
	}


	public CStoneStorageResultJO getResult() {
		return result;
	}


	public void setResult(CStoneStorageResultJO result) {
		this.result = result;
	}

	public StatusJO getStatus() {
		return status;
	}

	public void setStatus(StatusJO status) {
		this.status = status;
	}




	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class CStoneStorageResultJO {
		List<CStoneStorageInfoJO> feedList ;

		public void addCStoneStorageInfoJO(CStoneStorageInfoJO storageInfoJo){
			if(this.feedList == null){
				this.feedList = new ArrayList<CStoneStorageInfoJO>() ;
			}
			
			this.feedList.add(storageInfoJo);
			
		}
		
		public List<CStoneStorageInfoJO> getFeedList() {
			return feedList;
		}

		public void setFeedList(List<CStoneStorageInfoJO> feedList) {
			this.feedList = feedList;
		}

		@Override
		public String toString() {
			return "CStoneStorageResultJO [feedList=" + feedList + "]";
		}
		
		
	}
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class CStoneStorageInfoJO {
		private String table_name ;
		private Long storage_ID ;
		
		@Override
		public String toString() {
			return "CStoneStorageInfoJO [table_name=" + table_name + ", storage_ID=" + storage_ID + "]";
		}
		public String getTable_name() {
			return table_name;
		}
		public void setTable_name(String table_name) {
			this.table_name = table_name;
		}
		public Long getStorage_ID() {
			return storage_ID;
		}
		public void setStorage_ID(Long storage_ID) {
			this.storage_ID = storage_ID;
		}
		
		
	}

}
