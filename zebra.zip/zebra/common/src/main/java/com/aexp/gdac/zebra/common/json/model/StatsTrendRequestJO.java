package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatsTrendRequestJO {

	private String feedID;
	private String columnID;
	private String ruleID;
	private String pastRuns;
	private String requestChart;
	
	
	@Override
	public String toString() {
		return "StatsTrendRequestJO [feedID=" + feedID + ", columnID="
				+ columnID + ", ruleID=" + ruleID + ", pastRuns=" + pastRuns
				+ ", requestChart=" + requestChart + "]";
	}
	/*
	public Level getRequestLevel(){
		if(this.columnID != null && !this.columnID.isEmpty() 
				&& this.ruleID != null && !this.ruleID.isEmpty()){
			return Level.COLUMN_RULE_LEVEL ;
		}else if(this.columnID != null && !this.columnID.isEmpty()){
			return Level.COLUMN_LEVEL ;
		}
		
		return Level.FEED_LEVEL ;
	}
	*/
	
	
	public String getFeedID() {
		return feedID;
	}
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	public String getColumnID() {
		return columnID;
	}
	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}

	public String getRuleID() {
		return ruleID;
	}

	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}

	public String getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(String pastRuns) {
		this.pastRuns = pastRuns;
	}
	public String getRequestChart() {
		return requestChart;
	}
	public void setRequestChart(String requestChart) {
		this.requestChart = requestChart;
	}
	
	
}
