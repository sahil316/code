package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatsTrendJO {
	
	private String feedID;
	private String columnID;
	private String rules;
	private String pastRuns;
	private List<TrendJO> dataset;
	private StatusJO status;
	
	public StatsTrendJO(){}
	
	public StatsTrendJO(StatusJO status){
		this.status = status ;
	}
	public void addDataSet(TrendJO trendJo){
		if(dataset == null){
			dataset = new ArrayList<TrendJO>();
		}
		dataset.add(trendJo);
	}
	public String getFeedID() {
		return feedID;
	}

	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}

	public String getColumnID() {
		return columnID;
	}

	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}

	public String getRules() {
		return rules;
	}

	public void setRules(String rules) {
		this.rules = rules;
	}

	public String getPastRuns() {
		return pastRuns;
	}

	public void setPastRuns(String pastRuns) {
		this.pastRuns = pastRuns;
	}

	public List<TrendJO> getDataset() {
		return dataset;
	}

	public void setDataset(List<TrendJO> dataset) {
		this.dataset = dataset;
	}

	public StatusJO getStatus() {
		return status;
	}
	public void setStatus(StatusJO status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "StatsTrendJO [feedID=" + feedID + ", columnID=" + columnID
				+ ", rules=" + rules + ", pastRuns=" + pastRuns + ", dataset="
				+ dataset + "]";
	}



	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class TrendJO{
		private String seriesname;
		private List<DataJO> data;
		
		public TrendJO(String seriesname){
			this.seriesname = seriesname;
		}

		
		public void addData(DataJO dataJo){
			if(data == null){
				data = new ArrayList<DataJO>();
			}
			data.add(dataJo);
		}
		
		public String getSeriesname() {
			return seriesname;
		}
		public void setSeriesname(String seriesname) {
			this.seriesname = seriesname;
		}
		public List<DataJO> getData() {
			return data;
		}
		public void setData(List<DataJO> data) {
			this.data = data;
		}
		@Override
		public String toString() {
			return " [seriesname=" + seriesname + ", data=" + data + "]";
		}
				
	}
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class DataJO{
		private String value;
		public DataJO(){
		}
		
		public DataJO(String value){
			this.value = value;
		}
		
		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return " [value=" + value + "]";
		}
		
	}
}
