package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatsReportRequestJO {
	private String feedID ;
	private String requestChart ;
	private String pastRuns;
	
	public String getFeedID() {
		return feedID;
	}

	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}

	public String getRequestChart() {
		return requestChart;
	}

	public void setRequestChart(String requestChart) {
		this.requestChart = requestChart;
	}

	public String getPastRuns() {
		return pastRuns;
	}

	public void setPastRuns(String pastRuns) {
		this.pastRuns = pastRuns;
	}

	@Override
	public String toString() {
		return "StatsRequestJO [requestChart=" + requestChart + ", feedID="
				+ feedID + ", pastRuns=" + pastRuns + "]";
	}

	

	
}
