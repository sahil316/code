package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegisterColumnMDJO {
	private String feedID;
	private String feedName;
	private String userID;
	private List<ColumnMetadataJO> columns ;
	
	public void addColumns(ColumnMetadataJO colMdJo){
		if(columns == null){
			columns = new ArrayList<ColumnMetadataJO>();
		}
		columns.add(colMdJo);
	}
	
	public String getFeedID() {
		return feedID;
	}
	
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	
	public String getFeedName() {
		return feedName;
	}

	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		userID = userID;
	}

	public List<ColumnMetadataJO> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnMetadataJO> columns) {
		this.columns = columns;
	}

	@Override
	public String toString() {
		return "RegisterColumnMDJO [feedID=" + feedID + ", feedName="
				+ feedName + ", userID=" + userID + ", columns=" + columns
				+ "]";
	}

}
