package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CStoneStorageStatsJO {
	
	private Long storage_ID ;
	private Long attr_ID;
	private Integer pastRuns ;
	private List<StorageStatsDatasetJO> dataset ;
	private List<CStoneStorageAttrJO> columnList ;
	private StatusJO status ;
	
	public CStoneStorageStatsJO(){}
	
	public CStoneStorageStatsJO(StatusJO status){
		this.status = status ;
	}
	public void addCStoneStorageJO (CStoneStorageAttrJO storageAttJo) {
		if(this.columnList == null){
			this.columnList = new ArrayList<CStoneStorageAttrJO>();
		}
		
		this.columnList.add(storageAttJo);
	}
	
	public void addDataset(StorageStatsDatasetJO datasetJo){
		if(this.dataset == null){
			this.dataset = new ArrayList<StorageStatsDatasetJO>() ;
		}
		this.dataset.add(datasetJo);
	}

	
	@Override
	public String toString() {
		return "CStoneStorageStatsJO [storage_ID=" + storage_ID + ", attr_ID=" + attr_ID + ", pastRuns=" + pastRuns
				+ ", dataset=" + dataset + ", status=" + status + ", columnList=" + columnList + "]";
	}

	public Long getAttr_ID() {
		return attr_ID;
	}

	public void setAttr_ID(Long attr_ID) {
		this.attr_ID = attr_ID;
	}

	public List<CStoneStorageAttrJO> getColumnList() {
		return columnList;
	}

	public void setColumnList(List<CStoneStorageAttrJO> columnList) {
		this.columnList = columnList;
	}

	public StatusJO getStatus() {
		return status;
	}


	public void setStatus(StatusJO status) {
		this.status = status;
	}


	public Long getStorage_ID() {
		return storage_ID;
	}

	public void setStorage_ID(Long storage_ID) {
		this.storage_ID = storage_ID;
	}

	public Integer getPastRuns() {
		return pastRuns;
	}

	public void setPastRuns(Integer pastRuns) {
		this.pastRuns = pastRuns;
	}

	public List<StorageStatsDatasetJO> getDataset() {
		return dataset;
	}

	public void setDataset(List<StorageStatsDatasetJO> dataset) {
		this.dataset = dataset;
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class StorageStatsDatasetJO {
		private String seriesname ;
		private List<StorageStatDataJO> data ;
		
		public StorageStatsDatasetJO(){}
		
		public StorageStatsDatasetJO(String seriesname){
			this.seriesname = seriesname ;
		}
		public String getSeriesname() {
			return seriesname;
		}

		public void setSeriesname(String seriesname) {
			this.seriesname = seriesname;
		}

		public List<StorageStatDataJO> getData() {
			return data;
		}

		public void setData(List<StorageStatDataJO> data) {
			this.data = data;
		}

		public void addData(StorageStatDataJO dataJo) {
			if(this.data == null){
				this.data = new ArrayList<StorageStatDataJO>() ;
			}
			
			this.data.add(dataJo) ;
		}

		@Override
		public String toString() {
			return "DatasetJO [seriesname=" + seriesname + ", data=" + data + "]";
		}
		
	}
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class StorageStatDataJO {
		public StorageStatDataJO(){}
		
		public StorageStatDataJO(Object value){
			this.value = "" +value ;
		}
		
		private String value ;

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return "DataJO [value=" + value + "]";
		}
		
		
	}
}
