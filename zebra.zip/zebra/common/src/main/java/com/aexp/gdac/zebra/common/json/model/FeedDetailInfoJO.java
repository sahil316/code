package com.aexp.gdac.zebra.common.json.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedDetailInfoJO {
	
	private FeedResultJO result;
	private StatusJO status ;

	public StatusJO getStatus() {
		return status;
	}

	public void setStatus(StatusJO status) {
		this.status = status;
	}

	public FeedResultJO getResult() {
		return result;
	}

	public void setResult(FeedResultJO result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "FeedDetailInfoJO [result=" + result + ", status=" + status
				+ "]";
	}



	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class FeedResultJO{
		private List<FeedInfoJO> feedList;
		
		public void addFeedInfo(FeedInfoJO feedInfoJo){
			if(feedList == null){
				this.feedList = new ArrayList<FeedInfoJO>();
			}
			
			feedList.add(feedInfoJo);
		}

		public List<FeedInfoJO> getFeedList() {
			return feedList;
		}

		public void setFeedList(List<FeedInfoJO> feedList) {
			this.feedList = feedList;
		}

		@Override
		public String toString() {
			return "FeedResultJO [feedList=" + feedList + "]";
		}
		
	}
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class FeedInfoJO{
		
		private String feedID ;
		private String feedName;
		private List<ColumnInfoJO> columnList ;
		private StatusJO status ;
		
		
		public FeedInfoJO(){}
		public FeedInfoJO(StatusJO status){
			this.status = status;
		}
		
		public FeedInfoJO(String feedID,String feedName){
			this.feedID = feedID;
			this.feedName = feedName;
		}
		
		public void addColumnInfo(ColumnInfoJO colInfoJo){
			if(columnList == null){
				this.columnList = new ArrayList<ColumnInfoJO>();
			}
			
			columnList.add(colInfoJo);
		}
		
		public void sortColumnList(){
			if(this.columnList!=null){
				Collections.sort(this.columnList);
			}
		}

		public String getFeedID() {
			return feedID;
		}

		public void setFeedID(String feedID) {
			this.feedID = feedID;
		}

		public String getFeedName() {
			return feedName;
		}

		public void setFeedName(String feedName) {
			this.feedName = feedName;
		}

		public List<ColumnInfoJO> getColumnList() {
			return columnList;
		}

		public void setColumnList(List<ColumnInfoJO> columnList) {
			this.columnList = columnList;
		}
		
		public StatusJO getStatus() {
			return status;
		}

		public void setStatus(StatusJO status) {
			this.status = status;
		}
		
		@Override
		public String toString() {
			return "FeedInfoJO [feedID=" + feedID + ", feedName=" + feedName
					+ ", columnList=" + columnList + "]";
		}
		
		
	}
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ColumnInfoJO implements Comparable<ColumnInfoJO>{
		private String columnID;
		private String columnName ;
		private List<ColumnRuleInfoJO> ruleList ;
		
		public ColumnInfoJO(){}
		
		public ColumnInfoJO(String columnID, String columnName){
			this.columnID = columnID;
			this.columnName = columnName ;
		}
		
		public void addColumnRulenfo(ColumnRuleInfoJO colRuleInfoJo){
			if(ruleList == null){
				this.ruleList = new ArrayList<ColumnRuleInfoJO>();
			}
			
			ruleList.add(colRuleInfoJo);
		}

		public String getColumnID() {
			return columnID;
		}

		public void setColumnID(String columnID) {
			this.columnID = columnID;
		}

		public String getColumnName() {
			return columnName;
		}

		public void setColumnName(String columnName) {
			this.columnName = columnName;
		}

		public List<ColumnRuleInfoJO> getRuleList() {
			return ruleList;
		}

		public void setRuleList(List<ColumnRuleInfoJO> ruleList) {
			this.ruleList = ruleList;
		}

		@Override
		public String toString() {
			return "ColumnInfoJO [columnID=" + columnID + ", columnName="
					+ columnName + ", ruleList=" + ruleList + "]";
		}

		@Override
		public int compareTo(ColumnInfoJO o) {
			int result = -1; 
			if(o == null){
				result = 1 ;
			} else if(this.columnName != null ){
				result = this.columnName.compareToIgnoreCase(o.getColumnName()) ;
			}
			
			return result;
		}
		
		
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ColumnRuleInfoJO{
		
		public ColumnRuleInfoJO(){}
		
		public ColumnRuleInfoJO(String ruleID, String ruleName){
			this.ruleID = ruleID;
			this.ruleName = ruleName ;
		}
		
		private String ruleID;
		private String ruleName;
		public String getRuleID() {
			return ruleID;
		}
		public void setRuleID(String ruleID) {
			this.ruleID = ruleID;
		}
		public String getRuleName() {
			return ruleName;
		}
		public void setRuleName(String ruleName) {
			this.ruleName = ruleName;
		}
		@Override
		public String toString() {
			return "ColumnRuleInfoJO [ruleID=" + ruleID + ", ruleName="
					+ ruleName + "]";
		}
		
	}

}
