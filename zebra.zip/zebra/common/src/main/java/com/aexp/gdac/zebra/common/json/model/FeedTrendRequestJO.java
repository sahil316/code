package com.aexp.gdac.zebra.common.json.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedTrendRequestJO {
	private String feedID ;
	private String pastRuns;
	private String requestChart;
	@Override
	public String toString() {
		return "FeedTrendRequestJO [feedID=" + feedID + ", pastRuns="
				+ pastRuns + ", requestChart=" + requestChart + "]";
	}
	public String getFeedID() {
		return feedID;
	}
	public void setFeedID(String feedID) {
		this.feedID = feedID;
	}
	public String getPastRuns() {
		return pastRuns;
	}
	public void setPastRuns(String pastRuns) {
		this.pastRuns = pastRuns;
	}
	public String getRequestChart() {
		return requestChart;
	}
	public void setRequestChart(String requestChart) {
		this.requestChart = requestChart;
	}
	
}
