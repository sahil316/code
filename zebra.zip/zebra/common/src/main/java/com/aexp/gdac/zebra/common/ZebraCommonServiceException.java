package com.aexp.gdac.zebra.common;



public class ZebraCommonServiceException extends Exception {
	
	private Reason reason ;

	public ZebraCommonServiceException(Exception e) {
		// TODO Auto-generated constructor stub
		super(e);
	}

	public ZebraCommonServiceException(String message){
		super(message);
		this.reason = Reason.UNEXPECTED_EXCEPTION;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraCommonServiceException(Reason reason){
		this.reason = reason;
	}
	
	public ZebraCommonServiceException(String message ,Reason reason){
		super(message);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraCommonServiceException(String message , Throwable cause){
		super(message,cause);
	}
	
	public ZebraCommonServiceException(Throwable cause){
		super(cause);
	}
	
	public ZebraCommonServiceException(Reason reason,Throwable cause){
		super(cause);
		this.reason = reason ;
	}
	
	public ZebraCommonServiceException(String message ,Reason reason,Throwable cause){
		super(message,cause);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public Reason getReason() {
		return reason;
	}

	public void setReason(Reason reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "ZebraCommonServiceException [reason=" + reason + " desc:"+reason.getReasonDesc()+"]";
	}
	
	
	public enum Reason{

		REST_CLIENT_EXCEPTION("Exception occured while call rest service"),
		UNEXPECTED_EXCEPTION("Unexpected exception occured");
		
		private String reasonDesc ;
		
		private Reason(){
		}
		
		private Reason(String desc){
			reasonDesc = desc ;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}
		
	}
}
