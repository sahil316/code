package com.aexp.gdac.zebra.mr;

import java.util.HashMap;
import java.util.Map;

public class DelimiterCodes {
	public static Map<String,String> delimiterCode = new HashMap<String,String>();
	static{
		delimiterCode.put("PIPE", "\\|");
		delimiterCode.put("CONTROL-A", "\u0001");
		delimiterCode.put("SPACE"," ");
		delimiterCode.put("TAB", "\t");
		delimiterCode.put("EXCLAMATION MARK", "!");
		delimiterCode.put("COLON", ":");
		delimiterCode.put("COMMA", ",");
		delimiterCode.put("QUESTION MARK", "?");
		delimiterCode.put("CARET", "^");
	}
}
