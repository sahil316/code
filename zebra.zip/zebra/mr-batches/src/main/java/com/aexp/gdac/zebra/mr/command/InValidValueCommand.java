package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class InValidValueCommand extends Command{

	private Logger log =  LogFactory.getLoggerInstance(InValidValueCommand.class) ;
	private static final String splitRegex = ",";
	
	private long inValidValueCount ;

	
	private List<String> inValidValueList = new ArrayList<String>();
	
	public InValidValueCommand(Object in_valid_values, boolean isReducerPhase){
		super(isReducerPhase);
		if(!in_valid_values.toString().isEmpty()){
			String[] valueArr = in_valid_values.toString().split(splitRegex);
			for(int i=0; i<valueArr.length ;  i++){
				inValidValueList.add(valueArr[i]);
			}
			
		}
		
	}

	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		if(o == null){
			log.debug("Illegal record passed "+o);
			return ;
		}
		if(!isReducerPhase){
			if(checkInValidValue(o.toString())){
				inValidValueCount ++;
			}
		}else{
			inValidValueCount = inValidValueCount + Long.parseLong((o.toString()));
		}
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(""+(inValidValueCount)));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: InValid Value Count Calculated From InputSplit "+(inValidValueCount));
				}
			}else if(o instanceof org.apache.hadoop.mapreduce.Reducer.Context){
				if(log.isDebugEnabled()){
					log.debug("Reducer: InValid Value Count Calculated From Mapper Outputs "+inValidValueCount);
				}
				return new Long(inValidValueCount);
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" + RuleCodeConstants.COMMAND_INVALID_VALUE,e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_INVALID_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException occured "+RuleCodeConstants.COMMAND_INVALID_VALUE,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_INVALID_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_INVALID_VALUE;
	}
	
	private boolean checkInValidValue(Object input){
		for(String value : inValidValueList){
			if(value.equalsIgnoreCase(input.toString())){
				return true ;
			}
		}
		
		return false ;
	}
	
}
