package com.aexp.gdac.zebra.mr_test;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aexp.gdac.zebra.base.CommonMethods;
import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.metadata.Metadata;
import com.aexp.gdac.zebra.base.metadata.MetadataParser;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.command.Command;
import com.aexp.gdac.zebra.mr.command.DataTypeCheckCommand;
import com.aexp.gdac.zebra.mr.tools.Worker;
import com.aexp.gdac.zebra.mr.tools.WorkerFactory;

public class Main {
	public static void main(String args[]) throws ZebraServiceException {
	
		/*File metadataFile = new File("C:\\AATRI\\Workspace\\Zebra\\ZebraCombinedProj_v3\\test-resources\\SAMPLE_MD_DB");
		Metadata md = MetadataParser.marshallMetadata(metadataFile);
		
		List<Worker> workerClist = WorkerFactory.getColumnLevelWorkerList(null, md, false);
		List<Worker> workerCRlist  = WorkerFactory.getColumnRuleLevelWorkerList(null, md, false);
		
	//	System.out.print( WorkerFactory.getWorkerList(null, md, false));
		
		//System.out.println(workerClist.get(0).getLevel() == Level.valueOf("COLUMN_LEVEL")) ;
		System.out.println(md.getColumnRuleLevelMetadata(1L, 1L, 1L));
		System.out.println("Done");
		*/
		/*String dataFormat = "dd/MM/yyyy" ;
		String dataType = "date";
		
		Command command = new DataTypeCheckCommand(dataFormat, dataType, false);
		
		command.execute("07/01/2014");
		
		System.out.println();*/
		/*
		SimpleDateFormat formatter = new SimpleDateFormat();
		String dateInString = "07/01/2013";
	 
		try {
	 
			Date date = formatter.parse(dateInString);
			System.out.println(date);
			System.out.println(formatter.format(date));
			
			Date date2 = new SimpleDateFormat("dd/MM/yyyy").parse("20130925");


	 
		} catch (ParseException e) {
			e.printStackTrace();
		}
		*/
		Double obj = new Double(1234132.123d);
		//System.out.println(roundTo2Decimals(obj).toString());
		//System.out.println(formatDouble(obj));
		
		System.out.println(CommonMethods.formatDouble2Decimals(obj));
		
		validValueCommand("USD");
		

	}
	
	
	
	
	
	public static  void  validValueCommand(Object valid_values){
		List<String> validValueList = new ArrayList<String>();

		if(!valid_values.toString().isEmpty()){
			String[] valueArr = valid_values.toString().split(",");
		
			for(int i=0; i<valueArr.length ;  i++){
				validValueList.add(valueArr[i]);
			}
			
			
		}
		
		System.out.println(validValueList.contains("USD1"));
		
		
		
	}
	
/*	
	private static Double roundTo2Decimals(double val) {
        DecimalFormat df2 = new DecimalFormat("#.###");
    return Double.valueOf(df2.format(val));
}
	
	public static String formatDouble(Double d){
		DecimalFormat df = new DecimalFormat("#.####");
		df.setRoundingMode(RoundingMode.CEILING);
		return df.format(d); 
			
		
	}
*/
}
