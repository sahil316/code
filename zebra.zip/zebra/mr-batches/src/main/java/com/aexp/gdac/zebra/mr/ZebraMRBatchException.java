package com.aexp.gdac.zebra.mr;


public class ZebraMRBatchException extends RuntimeException {
	
	public Reason getReason() {
		return reason;
	}

	public void setReason(Reason reason) {
		this.reason = reason;
	}

	private Reason reason;
	
	public ZebraMRBatchException(){
		super();
	}
	
	public ZebraMRBatchException(String message){
		super(message);
	}
	
	public ZebraMRBatchException(String message,Reason reason){
		super(message);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	public ZebraMRBatchException(String message , Throwable cause){
		super(message,cause);
	}
	
	public ZebraMRBatchException(Throwable cause){
		super(cause);
	}
	
	public ZebraMRBatchException(Reason reason,Throwable cause){
		super(cause);
		this.reason = reason ;
	}
	
	public ZebraMRBatchException(String message ,Reason reason,Throwable cause){
		super(message,cause);
		this.reason = reason;
		this.reason.setReasonDesc(message);
	}
	
	@Override
	public String toString() {
		return "ZebraServiceException [reason=" + reason +" desc: "+reason.getReasonDesc()+"]";
	}
	
	public enum Reason{
		MR_IOEXCEPTION("IOException Occured during MR run "),
		MR_INTERRUPTED_EXCEPTION("InterruptedExcepttion Occured during MR run "),
		MR_COMMAND_EXCEPTION("Command execution failed"),
		MR_EXCEPTION_AT_METADAT_CREATION("Exception while creating metadata"),
		MR_BAD_RECORD_EXCEPTOIN("Bad record detected"),
		MR_BAD_RECORD_THRESHOLD_EXCEPTOIN("Number of bad records are more than configured threshold."),
		UNEXPECTED_EXCEPTION("Unexpected exception occured");
		
		private String reasonDesc ;
		
		private Reason(){
		}
		
		 Reason(String desc){
			reasonDesc = desc ;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}
		
	}
}
