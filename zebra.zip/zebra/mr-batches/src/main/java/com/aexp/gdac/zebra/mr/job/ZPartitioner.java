package com.aexp.gdac.zebra.mr.job;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class ZPartitioner extends Partitioner<ZCustomKey, Text> {

	@Override
	public int getPartition(ZCustomKey key, Text value, int reducerCount) {
		int partition = 0 ;
		if(reducerCount==0){ 
			partition = 0;
		} else if(Level.COLUMN_COMPLEX_RULE_LEVEL.name().equals(key.getLevel().toString())){
			partition = (value.hashCode() & Integer.MAX_VALUE) % reducerCount;
		} else {
			partition = key.hashCode() % reducerCount ;
		}
		
		if(partition < 0){
			partition = partition * -1 ;
		}
		
		return partition ;
		 
	}

}
