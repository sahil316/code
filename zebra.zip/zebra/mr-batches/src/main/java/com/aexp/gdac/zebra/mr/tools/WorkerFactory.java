package com.aexp.gdac.zebra.mr.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.mapreduce.TaskInputOutputContext;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.base.metadata.Metadata;
import com.aexp.gdac.zebra.base.metadata.MetadataRow;
import com.aexp.gdac.zebra.batches.StatsFileConstants;
import com.aexp.gdac.zebra.mr.DataTypes;
import com.aexp.gdac.zebra.mr.DelimiterCodes;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.command.*;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;


/**
 * 
 * @author aatri1
 * Creates Worker instances for Feed Level ,Column Level and Column Rule Level 
 * based on metadata passed.
 */

public class WorkerFactory {
	private static Logger log =  LogFactory.getLoggerInstance(WorkerFactory.class) ;
	
	public static Metadata metadata ;
	//this map will have information for worker, which column id will process which index in the record.
	//Index as Integer only as Long array is not supported in java as will be size of 17 GB. Which is waste.
	private static Map<Integer, Integer> columnIdIndexMap = new HashMap<Integer, Integer>(); 
	
	public static List<Worker> getWorkerList(TaskInputOutputContext context, Metadata metadata, boolean isReducerPhase){
		List<Worker> workerList = new ArrayList<Worker>();
		
		WorkerFactory.metadata = metadata;
		
		workerList.add(getFeedLevelWorker(context, WorkerFactory.metadata  , isReducerPhase));
		workerList.addAll(getColumnLevelWorkerList(context, WorkerFactory.metadata  , isReducerPhase));
		workerList.addAll(getColumnRuleLevelWorkerList(context, WorkerFactory.metadata  , isReducerPhase));
		workerList.addAll(getComplexColumnLevelWorkerList(context, WorkerFactory.metadata  , isReducerPhase));
		
		return workerList ;
			
		
	}
	
	private static Worker getFeedLevelWorker(TaskInputOutputContext context, Metadata metadata, boolean isReducerPhase){

		
		MetadataRow	mdRow = metadata.getFeedLevelMetadata();

		
		Worker worker = null;
		if(StatsFileConstants.MR_INPUT_FILE_FORMAT_DELIMITER.equals(mdRow.getFileFormat())){
			worker = new Worker(context, mdRow.getFeedId().toString(),mdRow.getFeedName(), Level.FEED_LEVEL,DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()),isReducerPhase,
				mdRow.getFeedId() , mdRow.getStateId());
		}else if (StatsFileConstants.MR_INPUT_FILE_FORMAT_FIXED.equals(mdRow.getFileFormat())){
			worker = new Worker(context, mdRow.getFeedId().toString(),mdRow.getFeedName(), Level.FEED_LEVEL,DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()),isReducerPhase,
					mdRow.getFeedId() , mdRow.getStateId(),0,0);
		}else {
			throw new ZebraMRBatchException("FileFormat ["+mdRow.getFileFormat()+"] not recorgnized !",ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION);
		}
	//	log.info("FEED_LEVEL Worker created:"+" and delimiter set to "+DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()));
		/* add default feed level commands */
		worker.addCommand(new RecordCountCommand(isReducerPhase));
		
		return worker;
	}

	private static List<Worker> getColumnLevelWorkerList(TaskInputOutputContext context, Metadata metadata, boolean isReducerPhase){
		MetadataRow mdRow  = null ;
		List<Worker> workerList = new ArrayList<Worker>();
		

		int startIndex = 0;
		int endIndex =0 ;
		int cumLength = 0;
		int columnCursor = 0 ;
		int recordIndex=0;
		
		while((mdRow = metadata.getNextColumnMetadata())!=null){
			Worker worker = null ;
			
			if(StatsFileConstants.MR_INPUT_FILE_FORMAT_DELIMITER.equals(mdRow.getFileFormat())){
				worker = new Worker(context,""+mdRow.getColumnId(),mdRow.getColumnName(), Level.COLUMN_LEVEL,DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()),isReducerPhase,
					mdRow.getFeedId() , mdRow.getStateId());
			}else if (StatsFileConstants.MR_INPUT_FILE_FORMAT_FIXED.equals(mdRow.getFileFormat())){
				/** For fixed file format  **/
				while(columnCursor < mdRow.getColumnId()){
					if(cumLength > 0){
						startIndex = cumLength ;
						
					}
					columnCursor ++ ;
					cumLength = cumLength + getDataTypeLengthByColumnID(metadata,columnCursor);
					endIndex = cumLength ;
				}
			//	cumLength = cumLength + DataTypes.calculateDataLength(mdRow.getDataType(), mdRow.getDataFormat());
			//	endIndex = cumLength ;

				worker = new Worker(context,""+mdRow.getColumnId(),mdRow.getColumnName(), Level.COLUMN_LEVEL,DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()),isReducerPhase,
						mdRow.getFeedId() , mdRow.getStateId(),startIndex,endIndex);
				
			//	startIndex = cumLength ;
			} else{
				throw new ZebraMRBatchException("FileFormat ["+mdRow.getFileFormat()+"] not recorgnized !",ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION);
			}
			columnIdIndexMap.put(new Integer(""+mdRow.getColumnId()), recordIndex);
			worker.setRecordIndex(recordIndex);
			recordIndex++;
			/* add default column level commands */
			worker.addCommand(new RecordCountCommand(isReducerPhase));
			//worker.addCommand(new CountDistinctCommand(isReducerPhase));
			worker.addCommand(new NullCountCommand(isReducerPhase,worker.isFixed()));
			worker.addCommand(new AverageCommand(isReducerPhase));
			worker.addCommand(new MinValueCommand(isReducerPhase));
			worker.addCommand(new MaxValueCommand(isReducerPhase));
			worker.addCommand(new DataTypeCheckCommand(mdRow.getDataFormat(),mdRow.getDataType(),isReducerPhase));
			
			workerList.add(worker);
		}
		
		metadata.resetBookMarks(Level.COLUMN_LEVEL);
		
		return workerList ;
	}
	
	private static List<Worker> getColumnRuleLevelWorkerList(TaskInputOutputContext context, Metadata metadata, boolean isReducerPhase){

		List<Worker> workerList = new ArrayList<Worker>();
		List<MetadataRow> mdRowList = null;
		
		int startIndex = 0;
		int endIndex =0 ;
		int cumLength = 0;
		int columnCursor = 0 ; 
		
		while(!(mdRowList = metadata.getNextColumnRuleMetadata()).isEmpty()){
			Worker worker = null ;
			if(StatsFileConstants.MR_INPUT_FILE_FORMAT_DELIMITER.equals(mdRowList.get(0).getFileFormat())){
				
				worker = new Worker(context,""+mdRowList.get(0).getColumnId(),mdRowList.get(0).getColumnName(),Level.COLUMN_RULE_LEVEL,DelimiterCodes.delimiterCode.get(mdRowList.get(0).getColumnDelimiter()),
					isReducerPhase, mdRowList.get(0).getFeedId() ,mdRowList.get(0).getStateId());
				
			}else if (StatsFileConstants.MR_INPUT_FILE_FORMAT_FIXED.equals(mdRowList.get(0).getFileFormat())){
				/** For fixed file format  **/
				
				while(columnCursor < mdRowList.get(0).getColumnId()){
					if(cumLength > 0){
						startIndex = cumLength ;
						
					}
					columnCursor ++ ;
					cumLength = cumLength + getDataTypeLengthByColumnID(metadata,columnCursor);
					endIndex = cumLength ;
				}
				
				//cumLength = cumLength + getDataTypeLengthByColumnID(metadata,mdRowList.get(0).getColumnId());
				
				//log.info("[ColumnID:"+mdRowList.get(0).getColumnId()+", startPos:"+startIndex+", endIndex:"+endIndex+"]");

				worker = new Worker(context,""+mdRowList.get(0).getColumnId(),mdRowList.get(0).getColumnName(), Level.COLUMN_RULE_LEVEL,DelimiterCodes.delimiterCode.get(mdRowList.get(0).getColumnDelimiter()),isReducerPhase,
						mdRowList.get(0).getFeedId() , mdRowList.get(0).getStateId(),startIndex,endIndex);
				
				//startIndex = cumLength ;
			} else{
				throw new ZebraMRBatchException("FileFormat ["+mdRowList.get(0).getFileFormat()+"] not recorgnized !",ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION);
			}
			worker.setRecordIndex(columnIdIndexMap.get(new Integer(""+mdRowList.get(0).getColumnId())));
			//System.out.println(mdRowList);
			for(MetadataRow mdRow : mdRowList){				
				Command command = getRegisterdCommand(""+mdRow.getRuleId(),""+mdRow.getColumnRuleId(),
						mdRow.getRuleParameter(),mdRow.getDataType(),mdRow.getDataFormat() ,isReducerPhase,worker.isFixed());
				if(command!=null){
					worker.addCommand(command);
				}
			}
			
			workerList.add(worker);
		}
		
		metadata.resetBookMarks(Level.COLUMN_RULE_LEVEL);
		
		return workerList ;
	}
	
	
	private static List<Worker> getComplexColumnLevelWorkerList(TaskInputOutputContext context, Metadata metadata, boolean isReducerPhase){
		MetadataRow mdRow  = null ;
		List<Worker> workerList = new ArrayList<Worker>();
		

		int startIndex = 0;
		int endIndex =0 ;
		int cumLength = 0;
		int columnCursor = 0 ;
		int recordIndex=0;
		
		while((mdRow = metadata.getNextColumnMetadata())!=null){
			Worker worker = null ;
			
			if(StatsFileConstants.MR_INPUT_FILE_FORMAT_DELIMITER.equals(mdRow.getFileFormat())){
				worker = new Worker(context,""+mdRow.getColumnId(),mdRow.getColumnName(), Level.COLUMN_COMPLEX_RULE_LEVEL,DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()),isReducerPhase,
					mdRow.getFeedId() , mdRow.getStateId());
			}else if (StatsFileConstants.MR_INPUT_FILE_FORMAT_FIXED.equals(mdRow.getFileFormat())){
				/** For fixed file format  **/
				while(columnCursor < mdRow.getColumnId()){
					if(cumLength > 0){
						startIndex = cumLength ;
						
					}
					columnCursor ++ ;
					cumLength = cumLength + getDataTypeLengthByColumnID(metadata,columnCursor);
					endIndex = cumLength ;
				}
			//	cumLength = cumLength + DataTypes.calculateDataLength(mdRow.getDataType(), mdRow.getDataFormat());
			//	endIndex = cumLength ;
				
				worker = new Worker(context,""+mdRow.getColumnId(),mdRow.getColumnName(), Level.COLUMN_COMPLEX_RULE_LEVEL,DelimiterCodes.delimiterCode.get(mdRow.getColumnDelimiter()),isReducerPhase,
						mdRow.getFeedId() , mdRow.getStateId(),startIndex,endIndex);
				
			//	startIndex = cumLength ;
			} else{
				throw new ZebraMRBatchException("FileFormat ["+mdRow.getFileFormat()+"] not recorgnized !",ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION);
			}
			
			worker.setRecordIndex(recordIndex);
			recordIndex++;
			
			/* add count distinct column level commands */
			worker.addCommand(new CountDistinctCommand(isReducerPhase,worker.isFixed()));

			
			workerList.add(worker);
		}
		
		
		metadata.resetBookMarks(Level.COLUMN_COMPLEX_RULE_LEVEL);
		
		return workerList ;
	}
	
	
	private static Command getRegisterdCommand(String ruleId , String columnRuleId, String parameter,
			String dataType, String dataFormat, boolean isReducerPhase, boolean isFixed){
		
		Command command = null;
		
		if(RuleCodeConstants.COMMAND_MIN_VALUE.equals(ruleId)){
			command = new MinValueCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_MAX_VALUE.equals(ruleId)){
			command = new MaxValueCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_AVERAGE_VALUE.equals(ruleId)){
			command = new AverageCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_DISTINCT_VALUE.equals(ruleId)){
			command = new DistinctCheckCommand(isReducerPhase);
		}/*else if(RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT.equals(ruleId)){
			command = new CountDistinctCommand(isReducerPhase);
		}*/else if(RuleCodeConstants.COMMAND_NULL_COUNT.equals(ruleId)){
			command = new NullCountCommand(isReducerPhase,isFixed);
		}else if(RuleCodeConstants.COMMAND_NOT_NULL_COUNT.equals(ruleId)){
			command = new NotNullCountCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_RECORD_COUNT.equals(ruleId)){
			command = new RecordCountCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_IN_RANGE.equals(ruleId)){
			command = new InRangeCommand(parameter,isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_VALID_VALUE.equals(ruleId)){
			command = new ValidValueCommand(parameter,isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_INVALID_VALUE.equals(ruleId)){
			command = new InValidValueCommand(parameter,isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_DATA_TYPE_CHECK.equals(ruleId)){
			command = new DataTypeCheckCommand(dataFormat,dataType,isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_CM11_CHECK.equals(ruleId)){
			command = new CM11CheckCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_CM13_CHECK.equals(ruleId)){
			command = new CM13CheckCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_CM15_CHECK.equals(ruleId)){
			command = new CM15CheckCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_DUPLICATE_VALUE_COUNT.equals(ruleId)){
			command = new DuplicateCountCommand(isReducerPhase);
		}else if(RuleCodeConstants.COMMAND_EMPTY_CHECK.equals(ruleId)){
			command = new EmptyCheckCommand(isReducerPhase);
		}		
		
		if(command != null){
			command.setColumnRuleId(columnRuleId);
		}
		
		return command;
	}
	
	private static int getDataTypeLengthByColumnID(Metadata metadata , long columnId){
		MetadataRow mdRow = metadata.getColumnLevelMetadata(columnId);
		return DataTypes.calculateDataLength(mdRow.getDataType(),mdRow.getDataFormat());
		
	}
	
}
