package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.DataTypes;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class DataTypeCheckCommand extends Command{
	private Logger log =  LogFactory.getLoggerInstance(DataTypeCheckCommand.class) ;
	

	private String dataFormat ;
	private String dataType ;
	private int recordLengthLimit ;
	private int precisionLengthLimit ;
	
	private long  failCount ;
	
	
	public DataTypeCheckCommand(Object dataFormat,Object dataType, boolean isReducerPhase){
		super(isReducerPhase);
		this.dataFormat = dataFormat.toString();
		this.dataType = dataType.toString() ;
		this.recordLengthLimit = DataTypes.calculateDataLength(this.dataType,this.dataFormat);
		this.precisionLengthLimit = DataTypes.calculatePrecision(this.dataType);
	}
	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		
		if(!isReducerPhase){
			if(checkDataLenth(o.toString())){
				if(checkDataType(o.toString())){
					if(checkPrecision(o.toString())){
						
					}else{
						//log.info("Record:["+o+"] Failed Precision Check");
					}
				}else{
					//log.info("Record:["+o+"] Failed Data Type Check");
				}
			}else{
				//log.info("Record:["+o+"] Failed Data Length Check");
			}

		}else{
			failCount = failCount + Long.parseLong(o.toString());
		}
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(""+failCount));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: DataTye Check failCount Calculated From InputSplit "+failCount);
				}
			}else if(o instanceof org.apache.hadoop.mapreduce.Reducer.Context){
				if(log.isDebugEnabled()){
					log.debug("Reducer: DataType Check failCount Calculated From Mapper Outputs "+failCount);
				}
				
				return new Long(failCount);
			}
			
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" +RuleCodeConstants.COMMAND_DATA_TYPE_CHECK , e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DATA_TYPE_CHECK + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException Occured "+RuleCodeConstants.COMMAND_DATA_TYPE_CHECK ,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DATA_TYPE_CHECK + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_DATA_TYPE_CHECK;
	}
	
	
	private boolean checkDataType(String value){
		if(DataTypes.TINYINT.equalsIgnoreCase(dataType)){
			try{
				int intValue = Integer.parseInt(value);
				if(intValue < 0 || intValue > 255){
					failCount++;
					return false ;
				}
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}if(DataTypes.SMALLINT.equalsIgnoreCase(dataType)){
			try{
				Short.parseShort(value);
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}if(DataTypes.INT.equalsIgnoreCase(dataType)){
			try{
				Integer.parseInt(value);
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}if(DataTypes.INTEGER.equalsIgnoreCase(dataType)){
			try{
				Integer.parseInt(value);
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}else if(DataTypes.BIGINT.equalsIgnoreCase(dataType)){
			try{
				Long.parseLong(value);
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}else if(dataType.contains(DataTypes.DOUBLE)){
			try{
				Double.parseDouble(value);
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}else if(dataType.contains(DataTypes.DECIMAL)){
			try{
				Double.parseDouble(value);
			}catch(NumberFormatException e){
				failCount++;
				return false ;
			}
		}else if(DataTypes.DATETIME.equalsIgnoreCase(dataType) || DataTypes.DATE.equalsIgnoreCase(dataType)){
			 try {
				new SimpleDateFormat(dataFormat).parse(value);
			} catch (ParseException e) {
				failCount ++;
				return false ;
			}
			 
		}else if(dataType.contains(DataTypes.VARCHAR) || dataType.contains(DataTypes.CHAR) || dataType.contains(DataTypes.STRING)){
			// No check for text based data type 
		}
		
		return true ;
	}
	
	private boolean checkPrecision(String value){
		if(precisionLengthLimit  > 0){
			if(value.contains(DataTypes.precisionChar)){
				String[] valueSplits = value.split("\\"+DataTypes.precisionChar);
				if(valueSplits.length > 1){
					if(valueSplits[1].length() > precisionLengthLimit){
						failCount ++;
						return false;
					}
				}else{
					failCount ++;
					return false;
				}
			}else{
				failCount ++;
				return false;
			}
		}
		return true ;
	}
	
	private  boolean checkDataLenth(String value){
		if(value.length() > this.recordLengthLimit){
			failCount ++; 
			return false ;
		}
		
		return true ;
	}
	

	

}
