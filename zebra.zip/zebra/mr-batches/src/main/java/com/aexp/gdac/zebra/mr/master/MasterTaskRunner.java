package com.aexp.gdac.zebra.mr.master;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.aexp.gdac.zebra.base.Action;
import com.aexp.gdac.zebra.base.jdbc.model.FeedMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.SLAMetadata;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.batches.CommonStatsWriter;
import com.aexp.gdac.zebra.batches.TaskInputParams;
import com.aexp.gdac.zebra.batches.ZebraBatchDAO;
import com.aexp.gdac.zebra.batches.ZebraBatchException;
import com.aexp.gdac.zebra.batches.mailsender.MailSender;
import com.aexp.gdac.zebra.batches.mdgen.MetadataFileCreator;
import com.aexp.gdac.zebra.batches.statsloader.StatsFileLoader;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.job.ZebraStatsGenDriver;

/*
 * MasterTaskRunner was created to integrate all three subprocesses in single fat jar.
 *  
 * Executes below mentioned processes one by one
 * 1) Generates Metadata ( MetadataFileCreator )
 * 2) Generates Stats (ZebraStatsGenDriver) 
 * 3) Load Stat Files (StatsFileLoader) 
 * 
 * Execution Flow
 * ->Check for Skip Day
 * ->Generates interm file for ticket robo
 * ->Register Stats
 * ->Generates Metadata File
 * ->Execute MR Job to Generate Stat Files.
 * ->Load Stats from generated Stats files.
 * ->Generate interm file for email notification
 * 
 * Script return below exit codes 
 * 11- PASS
 * 12- ALERT
 * 13- ABORT
 * 21- SKIP DAY
 * 1- ERROR
 */

public class MasterTaskRunner {
	private static org.apache.log4j.Logger log = Logger.getLogger(MasterTaskRunner.class);
	
		private static ZebraBatchDAO zebraBatchDAO ;
		private static final String application_id = "MasterTaskRunner"; 
		public static final String RUN_DATE_FORMAT = "yyyy-MM-dd";
		private CommonStatsWriter statsWriter;
		
	public static void main(String args[]) throws ZebraBatchException{
		if(args.length<6){
			System.err.println("hadoop com.aexp.gdac.zebra.batches.master.MasterTaskRunner "
					+ " --statsOutDir=<task_stats_output_dir> --mdOutDir=<task_md_output_dir> --feedId=<task_feed_id>"
					+ " --queueName=<task_queue_name> --reducerCount=<task_reducer_count_default[10]> --userId=<task_userid> --feedName=<task-input-filepath-optional> "
					+ "--inputFeedPath=<task-input-feed-name-optional> --portalUrl=<option-zebra-portal-url> --runDate=<optinal-run-date> --tktRoboIntermFile=<imr-interm-file>");
			System.exit(1);
		}
		
		log.info("Started:"+new java.sql.Timestamp(new Date().getTime()));
		
		MasterTaskRunner mtr = new MasterTaskRunner(args) ;
		
		try {
			
			mtr.execute();
		
		log.info("Finnished:"+new java.sql.Timestamp(new Date().getTime()));
			
			
		} catch (ZebraBatchException zbe) {
			log.error("Batch Job Failed ! ",zbe);
			zbe.printStackTrace();
			reportFailure(zbe);
			if(zbe.getReason() == ZebraBatchException.Reason.SKIP_DAY_EXCEPTION){
				System.exit(21);
			}
			else if (ZebraStatsGenDriver.isJobKilled()){
				System.exit(15);
			}
			else {
				System.exit(1);
			}
		} catch (ZebraMRBatchException zmbe){
			log.error("MapReduce Job Failed ! ",zmbe);
			zmbe.printStackTrace();
			reportFailure(zmbe);
			System.exit(1);
		} catch (Throwable t){
			log.error("Fatal Error Job Failed ! ",t);
			t.printStackTrace();
			reportFailure(t);
			System.exit(1);
		}
		
		
		if (Action.ABORT.name().equals(TaskInputParams.stl_action)){
			System.exit(13);
		}else if(Action.ALERT.name().equals(TaskInputParams.stl_action)) {
			System.exit(12);
		}else if(Action.PASS.name().equals(TaskInputParams.stl_action)){
			System.exit(11);
		}
		
		
		System.exit(0);
	}

	private MasterTaskRunner(String args[]) throws ZebraBatchException{
		//loadParameters(args);	
	
		 loadNamedParemeters(args);
		 TaskInputParams.assertMandatoryParameters();
		 statsWriter = new CommonStatsWriter(TaskInputParams.task_interm_file,true);
		 zebraBatchDAO = new ZebraBatchDAO();
	}
	/*
	private void loadParameters(String args[]){

		TaskInputParams.task_stats_output_dir =args[0];
		TaskInputParams.task_md_output_dir = args[1] ;
		TaskInputParams.task_feed_id = args[2] ;
		TaskInputParams.task_queue_name = args[3];
		TaskInputParams.task_reducer_count = args[4];
		TaskInputParams.task_userid = args[5];
		
		if(args.length>6){
			TaskInputParams.task_input_file_path = args[6] ; 
		}
		
		if(args.length>7){
			TaskInputParams.task_feed_name = args[7];
		}
				
	}
	*/
	private void loadNamedParemeters(String[] args){
		StringBuilder user_args = new StringBuilder("");
		
		for(String arg : args){
			if(args == null ){
				continue ;
			}
			
			user_args.append(arg + " ");
			
			if(arg.contains(TaskInputParams.statsOutDir)){
				TaskInputParams.task_stats_output_dir =TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.mdOutDir)){
				TaskInputParams.task_md_output_dir = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.feedId)){
				TaskInputParams.task_feed_id = TaskInputParams.getParameterValue(arg); 
			}else if(arg.contains(TaskInputParams.queueName)){
				TaskInputParams.task_queue_name = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.reducerCount)){
				TaskInputParams.task_reducer_count = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.userId)){
				TaskInputParams.task_userid = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.inputFeedPath)){
				TaskInputParams.task_input_file_path = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.feedName)){
				TaskInputParams.task_feed_name = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.intermFile)){
				TaskInputParams.task_interm_file = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.portalUrl)){
				TaskInputParams.task_portal_url = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.runDate)){
				TaskInputParams.task_run_date = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.ticketRoboIntermFile)){
				TaskInputParams.task_ticketrobo_interm_file = TaskInputParams.getParameterValue(arg);
			}else if(arg.contains(TaskInputParams.badRecordRejectCount)){
				TaskInputParams.badRecRejectCount = TaskInputParams.getParameterValue(arg);
			}
			
		}
		
		log.info("USER ARGS : ["+ user_args.toString() + "]");
	}
	
	
	private  void execute() throws ZebraBatchException{
		
		try {
			Timestamp runDate = null ;
			if(TaskInputParams.task_run_date != null){
				try {
					/*generate rundate timestamp*/
					runDate = new Timestamp(new SimpleDateFormat(RUN_DATE_FORMAT).parse(TaskInputParams.task_run_date).getTime()) ;
				
					/* update with current time details */
					Date currDate = new  Date() ;
					runDate.setHours(currDate.getHours());
					runDate.setMinutes(currDate.getMinutes());
					runDate.setSeconds(currDate.getSeconds());

				} catch (ParseException e) {
					throw new ZebraBatchException("Rundate format must be ["+RUN_DATE_FORMAT+"]",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
				}
			}
				/* check for skip day  */
				assertSkippDay(runDate);
				

				/* Check if file name is provided explicitly and if yes register stats before starting execution */
			
				if(TaskInputParams.task_input_file_path != null ){
					TaskInputParams.task_state_id = registerStats(runDate).toString();
				}
				
				log.info("Stats Registerd in DB :["+TaskInputParams.task_state_id+"]");
				
				MetadataFileCreator.main(TaskInputParams.getMetadataGenInputArgs());
				
				TaskInputParams.task_target_email_id = MetadataFileCreator.targetEmailId ;
				TaskInputParams.task_state_id = MetadataFileCreator.stateId ;
				
				try {			
					ZebraStatsGenDriver.main(TaskInputParams.getStatsGeneratorInputArgs(MetadataFileCreator.inputFilePath, 
							MetadataFileCreator.metadataFile, MetadataFileCreator.header, MetadataFileCreator.tailer, MetadataFileCreator.stateId));
					if(ZebraStatsGenDriver.isJobKilled()){
						throw new ZebraBatchException(" Mapreduce phase is terminated due to bad record count is more than provided threashold.",ZebraBatchException.Reason.BAD_RECORD_EXCEPTION);
					}
				} catch (ZebraMRBatchException e) {
					throw new ZebraBatchException(ZebraBatchException.Reason.STATS_GENERATOR_EXCEPTION,e);
				}catch (Throwable t) {
					throw new ZebraBatchException(ZebraBatchException.Reason.STATS_GENERATOR_EXCEPTION,t);
				}
				
				StatsFileLoader.main(TaskInputParams.getStatsLoaderInputArgs());
				
				TaskInputParams.stl_action = StatsFileLoader.action ;
				
				/* send mail in case of ALERT and ABORT */
				if(StatsFileLoader.action != null 
						&& !Action.PASS.name().equals(StatsFileLoader.action)){
					
					/*	MailSender.sendMail("Zebra "+MetadataFileCreator.feedId+":"+MetadataFileCreator.feedName+" "+StatsFileLoader.action
								, TaskInputParams.task_target_email_id, getJobStats());
					*/
					printHtmlStats();
				}else if (Action.PASS.name().equals(StatsFileLoader.action)){
					/* Mail must not be sent in case of PASS , its handling is done in script now */
					
					printHtmlStats();
				}
				
				/* Generate Ticket Robo File */
				generateTicketRoboFile() ;
				
		} finally{
			TaskInputParams.task_target_email_id = MetadataFileCreator.targetEmailId ;
			TaskInputParams.task_state_id = MetadataFileCreator.stateId ;
		}
	}
	
	private static void reportFailure(Throwable t) throws  ZebraBatchException{
		
		String errorMessage = t.getMessage();
		
		errorMessage = " FeedID :"+ TaskInputParams.task_feed_id
				+"\n"+ " UserId :"+ TaskInputParams.task_userid
				+"\n"+ " StateID :"+ TaskInputParams.task_state_id
				+"\n"+ " OutDir :"+ TaskInputParams.task_stats_output_dir
				+"\n"+ " Error :"+ errorMessage ;
	
		if(errorMessage.length() > 7999){
			errorMessage = errorMessage.substring(0,7999);
		}
		
		if(TaskInputParams.task_state_id != null 
				&& !TaskInputParams.task_state_id.trim().isEmpty()){
			updateStatus(Long.parseLong(TaskInputParams.task_state_id), errorMessage);
			
		}
		zebraBatchDAO.logError(application_id,TaskInputParams.task_userid,TaskInputParams.task_state_id, t);
		MailSender.sendMailToGroup("Zebra Job Failed", errorMessage);
	}
	

	public Long registerStats(Timestamp runDate) throws ZebraBatchException{
		Stats stat = new Stats();
		stat.setFeedID(Long.parseLong(TaskInputParams.task_feed_id));
		
		if(TaskInputParams.task_feed_name!=null){
			stat.setFeedName(TaskInputParams.task_feed_name);
		}else{
			stat.setFeedName("FeedID :"+TaskInputParams.task_feed_id);
		}
		
		stat.setInputFilePath(TaskInputParams.task_input_file_path);
		if(runDate==null){
			stat.setRunDate(new Timestamp(new Date().getTime()));
		}else{
			stat.setRunDate(runDate);
		}
		stat.setUserID(TaskInputParams.task_userid);
		stat.setCreated(new Timestamp(new Date().getTime()));
		stat.setOutputDirPath(TaskInputParams.task_md_output_dir);
		return (Long)zebraBatchDAO.registerStats(stat);
		
	}
	
	private static void updateStatus(long stateID, String message) throws ZebraBatchException{
		Stats stat = new Stats();
		
		stat.setStateID(stateID);
		if(message!=null && message.length() >100){
			message = message.substring(0,99);
		}
		stat.setErrorMessage(message);
		
    	//StatsDAO statsDAO = (StatsDAO)ZebraResourceManager.getBean("statsDAO");
    	
    	zebraBatchDAO.updateStatsErrorMessage(stat);
	}
	
	private  void printHtmlStats(){
	
		statsWriter.insertMetadataRow("Receiver", TaskInputParams.task_target_email_id);
		statsWriter.insertMetadataRow("Subject", "Zebra "+MetadataFileCreator.feedId+"-"+MetadataFileCreator.feedName+" "+StatsFileLoader.action);
		
		statsWriter.insertHTMLRow("FeedID", TaskInputParams.task_feed_id, false);
		statsWriter.insertHTMLRow("InputFile", MetadataFileCreator.inputFilePath, false);
		statsWriter.insertHTMLRow("MetadataFile", MetadataFileCreator.metadataFile, false);
		statsWriter.insertHTMLRow("StatsOutDir", TaskInputParams.task_stats_output_dir, false);
		statsWriter.insertHTMLRow("Action", StatsFileLoader.action, false);
		statsWriter.insertHTMLRow("Feed Stats Count", ""+StatsFileLoader.feed_stats_count, false);
		statsWriter.insertHTMLRow("Column Stats Count", ""+StatsFileLoader.column_stats_count, false);
		statsWriter.insertHTMLRow("Column Rule Stats Count",""+ StatsFileLoader.column_rule_stats_count, false);
		statsWriter.insertHTMLRow("Portal URL",TaskInputParams.task_portal_url, false);
		statsWriter.insertHTMLRow("Alert/Abort Hit Count", StatsFileLoader.failedRule.toString().replace("\n", "<br>"), true);

	}
	
	
	private static String getJobStats(){
		String textStats = "FeedID:" +TaskInputParams.task_feed_id
				+"\n"+"InputFile:" +MetadataFileCreator.inputFilePath
				+"\n"+"MetadataFile:" +MetadataFileCreator.metadataFile
				+"\n"+"StatsOutDir:" +TaskInputParams.task_stats_output_dir
				+"\n"+"Action:" +StatsFileLoader.action
				+"\n"+"Feed Stats Count:"+StatsFileLoader.feed_stats_count
				+"\n"+"Column Stats Count:"+StatsFileLoader.column_stats_count
				+"\n"+"Column Rule Stats Count:"+StatsFileLoader.column_rule_stats_count;
		return textStats ;
	}
	
	private static void assertSkippDay(Timestamp userRunDate) throws NumberFormatException, ZebraBatchException{
		SLAMetadata slaMd = zebraBatchDAO.getEligibleSLAMetadataByFeedId(Long.parseLong(TaskInputParams.task_feed_id)) ;
		java.sql.Timestamp rundate_timestamp = new java.sql.Timestamp(new java.util.Date().getTime());
		
		if(userRunDate!=null &&
				(rundate_timestamp.compareTo(userRunDate) < 0)){
			throw new ZebraBatchException("Rundate provided cannot be greater than current timestamp",ZebraBatchException.Reason.CANNOT_PROCEED_EXCEPTION);
		}
		
		if(userRunDate!=null){
			rundate_timestamp = userRunDate ;
		}
		
		int skipday = -1;
		if(slaMd!= null && (slaMd.isDaily() || slaMd.isIntraDay()) && slaMd.getSkipDayOfWeek()!=null){
			int skipdays = slaMd.getSkipDayOfWeek();
			while(!((skipday = skipdays%10) == 0) ){
				//from UI -    Sunday - 1, Monday - 2, Tuesday - 3, Wednesday -4, Thursday - 5, Friday - 6, Saturday - 7 //this is due to DB limitation 01 converts to 1 in DB int skipday field
				//java.util -  Sunday - 0, Monday - 1, Tuesday - 2, Wednesday -3, Thursday - 4, Friday - 5, Saturday - 6 
				if((skipday-1) == rundate_timestamp.getDay())
					throw new ZebraBatchException("Today is the skip day for feed["+TaskInputParams.task_feed_id+"]",ZebraBatchException.Reason.SKIP_DAY_EXCEPTION);
				
				skipdays = skipdays/10;
		    }
		}
		
		
//		/* check for skip day */
//		if(slaMd!= null &&
//			(slaMd.isDaily() || slaMd.isIntraDay()) &&
//				slaMd.getSkipDayOfWeek()!=null &&
//				(slaMd.getSkipDayOfWeek() == rundate_timestamp.getDay() || // check for particular day
//					(slaMd.getSkipDayOfWeek() == 7 && 
//						(rundate_timestamp.getDay() == 0 || // check for weekend
//								rundate_timestamp.getDay() ==6
//						)
//					)
//				)
//			){
//			
//			throw new ZebraBatchException("Today is the skip day for feed["+TaskInputParams.task_feed_id+"]",ZebraBatchException.Reason.SKIP_DAY_EXCEPTION);
//		}
		
	}
	
	private static void generateTicketRoboFile() throws ZebraBatchException {
		try {
			
			FeedMetadata feedMd = zebraBatchDAO.getEligibleFeedMetadata(Long.parseLong(TaskInputParams.task_feed_id)) ;
			
			if(feedMd != null && feedMd.getTicketRobo() !=null && Boolean.parseBoolean(feedMd.getTicketRobo())){
				if(TaskInputParams.task_ticketrobo_interm_file!=null && feedMd.getAGRP()!= null && feedMd.getRGRP()!=null){
					CommonStatsWriter ticketRoboWriter = new  CommonStatsWriter(TaskInputParams.task_ticketrobo_interm_file) ;
					ticketRoboWriter.insertRow("AGRP", feedMd.getAGRP(), false);
					ticketRoboWriter.insertRow("RGRP", feedMd.getAGRP(), false);
					ticketRoboWriter.insertRow("OUT_DIR", TaskInputParams.task_stats_output_dir, false);
					ticketRoboWriter.insertRow("FEED_ID", TaskInputParams.task_feed_id, false);
					ticketRoboWriter.insertRow("STATE_ID", TaskInputParams.task_state_id, false);
					ticketRoboWriter.insertRow("FEED_NAME", feedMd.getFeedName(), true);
				}
			}
		} catch (ZebraBatchException e) {
			throw new ZebraBatchException("Failed while fetching Metadata for Feed ["+TaskInputParams.task_feed_id+"]",ZebraBatchException.Reason.UNEXPECTED_EXCEPTION);
		}
	}
	
}
