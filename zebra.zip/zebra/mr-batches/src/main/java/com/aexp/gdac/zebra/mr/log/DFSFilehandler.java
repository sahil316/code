package com.aexp.gdac.zebra.mr.log;

import java.io.IOException;


import java.io.PrintStream;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class DFSFilehandler {
	private static String jobName;
	private static String dirName;
	private static String taskAttemptId;
	private static FSDataOutputStream outStreamWriter ;
	private static int replicationFactor = 1;
	private static Path logfilepath;
	private static Configuration conf;
	private static FileSystem fileSys;
	
	public DFSFilehandler(String jobName,String dirName, String taskAttemptId) throws IOException{
		DFSFilehandler.jobName = jobName;
		DFSFilehandler.dirName = dirName;
		DFSFilehandler.taskAttemptId = taskAttemptId;
		
		setUpOutStreamWriter();

	}
	
	public DFSFilehandler(String jobName,String dirName, String taskAttemptId, int replicationFactor) throws IOException{
		DFSFilehandler.jobName = jobName;
		DFSFilehandler.dirName = dirName;
		DFSFilehandler.taskAttemptId = taskAttemptId;
		DFSFilehandler.replicationFactor = replicationFactor;
		
		setUpOutStreamWriter();

	}
	
	private void setUpOutStreamWriter() throws IOException{

		if(DFSFilehandler.logfilepath == null){
			DFSFilehandler.logfilepath =  new Path( DFSFilehandler.dirName = dirName + "/_log/"+DFSFilehandler.taskAttemptId+"_"+DFSFilehandler.jobName+".log"); 
		}
		
		if(conf == null || fileSys == null){
			conf = new Configuration();           
			fileSys = FileSystem.get(conf);
		}
		
      	if(fileSys.exists(logfilepath)){
      		DFSFilehandler.outStreamWriter = fileSys.append(logfilepath,4096);
      	}else{
      		DFSFilehandler.outStreamWriter = fileSys.create( logfilepath,true, // overwrite      
    				4096, // buffersize      
    				(short) DFSFilehandler.replicationFactor, // replication    
    				(long)(64*1024*1024) // chunksize          
    				);   
      	}
      	

	}
	
	public synchronized void write(String logStatement) throws IOException{
		if(logStatement != null){
			setUpOutStreamWriter();
			outStreamWriter.write(logStatement.getBytes());    
			outStreamWriter.close();       
		}
	}
	
	public synchronized void writeError(String logStatement, Exception e) throws IOException{
		if(logStatement != null){
			setUpOutStreamWriter();
			outStreamWriter.write(logStatement.getBytes());
			e.printStackTrace(new PrintStream(outStreamWriter));
			outStreamWriter.close();       
		}
	}
	
	
	public static String getDirName() {
		return dirName;
	}


	public static void setDirName(String dirName) {
		DFSFilehandler.dirName = dirName;
	}


	public static String getJobName() {
		return jobName.replace(" ", "_");
	}


	public static void setJobName(String jobName) {
		DFSFilehandler.jobName = jobName.replace(" ", "_");
	}

}
