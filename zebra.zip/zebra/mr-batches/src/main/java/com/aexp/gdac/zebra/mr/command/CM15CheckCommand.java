package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class CM15CheckCommand extends Command{
	/*
	 * The CM 15 Card Number Check
	 * is a business rule which verifies that the Card Number is a possible Amex
	 * Card Number - it does verify that it is an issued Card Number. The
	 * current valid Card Numbers are between 340000000000000 - 349999999999999 and
	 * 370000000000000 - 379999999999999.
	 */
	
	
	private Logger log =  LogFactory.getLoggerInstance(CM15CheckCommand.class) ;
	
	public CM15CheckCommand(boolean isReducerPhase) {
		super(isReducerPhase);
		// TODO Auto-generated constructor stub
	}

	private long failCount ;
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		
				if(!isReducerPhase){
				
				try{
					long num = Long.parseLong(o.toString());
						if (((num >= 340000000000000L) && (num <= 349999999999999L))
							|| ((num >= 370000000000000L) && (num <= 379999999999999L))) {
							// do nothing
						}else{
							failCount++;
						}
					}catch(NumberFormatException nfe){
					
						log.debug(RuleCodeConstants.COMMAND_CM11_CHECK + " Input is not a number :" +o);
						failCount ++;
					}
				}else{
					failCount = failCount + Long.parseLong(o.toString());
					
				}		
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(""+failCount));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: CM13 Check failCount Calculated From InputSplit "+failCount);
				}
			}else if(o instanceof org.apache.hadoop.mapreduce.Reducer.Context){
				if(log.isDebugEnabled()){
					log.debug("Reducer: CM13 Check failCount Calculated From Mapper Outputs "+failCount);
				}
				
				return new Long(failCount);
			}
			
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" +RuleCodeConstants.COMMAND_CM15_CHECK , e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_CM15_CHECK + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException Occured "+RuleCodeConstants.COMMAND_CM15_CHECK ,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_CM15_CHECK + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	@Override
	public void setRuleId() {
		this.ruleId = RuleCodeConstants.COMMAND_CM15_CHECK ;
		
	}



}
