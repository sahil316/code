package com.aexp.gdac.zebra.mr.log;

import org.apache.hadoop.conf.Configuration;

public class LogFactory {

	public static final String CONF_LOG_PATH= "log.com.aexp.zebra.path";
	public static final String CONF_JOB_NAME = "log.com.aexp.zebra.jobname";
	
	public static Logger getLoggerInstance(String jobName,String dirName,String taskAttemptId,Class classzz){
		return new LoggerImpl(jobName,dirName,taskAttemptId,classzz);
	}

	public static Logger getLoggerInstance(Class classzz){
		return new LoggerImpl(classzz);
	}
	
	
	
	/** default replication factor is 1 . And its recommended not to be increased unless really necessary 
	 * */
	
	public static Logger getLoggerInstance(String jobName,String dirName,int replicatoinFactor,String taskAttemptId,Class classzz){
		return new LoggerImpl(jobName,dirName,replicatoinFactor,taskAttemptId,classzz);
	}
	
	public static Logger getLoggerInstance(Class classzz,int replicatoinFactor){
		return new LoggerImpl(classzz,replicatoinFactor);
	}
	
	
	public static String getAttemptId(Configuration conf,boolean isReucerPhase) 
	   {
		try{
	       if (conf == null) {
	           throw new NullPointerException("conf is null");
	       }

	       String taskId = conf.get("mapred.task.id");
	       if (taskId == null) {
	           throw new IllegalArgumentException("Configutaion does not contain the property mapred.task.id");
	       }

	       String[] parts = taskId.split("_");
	       if (parts.length != 6 ||
	               !parts[0].equals("attempt") ||
	               (!"m".equals(parts[3]) && !"r".equals(parts[3]))) {
	           throw new IllegalArgumentException("TaskAttemptId string : " + taskId + " is not properly formed");
	       }
	       String suffix = "m";
	       if(isReucerPhase){
	    	   suffix ="r";
	       }
	       return parts[4] + "-" + parts[5]+"-"+suffix;
	   }catch(Exception e){
		   // suppressing exceptions 
	   }
		return "";
	}

}
