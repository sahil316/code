package com.aexp.gdac.zebra.mr.job;


import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.SnappyCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.aexp.gdac.zebra.base.ZebraResourceManager;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.jdbc.dao.StatsDAO;
import com.aexp.gdac.zebra.base.jdbc.model.Stats;
import com.aexp.gdac.zebra.batches.StatsFileConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;


public class ZebraStatsGenDriver extends Configured implements Tool{

	private static long stateId ;
	private static boolean masterRun ;
	private static boolean isJobKilled;

	public static void main(String[] args) throws Exception  {
			  if(args.length < 7){
				  System.err.println("hadoop com.aexp.gdac.zebra.mr.job.ZebraStatsGenDriver <mr_output_dir>"
				  		+ " <mr_input_feed> <mr_md_file> <mr_queue_name> <mr_header> <mr_tailer> <mr_stateId> <optional-reducer-count-default-5> <optional-master-run> <optional-bad-record-reject-threshhold>");
			  }
				int res = ToolRunner.run(new Configuration(), new ZebraStatsGenDriver(), args);
				if(!masterRun){
					System.exit(res);
				}
	}

	@Override
		public int run(String[] args) throws Exception {
		int result =1;
		try{
			
	    	Configuration conf = getConf();
	    	//  String extraArgs[] = new GenericOptionsParser(conf, args).getRemainingArgs();
	
	    	conf.set("mapred.job.queue.name", args[3]);
	    	conf.set(LogFactory.CONF_LOG_PATH, args[1]);
	    	conf.set(LogFactory.CONF_JOB_NAME, "zebra");
	    	conf.set("zebra.header.present", args[4]);
	    	conf.set("zebra.tailer.present", args[5]);
	    	conf.set("mapred.task.ping.timeout", "600000");
	    	conf.set("mapred.job.shuffle.input.buffer.percent", "0.2");
	    	
	    	/* setting run stateId */
	    	this.stateId = Long.parseLong(args[6]);

	    	
			int reducerCount = 10 ;
			long badRecordsRejCount = -1 ;
			
			if(args.length > 7 && args[7]!= null){
				reducerCount = Integer.parseInt(args[7]);
			}
			
			if(args.length > 8 && "true".equals(args[8])) {
				masterRun = true ;
			}
	    	
			if(args.length > 9 && !args[9].equals("-1")){
				badRecordsRejCount = Long.parseLong(args[9]);
				conf.set("zebra.job.badRecRejThreshold", Long.toString(badRecordsRejCount));
			}

	    	// put md file in distributed cache
	    	DistributedCache.addCacheFile(new URI(args[2]), conf);
	    	
	    	// combiner not required
	    	Job job = new Job(conf, "zebra");
	    	job.setJarByClass(ZebraStatsGenDriver.class);
	    
	    	job.setMapperClass(DoNothingMapper.class);
	    	/* partitioner */
	    	job.setPartitionerClass(ZPartitioner.class);
	    	job.setReducerClass(WorkerExecutorReducer.class);
	    
	    	// set custom input format 
	    	job.setInputFormatClass(ZCustomFileInputFormat.class);
	    
	    	//Custom key 
	    	job.setMapOutputKeyClass(ZCustomKey.class);
	    	job.setMapOutputValueClass(Text.class);
	    
	    	job.setOutputKeyClass(NullWritable.class);
	    	job.setOutputValueClass(Text.class);
	    
	    	/* preventing creation of 0 byte part files*/
	    	LazyOutputFormat.setOutputFormatClass(job, TextOutputFormat.class);
	    
	    	// Multioutput format
	    	MultipleOutputs.addNamedOutput(job, StatsFileConstants.MR_OUT_FEED_LEVEL_FILE_NAME, TextOutputFormat.class, NullWritable.class, Text.class);
	    	MultipleOutputs.addNamedOutput(job, StatsFileConstants.MR_OUT_COLUMN_LEVEL_FILE_NAME, TextOutputFormat.class, NullWritable.class, Text.class);
	    	MultipleOutputs.addNamedOutput(job, StatsFileConstants.MR_OUT_COLUMN_RULE_LEVEL_FILE_NAME, TextOutputFormat.class, NullWritable.class, Text.class);
	     	MultipleOutputs.addNamedOutput(job, StatsFileConstants.MR_OUT_COMPLEX_COLUMN_LEVEL_FILE_NAME, TextOutputFormat.class, NullWritable.class, Text.class);
	    	MultipleOutputs.addNamedOutput(job, StatsFileConstants.MR_OUT_COMPLEX_COLUMN_RULE_LEVEL_FILE_NAME, TextOutputFormat.class, NullWritable.class, Text.class);
	    
	    	/* setting compression */
	    //	job.getConfiguration().setBoolean("mapred.compress.map.output", true);
	    //	job.getConfiguration().setClass("mapred.map.output.compression.codec",SnappyCodec.class, CompressionCodec.class);

	    	/*increse number of reducers */
	    	job.setNumReduceTasks(reducerCount);
	    	FileInputFormat.addInputPath(job, new Path(args[0]));
	    	FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    	
	    	job.submit();
	    	MRTrackerThread aMRTracker = null;
	    	if(args.length > 9 && !args[9].equals("-1")){
				aMRTracker = new MRTrackerThread(job);
				aMRTracker.setBadRecordRejectThreshold(badRecordsRejCount);
				aMRTracker.start();
			}
	    	//result = (job.waitForCompletion(true) ? 0 : 1);
	    	job.monitorAndPrintJob();
	    	int completionPollIntervalMillis = Job.getCompletionPollInterval(conf);
			while (!job.isComplete()) {
				     try {
				       Thread.sleep(completionPollIntervalMillis);
				     } catch (InterruptedException ie) {
				     }
			}
	
			result = ( job.isSuccessful() ? 0 :1);
			
		}catch(ZebraMRBatchException zmbe){
			zmbe.printStackTrace();
			
			if(masterRun){
				throw zmbe ;
			}else {
				updateStatus(stateId,zmbe.getMessage());
			}
			
			result = 1;
			
		}catch(Throwable t){
			t.printStackTrace(); 
			
			if(masterRun){
				throw new ZebraMRBatchException(ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION , t) ;
			}else {
				updateStatus(stateId,t.getMessage());
			}
			
			result = 1;
		}

		return result;
	}
	
	private static void updateStatus(long stateID, String message){
			Stats stat = new Stats();
			
			stat.setStateID(stateID);
			stat.setErrorMessage(message);
			
	    	StatsDAO statsDAO = (StatsDAO)ZebraResourceManager.getBean("statsDAO");
	    	
	    	try {
				statsDAO.updateStatsErrorMessage(stat);
			} catch (ZebraServiceException e) {
				throw new ZebraMRBatchException("Exception Occured while updating stats status ",ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION,e);
			}
	}
	
	public static void setJobKilled(boolean isJobKilled) {
		ZebraStatsGenDriver.isJobKilled = isJobKilled;
	}
	public static boolean isJobKilled() {
		return isJobKilled;
	}
		
}
