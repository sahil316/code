package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class MinValueCommand extends Command{

	//private Logger log =  LogFactory.getLoggerInstance("MinMaxCount", "/idn/home/aatri1/output", MinValueCommand.class) ;
	private Logger log =  LogFactory.getLoggerInstance(MinValueCommand.class) ;
	
	private Double minValue ;
	
	public MinValueCommand(boolean isReducerPhase) {
		super(isReducerPhase);
		// TODO Auto-generated constructor stub
	}


	public void execute(Object o) throws ZebraMRBatchException{
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		try{
			if(minValue == null){
				minValue = Double.parseDouble(o.toString());
			}
		
			if(minValue > Double.parseDouble(o.toString())){
				minValue = Double.parseDouble(o.toString());
			}
		}catch(NumberFormatException nfe){
			log.debug(RuleCodeConstants.COMMAND_MIN_VALUE + " Input is not a number :" +o);
		}
	}
	
	public Object flush(Object o) throws ZebraMRBatchException{

		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(new Text(((minValue==null)?"NULL": minValue.toString()))));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: MinValue Calculated From InputSplit "+minValue);
				}
			}else if(o instanceof org.apache.hadoop.mapreduce.Reducer.Context){
				if(log.isDebugEnabled()){
					log.debug("Reducer: MinValue Calculated From Mapper Outputs "+minValue);
				}
				return minValue;
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" +RuleCodeConstants.COMMAND_MIN_VALUE, e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_MIN_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch(IOException e){
			log.error("IOException occured "+RuleCodeConstants.COMMAND_MIN_VALUE,e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_MIN_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,e);
		}
		
		return null;
	}
	
	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_MIN_VALUE;
	}

	
	
}
