package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class InRangeCommand extends Command{

	private Logger log =  LogFactory.getLoggerInstance(InRangeCommand.class) ;
	
	private static final String splitRegex = ":";
	private double upperLimit;
	private double lowerLimit;
	
	private long lowerLimitHit;
	private long upperLimitHit;
	private long outOfRangeCount ;
	
	public InRangeCommand(Object o, boolean isReducerPhase){
		super(isReducerPhase);
		String limits[] = o.toString().split(splitRegex);
		lowerLimit = Double.parseDouble(limits[0]);
		upperLimit = Double.parseDouble(limits[1]);
	}
	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		
		if(!isReducerPhase){
			try{
				if(Double.parseDouble(o.toString()) < lowerLimit){
					lowerLimitHit ++;
				}else if(Double.parseDouble(o.toString()) > upperLimit){
					upperLimitHit ++;
				}
			}catch(NumberFormatException nfe){
				log.debug(RuleCodeConstants.COMMAND_IN_RANGE + " Input is not a number :" +o);
			}
			outOfRangeCount = lowerLimitHit + upperLimitHit;
		}else{
				outOfRangeCount += Long.parseLong(o.toString());
		}

	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(""+(outOfRangeCount)));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: Out of Range Count Calculated From InputSplit "+(outOfRangeCount));
				}
			}else if(isReducerPhase){
				if(log.isDebugEnabled()){
					log.debug("Reducer: Out of Range Count Calculated From Mapper Outputs "+outOfRangeCount);
				}
				return new Long(outOfRangeCount);
			
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" + RuleCodeConstants.COMMAND_IN_RANGE,e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_IN_RANGE + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException occured "+RuleCodeConstants.COMMAND_IN_RANGE,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_IN_RANGE + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
		
	}

	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_IN_RANGE;
	}

}
