package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class CountDistinctCommand extends Command{


	private Logger log =  LogFactory.getLoggerInstance(CountDistinctCommand.class) ;
			
	private Set<String> distinctSet = new HashSet<String>();
	private boolean isFixed ;
	private String emptyRecord;
	
	public CountDistinctCommand(boolean isReducerPhase , boolean isFixed) {
		super(isReducerPhase);
		this.isFixed = isFixed ;
		
		if(!isFixed){
			this.emptyRecord = "";
		}
	}
	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		String record = null;
		
		if(o != null){
			record = o.toString() ;
		}
		
		if(!isFixed && (record == null || record.equals(emptyRecord) || record.isEmpty())){
			log.debug("Illegal record passed "+ record);
			return ;
		}else if(isFixed && 
				( record == null || record.equals(emptyRecord) || record.trim().isEmpty())){
			if(emptyRecord == null){
				emptyRecord = record ;
			}
			return ;
			
		}else{
			
			if(!distinctSet.contains(record)){
				distinctSet.add(record);
			}
			
		}
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {

		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				//((org.apache.hadoop.mapreduce.Mapper.Context)o).write(new Text(Constants.COMMAND_DISTINCT_VALUE), new LongWritable(maxValue));
				Text value = new Text();
				
				
				if(distinctSet.isEmpty()){
					((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey,value);
				}
				
				for(String setMember : distinctSet){
					value.set(setMember);
					((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey,value);
				}
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: Distinct Value Calculated From InputSplit "+distinctSet.size());
				}
				distinctSet.clear();
			}else if(isReducerPhase){
				if(log.isDebugEnabled()){
					log.debug("Reducer: Distinct Value From Mapper Outputs "+distinctSet.size());
				}
				long distinctCount = distinctSet.size();
				distinctSet.clear();	
				
				return new Long(distinctCount);
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured "+ RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT, e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		}catch(IOException ioe){
			log.error("IO exception "+RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	@Override
	public void setRuleId() {
		// TODO Auto-generated method stub
		 ruleId = RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT;
	}
	

	
}
