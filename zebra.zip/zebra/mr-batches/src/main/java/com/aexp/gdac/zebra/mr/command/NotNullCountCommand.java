package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class NotNullCountCommand extends Command{

	private Logger log =  LogFactory.getLoggerInstance(NotNullCountCommand.class) ;
	
	private long count;

	
	public NotNullCountCommand(boolean isReducerPhase){
		super(isReducerPhase);
	}
	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		if(isReducerPhase){
				count = count + Integer.parseInt(o.toString());
		}else if(o != null || o.toString().length() > 0){ //white spaces are treated as not null
			count++;			
		}
		
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(""+(count)));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: Null Count Calculated From InputSplit "+count);
				}
			}else if(o instanceof org.apache.hadoop.mapreduce.Reducer.Context){
				if(log.isDebugEnabled()){
					log.debug("Reducer: Null Count Calculated From Mapper Outputs "+count);
				}
				
				return new Long(count);
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" + RuleCodeConstants.COMMAND_NULL_COUNT,e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_NULL_COUNT + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException occured "+RuleCodeConstants.COMMAND_NULL_COUNT,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_NULL_COUNT + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		return null ;
	}
	
	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_NOT_NULL_COUNT;
	}
	

}
