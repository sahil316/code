package com.aexp.gdac.zebra.mr.log;

public interface Logger {

	void info(String logStatement);
	
	void error(String logStatement,Exception e);
	
	void debug(String logStatement);
	
	boolean isDebugEnabled();
	
	void setLevel(Level level);
	
	
	 enum Level{
			DEBUG,
			INFO,
			ERROR;
					
		}
}
