package com.aexp.gdac.zebra.mr.job;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

class DoNothingMapper extends Mapper<Object, Text, Text, Text>{
    
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
    	
    }
  }



