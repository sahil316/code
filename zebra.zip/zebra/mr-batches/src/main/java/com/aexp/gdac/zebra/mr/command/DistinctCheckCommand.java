package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class DistinctCheckCommand extends Command{
	
	public DistinctCheckCommand(boolean isReducerPhase) {
		super(isReducerPhase);

	}

	private Logger log =  LogFactory.getLoggerInstance(DistinctCheckCommand.class) ;
	
	private Set<String> distinctSet = new HashSet<String>();;

	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}else{
			String value = o.toString();
			if(!distinctSet.contains(value)){
				distinctSet.add(value);
			}
			
		}
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				org.apache.hadoop.mapreduce.Mapper.Context contextMapper = (org.apache.hadoop.mapreduce.Mapper.Context)o;
				Text value = new Text();
				for(String setMember : distinctSet){
					value.set(setMember);
					contextMapper.write(commandKey,value);
				}
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: Distinct Value Calculated From InputSplit "+distinctSet.size());
				}
				distinctSet.clear();
			}else if(isReducerPhase){
				
				int distinctCount = distinctSet.size();

				if(log.isDebugEnabled()){
					log.debug("Reducer: Distinct Value From Mapper Outputs "+distinctSet.size());
				}
				distinctSet.clear();
				
				if(distinctCount == 0){
					return true;
				}else{
					return false;
				}
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured "+RuleCodeConstants.COMMAND_DISTINCT_VALUE, e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DISTINCT_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException occured "+RuleCodeConstants.COMMAND_DISTINCT_VALUE, ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DISTINCT_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	
	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_DISTINCT_VALUE;
	}

}
