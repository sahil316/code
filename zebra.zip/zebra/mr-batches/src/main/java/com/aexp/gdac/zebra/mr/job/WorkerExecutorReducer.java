package com.aexp.gdac.zebra.mr.job;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.metadata.Metadata;
import com.aexp.gdac.zebra.base.metadata.MetadataParser;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;
import com.aexp.gdac.zebra.mr.tools.Worker;
import com.aexp.gdac.zebra.mr.tools.WorkerFactory;

public class WorkerExecutorReducer  extends Reducer<ZCustomKey,Text,NullWritable,Text>{
	//private Logger log =  LogFactory.getLoggerInstance("MinMaxCount", "/idn/home/aatri1/output", CommandExecutorReducer.class) ;
	private Logger log;
	
	private List<Worker> workerList ;
	

	//private CommandExecutor executor ;
	
	@Override
	public void setup(Context context) throws IOException, InterruptedException{
		super.setup(context);

		
		log = LogFactory.getLoggerInstance(context.getConfiguration().get(LogFactory.CONF_JOB_NAME), 
				context.getConfiguration().get(LogFactory.CONF_LOG_PATH),LogFactory.getAttemptId(context.getConfiguration(),true), WorkerExecutorReducer.class) ;
		//log.setLevel(Logger.Level.DEBUG);
		
		Metadata metadata = null ;
		Path[] uris = null ;
		try {
			uris = DistributedCache.getLocalCacheFiles(context
					.getConfiguration());
			String metadataFile = uris[0].toString();
			log.info("Metadata file path :"+metadataFile);
			metadata = MetadataParser.marshallMetadata(new File(metadataFile));
		} catch (ZebraServiceException e) {
			throw new ZebraMRBatchException(ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION , e);
		}catch (IOException e) {
			throw new ZebraMRBatchException("Error in reading MD file :"+ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION , e);
		}
		
		workerList = WorkerFactory.getWorkerList((TaskInputOutputContext) context, metadata, true);
		//log.info("WorkerList Created :"+workerList);
		//executor = new CommandExecutor(true);
		
	}
	
	@Override
    public void reduce(ZCustomKey key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
    	/*
    	executor.setKey(key.toString());
    	
    	for(Text value : values){

			executor.execute(value);
    	}
    	
		executor.flush(context);
    	 */
    	try{
    		List<Worker> selectedWorkers = new ArrayList<Worker>() ;
    	
    		for(Worker worker : workerList){
    			
    			if((worker.getLevel() == Level.valueOf(key.getLevel().toString()))
    					&& (worker.getWorkerId().equals(key.getWorkerId().toString()))){
    				if(log.isDebugEnabled()){
    					log.debug("Worker got selected ");
    				}
    				selectedWorkers.add(worker) ;
    				for(Text value : values){
    					worker.executeCommandAtReducer(key, value);

    				}
    			}
    		}
    		
    	/*	
    		for(Text value : values) {
    			for(Worker worker: selectedWorkers){
					worker.executeCommandAtReducer(key, value);

				}
    		}
    	*/
    		if(!selectedWorkers.isEmpty()){	
    			for(Worker selectedWorker : selectedWorkers){
    				selectedWorker.flushCommandAtReducer(key);
    			}
    		}else{
    			log.info("Worker not selected for key :"+key);
    		}
    		
    		
    		if(log.isDebugEnabled()){
    			log.info("Execution Finished for key : "+key.toString());
    		}
    	}catch( Exception e){
    		log.error("Unexpected exception occured ", e);
    		throw new ZebraMRBatchException("Unexpected exception occured " ,ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION, e);
    	}
   		
    }
	
    @Override
    public void cleanup(Context contex) throws IOException, InterruptedException{
    	for(Worker worker: workerList){
    		worker.cleanup();
    	}
    }
}
