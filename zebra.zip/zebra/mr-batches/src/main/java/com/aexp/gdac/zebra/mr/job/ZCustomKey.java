package com.aexp.gdac.zebra.mr.job;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public class ZCustomKey implements WritableComparable {
	/* Level and WorkerId is used for deciding hash code , so that all mapper output for a column 
	 * should go to a single reducer. This is required for effective stats generation */
	private Text level = new Text();
	private Text workerId = new Text();
	
	/* properties used at command level*/
	private Text ruleId = new Text();
	private Text columnRuleId = new Text();
	
	@Override
	public void readFields(DataInput in) throws IOException {
		
		level.readFields(in);
		workerId.readFields(in);
		ruleId.readFields(in);
		columnRuleId.readFields(in);
		
	}

	@Override
	public void write(DataOutput out) throws IOException {
		level.write(out);
		workerId.write(out);
		ruleId.write(out);
		columnRuleId.write(out);
		
	}

	@Override
	public int compareTo(Object o) {
		int result = 0; 
		if((result=(this.level.compareTo(((ZCustomKey)o).getLevel())))!=0){
			return result;
		}else if((result=(this.workerId.compareTo(((ZCustomKey)o).getWorkerId())))!=0){
			return result ;
		}else if((result=(this.ruleId.compareTo(((ZCustomKey)o).getRuleId())))!=0){
			return result ;
		}else if((result=(this.columnRuleId.compareTo(((ZCustomKey)o).getColumnRuleId())))!=0){
			return result;
		}
		
		return result;
	}

	@Override
	public int hashCode(){   
		return  workerId.hashCode()*163;// + level.hashCode() ;  
	} 
	
	@Override
	public boolean equals(Object o)   
	{     
		if(o instanceof ZCustomKey) {  
			ZCustomKey tp = (ZCustomKey) o;     
			return this.level.equals(tp.getLevel()) && this.workerId.equals(tp.getWorkerId())
					&& this.ruleId.equals(tp.getRuleId()) && this.columnRuleId.equals(tp.getColumnRuleId());    
		}   
		return false;   
	}
	
	public void set(ZCustomKey key){
		this.setLevel(key.getLevel());
		this.setWorkerId(key.getWorkerId());
		this.setRuleId(key.getRuleId());
		this.setColumnRuleId(key.getColumnRuleId());
	}
	
	public Text getLevel() {
		return level;
	}

	public void setLevel(Text level) {
		this.level.set(level);
	}
	
	public void setLevel(String level) {
		this.level.set(level);
	}
	
	public Text getWorkerId() {
		return workerId;
	}

	public void setWorkerId(Text workerId) {
		this.workerId.set(workerId);
	}

	public void setWorkerId(String workerId) {
		this.workerId.set(workerId);
	}
	
	public Text getColumnRuleId() {
		return columnRuleId;
	}

	public void setColumnRuleId(Text columnRuleId) {
		this.columnRuleId.set(columnRuleId);
	}
	
	public void setColumnRuleId(String columnRuleId) {
		this.columnRuleId.set(columnRuleId);
	}	
	public Text getRuleId() {
		return ruleId;
	}

	public void setRuleId(Text ruleId) {
		this.ruleId.set(ruleId);
	}

	public void setRuleId(String ruleId) {
		this.ruleId.set(ruleId);
	}

	@Override
	public String toString() {
		return "ZCustomKey [level=" + level + ", workerId=" + workerId
				+ ", ruleId=" + ruleId + ", columnRuleId=" + columnRuleId + "]";
	}
	
	
}
