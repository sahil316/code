package com.aexp.gdac.zebra.mr.job;

import java.io.IOException;

import javax.naming.Context;

import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

import com.aexp.gdac.zebra.mr.ZebraMRBatchException;

public abstract class ZCustomWrapperLineRecordReader extends LineRecordReader{
	/* This is called after RecordReader initialize is been call . */
	protected abstract void postRecordReaderInitialize( InputSplit genericSplit, TaskAttemptContext context) throws ZebraMRBatchException;
	
	/* This is called after RecordReader initialize is been call */
	protected abstract void postRecordRead() throws ZebraMRBatchException;
	protected abstract void postLastRecordRead() throws ZebraMRBatchException;
		
	
	@Override
	public void initialize(
	        InputSplit genericSplit, 
	        TaskAttemptContext context)
	        throws IOException {
		super.initialize(genericSplit, context);
		postRecordReaderInitialize(genericSplit,context);

	}
	
	@Override
	public boolean nextKeyValue() throws IOException {
		if(super.nextKeyValue()){
			postRecordRead();
			return true;
		}else{
			postLastRecordRead();
			return false;
		}
	}
}
