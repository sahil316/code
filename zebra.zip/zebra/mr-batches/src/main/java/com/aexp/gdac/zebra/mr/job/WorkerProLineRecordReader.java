package com.aexp.gdac.zebra.mr.job;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.ZebraServiceException;
import com.aexp.gdac.zebra.base.metadata.Metadata;
import com.aexp.gdac.zebra.base.metadata.MetadataParser;
import com.aexp.gdac.zebra.mr.ZebraCounters;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;
import com.aexp.gdac.zebra.mr.tools.Worker;
import com.aexp.gdac.zebra.mr.tools.WorkerFactory;

public class WorkerProLineRecordReader extends ZCustomWrapperLineRecordReader{
	//private CommandExecutor command ;
	private TaskAttemptContext context;
	private List<Worker> workerList ;
	private Logger log ;
	
	/* for header tailer check */
	private long lastSplitStartIndex ;
	private long fileLength ;
	/* for header tailer check */
	private static String columnDelimiter ;
	
	public static int expectedColumnCount ;

	public static long badRecordCount ;
	
	public static boolean headerExist ;
	public static boolean tailerExist ;
//	public static boolean couldBeTailFlag ;

	//public static Text possibleTailOrBadRecord   = new Text();
	
	
	public WorkerProLineRecordReader(long lastSplitStartIndex,long fileLength){
		this.lastSplitStartIndex = lastSplitStartIndex;
		this.fileLength = fileLength;
	}
	
	@Override
	protected void postRecordReaderInitialize(InputSplit genericSplit, TaskAttemptContext context) throws ZebraMRBatchException {
		this.context = context ;
		
		log = LogFactory.getLoggerInstance(context.getConfiguration().get(LogFactory.CONF_JOB_NAME)
				, context.getConfiguration().get(LogFactory.CONF_LOG_PATH),LogFactory.getAttemptId(context.getConfiguration(),false), WorkerProLineRecordReader.class) ;
		//log.setLevel(Logger.Level.DEBUG);
		
		// read metadata 
		Metadata metadata = null ;
		Path[] uris = null;
		try {
			uris = DistributedCache.getLocalCacheFiles(context
					.getConfiguration());
			String metadataFile = uris[0].toString();
			
			log.info("Metadata file path :"+metadataFile);
			metadata = MetadataParser.marshallMetadata(new File(metadataFile));
			
			//metadata = ZebraResourceManager.getMetadataParser().marshallMetadata(new File(metadataFile));
		} catch (ZebraServiceException e) {
			throw new ZebraMRBatchException(ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION , e);
		} catch (IOException e) {
			throw new ZebraMRBatchException("Error in reading MD file :"+ZebraMRBatchException.Reason.MR_EXCEPTION_AT_METADAT_CREATION , e);
		}
		
		expectedColumnCount = MetadataParser.columnCount ;
		// Generate worker list
		workerList = WorkerFactory.getWorkerList((TaskInputOutputContext) context, metadata, false);
		
		//get the column delimiter from feed worker
		columnDelimiter = workerList.get(0).getColumnDelimiter();
		//enable/disable check for header/tailer
		if(context.getConfiguration().get("zebra.header.present") != null && context.getConfiguration().get("zebra.header.present").length()>0){
			headerExist = Boolean.parseBoolean(context.getConfiguration().get("zebra.header.present"));
			
		}
		
		if(context.getConfiguration().get("zebra.tailer.present") != null && context.getConfiguration().get("zebra.tailer.present").length()>0){
			tailerExist = Boolean.parseBoolean(context.getConfiguration().get("zebra.tailer.present"));
			
		}
		//command = new CommandExecutor(false);
		//attemptContext = (Context)context;
		
		
	}

	@Override
	protected void postRecordRead()  throws ZebraMRBatchException{
		/*
		 * Set<String> keys = command.commandMap.keySet(); Iterator<String>
		 * iterator = keys.iterator(); while(iterator.hasNext()){
		 * command.setKey(iterator.next()); command.execute(getCurrentValue());
		 * }
		 */

		try {
			if(headerExist && isHeader()){
				log.info("Header found : " + getCurrentValue());
				return ;
			}else if(tailerExist && isFooter()){
				log.info("Tailer found : " + getCurrentValue());
				return ;
			}
		/*	if (headTailExist) {
				if (getCurrentKey().get() == 0) {
					log.info("Skipping Header : " + getCurrentValue());
					return;
				} else if (couldBeTailFlag) {
						couldBeTailFlag = false;
						possibleTailOrBadRecord.set("");

				}
				
			}
		*/	
			if(context.getConfiguration().get("zebra.job.badRecRejThreshold") != null && context.getConfiguration().get("zebra.job.badRecRejThreshold").length()>0){
				if((StringUtils.countMatches(getCurrentValue().toString(), columnDelimiter)) != expectedColumnCount-1 ){
					log.info("ZebraCounters.UNEXPECTED_RECORDS_COUNT in this split is:  "+((TaskInputOutputContext)context).getCounter(ZebraCounters.UNEXPECTED_RECORDS_COUNT).getValue());
					((TaskInputOutputContext)context).getCounter(ZebraCounters.UNEXPECTED_RECORDS_COUNT).increment(1);
				}
			}
			Worker.setRecordArr(null);
			for (Worker worker : workerList) {
				try{
					worker.executeCommandsAtMapper(getCurrentValue());
				} catch(ZebraMRBatchException zmrbe){
					if(ZebraMRBatchException.Reason.MR_BAD_RECORD_EXCEPTOIN == zmrbe.getReason()){
							if(worker.getLevel() == Level.COLUMN_LEVEL){	
								log.error("Bad Record detected "+getCurrentValue(), zmrbe);
							
								WorkerProLineRecordReader.badRecordCount ++;
								((TaskInputOutputContext)context).getCounter(ZebraCounters.BAD_RECORD_COUNT).increment(1);
							}
					}else{
						throw zmrbe;
					}
					
				}
			}
			//}
			
		} catch (Exception e) {
			log.error("Unexpected Error Caught at postRecordRead() reader ", e);
			throw new ZebraMRBatchException(
					ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION, e);
		}
		
	}

	@Override
	protected void postLastRecordRead() throws ZebraMRBatchException {
		try{
			/*
			 * Set<String> keys = command.commandMap.keySet(); Iterator<String>
			 * iterator = keys.iterator(); while(iterator.hasNext()){
			 * command.setKey(iterator.next()); command.flush(attemptContext); }
			 */
		/*	if (headTailExist) {
				if (couldBeTailFlag) {
					WorkerProLineRecordReader.badRecordCount -- ;
					log.info("Footer(Tail) found : " + possibleTailOrBadRecord);
				} else {
					log.info("Footer(Tail) not found ");
				}
			}*/

			for (Worker worker : workerList) {
				worker.flushCommandsAtMapper();
			}
			
		}catch(Exception e){
			log.error("Unexpected Error Caught at postLastRecordRead() reader ", e);
			throw new ZebraMRBatchException(ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION,e);
		}
	}
	
	private boolean isHeader(){
		if(this.getCurrentKey().get() == 0L){
			return true;
		}
		return false;
	}
	
	private boolean isFooter(){
		if(this.getCurrentKey().get() >= lastSplitStartIndex &&
				(this.getCurrentKey().get() + this.getCurrentValue().getLength() + 1) >= fileLength ){
			return true;
		}
		
		return false;

	}
	
	
	
}
