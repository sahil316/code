package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class MaxValueCommand extends Command{

	//private Logger log =  LogFactory.getLoggerInstance("MinMaxCount", "/idn/home/aatri1/output", MaxValueCommand.class) ;
	private Logger log =  LogFactory.getLoggerInstance(MaxValueCommand.class) ;
	
	private Double maxValue ;

	public MaxValueCommand(boolean isReducerPhase) {
		super(isReducerPhase);
		// TODO Auto-generated constructor stub
	}
	
	public void execute(Object o) throws ZebraMRBatchException{
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		try{
			if(maxValue == null){
				maxValue = Double.parseDouble(o.toString());
			}
		
			if(maxValue < Double.parseDouble(o.toString())){
				maxValue = Double.parseDouble(o.toString());
			}
		}catch(NumberFormatException nfe){
			log.debug(RuleCodeConstants.COMMAND_MAX_VALUE + " Input is not a number :" +o);
		}
	}
	
	public Object flush(Object o) throws ZebraMRBatchException{
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(((maxValue==null)?"NULL": maxValue.toString())));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: MaxValue Calculated From InputSplit "+maxValue);
				}
			}else if(isReducerPhase){
				if(log.isDebugEnabled()){
					log.debug("Reducer: MaxValue Calculated From Mapper Outputs "+maxValue);
				}
				
				return maxValue;
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" +RuleCodeConstants.COMMAND_MAX_VALUE , e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_MAX_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException Occured "+RuleCodeConstants.COMMAND_MAX_VALUE ,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_MAX_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}


	@Override
	public void setRuleId() {
		 ruleId = RuleCodeConstants.COMMAND_MAX_VALUE;
	}


}
