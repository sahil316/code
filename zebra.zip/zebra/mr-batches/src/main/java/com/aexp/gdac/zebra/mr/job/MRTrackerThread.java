package com.aexp.gdac.zebra.mr.job;

import org.apache.hadoop.mapreduce.Job;

import com.aexp.gdac.zebra.mr.ZebraCounters;

public class MRTrackerThread extends Thread {
	
	private Job itsJob;
	private long badRecRejectThreshold;
	private static final int THREAD_SLEEP_TIME = 1000;
	

	public MRTrackerThread() {
		// TODO Auto-generated constructor stub
	}
	public MRTrackerThread(Job theJob) {
		// TODO Auto-generated constructor stub
		itsJob = theJob;
	}
	
	public void setBadRecordRejectThreshold(long badRecRejectCount){
		badRecRejectThreshold = badRecRejectCount;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		try{
			while(!itsJob.isComplete()){
				this.sleep(THREAD_SLEEP_TIME);
				if(itsJob.getCounters().findCounter(ZebraCounters.UNEXPECTED_RECORDS_COUNT).getValue() > badRecRejectThreshold)
				{
					ZebraStatsGenDriver.setJobKilled(true);
					System.out.println("Current count of bad records : "+itsJob.getCounters().findCounter(ZebraCounters.UNEXPECTED_RECORDS_COUNT).getValue());
					System.out.println("Number of bad records are more than provided threshhold value. Rest of mapreduce job will not be proceed.");
					System.out.println("Terminating mapreduce process ....\n");   
					itsJob.killJob();
					
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
