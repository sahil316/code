package com.aexp.gdac.zebra.mr.tools;
/**
 * 
 * Level
 * Commands
 * 
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.TaskInputOutputContext;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

import com.aexp.gdac.zebra.base.Level;
import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.base.jdbc.dao.core.TableValueObjectBase;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnRuleStats;
import com.aexp.gdac.zebra.base.jdbc.model.ColumnStats;
import com.aexp.gdac.zebra.base.jdbc.model.FeedStats;
import com.aexp.gdac.zebra.base.metadata.MetadataRow;
import com.aexp.gdac.zebra.batches.StatsFileConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.command.Command;
import com.aexp.gdac.zebra.mr.job.ZCustomKey;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

/**
 * Workers are created  based on level and column . 
 * At each level(FEED_LEVEL,COLUMN_LEVEL,COLUMN_RULE_LEVEL) , for a particular column , a worker is instanciated .
 * This worker holds all the commands which must be executed for that column. 
 * @author aatri1
 *
 */
public class Worker {
	private Logger log =  LogFactory.getLoggerInstance(Worker.class) ;
	private TaskInputOutputContext context ;
	
	private static MultipleOutputs<Text, Text> mos;
	
	/* worker id must be columnId for COLUMN_LEVEL or COLUMN_RULE_LEVEL 
	 * worker id must be feedId for FEED_LEVEL
	 */
	private String workerId ;
	
	private String workerName ;
	
	/* LEVEL */
	private Level level;
	
	/* From MD **/
	private Long feedId;
	private Long stateId;
	private static String columnDelimiter ;
	
	private List<Command> commands = new ArrayList<Command>();
	
	private int commandsProcessedCount;
	
	private boolean isReducerPhase;
	
	/* Keeps stats state till all commands are executed at FEED_LEVL/COLUMN_LEVEL */
	TableValueObjectBase stats ;
	
	/* File format DELIMITED/FIXED params*/
	private boolean isfixed ;
	private int startPos ;
	private int endPos ;
	
	private static String[] recordArr;
	//this is index of record to be process by worker.
	private int recordIndex;

	/* constructor call for DELIMITER file format metadata*/
	public Worker(TaskInputOutputContext context,String workerId, String workerName,Level level, String columnDelimiter,boolean isReducerPhase,Long feedId, Long stateId){
		this.context = context;
		this.workerId = workerId;
		this.workerName = workerName;
		this.level = level;
		Worker.columnDelimiter = columnDelimiter;
		this.isReducerPhase = isReducerPhase;
		if(isReducerPhase){
			 mos = new MultipleOutputs(context);

		}
		this.feedId = feedId ;
		this.stateId = stateId ;
		
		this.isfixed = false ;
		
	}
	
	/* constructor call for FIXED file format metadata*/
	public Worker(TaskInputOutputContext context,String workerId, String workerName,Level level, String columnDelimiter,boolean isReducerPhase,Long feedId, Long stateId, int startPos, int endPos){
		this.context = context;
		this.workerId = workerId;
		this.workerName = workerName;
		this.level = level;
		Worker.columnDelimiter = columnDelimiter;
		this.isReducerPhase = isReducerPhase;
		if(isReducerPhase){
			 mos = new MultipleOutputs(context);

		}
		this.feedId = feedId ;
		this.stateId = stateId ;
		
		this.isfixed = true ;
		this.startPos = startPos ;
		this.endPos = endPos ;
		
	}
	
	public void executeCommandsAtMapper(Object o) throws ZebraMRBatchException{
		if(o == null){
			return ;
		}
		try{
			String record = o.toString();
			
			if(!isfixed){
				if(recordArr == null)
					recordArr = record.split(columnDelimiter);
			
				if(this.level == Level.FEED_LEVEL){
					executeCommands(record);
				}else if(this.level == Level.COLUMN_LEVEL){
					executeCommands(recordArr[recordIndex]);
				}else if(this.level == Level.COLUMN_RULE_LEVEL){
					executeCommands(recordArr[recordIndex]);
				}else if(this.level == Level.COLUMN_COMPLEX_RULE_LEVEL){
					executeCommands(recordArr[recordIndex]);
				}
			}else {
				
				
				if(this.level == Level.FEED_LEVEL){
					executeCommands(record);
				}else if(this.level == Level.COLUMN_LEVEL){
					String colRecord = record.substring(startPos,endPos);
					executeCommands(colRecord);
				}else if(this.level == Level.COLUMN_RULE_LEVEL){
					String colRecord = record.substring(startPos,endPos);
					executeCommands(colRecord);
				}else if(this.level == Level.COLUMN_COMPLEX_RULE_LEVEL){
					String colRecord = record.substring(startPos,endPos);
					executeCommands(colRecord);
				}
			}
			
		}catch(ArrayIndexOutOfBoundsException aiob){
			throw new ZebraMRBatchException("Record:["+o+"], Column["+workerId+"]",ZebraMRBatchException.Reason.MR_BAD_RECORD_EXCEPTOIN ,aiob);
		}catch(java.lang.StringIndexOutOfBoundsException siob){
			throw new ZebraMRBatchException("Record:["+o+"], Column["+workerId+"]",ZebraMRBatchException.Reason.MR_BAD_RECORD_EXCEPTOIN ,siob);
		}
		
	}
		
	public void executeCommands(Object o) throws ZebraMRBatchException {
		for(Command command : commands){
			command.execute(o);
		}
	}
	
	public void executeCommandAtReducer(ZCustomKey key, Object o) throws ZebraMRBatchException {
		
		for(Command command : commands){
			if(key.getRuleId().toString().equals(command.getRuleId()) &&
					key.getColumnRuleId().toString().equals(command.getColumnRuleId())){
				command.execute(o);
				break ;
			}
		}
	}

	public void flushCommandsAtMapper() throws ZebraMRBatchException{
		ZCustomKey key = new ZCustomKey();
		key.setLevel(this.level.name());
		key.setWorkerId(this.workerId);
		
		for(Command command : commands){
			command.setCommandKey(key);
			command.updateKey();
			
			command.flush(context);
		}
	}
	
	public void flushCommandAtReducer(ZCustomKey key) throws ZebraMRBatchException {
		/* used at FEED_LEVEL and COLUMN_LEVEL */

		try {
			for (Command command : commands) {

				if (this.level == Level.FEED_LEVEL) {
					if (stats == null) {
						stats = new FeedStats();
					}
					((FeedStats) stats).setFeedID(this.feedId);
					((FeedStats) stats).setStateID(this.stateId);
					if (RuleCodeConstants.COMMAND_RECORD_COUNT.equals(key.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {

						((FeedStats) stats).setVolume((Long) command
								.flush(context));
						commandsProcessedCount++;
					}

					if (commandsProcessedCount == commands.size()) {
						/* write data to disk */
						//context.write(new Text("FEED_LEVEL"), new Text(((FeedStats) stats).toString()));
						
						
						/** get metadata row from metadata **/
						MetadataRow mdRow = WorkerFactory.metadata.getFeedLevelMetadata();

						/** set carry forward details */
						
						((FeedStats) stats).setMaxAlertThreshold(mdRow.getMaxAlertThreshold());
						((FeedStats) stats).setMaxAbortThreshold(mdRow.getMaxAbortThreshold());
						((FeedStats) stats).setMinAbortThreshold(mdRow.getMinAbortThreshold());
						((FeedStats) stats).setMinAlertThreshold(mdRow.getMinAlertThreshold());
						((FeedStats) stats).setPastRuns(mdRow.getPastRun());
						((FeedStats) stats).setThresholdType(mdRow.getThresholdType());
						
						mos.write(StatsFileConstants.MR_OUT_FEED_LEVEL_FILE_NAME,NullWritable.get(), new Text(((FeedStats) stats).toString()));

						commandsProcessedCount = 0;
						stats = null;

						break;
					}

				} else if (this.level == Level.COLUMN_LEVEL) {
					if (stats == null) {
						stats = new ColumnStats();
					}

					((ColumnStats) stats).setFeedID(this.feedId);
					((ColumnStats) stats).setStateID(this.stateId);
					((ColumnStats) stats).setColumnID(Long
							.parseLong(this.workerId));
					((ColumnStats) stats).setColumnName(this.workerName);
					((ColumnStats) stats).setLevel(this.level.name());
					
					if (RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setCountDistinctvalues((Long) command
								.flush(context));
						commandsProcessedCount++;
					} else if (RuleCodeConstants.COMMAND_NULL_COUNT.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setCountNullValues((Long) command
								.flush(context));
						commandsProcessedCount++;
					} else if (RuleCodeConstants.COMMAND_AVERAGE_VALUE.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setAverage(( command.flush(context) == null)?null :command
								.flush(context).toString());
						commandsProcessedCount++;
					} else if (RuleCodeConstants.COMMAND_RECORD_COUNT.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setRecordCount(( command.flush(context) == null)?null :(Long) command
								.flush(context));
						commandsProcessedCount++;
					} else if (RuleCodeConstants.COMMAND_MIN_VALUE.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setMinValue(( command.flush(context) == null)?null :command
								.flush(context).toString());
						commandsProcessedCount++;
					} else if (RuleCodeConstants.COMMAND_MAX_VALUE.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						//log.debug("Flushed Max Value : "+command.flush(context));
						((ColumnStats) stats).setMaxValue(( command.flush(context) == null)? null :command
								.flush(context).toString());
						commandsProcessedCount++;
					}else if (RuleCodeConstants.COMMAND_DATA_TYPE_CHECK.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setDataTypeHit((( command.flush(context) == null)? null :(Long) command
								.flush(context)));
						commandsProcessedCount++;
					}

					if (commandsProcessedCount == commands.size()) {

						/* write data to disk */
						//context.write("COLUMN_STATS",((ColumnStats) stats).toString());
						mos.write(StatsFileConstants.MR_OUT_COLUMN_LEVEL_FILE_NAME,NullWritable.get(), new Text(((ColumnStats) stats).toString()));
						commandsProcessedCount = 0;
						stats = null;
						break;
					}

				} else if (this.level == Level.COLUMN_RULE_LEVEL) {
					if (key.getRuleId().toString().equals(command.getRuleId())
							&& (key.getColumnRuleId().toString().equals(command
									.getColumnRuleId()))) {
						ColumnRuleStats columnRuleStatVO = new ColumnRuleStats();

						columnRuleStatVO.setFeedID(this.feedId);
						columnRuleStatVO.setStateID(this.stateId);
						columnRuleStatVO.setRuleID(Long.parseLong(command.getRuleId()));
						columnRuleStatVO.setColumnID(Long
								.parseLong(this.workerId));
						columnRuleStatVO.setColumnRuleID(Long.parseLong(command
								.getColumnRuleId()));
						columnRuleStatVO.setValue(command.flush(context));
						
						/** get metadata row from metadata **/
						MetadataRow mdRow = WorkerFactory.metadata.getColumnRuleLevelMetadata(Long.parseLong(this.workerId), Long.parseLong(command.getRuleId()), Long.parseLong(command.getColumnRuleId()));
						
						/** set carry forward details */
						
						columnRuleStatVO.setMaxAlertThreshold(mdRow.getMaxAlertThreshold());
						columnRuleStatVO.setMaxAbortThreshold(mdRow.getMaxAbortThreshold());
						columnRuleStatVO.setMinAbortThreshold(mdRow.getMinAbortThreshold());
						columnRuleStatVO.setMinAlertThreshold(mdRow.getMinAlertThreshold());;
						columnRuleStatVO.setPastRuns(mdRow.getPastRun());
						columnRuleStatVO.setThresholdType(mdRow.getThresholdType());
						
						/* write stats here */
						//context.write("COLUMN_RULE_STATS",columnRuleStatVO.toString());
						mos.write(StatsFileConstants.MR_OUT_COLUMN_RULE_LEVEL_FILE_NAME,NullWritable.get(), new Text(columnRuleStatVO.toString()));
						break;
					}

				} else if (this.level == Level.COLUMN_COMPLEX_RULE_LEVEL) {
					if (stats == null) {
						stats = new ColumnStats();
					}
					
					Object value = command.flush(context) ;
					
					/* column rule stats*/
					if (key.getRuleId().toString().equals(command.getRuleId())) {
						
						
						/** get metadata row from metadata **/
						MetadataRow mdRow = WorkerFactory.metadata.getColumnRuleLevelMetadata(Long.parseLong(this.workerId), Long.parseLong(command.getRuleId()), Long.parseLong(command.getColumnRuleId()));
						
						/** set carry forward details */
						if(mdRow!=null){
							
							ColumnRuleStats columnRuleStatVO = new ColumnRuleStats();

							columnRuleStatVO.setFeedID(this.feedId);
							columnRuleStatVO.setStateID(this.stateId);
							columnRuleStatVO.setRuleID(Long.parseLong(command.getRuleId()));
							columnRuleStatVO.setColumnID(Long
									.parseLong(this.workerId));
							columnRuleStatVO.setColumnRuleID(Long.parseLong(command
									.getColumnRuleId()));
							columnRuleStatVO.setValue(value);
							
							columnRuleStatVO.setMaxAlertThreshold(mdRow.getMaxAlertThreshold());
							columnRuleStatVO.setMaxAbortThreshold(mdRow.getMaxAbortThreshold());
							columnRuleStatVO.setMinAbortThreshold(mdRow.getMinAbortThreshold());
							columnRuleStatVO.setMinAlertThreshold(mdRow.getMinAlertThreshold());;
							columnRuleStatVO.setPastRuns(mdRow.getPastRun());
							columnRuleStatVO.setThresholdType(mdRow.getThresholdType());
							
							//log.info("CCRL Rule Flush: WorkerId["+this.workerId+"], HitCount ["+value+"]");
							/* write stats here */
							//context.write("COLUMN_RULE_STATS",columnRuleStatVO.toString());
							mos.write(StatsFileConstants.MR_OUT_COMPLEX_COLUMN_RULE_LEVEL_FILE_NAME,NullWritable.get(), new Text(columnRuleStatVO.toString()));
						}
						
					}
					
					
					/* column stats */
					((ColumnStats) stats).setFeedID(this.feedId);
					((ColumnStats) stats).setStateID(this.stateId);
					((ColumnStats) stats).setColumnID(Long
							.parseLong(this.workerId));
					((ColumnStats) stats).setColumnName(this.workerName);
					((ColumnStats) stats).setLevel(this.level.name());
					
					if (RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT.equals(key
							.getRuleId().toString())
							&& (key.getRuleId().toString().equals(command.getRuleId()))) {
						((ColumnStats) stats).setCountDistinctvalues((Long)value);
						commandsProcessedCount++;
					}
					
					
					if (commandsProcessedCount == commands.size()) {
						//log.info("CCRL Column Flush: WorkerId["+this.workerId+"], HitCount ["+value+"]");
						/* write data to disk */
						//context.write("COLUMN_STATS",((ColumnStats) stats).toString());
						mos.write(StatsFileConstants.MR_OUT_COMPLEX_COLUMN_LEVEL_FILE_NAME,NullWritable.get(), new Text(((ColumnStats) stats).toString()));
						commandsProcessedCount = 0;
						stats = null;
						break ;
					}
				}
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured :"
					+ key, e);
			throw new ZebraMRBatchException(
					 " Failed!: "+ key,
					ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION, e);
		} catch (IOException ioe) {
			log.error("IO exception :" + key,
					ioe);
			throw new ZebraMRBatchException(
					 " Failed!: "+ key,
					ZebraMRBatchException.Reason.MR_IOEXCEPTION, ioe);
		}

	}
	
	
   
    public void cleanup() throws IOException, InterruptedException {
    	if(mos != null){
    		mos.close();
    	}
    }

	
	
	public void addCommand(Command command){
		commands.add(command);
	}

	/**  getters and setters **/
	public TaskInputOutputContext getContext() {
		return context;
	}

	public void setContext(TaskInputOutputContext context) {
		this.context = context;
	}

	public String getWorkerId() {
		return workerId;
	}

	public void setWorkerId(String workerId) {
		this.workerId = workerId;
	}

	
	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public Level getLevel() {
		return level;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public List<Command> getCommands() {
		return commands;
	}

	public void setCommands(List<Command> commands) {
		this.commands = commands;
	}

	public static String getColumnDelimiter() {
		return columnDelimiter;
	}

	public static void setColumnDelimiter(String columnDelimiter) {
		Worker.columnDelimiter = columnDelimiter;
	}

	
	public boolean isFixed() {
		return isfixed;
	}

	public void setIsfixed(boolean isfixed) {
		this.isfixed = isfixed;
	}

	public boolean isReducerPhase() {
		return isReducerPhase;
	}

	public void setReducerPhase(boolean isReducerPhase) {
		this.isReducerPhase = isReducerPhase;
	}
	
	public static String[] getRecordArr() {
		return recordArr;
	}

	public static void setRecordArr(String[] recordArr) {
		Worker.recordArr = recordArr;
	}

	public int getRecordIndex() {
		return recordIndex;
	}

	public void setRecordIndex(int recordIndex) {
		this.recordIndex = recordIndex;
	}


	@Override
	public String toString() {
		return "Worker [workerId=" + workerId + ", level=" + level
				+ ", commands=" + commands + "]";
	}
	
	
}
