package com.aexp.gdac.zebra.mr.command;
/**
 * Feed/Column Level rules execution instances contract
 */

import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.job.ZCustomKey;

public abstract class Command {
	
	
	protected String columnRuleId = "1";
	/* Must be set for every command */
	protected String ruleId = "";
	protected ZCustomKey commandKey =  new ZCustomKey();
	protected boolean isReducerPhase ;
	
	public Command(boolean isReducerPhase){
		this.isReducerPhase = isReducerPhase;
		setRuleId();
	}
	
	/* computation logic must be defined in execute method . It is called in mapper as well as in reducer */
	public abstract void execute(Object o) throws ZebraMRBatchException;

	/* Command must override flush . flush implementation must write(at Mapper) or return (generally at Reducer)
	 *  final output of the command */
	public abstract Object flush(Object o) throws ZebraMRBatchException;
    
	/* Ever command class must set a unique rule id **/
	public abstract void setRuleId();
	
    public ZCustomKey getCommandKey() {
		return commandKey;
	}

	@Override
	public String toString() {
		return "Command [columnRuleId=" + columnRuleId + ", ruleId=" + ruleId
				+ "]";
	}

	public void setCommandKey(ZCustomKey commandKey) {
		this.commandKey.set(commandKey);
	}

	public void setColumnRuleId(String columnRuleId){
    	this.columnRuleId = columnRuleId ;
    	this.commandKey.setColumnRuleId(columnRuleId);
    }
	public String getColumnRuleId(){
		return  ((columnRuleId==null)?"1":columnRuleId);
    }    

    
    public  String getRuleId(){
    	return ruleId ;
    }
    
    public void setReducerPhase(boolean isReducerPhase){
    	this.isReducerPhase = isReducerPhase;
    }
    
    public void updateKey(){
    	commandKey.setColumnRuleId(columnRuleId);
    	commandKey.setRuleId(ruleId);
    }
}
