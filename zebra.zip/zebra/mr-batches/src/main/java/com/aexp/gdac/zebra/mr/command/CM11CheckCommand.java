package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class CM11CheckCommand extends Command{
	/*
	 * cm11_check is equivalent to rule_code VR22. The CM 11 Card Number Check
	 * is a business rule which verifies that the Card Number is a possible Amex
	 * Card Number - it does verify that it is an issued Card Number. The
	 * current valid Card Numbers are between 34000000000 - 34999999999 and
	 * 37000000000 - 37999999999.
	 */
	
	
	private Logger log =  LogFactory.getLoggerInstance(CM11CheckCommand.class) ;
	
	public CM11CheckCommand(boolean isReducerPhase) {
		super(isReducerPhase);
		// TODO Auto-generated constructor stub
	}

	private long failCount ;
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		
				if(!isReducerPhase){
				
				try{
					long num = Long.parseLong(o.toString());
						if (((num >= 34000000000L) && (num <= 34999999999L))
							|| ((num >= 37000000000L) && (num <= 37999999999L))) {
					
						}else{
							failCount++;
						}
					}catch(NumberFormatException nfe){
					
						log.debug(RuleCodeConstants.COMMAND_CM11_CHECK + " Input is not a number :" +o);
						failCount ++;
					}
				}else{
					failCount = failCount + Long.parseLong(o.toString());
					
				}		
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(""+failCount));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: CM11 Check failCount Calculated From InputSplit "+failCount);
				}
			}else if(o instanceof org.apache.hadoop.mapreduce.Reducer.Context){
				if(log.isDebugEnabled()){
					log.debug("Reducer: CM11 Check failCount Calculated From Mapper Outputs "+failCount);
				}
				
				return new Long(failCount);
			}
			
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured" +RuleCodeConstants.COMMAND_CM11_CHECK , e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_CM11_CHECK + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		} catch (IOException ioe){
			log.error("IOException Occured "+RuleCodeConstants.COMMAND_CM11_CHECK ,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_CM11_CHECK + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	@Override
	public void setRuleId() {
		this.ruleId = RuleCodeConstants.COMMAND_CM11_CHECK ;
		
	}

}
