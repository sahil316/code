package com.aexp.gdac.zebra.mr.log;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LoggerImpl implements Logger {

	private static Level level ;
	private static String dirName ;
	private static String jobName ;
	
	private static DFSFilehandler fileHandler ;
	private static String hostName ;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
	private String className ;
	private static String taskAttemptId;
	
	public LoggerImpl(String jobName,String dirName, String taskAttemptId ,Class classzz) {
		if(LoggerImpl.level == null){
			LoggerImpl.level = Level.INFO ;
		}
		LoggerImpl.dirName = dirName;
		LoggerImpl.jobName = jobName;
		LoggerImpl.taskAttemptId = taskAttemptId;
		
		className = classzz.getCanonicalName();
		
		if(hostName == null){
			try {
				LoggerImpl.hostName = java.net.InetAddress.getLocalHost().getHostName();
			} catch (UnknownHostException uhe) {
				// do nothing 
			}
		}
		
		if(fileHandler==null){
			try {
				fileHandler = new DFSFilehandler(jobName,dirName,taskAttemptId);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public LoggerImpl(String jobName,String dirName,int replicationFactor, String taskAttemptId, Class classzz){

		if(LoggerImpl.level == null){
			LoggerImpl.level = Level.INFO ;
		}
		
		LoggerImpl.dirName = dirName;
		LoggerImpl.jobName = jobName;
		LoggerImpl.taskAttemptId = taskAttemptId;
		className = classzz.getCanonicalName();
		
		if(hostName == null){
			try {
				LoggerImpl.hostName = java.net.InetAddress.getLocalHost().getHostName();
			} catch (UnknownHostException uhe) {
				// do nothing 
			}
		}
		
		if(fileHandler==null){
			try {
				fileHandler = new DFSFilehandler(jobName,dirName,taskAttemptId,replicationFactor);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public LoggerImpl(Class classzz){
		if(LoggerImpl.level==null){
			LoggerImpl.level = Level.INFO;
		}

		className = classzz.getCanonicalName();
		if(hostName == null){
			try {
				LoggerImpl.hostName = java.net.InetAddress.getLocalHost().getHostName();
			} catch (UnknownHostException uhe) {
				// do nothing 
			}
		}
		
		if(fileHandler==null){
			try {
				fileHandler = new DFSFilehandler(jobName,dirName,taskAttemptId,1);
			} catch (IOException e) {
				//e.printStackTrace();
			}
		}
	}
	
	public LoggerImpl(Class classzz,int replicationFactor){
		if(LoggerImpl.level == null){
			LoggerImpl.level = Level.INFO;
		}
		className = classzz.getCanonicalName();
		if(hostName == null){
			try {
				LoggerImpl.hostName = java.net.InetAddress.getLocalHost().getHostName();
			} catch (UnknownHostException uhe) {
				// do nothing 
			}
		}
		if(fileHandler==null){
			try {
				fileHandler = new DFSFilehandler(jobName,dirName,taskAttemptId,replicationFactor);
			} catch (IOException e) {
			//	e.printStackTrace();
			}
		}
	}
	
	
	@Override
	public void info(String logStatement) {
		
			try {
				fileHandler.write(createLogStatement(logStatement,Level.INFO));
			} catch (IOException ioe) {
				// no action is taken 
			}
			
	}
	
	@Override
	public void error(String logStatement,Exception e) {

			try {
				fileHandler.writeError(createLogStatement(logStatement,Level.ERROR),e);
			} catch (IOException ioe) {
				// no action is taken 
			}
		
	}

	@Override
	public void debug(String logStatement) {
		if(Level.DEBUG == level){
			try {
				fileHandler.write(createLogStatement(logStatement,Level.DEBUG));
			} catch (IOException ioe) {
				// no action is taken 
			}
		}
		
	}
	
	private String createLogStatement(String userLogStatement,Level level ){
		return "["+LoggerImpl.hostName+" : "+ sdf.format(new Date())+"]["+level.name()+"] ["+className+"] "+userLogStatement+"\n";
	}
	
	
	public boolean isDebugEnabled(){
		if(Logger.Level.DEBUG == level){
			return true;
		}
			return false;
	}
	
	public boolean isInfoEnabled(){
		if(Logger.Level.INFO == level){
			return true;
		}
		return false;
	}
	
	public boolean isErrorEnabled(){
		if(Logger.Level.ERROR == level){
			return true;
		}
		return false;
	}
	
	
	public Level getLevel() {
		return level;
	}


	public void setLevel(Level level) {
		LoggerImpl.level = level;
	}

	
}
