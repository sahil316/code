package com.aexp.gdac.zebra.mr;

public enum ZebraCounters {

	BAD_RECORD_COUNT,
	UNEXPECTED_RECORDS_COUNT;
}
