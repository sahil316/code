package com.aexp.gdac.zebra.mr.tools;

import java.util.HashMap;
import java.util.Map;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.command.AverageCommand;
import com.aexp.gdac.zebra.mr.command.Command;
import com.aexp.gdac.zebra.mr.command.CountDistinctCommand;
import com.aexp.gdac.zebra.mr.command.MaxValueCommand;
import com.aexp.gdac.zebra.mr.command.MinValueCommand;
import com.aexp.gdac.zebra.mr.command.NullCountCommand;
import com.aexp.gdac.zebra.mr.command.RecordCountCommand;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;


public class CommandExecutor {
	//private Logger log =  LogFactory.getLoggerInstance("MinMaxCount", "/idn/home/aatri1/output", CommandExecutor.class) ;
	private Logger log =  LogFactory.getLoggerInstance(CommandExecutor.class) ;
	
	private boolean isReducePhase;
	private boolean isFixed ;
	private String key;
	public  Map<String,Command> commandMap = new HashMap<String,Command>();
	

	public CommandExecutor(boolean isReducePhase,boolean isFixed){
		this.isReducePhase = isReducePhase;
		this.isFixed = isFixed ;
		loadCommands(isReducePhase,isFixed);
	}
	
	
	private void loadCommands(boolean isReducePhase,boolean isFixed){
		commandMap.put(RuleCodeConstants.COMMAND_MIN_VALUE,new MinValueCommand(isReducePhase));
		commandMap.put(RuleCodeConstants.COMMAND_MAX_VALUE, new MaxValueCommand(isReducePhase));
		commandMap.put(RuleCodeConstants.COMMAND_AVERAGE_VALUE, new AverageCommand(isReducePhase));
		//commandMap.put(Constants.COMMAND_DISTINCT_VALUE, new DistinctCommand());
		commandMap.put(RuleCodeConstants.COMMAND_DISTINCT_VALUE_COUNT , new CountDistinctCommand(isReducePhase,isFixed));
		commandMap.put(RuleCodeConstants.COMMAND_NULL_COUNT, new NullCountCommand(isReducePhase,isFixed));
		commandMap.put(RuleCodeConstants.COMMAND_RECORD_COUNT, new RecordCountCommand(isReducePhase));
	}
	
	
	public void execute(Object o) throws ZebraMRBatchException {
		if(commandMap.containsKey(key))
				commandMap.get(key).execute(o);
		else
			log.debug("Requested Command Not Found :" + key);
	}
	

	public void flush(Object o) throws ZebraMRBatchException {
		if(commandMap.containsKey(key))
			commandMap.get(key).flush(o);
		else
			log.debug("Requested Command Not Found :" + key);
		
	}
	
	public String getKey() {
		return key;
	}
	
	public void setKey(String key) {
		this.key = key;
	}

	public boolean getIsReducePhase() {
		return isReducePhase;
	}

	public void setIsReducePhase(boolean isReducePhase) {
		this.isReducePhase = isReducePhase;
	}	
}
