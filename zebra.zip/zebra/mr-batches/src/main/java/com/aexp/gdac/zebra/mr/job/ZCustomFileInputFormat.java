package com.aexp.gdac.zebra.mr.job;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.io.LongWritable;

import com.aexp.gdac.zebra.mr.ZebraMRBatchException;

public class ZCustomFileInputFormat extends FileInputFormat<LongWritable,Text>{
	 
    @Override
    public RecordReader<LongWritable, Text> createRecordReader(
            InputSplit split, TaskAttemptContext context) throws IOException,
            InterruptedException {
        return new WorkerProLineRecordReader(lastSplitIndex(super.getSplits(context)),
        		inputFileSize((FileSplit)super.getSplits(context).get(0),context.getConfiguration()));
    }
    
    
    private long inputFileSize(FileSplit fileSplit ,Configuration conf){
    	long fileLength = 0L;
    	try {
    		
    		Path file = fileSplit.getPath();
			FileSystem fs = file.getFileSystem(conf);
			fileLength = fs.getFileStatus(file).getLen() ;
	
		} catch (IOException e) {
			throw new ZebraMRBatchException("Exception occured while geting file size",ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION,e);
		}

    	return fileLength;
    }
    
    
    private long lastSplitIndex(List<InputSplit> inputSplits){
    	if(inputSplits.size()<1){
    		throw new ZebraMRBatchException("No of splits lesser than 1 , check file and filesize",ZebraMRBatchException.Reason.UNEXPECTED_EXCEPTION);
    	}
    	
    	long lastSplitIndex = ((FileSplit)inputSplits.get(inputSplits.size()-1)).getStart();

    	for(InputSplit inputSplit : inputSplits){
    		FileSplit fileInputSplit = (FileSplit)inputSplit;
    		if(lastSplitIndex < fileInputSplit.getStart()){
    			lastSplitIndex = fileInputSplit.getStart();
    		}
    	}
    	
    	return lastSplitIndex;
    }
}
