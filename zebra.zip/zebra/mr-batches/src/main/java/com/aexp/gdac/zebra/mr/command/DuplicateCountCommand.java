package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class DuplicateCountCommand extends Command{


	private Logger log =  LogFactory.getLoggerInstance(CountDistinctCommand.class) ;
			
	//private Set<String> distinctSet = new HashSet<String>();
	//private boolean isFixed ;
	//private String emptyRecord;
	
	public DuplicateCountCommand(boolean isReducerPhase) {
		super(isReducerPhase);
	}
	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
		
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {

		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				IntWritable value = new IntWritable(0);
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey,new Text(""+(value)));
			}
			else if(isReducerPhase){
				return new Integer(0);
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured "+ RuleCodeConstants.COMMAND_DUPLICATE_VALUE_COUNT , e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DUPLICATE_VALUE_COUNT + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
		}catch(IOException ioe){
			log.error("IO exception "+RuleCodeConstants.COMMAND_DUPLICATE_VALUE_COUNT,ioe);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_DUPLICATE_VALUE_COUNT + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,ioe);
		}
		
		return null;
	}

	@Override
	public void setRuleId() {
		// TODO Auto-generated method stub
		 ruleId = RuleCodeConstants.COMMAND_DUPLICATE_VALUE_COUNT;
	}
	

	
}
