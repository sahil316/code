package com.aexp.gdac.zebra.mr.command;

import java.io.IOException;

import org.apache.hadoop.io.Text;

import com.aexp.gdac.zebra.base.RuleCodeConstants;
import com.aexp.gdac.zebra.mr.ZebraMRBatchException;
import com.aexp.gdac.zebra.mr.log.LogFactory;
import com.aexp.gdac.zebra.mr.log.Logger;

public class AverageCommand extends Command{

	private Logger log =  LogFactory.getLoggerInstance(AverageCommand.class) ;
	
	
	private double sum ;
	private double count = 0;

	public AverageCommand(boolean isReducerPhase) {
		super(isReducerPhase);

	}
	
	@Override
	public void execute(Object o) throws ZebraMRBatchException {
	
		if(o == null || o.toString().trim().isEmpty()){
			log.debug("Illegal record passed "+o);
			return ;
		}
		try{
			if(!isReducerPhase){
				sum  = sum + Double.parseDouble(o.toString());
				count ++ ;
			}else {
				String[] args = o.toString().split(":");
				sum  = sum + Double.parseDouble(args[0]);
				count = count + Double.parseDouble(args[1]) ;
			}
		}catch(NumberFormatException nfe){
			log.debug(RuleCodeConstants.COMMAND_AVERAGE_VALUE + " Input is not a number :" +o);
		}catch(Exception e){
			ZebraMRBatchException zmre = new ZebraMRBatchException("AVG COMMAND failed ",ZebraMRBatchException.Reason.MR_COMMAND_EXCEPTION,e);
			log.error("Unexpected Exception Occured", zmre);
			throw zmre;
		}
	
		
	}

	@Override
	public Object flush(Object o) throws ZebraMRBatchException {
		try {
			if(o instanceof org.apache.hadoop.mapreduce.Mapper.Context){
				((org.apache.hadoop.mapreduce.Mapper.Context)o).write(commandKey, new Text(sum +":"+ count));
				if(log.isDebugEnabled()){
					log.debug("Key:"+commandKey+ " Mapper: Sum:Count Calculated From InputSplit: "+(sum +":"+ count));
				}
			}else if(isReducerPhase){
				if(log.isDebugEnabled()){
					log.debug("Reducer: Average Calculated From Mapper Outputs "+(sum / count));
				}
				return ( (sum / count));
			}
		} catch (InterruptedException e) {
			log.error("Interrupted Exception Occured "+RuleCodeConstants.COMMAND_AVERAGE_VALUE , e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_AVERAGE_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_INTERRUPTED_EXCEPTION,e);
			
		} catch (IOException e) {
			log.error("IO Exception Occured "+RuleCodeConstants.COMMAND_AVERAGE_VALUE ,e);
			throw new ZebraMRBatchException(RuleCodeConstants.COMMAND_AVERAGE_VALUE + " Failed" ,ZebraMRBatchException.Reason.MR_IOEXCEPTION,e);
		}
		
		return null;
	}


	@Override
	public void setRuleId() {
		// TODO Auto-generated method stub
		 ruleId = RuleCodeConstants.COMMAND_AVERAGE_VALUE;
	}


	
	
}
