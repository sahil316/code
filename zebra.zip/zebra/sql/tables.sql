CREATE TABLE FeedMetadata (
 FeedID             bigint  NOT NULL,    
 FeedName           varchar(255) NOT NULL,
 Frequency          varchar(255)  ,
 FileFormat         varchar(10) NOT NULL check ( FileFormat in ('FIXED','DELIMITER')) ,  
 ColumnDelimiter    varchar(25) ,                       
 RecordDelimiter    varchar(25)  ,             
 Header             varchar(5)  check (Header in ('true','false')) ,                               
 Tailer             varchar(5)  check (Tailer in ('true','false')),                                
 MinAlertThreshold  decimal(15,3) ,          
 MinAbortThreshold  decimal(15,3) ,           
 MaxAlertThreshold  decimal(15,3) ,          
 MaxAbortThreshold  decimal(15,3) ,            
 ThresholdType      varchar(20) check (ThresholdType in ('Absolute','Percentage','StandardDeviation')),            
 PastRuns           int ,                   
 StartDate          datetime  NOT NULL ,
 EndDate            datetime   NOT NULL ,
 UserID             varchar(100) ,             
 EmailID            varchar(255) ,
 RGRP            	varchar(20)  ,   
 AGRP             	varchar(20)  ,
 TicketRobo 		varchar(5)  check (TicketRobo in ('true','false')),
 PRIMARY KEY  (FeedID,StartDate,EndDate)
) ;


CREATE TABLE ColumnMetadata (
 FeedID      bigint        NOT NULL ,   
 FeedName    varchar(255)  NOT NULL ,      
 ColumnID    int      	   NOT NULL ,  
 ColumnName  varchar(255)        ,
 DataType    varchar(255)        ,
 DataFormat  varchar(255)        ,
 StartDate   datetime      NOT NULL,    
 EndDate     datetime      NOT NULL ,   
 UserID      varchar(100)   ,
 PRIMARY KEY (FeedID,ColumnID,StartDate,EndDate)
 );
 
 
 CREATE TABLE ColumnRuleMetadata(
 FeedID             bigint                NOT NULL ,    
 ColumnID           int                   NOT NULL ,   
 RuleID             int                   NOT NULL ,    
 ColumnRuleID       int                   NOT NULL ,    
 RuleParameter      varchar(8000)                   ,                          
 PastRuns           int                            ,                      
 UserID             varchar(100)                   ,                           
 StartDate          datetime              NOT NULL ,    
 EndDate            datetime              NOT NULL ,    
 ThresholdType      varchar(20) CHECK (ThresholdType in ('Absolute','Percentage','StandardDeviation')),
 MinAlertThreshold  decimal(15,3)  ,
 MinAbortThreshold  decimal(15,3)  ,                                           
 MaxAlertThreshold  decimal(15,3)  ,                                          
 MaxAbortThreshold  decimal(15,3)  ,  
 PRIMARY KEY (FeedID,ColumnID,RuleID,StartDate,EndDate) 
 );

 
 CREATE TABLE Stats (
 StateID        bigint                NOT NULL   , 
 FeedID         bigint                NOT NULL   ,    
 FeedName       varchar(255)          NOT NULL   ,   
 InputFilePath  varchar(255)                 ,
 HeaderTailer   varchar(5) CHECK (HeaderTailer in ('true','false')) ,
 Action         varchar(10)                  ,
 ErrorMessage   varchar(100)                 ,
 RunDate        datetime                     ,
 ProcessDate    datetime                     ,
 UserID         varchar(100)                 ,
 ExecMode   	varchar(6) CHECK (ExecMode in ('AUTO','MANUAL')) ,
 Created        datetime					 ,
 OutputDirPath  varchar(255)                 ,
 PRIMARY KEY (StateID)
);

 CREATE TABLE FeedStats(
 FeedID                bigint     NOT NULL  ,
 Volume                bigint     NOT NULL  ,  
 MinAlertThresholdVal  decimal(15,3)        ,
 MinAbortThresholdVal  decimal(15,3)        ,
 MaxAlertThresholdVal  decimal(15,3)        ,
 MaxAbortThresholdVal  decimal(15,3)        ,
 Action                varchar(10)          ,
 StateID               bigint     NOT NULL  ,
 Mean                  decimal(15,3)        ,
 StdDev                decimal(15,3)   ,
 PRIMARY KEY (FeedID,StateID) 
);


CREATE TABLE ColumnStats (
 FeedID               bigint        NOT NULL,  
 ColumnID             int           NOT NULL,     
 DataTypeHit          bigint            ,
 CountDistinctvalues  bigint            ,
 CountNullValues      bigint            ,
 Average              varchar(255)      ,
 RecordCount          bigint            ,
 MinValue             varchar(255)      ,
 MaxValue             varchar(255)      ,
 Action               varchar(10)       ,
 StateID              bigint     NOT NULL,     
 ColumnName           varchar(255)   ,
 PRIMARY KEY (FeedID,ColumnID,StateID)
);

CREATE TABLE ColumnRuleStats(
 FeedID                bigint        NOT NULL,   
 ColumnID              int        NOT NULL, 
 RuleID                int        NOT NULL,   
 ColumnRuleID          int        NOT NULL,    
 DecisionCount         bigint            ,
 DecisionRate          decimal(4,3)          ,
 MinAlertThresholdVal  decimal(15,3)         ,
 MinAbortThresholdVal  decimal(15,3)         ,
 MaxAlertThresholdVal  decimal(15,3)         ,
 MaxAbortThresholdVal  decimal(15,3)         ,
 Action                varchar(10)           ,
 StateID               bigint     NOT NULL,     
 Mean                  decimal(15,3)   ,     
 StdDev                decimal(15,3)   ,
 PRIMARY KEY (FeedID,ColumnID,RuleID,ColumnRuleID,StateID) 
 );

 CREATE TABLE ZEBRA_LOGS(
 application_id varchar(20),
 log_entry  	varchar(8000),
 user_id		varchar(20),
 time_stamp 	datetime,
 StateID 		bigint
 );
 
CREATE TABLE SLAMetadata (
 FeedID      	bigint   NOT NULL ,
 FeedName    	varchar(255)  NOT NULL ,
 FeedFrequency  varchar(20) NOT NULL,
 DayOfWeek     	int CHECK (DayOfWeek between 1 and 7) ,
 DateOfMonth  	int CHECK (DateOfMonth between -1 and 31) , -- here -1 represents last date of current month
 MonthOfQuarter  int CHECK (MonthOfQuarter between 1 and 3) ,
 SkipDayOfWeek  int ,
 ExecTime       int,
 ElapseTime  	int,
 StartDate   	datetime  NOT NULL,
 EndDate     	datetime  NOT NULL ,
 UserID      	varchar(20)   ,
 PRIMARY KEY (FeedID,StartDate,EndDate)
 );
 
 
 CREATE TABLE SLAStats(
	FeedID  		bigint NOT NULL,  
	Status  		varchar(4) CHECK (Status in ('PASS','FAIL')),
	Message 		varchar(255) ,
	ExpectedTime 	datetime NOT NULL,
	CalculatedTime  datetime NOT NULL,
	Notified 		varchar(5) CHECK (Notified in ('true','false')),
	StateID 		bigint ,
	PRIMARY KEY 	(FeedID,ExpectedTime)
 );
 
CREATE SEQUENCE dbo.SEQ_ZEBRA_STAT
  AS BIGINT
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1
  MAXVALUE 99999999999999999
  CACHE 10;
  
  CREATE SEQUENCE dbo.SEQ_ZEBRA
  AS BIGINT
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1
  MAXVALUE 99999999999999999
  CACHE 10;